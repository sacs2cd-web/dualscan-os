/* Local settings shared by the popup, options page and isolated content script. */
(() => {
  'use strict';
  const DEFAULT_KEY = '0xd125A6515F5280cb424cBCe36BE8213C5C6db406';
  const STORAGE_KEY = 'typelockerSettings';
  const defaults = () => ({ version: 1, keys: [], selectedKeyId: 'default', enabled: true });

  function validate(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid key configuration.');
    if (value.version !== undefined && value.version !== 1) throw new Error('Unsupported configuration version.');
    if (!Array.isArray(value.keys)) throw new Error('The configuration must include a keys array.');
    const ids = new Set();
    const keys = value.keys.map(key => {
      if (!key || typeof key.id !== 'string' || !key.id || key.id === 'default' || ids.has(key.id)) throw new Error('Custom keys must have unique IDs.');
      if (typeof key.name !== 'string' || !key.name.trim()) throw new Error('Each key needs a name.');
      if (typeof key.value !== 'string' || !key.value.length) throw new Error('Each key needs a value.');
      ids.add(key.id);
      return { id: key.id, name: key.name.trim(), value: key.value };
    });
    const selectedKeyId = value.selectedKeyId ?? 'default';
    if (selectedKeyId !== 'default' && !ids.has(selectedKeyId)) throw new Error('The selected key is missing.');
    if (value.enabled !== undefined && typeof value.enabled !== 'boolean') throw new Error('Automatic decoding must be true or false.');
    return { version: 1, keys, selectedKeyId, enabled: value.enabled ?? true };
  }

  let mutationTail = Promise.resolve();
  const LOCK_NAME = 'typelocker-chat-local-settings';

  function serialized(action) {
    const run = () => {
      // Extension popup and options documents share an origin, and therefore
      // this lock. The promise chain also protects contexts without Web Locks.
      const locks = globalThis.navigator?.locks;
      return locks?.request ? locks.request(LOCK_NAME, { mode: 'exclusive' }, action) : action();
    };
    const result = mutationTail.then(run, run);
    mutationTail = result.catch(() => {});
    return result;
  }

  async function persist(value) {
    const settings = validate(value);
    await chrome.storage.local.set({ [STORAGE_KEY]: settings });
    return settings;
  }

  async function readStored() {
    return chrome.storage.local.get([STORAGE_KEY, 'defaultKey', 'additionalKeys', 'enabled']);
  }

  const hasLegacy = stored => ['defaultKey', 'additionalKeys', 'enabled'].some(key => stored[key] !== undefined);

  async function readLatest() {
    const stored = await readStored();
    if (stored[STORAGE_KEY]) return validate(stored[STORAGE_KEY]);
    // A content script reading fresh defaults must not overwrite a popup edit
    // with an unnecessary initialization write.
    if (!hasLegacy(stored)) return defaults();
    const settings = defaults();
    const oldKeys = [];
    if (typeof stored.defaultKey === 'string' && stored.defaultKey && stored.defaultKey !== DEFAULT_KEY) oldKeys.push(stored.defaultKey);
    if (Array.isArray(stored.additionalKeys)) oldKeys.push(...stored.additionalKeys.filter(key => typeof key === 'string' && key && key !== DEFAULT_KEY));
    settings.keys = [...new Set(oldKeys)].map((value, index) => ({ id: `migrated-${index + 1}`, name: index === 0 && value === stored.defaultKey ? 'Previous custom key' : `Imported key ${index + 1}`, value }));
    if (stored.defaultKey && stored.defaultKey !== DEFAULT_KEY && settings.keys.length) settings.selectedKeyId = settings.keys[0].id;
    settings.enabled = typeof stored.enabled === 'boolean' ? stored.enabled : true;
    // Called inside the mutation lock. Do not recursively call save().
    await persist(settings);
    await chrome.storage.local.remove(['defaultKey', 'additionalKeys', 'enabled']);
    return settings;
  }

  async function load() {
    const stored = await readStored();
    if (stored[STORAGE_KEY]) return validate(stored[STORAGE_KEY]);
    if (!hasLegacy(stored)) return defaults();
    // Re-read after acquiring the lock: a different extension document might
    // already have migrated or changed the configuration in the meantime.
    return serialized(readLatest);
  }

  function save(value) {
    // save() intentionally replaces the whole configuration (for import).
    // Copy and validate at invocation so a queued caller cannot change it.
    let next;
    try { next = validate(value); } catch (error) { return Promise.reject(error); }
    return serialized(() => persist(next));
  }

  function update(mutator) {
    if (typeof mutator !== 'function') return Promise.reject(new Error('A settings update function is required.'));
    return serialized(async () => {
      const latest = await readLatest();
      const result = await mutator(latest);
      return persist(result === undefined ? latest : result);
    });
  }

  function activeKey(settings) {
    return settings.keys.find(key => key.id === settings.selectedKeyId)?.value ?? DEFAULT_KEY;
  }

  globalThis.TypelockerSettings = Object.freeze({ DEFAULT_KEY, STORAGE_KEY, defaults, validate, load, save, update, activeKey });
})();
