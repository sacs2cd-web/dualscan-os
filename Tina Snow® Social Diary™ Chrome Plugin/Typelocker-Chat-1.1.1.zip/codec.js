/* BSK1 compatibility with supplied Typelocker_2026.html. Not cryptographic encryption. */
const BISHIKI_ALPHABET =
  "ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊ" + // runes
  "অআইঈউঊএঐওঔকখগঘঙচছজঝ" + // Bengali
  "ㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔ" + // Bopomofo
  "ϟϠϡϢϣϤϥϦϧϨϩϪϫϬϭϮ"; // Greek-ish symbols
// Ensure exactly 64 chars:
const ALPHA = Array.from(BISHIKI_ALPHABET).slice(0, 64);
const ALPHA_MAP = new Map(ALPHA.map((ch, i) => [ch, i]));


/** Utilities **/
const te = new TextEncoder();
const td = new TextDecoder("utf-8", {fatal:true});

function u32(x){ return x >>> 0; }

// FNV-1a 32-bit hash for key -> seed
function fnv1a32(str){
  let h = 0x811c9dc5;
  const bytes = te.encode(str);
  for (let i=0;i<bytes.length;i++){
    h ^= bytes[i];
    h = u32(Math.imul(h, 0x01000193));
  }
  return h;
}

// xorshift32 PRNG
function xorshift32(seed){
  let x = u32(seed || 0xA5A5A5A5);
  return function next(){
    x ^= (x << 13); x = u32(x);
    x ^= (x >>> 17); x = u32(x);
    x ^= (x << 5);  x = u32(x);
    return x;
  };
}

// Original BSK1 nonce generation. A random nonce does not make BSK1 secure encryption.
function randomNonce(){
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return u32(a[0]);
}

// Simple checksum of bytes (not crypto MAC; just integrity detection)
function checksum32(bytes){
  let h = 0x9747b28c; // mix seed
  for (let i=0;i<bytes.length;i++){
    h ^= bytes[i];
    h = u32(Math.imul(h, 0x5bd1e995));
    h ^= (h >>> 15);
  }
  return u32(h);
}

/**
 * Convert bytes -> 6-bit groups -> glyphs
 */
function bytesToGlyphs(bytes){
  let bits = 0, bitCount = 0;
  let out = [];
  for (let i=0;i<bytes.length;i++){
    bits = (bits << 8) | bytes[i];
    bitCount += 8;
    while (bitCount >= 6){
      const idx = (bits >>> (bitCount - 6)) & 0x3f;
      out.push(ALPHA[idx]);
      bitCount -= 6;
    }
  }
  // pad remaining bits with zeros, but store pad length implicitly by including raw byte length elsewhere (nonce + checksum detect)
  if (bitCount > 0){
    const idx = (bits << (6 - bitCount)) & 0x3f;
    out.push(ALPHA[idx]);
  }
  return out.join("");
}

/**
 * Convert glyphs -> 6-bit groups -> bytes
 */
function glyphsToBytes(glyphs){
  const chars = Array.from(glyphs).filter(ch => ALPHA_MAP.has(ch));
  let bits = 0, bitCount = 0;
  let out = [];
  for (const ch of chars){
    const v = ALPHA_MAP.get(ch);
    bits = (bits << 6) | v;
    bitCount += 6;
    while (bitCount >= 8){
      const b = (bits >>> (bitCount - 8)) & 0xff;
      out.push(b);
      bitCount -= 8;
    }
  }
  return new Uint8Array(out);
}

/**
 * Obfuscate/deobfuscate bytes with the original XOR keystream.
 * seed = hash(key) XOR nonce
 */
function applyKeystream(bytes, key, nonce){
  const seed = u32(fnv1a32(key) ^ nonce ^ 0xC0DEC0DE);
  const rnd = xorshift32(seed);
  const out = new Uint8Array(bytes.length);
  for (let i=0;i<bytes.length;i++){
    // Use high byte from PRNG word as keystream byte
    const ks = (rnd() >>> 24) & 0xff;
    out[i] = bytes[i] ^ ks;
  }
  return out;
}

/**
 * Encode plaintext -> Bishiki
 * Format: BSK1·[nonce_glyphs]·[payload_glyphs]·[check_glyphs]
 */
function encodeBishiki(plain, key){
  const nonce = randomNonce();
  const plainBytes = te.encode(plain);
  const cipherBytes = applyKeystream(plainBytes, key, nonce);

  // checksum over (nonce bytes + cipher bytes)
  const nonceBytes = new Uint8Array([
    (nonce >>> 24) & 0xff,
    (nonce >>> 16) & 0xff,
    (nonce >>>  8) & 0xff,
    (nonce >>>  0) & 0xff
  ]);
  const combo = new Uint8Array(nonceBytes.length + cipherBytes.length);
  combo.set(nonceBytes, 0);
  combo.set(cipherBytes, nonceBytes.length);
  const check = checksum32(combo);

  const nonceGlyphs = bytesToGlyphs(nonceBytes); // will be 6 glyphs (4 bytes -> 6*6=36 bits, last bits padded)
  const payloadGlyphs = bytesToGlyphs(cipherBytes);
  const checkBytes = new Uint8Array([
    (check >>> 24) & 0xff,
    (check >>> 16) & 0xff,
    (check >>>  8) & 0xff,
    (check >>>  0) & 0xff
  ]);
  const checkGlyphs = bytesToGlyphs(checkBytes);

  return `BSK1·${nonceGlyphs}·${payloadGlyphs}·${checkGlyphs}`;
}

/**
 * Decode Bishiki -> plaintext
 */
function decodeBishiki(bsk, key){
  const s = (bsk || "").trim();

  if (!s.startsWith("BSK1·")) {
    throw new Error("Missing BSK1 header. Paste full Bishiki text.");
  }
  const parts = s.split("·");
  if (parts.length !== 4) throw new Error("Invalid BSK1 format (expected four parts).");
  const [, nonceGlyphs, payloadGlyphs, checkGlyphs] = parts;
  if (nonceGlyphs.length !== 6 || checkGlyphs.length !== 6 ||
      ![...nonceGlyphs, ...payloadGlyphs, ...checkGlyphs].every(ch => ALPHA_MAP.has(ch))) {
    throw new Error("Invalid BSK1 glyphs or field lengths.");
  }

  const nonceBytesRaw = glyphsToBytes(nonceGlyphs);
  if (nonceBytesRaw.length < 4) throw new Error("Nonce too short / corrupted.");
  const nonceBytes = nonceBytesRaw.slice(0,4);
  const nonce =
    (nonceBytes[0] << 24) |
    (nonceBytes[1] << 16) |
    (nonceBytes[2] <<  8) |
    (nonceBytes[3] <<  0);

  const cipherBytes = glyphsToBytes(payloadGlyphs);

  const checkBytesRaw = glyphsToBytes(checkGlyphs);
  if (checkBytesRaw.length < 4) throw new Error("Checksum too short / corrupted.");
  const checkBytes = checkBytesRaw.slice(0,4);
  // Reject truncated streams and nonzero padding instead of silently discarding data.
  // Every message produced by the original encoder has this canonical form.
  if (bytesToGlyphs(nonceBytes) !== nonceGlyphs ||
      bytesToGlyphs(cipherBytes) !== payloadGlyphs ||
      bytesToGlyphs(checkBytes) !== checkGlyphs) {
    throw new Error("Invalid BSK1 padding or truncated glyph stream.");
  }
  const check =
    (checkBytes[0] << 24) |
    (checkBytes[1] << 16) |
    (checkBytes[2] <<  8) |
    (checkBytes[3] <<  0);

  // verify checksum
  const combo = new Uint8Array(4 + cipherBytes.length);
  combo.set(nonceBytes, 0);
  combo.set(cipherBytes, 4);
  const expected = checksum32(combo);

  if (u32(check) !== u32(expected)){
    throw new Error("Checksum mismatch. Corrupted Bishiki text.");
  }

  const plainBytes = applyKeystream(cipherBytes, key, u32(nonce));
  // BSK1 has no key authentication. Invalid UTF-8 can reveal some wrong keys,
  // but a wrong key that produces valid UTF-8 cannot be identified reliably.
  return td.decode(plainBytes);
}


