(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let settings;
  let encodedCache = null;
  const pending = new Set();
  const status = (text, error = false) => { $('status').textContent = text; $('status').classList.toggle('error', error); };
  const messageKey = () => $('key-override').value || TypelockerSettings.activeKey(settings);

  function renderKeys() {
    $('key-select').replaceChildren(new Option('Original default key', 'default'), ...settings.keys.map(key => new Option(key.name, key.id)));
    $('key-select').value = settings.selectedKeyId;
    $('key-select').disabled = false;
    $('delete-key').disabled = settings.selectedKeyId === 'default';
    for (const id of ['encode', 'decode', 'send', 'copy', 'save-key']) $(id).disabled = pending.has(id);
  }

  function makeEncoded() {
    const message = $('message').value;
    if (!message) throw new Error('Enter a message first.');
    const key = messageKey();
    if (!encodedCache || encodedCache.message !== message || encodedCache.key !== key) {
      encodedCache = { message, key, encoded: encodeBishiki(message, key), requestId: crypto.randomUUID() };
    }
    $('output').value = encodedCache.encoded;
    $('result-kind').textContent = '· BSK1';
    return encodedCache.encoded;
  }

  async function act(action) {
    try { await action(); } catch (error) { status(error.message || 'The action could not be completed.', true); }
  }

  async function exclusive(id, action) {
    // Guard as well as disabling the button: synthetic/native duplicate events
    // must not create a second insertion while the first request is pending.
    if (pending.has(id)) return;
    pending.add(id);
    $(id).disabled = true;
    try { await act(action); }
    finally { pending.delete(id); $(id).disabled = !settings; }
  }

  function invalidateOutput() {
    encodedCache = null;
    $('output').value = '';
    $('result-kind').textContent = '';
  }
  $('message').addEventListener('input', invalidateOutput);
  $('key-override').addEventListener('input', invalidateOutput);

  $('encode').addEventListener('click', () => act(() => { makeEncoded(); status('Encoded locally.'); }));
  $('decode').addEventListener('click', () => act(() => {
    try {
      const decoded = decodeBishiki($('message').value, messageKey());
      // BSK1 has no key authentication. Reject control-byte output as a likely wrong key.
      if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/u.test(decoded)) throw new Error('Invalid decoded text.');
      $('output').value = `${decoded} (Decoded with Typelocker™)`;
      $('result-kind').textContent = '· decoded';
      status('Decoded locally using the chosen key.');
    } catch (_) {
      $('output').value = 'Typelocker™ Private Content';
      $('result-kind').textContent = '· unavailable';
      status('Unable to decode. Check the key and complete BSK1 message.', true);
    }
  }));
  $('copy').addEventListener('click', () => exclusive('copy', async () => {
    await navigator.clipboard.writeText(makeEncoded());
    status('Encoded message copied.');
  }));
  $('send').addEventListener('click', () => exclusive('send', async () => {
    const encoded = makeEncoded();
    // The composition owns the request ID so a completed native duplicate click
    // or retry can also be recognized by the content script.
    const requestId = encodedCache.requestId;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No active website tab.');
    let result;
    try { result = await chrome.tabs.sendMessage(tab.id, { type: 'TYPELOCKER_INSERT', encoded, requestId }); }
    catch (_) { throw new Error('Open a supported website, refresh it, and select a text field. You can also copy the encoded message.'); }
    if (!result?.ok) throw new Error(result?.error || 'Select a compatible website text field first.');
    status('Inserted into the selected field. Publish or send from the website when ready.');
  }));
  $('key-select').addEventListener('change', () => {
    const selectedKeyId = $('key-select').value;
    act(async () => {
      settings = await TypelockerSettings.update(latest => ({ ...latest, selectedKeyId }));
      invalidateOutput();
      renderKeys();
      status('Selected key saved. Automatic decoding uses this key.');
    });
  });
  $('manage').addEventListener('click', () => { $('key-management').open = !$('key-management').open; });
  $('key-management').addEventListener('toggle', () => { $('manage').setAttribute('aria-expanded', String($('key-management').open)); });
  $('save-key').addEventListener('click', () => act(async () => {
    const name = $('key-name').value.trim();
    const value = $('key-override').value;
    if (!name || !value) throw new Error('Enter a key name and an override value to save.');
    const id = crypto.randomUUID();
    settings = await TypelockerSettings.update(latest => ({ ...latest, keys: [...latest.keys, { id, name, value }], selectedKeyId: id }));
    $('key-name').value = '';
    $('key-override').value = '';
    invalidateOutput();
    renderKeys();
    status('Custom key saved and selected.');
  }));
  $('delete-key').addEventListener('click', () => {
    const deletedId = $('key-select').value;
    if (deletedId === 'default') return;
    act(async () => {
      settings = await TypelockerSettings.update(latest => ({ ...latest, keys: latest.keys.filter(key => key.id !== deletedId), selectedKeyId: latest.selectedKeyId === deletedId ? 'default' : latest.selectedKeyId }));
      invalidateOutput();
      renderKeys();
      status('Custom key deleted.');
    });
  });
  $('settings').addEventListener('click', () => act(() => chrome.runtime.openOptionsPage()));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) act(async () => {
      settings = await TypelockerSettings.load();
      invalidateOutput();
      renderKeys();
    });
  });
  act(async () => { settings = await TypelockerSettings.load(); renderKeys(); });
})();
