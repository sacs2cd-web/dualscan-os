(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let settings;
  let pendingImport = null;
  const status = (text, error = false) => { $('status').textContent = text; $('status').classList.toggle('error', error); };
  async function act(action) { try { await action(); } catch (error) { status(error.message || 'Settings could not be saved.', true); } }
  function render() {
    $('key-select').replaceChildren(new Option('Original default key', 'default'), ...settings.keys.map(key => new Option(key.name, key.id)));
    $('key-select').value = settings.selectedKeyId;
    $('enabled').checked = settings.enabled;
    $('delete-key').disabled = settings.selectedKeyId === 'default';
    for (const id of ['key-select', 'enabled', 'add-key', 'import', 'export']) $(id).disabled = false;
  }
  async function update(mutator) { settings = await TypelockerSettings.update(mutator); render(); }
  $('enabled').addEventListener('change', () => {
    const enabled = $('enabled').checked;
    act(async () => {
      await update(latest => ({ ...latest, enabled }));
      status(enabled ? 'Automatic decoding enabled.' : 'Automatic decoding disabled. Original BSK1 messages are shown.');
    });
  });
  $('key-select').addEventListener('change', () => {
    const selectedKeyId = $('key-select').value;
    act(async () => { await update(latest => ({ ...latest, selectedKeyId })); status('Selected key saved.'); });
  });
  $('add-key-form').addEventListener('submit', event => {
    event.preventDefault();
    act(async () => {
      const name = $('key-name').value.trim();
      const value = $('key-value').value;
      if (!name || !value) throw new Error('Enter a key name and value.');
      const id = crypto.randomUUID();
      await update(latest => ({ ...latest, keys: [...latest.keys, { id, name, value }], selectedKeyId: id }));
      $('add-key-form').reset();
      status('Custom key saved and selected.');
    });
  });
  $('delete-key').addEventListener('click', () => {
    const deletedId = $('key-select').value;
    if (deletedId === 'default') return;
    act(async () => {
      await update(latest => ({ ...latest, keys: latest.keys.filter(key => key.id !== deletedId), selectedKeyId: latest.selectedKeyId === deletedId ? 'default' : latest.selectedKeyId }));
      status('Custom key deleted.');
    });
  });
  $('export').addEventListener('click', () => act(() => {
    const blob = new Blob([JSON.stringify(settings, null, 2) + '\n'], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'typelocker-chat-keys.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    status('Configuration exported. The file contains readable key values.');
  }));
  $('import').addEventListener('click', () => { $('import-file').value = ''; $('import-file').click(); });
  $('import-file').addEventListener('change', () => act(async () => {
    const file = $('import-file').files[0];
    if (!file) return;
    pendingImport = null;
    $('import-preview').hidden = true;
    // Storage has a browser-managed quota; avoid reading unbounded files into the options page.
    const quota = chrome.storage.local.QUOTA_BYTES || 10 * 1024 * 1024;
    if (file.size > quota) throw new Error('This configuration file exceeds Chrome’s local settings quota.');
    let parsed;
    try { parsed = JSON.parse(await file.text()); } catch (_) { throw new Error('Choose a valid JSON configuration file.'); }
    pendingImport = TypelockerSettings.validate(parsed);
    $('import-summary').textContent = `Ready to import ${pendingImport.keys.length} custom key(s). This will replace your current keys and settings.`;
    $('import-preview').hidden = false;
    status('Review the import, then choose Replace configuration.');
  }));
  $('confirm-import').addEventListener('click', () => act(async () => {
    if (!pendingImport) return;
    settings = await TypelockerSettings.save(pendingImport);
    pendingImport = null;
    $('import-preview').hidden = true;
    render();
    status('Configuration imported and saved locally.');
  }));
  $('cancel-import').addEventListener('click', () => { pendingImport = null; $('import-preview').hidden = true; status('Import cancelled.'); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) act(async () => { settings = await TypelockerSettings.load(); render(); });
  });
  act(async () => { settings = await TypelockerSettings.load(); render(); });
})();
