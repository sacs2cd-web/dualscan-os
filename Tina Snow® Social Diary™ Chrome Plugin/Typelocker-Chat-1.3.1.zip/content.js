/* Typelocker™ Chat — local page display and explicitly requested insertion. */
(() => {
  'use strict';

  // Keep a reinjected script from registering a second insertion listener.
  if (globalThis.__typelockerContentLoaded) return;
  globalThis.__typelockerContentLoaded = true;

  const MARKER = 'data-typelocker-rendered';
  const SKIP = 'script,style,noscript,template,textarea,input,select,option';
  const glyphClass = ALPHA.join('');
  const canonicalToken = new RegExp(`^BSK1·[${glyphClass}]{6}·[${glyphClass}]*·[${glyphClass}]{6}$`, 'u');
  // The fallback also marks truncated or damaged BSK1-prefixed strings as private.
  const candidateToken = new RegExp(`BSK1·[^\\s·]*·[^\\s·]*·[^\\s·]{0,6}(?![${glyphClass}])|BSK1·[^\\s]*`, 'gu');
  const originalTokens = new WeakMap();
  const originalParts = new WeakMap();
  const blockTags = new Set('ADDRESS ARTICLE ASIDE BLOCKQUOTE CAPTION DD DETAILS DIALOG DIV DL DT FIELDSET FIGCAPTION FIGURE FOOTER FORM H1 H2 H3 H4 H5 H6 HEADER HR LI MAIN NAV OL P PRE SECTION SUMMARY TABLE TBODY TD TFOOT TH THEAD TR UL'.split(' '));
  const completeToken = new RegExp(`BSK1·[${glyphClass}]{6}·[${glyphClass}]*·[${glyphClass}]{6}`, 'gu');
  const insertionReceipts = new WeakMap();
  const rendered = new Set();
  const pendingRoots = new Set();
  let settings = null;
  let settingsRevision = 0;
  let scanTimer = null;
  let expiryTimer = null;
  let lastEditor = null;
  let lastRange = null;
  let lastTextSelection = null;

  function editorFor(target) {
    if (!(target instanceof Element)) return null;
    if (target.matches('textarea,input')) {
      const supported = target instanceof HTMLTextAreaElement ||
        ['text', 'search'].includes(target.type);
      return supported && !target.disabled && !target.readOnly ? target : null;
    }
    if (!target.isContentEditable) return null;
    let editor = target;
    while (editor.parentElement?.isContentEditable) editor = editor.parentElement;
    return editor.getAttribute('aria-disabled') === 'true' ? null : editor;
  }

  function rangeInside(range, editor) {
    return editor.contains(range.startContainer) && editor.contains(range.endContainer);
  }

  function rememberSelection() {
    const editor = editorFor(document.activeElement);
    if (!editor) return;
    if (lastEditor !== editor) {
      lastRange = null;
      lastTextSelection = null;
    }
    lastEditor = editor;
    if (editor.isContentEditable) {
      const selection = document.getSelection();
      if (selection?.rangeCount && rangeInside(selection.getRangeAt(0), editor)) {
        lastRange = selection.getRangeAt(0).cloneRange();
      }
    } else {
      lastTextSelection = {
        start: editor.selectionStart ?? editor.value.length,
        end: editor.selectionEnd ?? editor.value.length
      };
    }
  }

  document.addEventListener('focusin', rememberSelection, true);
  document.addEventListener('selectionchange', rememberSelection, true);
  document.addEventListener('select', rememberSelection, true);
  document.addEventListener('input', rememberSelection, true);
  document.addEventListener('keyup', rememberSelection, true);
  document.addEventListener('pointerup', rememberSelection, true);

  const nextFrame = () => new Promise(resolve => requestAnimationFrame(resolve));
  const tokenCount = (text, token) => text.split(token).length - 1;

  function usesControlledPaste(editor) {
    return /(^|\.)(x|twitter)\.com$/i.test(location.hostname) || Boolean(editor.closest('.DraftEditor-root'));
  }

  async function insertControlledPaste(editor, encoded) {
    // Draft keeps a model selection. Let its onSelect observe the restored DOM range.
    await nextFrame();
    const selection = document.getSelection();
    if (!editor.isConnected || !selection?.rangeCount || !rangeInside(selection.getRangeAt(0), editor)) {
      throw new Error('The editor selection changed. Select the target field and try again.');
    }
    const expectedCount = tokenCount(editor.textContent, encoded) - tokenCount(selection.getRangeAt(0).toString(), encoded) + 1;
    const transfer = new DataTransfer();
    transfer.setData('text/plain', encoded);
    const paste = new ClipboardEvent('paste', { bubbles: true, cancelable: true, composed: true, clipboardData: transfer });
    // Synthetic paste has no browser default insertion and never reads the system clipboard.
    // The controlled editor must accept and apply this one event through its own model.
    editor.dispatchEvent(paste);
    if (!paste.defaultPrevented) {
      throw new Error('This editor did not accept insertion. Use Copy Encoded Message.');
    }
    await nextFrame();
    await nextFrame();
    if (!editor.isConnected || tokenCount(editor.textContent, encoded) !== expectedCount) {
      throw new Error('The editor could not confirm one insertion. Check the field and use Copy Encoded Message.');
    }
  }

  function insertEncoded(encoded, requestId) {
    if (typeof encoded !== 'string' || !canonicalToken.test(encoded)) {
      throw new Error('The message is not a complete BSK1 token. Encode it first.');
    }
    const activeEditor = editorFor(document.activeElement);
    if (activeEditor) rememberSelection();
    const editor = activeEditor || lastEditor;
    if (!editor?.isConnected || editorFor(editor) !== editor) {
      throw new Error('Click inside a compatible text field before opening Typelocker™ Chat.');
    }
    const receiptId = typeof requestId === 'string' && requestId.length > 0 && requestId.length <= 128 ? requestId : null;
    const receipts = insertionReceipts.get(editor) || new Map();
    const previous = receiptId && receipts.get(receiptId);
    if (previous) {
      if (!previous.pending) return;
      return previous.completion.then(outcome => {
        if (!outcome.ok) throw new Error(outcome.error);
      });
    }
    let complete;
    const receipt = receiptId ? { pending: true, completion: new Promise(resolve => { complete = resolve; }) } : null;
    if (receipt) {
      // Reserve before focus or event dispatch so reentrant and repeated messages share it.
      receipts.set(receiptId, receipt);
      insertionReceipts.set(editor, receipts);
    }
    const success = () => {
      if (receipt) {
        receipt.pending = false;
        complete({ ok: true });
        for (const [id, entry] of receipts) {
          if (receipts.size <= 64) break;
          if (!entry.pending) receipts.delete(id);
        }
      }
      rememberSelection();
      // Never click a site button or dispatch Enter, submit, or change events.
    };
    const failure = error => {
      if (receipt) {
        receipts.delete(receiptId);
        complete({ ok: false, error: error.message });
      }
      throw error;
    };
    try {
      const savedRange = lastEditor === editor && lastRange ? lastRange.cloneRange() : null;
      const savedTextSelection = lastEditor === editor ? lastTextSelection : null;
      editor.focus({ preventScroll: true });
      if (editor.isContentEditable) {
        const selection = document.getSelection();
        if (!selection) throw new Error('This editor does not expose a text selection. Use Copy Encoded Message.');
        const range = savedRange && rangeInside(savedRange, editor) ? savedRange : document.createRange();
        if (!savedRange || !rangeInside(savedRange, editor)) {
          range.selectNodeContents(editor);
          range.collapse(false);
        }
        selection.removeAllRanges();
        selection.addRange(range);
        if (usesControlledPaste(editor)) return insertControlledPaste(editor, encoded).then(success, failure);
        // Native editing preserves the undo buffer for generic rich text fields.
        if (!document.execCommand('insertText', false, encoded)) {
          throw new Error('This editor did not accept insertion. Use Copy Encoded Message.');
        }
      } else {
        const start = Math.min(savedTextSelection?.start ?? editor.value.length, editor.value.length);
        const end = Math.min(savedTextSelection?.end ?? start, editor.value.length);
        const before = new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: encoded
        });
        if (!editor.dispatchEvent(before)) throw new Error('The text field declined insertion. Use Copy Encoded Message.');
        const prototype = editor instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
        setter.call(editor, editor.value.slice(0, start) + encoded + editor.value.slice(end));
        editor.setSelectionRange(start + encoded.length, start + encoded.length);
        editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: encoded }));
      }
      success();
    } catch (error) {
      failure(error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.type === 'TYPELOCKER_REFRESH_SETTINGS') {
      refreshSettings().then(ok => reply({ ok, selectedKeyId: settings?.selectedKeyId, enabled: settings?.enabled }));
      return true;
    }
    if (message?.type !== 'TYPELOCKER_INSERT') return;
    try {
      const insertion = insertEncoded(message.encoded, message.requestId);
      if (insertion && typeof insertion.then === 'function') {
        insertion.then(() => reply({ ok: true }), error => reply({ ok: false, error: error.message }));
        // Promise-returning listeners are not available in the minimum supported Chrome.
        return true;
      }
      reply({ ok: true });
    } catch (error) {
      reply({ ok: false, error: error.message });
    }
  });

  function decodedText(token) {
    try {
      if (!canonicalToken.test(token)) return null;
      const parts = token.split('·');
      // Reject ignored characters or noncanonical padding without altering BSK1.
      if (parts.slice(1).some(part => bytesToGlyphs(glyphsToBytes(part)) !== part)) return null;
      const decoded = decodeBishiki(token, TypelockerSettings.activeKey(settings));
      // The original checksum cannot authenticate keys; reject unlikely control-byte output.
      if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/u.test(decoded)) return null;
      return decoded;
    } catch {
      return null;
    }
  }

  function renderToken(span, token) {
    const text = decodedText(token);
    span.textContent = text === null ? 'Typelocker™ Private Content' : `${text} (Decoded with Typelocker™)`;
    span.title = text === null ? 'Unable to decode with the selected key' : 'Decoded locally with the selected key';
    span.style.cssText = 'display:inline;white-space:pre-wrap;overflow-wrap:anywhere;background:rgba(83,104,230,.12);border-radius:4px;padding:1px 3px;';
  }

  function restoreToken(span) {
    const parents = new Set();
    const parts = originalParts.get(span);
    if (parts) {
      for (const part of parts) {
        if (!part.anchor.isConnected) continue;
        parents.add(part.anchor.parentNode);
        part.anchor.replaceWith(part.node);
      }
      // Only our text pieces were split. Keep every existing formatting
      // element/ID/listener and merge the adjacent text pieces on restoration.
      for (const parent of parents) parent.normalize();
    } else if (span.isConnected) span.replaceWith(document.createTextNode(originalTokens.get(span)));
    rendered.delete(span);
  }

  function excluded(node) {
    const parent = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return !parent || parent.isContentEditable || Boolean(parent.closest(`${SKIP},[${MARKER}],[contenteditable]:not([contenteditable="false"])`));
  }

  function blockBoundary(element) {
    if (blockTags.has(element.tagName)) return true;
    // A site can give an otherwise inline element a message/block layout.
    const display = getComputedStyle(element).display;
    return /^(block|flow-root|list-item|table(?:-.*)?|flex|grid)$/.test(display);
  }

  function scanScope(root) {
    let element = root?.nodeType === Node.TEXT_NODE ? root.parentElement : root;
    if (!(element instanceof Element) || !element.isConnected || excluded(element)) return null;
    while (element !== document.body && !blockBoundary(element) && element.parentElement) {
      element = element.parentElement;
      if (excluded(element)) return null;
    }
    return element;
  }

  function compactRun(text) {
    // Webmail may insert transport whitespace, soft hyphens or zero-width
    // breaks. Normalize only a candidate's carrier; the original codec and
    // checksum still validate the complete resulting BSK1 token.
    const chunks = [], cuts = [];
    const breaks = /[\s\u00AD\u200B\uFEFF]+/gu;
    let cursor = 0, removed = 0, match;
    while ((match = breaks.exec(text))) {
      chunks.push(text.slice(cursor, match.index));
      removed += match[0].length;
      cuts.push({ at: match.index - removed + match[0].length, removed });
      cursor = match.index + match[0].length;
    }
    chunks.push(text.slice(cursor));
    return {
      text: chunks.join(''),
      offset(index) {
        let low = 0, high = cuts.length;
        while (low < high) {
          const middle = (low + high) >>> 1;
          if (cuts[middle].at <= index) low = middle + 1;
          else high = middle;
        }
        return index + (low ? cuts[low - 1].removed : 0);
      }
    };
  }

  function renderRun(run) {
    const raw = run.text.join('');
    const compact = compactRun(raw);
    if (!compact.text.includes('BSK1·')) return;
    const matches = [];
    completeToken.lastIndex = 0;
    for (const match of compact.text.matchAll(completeToken)) {
      const start = compact.offset(match.index);
      const end = compact.offset(match.index + match[0].length - 1) + 1;
      // An immediate seventh checksum glyph is damaged data, not a shorter
      // valid message. Whitespace after a complete token belongs to its page.
      if (ALPHA_MAP.has(raw[end])) continue;
      matches.push({ start, end, token: match[0] });
    }
    candidateToken.lastIndex = 0;
    for (const match of raw.matchAll(candidateToken)) {
      const start = match.index, end = start + match[0].length;
      if (!matches.some(found => start < found.end && end > found.start)) {
        matches.push({ start, end, token: match[0] });
      }
    }
    // Replace individual source pieces, never their formatted ancestors.
    // extractContents() clones partial ancestors and would duplicate their IDs
    // and formatting whenever display is restored. Empty anchors retain each
    // actual text/break node's original position until it is restored.
    matches.sort((a, b) => b.start - a.start);
    for (const match of matches) {
      const pieces = run.nodes.filter(part => part.start < match.end && part.end > match.start);
      if (!pieces.length || pieces.some(part => !part.node.isConnected)) continue;
      const span = document.createElement('span');
      span.setAttribute(MARKER, '1');
      const originals = [];
      for (let index = pieces.length - 1; index >= 0; index--) {
        const part = pieces[index];
        let selected = part.node;
        if (selected.nodeType === Node.TEXT_NODE) {
          const start = Math.max(0, match.start - part.start);
          const end = Math.min(selected.nodeValue.length, match.end - part.start);
          if (end < selected.nodeValue.length) selected.splitText(end);
          if (start > 0) selected = selected.splitText(start);
        }
        const anchor = index === 0 ? span : document.createComment('typelocker-fragment');
        selected.replaceWith(anchor);
        originals.unshift({ anchor, node: selected });
      }
      originalTokens.set(span, match.token);
      originalParts.set(span, originals);
      renderToken(span, match.token);
      rendered.add(span);
    }
  }

  function scanRoot(root) {
    const scope = scanScope(root);
    if (!scope) return;
    // Reconstruct earlier private/decoded fragments before scanning this
    // message again. A webmail body may deliver its prefix before its tail.
    for (const span of rendered) {
      if (span.isConnected && scope.contains(span)) {
        restoreToken(span);
      }
    }
    let run = { scope, text: [], nodes: [], length: 0 };
    const runs = [];
    const flush = () => {
      if (run.nodes.length) runs.push(run);
      run = { scope, text: [], nodes: [], length: 0 };
    };
    const append = (text, node = null) => {
      if (!text) return;
      if (node) run.nodes.push({ node, start: run.length, end: run.length + text.length });
      run.text.push(text);
      run.length += text.length;
    };
    const visit = (node, top = false) => {
      if (node.nodeType === Node.TEXT_NODE) { append(node.nodeValue, node); return; }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      if (excluded(node) || /^(IFRAME|IMG|VIDEO|AUDIO|CANVAS)$/.test(node.tagName)) { flush(); return; }
      if (node.tagName === 'BR') { append('\n', node); return; }
      if (node.tagName === 'WBR') { append('\u200B', node); return; }
      const boundary = !top && blockBoundary(node);
      if (boundary) flush();
      for (const child of node.childNodes) visit(child);
      if (boundary) flush();
    };
    visit(scope, true);
    flush();
    runs.forEach(renderRun);
  }

  function queueScan(root) {
    if (!settings?.enabled || !root) return;
    const scope = scanScope(root);
    if (!scope) return;
    pendingRoots.add(scope);
    if (scanTimer !== null) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      const roots = Array.from(pendingRoots);
      const rootSet = new Set(roots);
      pendingRoots.clear();
      if (!settings?.enabled) return;
      // Ignore only our synchronous display writes. Observing them as site
      // edits would continually restore and re-render the same mail body.
      observer.disconnect();
      try {
        for (const candidate of roots) {
          // A queued ancestor covers nested mutations in the same batch.
          let parent = candidate.parentNode;
          while (parent && !rootSet.has(parent)) parent = parent.parentNode;
          if (!parent) scanRoot(candidate);
        }
      } finally {
        observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
      }
      for (const span of rendered) if (!span.isConnected) restoreToken(span);
    }, 80);
  }

  const observer = new MutationObserver(records => {
    for (const record of records) {
      if (record.type === 'characterData') queueScan(record.target);
      else if (!excluded(record.target)) {
        // A site can remove only the display anchor while other original
        // fragments remain connected. Recover those pieces during cleanup.
        if (record.removedNodes.length) queueScan(record.target);
        for (const node of record.addedNodes) queueScan(node);
      }
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  function updateRenderedContent() {
    for (const span of rendered) {
      if (!span.isConnected) {
        restoreToken(span);
        continue;
      }
      const token = originalTokens.get(span);
      if (settings.enabled) renderToken(span, token);
      else {
        restoreToken(span);
      }
    }
    if (settings.enabled) queueScan(document.body);
  }

  function scheduleKeyExpiry() {
    if (expiryTimer !== null) clearTimeout(expiryTimer);
    expiryTimer = null;
    const expirations = settings.keys.map(key => key.expiresAt).filter(Number.isFinite);
    if (!expirations.length) return;
    const delay = Math.min(60_000, Math.max(0, Math.min(...expirations) - Date.now()) + 1);
    expiryTimer = setTimeout(() => { expiryTimer = null; refreshExpiredKeys(); }, delay);
  }

  function refreshExpiredKeys() {
    if (!settings) return false;
    if (!settings.keys.some(key => Number.isFinite(key.expiresAt) && key.expiresAt <= Date.now())) {
      scheduleKeyExpiry();
      return false;
    }
    // Expired plaintext disappears even if extension storage is temporarily
    // unavailable after suspend or an extension reload.
    settings = TypelockerSettings.pruneExpired(settings, Date.now());
    updateRenderedContent();
    scheduleKeyExpiry();
    // Site content scripts never mutate extension settings under a site-origin
    // lock. The service worker owns persisted expiry cleanup.
    try {
      const cleanup = chrome.runtime.sendMessage?.({ type: 'TYPELOCKER_EXPIRE_KEYS' });
      cleanup?.catch?.(() => {});
    } catch { /* An extension update can invalidate an existing content context. */ }
    refreshSettings();
    return true;
  }

  async function refreshSettings() {
    const revision = ++settingsRevision;
    try {
      const next = await TypelockerSettings.load();
      if (revision !== settingsRevision) return false;
      settings = next;
      updateRenderedContent();
      scheduleKeyExpiry();
      return true;
    } catch {
      // A reloaded extension may invalidate an existing tab; its original content remains.
      return false;
    }
  }

  function resyncPageSettings() {
    if (!refreshExpiredKeys()) refreshSettings();
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) resyncPageSettings(); });
  window.addEventListener('focus', resyncPageSettings);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) refreshSettings();
  });
  rememberSelection();
  refreshSettings();
})();
