(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let settings;
  let encodedCache = null;
  let expiryTimer = null;
  let pendingKeyId = null;
  let statusRevision = 0;
  const pending = new Set();
  const status = (text, error = false) => {
    $('status').textContent = text;
    $('status').classList.toggle('error', error);
    return ++statusRevision;
  };
  const messageKey = () => {
    if (pendingKeyId !== null) throw new Error('Wait for the selected key to finish saving.');
    const expiredSelection = refreshExpiredKeys();
    if (expiredSelection && !$('key-override').value) throw new Error('The selected temporary key expired. Choose a key before continuing.');
    return $('key-override').value || TypelockerSettings.activeKey(settings);
  };

  const keyName = id => settings?.keys.find(key => key.id === id)?.name || 'Original default key';
  function renderKeyContext() {
    if (!settings) return;
    const helper = $('key-context');
    const override = Boolean($('key-override').value);
    helper.classList.toggle('override-active', override);
    if (pendingKeyId !== null) {
      helper.textContent = `Saving page key: ${keyName(pendingKeyId)}. Popup actions will be available when it is saved.`;
      return;
    }
    const name = keyName(settings.selectedKeyId);
    helper.textContent = override
      ? `Page key: ${name}. This popup message uses a one-off override. Save & select it to use it on pages.`
      : `Popup and page key: ${name}.`;
    if (!settings.enabled) helper.textContent += ' Automatic page decoding is off.';
  }

  function codecStatus(action) {
    return $('key-override').value
      ? `${action} locally using the one-off override. Page key remains ${keyName(settings.selectedKeyId)}.`
      : `${action} locally using ${keyName(settings.selectedKeyId)}.`;
  }

  async function resyncActiveTab(expected) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return false;
      // The page loads saved settings itself. Never transmit the key or popup override.
      const reply = await chrome.tabs.sendMessage(tab.id, { type: 'TYPELOCKER_REFRESH_SETTINGS' });
      return reply?.ok === true && reply.selectedKeyId === expected.selectedKeyId && reply.enabled === expected.enabled;
    } catch {
      // Unsupported pages and invalidated content contexts need no opening-popup error.
      return false;
    }
  }

  function renderKeys() {
    $('key-select').replaceChildren(new Option('Original default key', 'default'), ...settings.keys.map(key => new Option(
      Number.isFinite(key.expiresAt) ? `${key.name} · expires ${new Date(key.expiresAt).toLocaleString()}` : key.name, key.id)));
    $('key-select').value = pendingKeyId ?? settings.selectedKeyId;
    $('key-select').disabled = pendingKeyId !== null;
    $('delete-key').disabled = pendingKeyId !== null || settings.selectedKeyId === 'default';
    for (const id of ['encode', 'decode', 'send', 'copy', 'save-key']) $(id).disabled = pendingKeyId !== null || pending.has(id);
    renderKeyContext();
    scheduleKeyExpiry();
  }

  function scheduleKeyExpiry() {
    if (expiryTimer !== null) clearTimeout(expiryTimer);
    expiryTimer = null;
    const expirations = settings.keys.map(key => key.expiresAt).filter(Number.isFinite);
    if (!expirations.length) return;
    const delay = Math.min(60_000, Math.max(0, Math.min(...expirations) - Date.now()) + 1);
    expiryTimer = setTimeout(() => { expiryTimer = null; refreshExpiredKeys(); }, delay);
  }

  function refreshExpiredKeys() {
    if (!settings) return false;
    const now = Date.now();
    if (!settings.keys.some(key => Number.isFinite(key.expiresAt) && key.expiresAt <= now)) {
      scheduleKeyExpiry();
      return false;
    }
    const selectedKeyId = settings.selectedKeyId;
    settings = TypelockerSettings.pruneExpired(settings, now);
    const expiredSelection = selectedKeyId !== settings.selectedKeyId;
    invalidateOutput();
    renderKeys();
    status(expiredSelection ? 'The selected temporary key expired. Original default key selected.' : 'Expired temporary keys removed.');
    // Persist cleanup from this extension document under the shared settings lock.
    act(async () => {
      settings = await TypelockerSettings.update(latest => latest);
      renderKeys();
    });
    return expiredSelection;
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshExpiredKeys(); });
  window.addEventListener('focus', refreshExpiredKeys);

  function makeEncoded() {
    const message = $('message').value;
    if (!message) throw new Error('Enter a message first.');
    const key = messageKey();
    if (!encodedCache || encodedCache.message !== message || encodedCache.key !== key) {
      encodedCache = {
        message, key, encoded: encodeBishiki(message, key), requestId: crypto.randomUUID(),
        expiresAt: $('key-override').value ? undefined : settings.keys.find(item => item.id === settings.selectedKeyId)?.expiresAt
      };
    }
    $('output').value = encodedCache.encoded;
    $('result-kind').textContent = '· BSK1';
    return encodedCache.encoded;
  }

  async function act(action) {
    try { await action(); } catch (error) { status(error.message || 'The action could not be completed.', true); }
  }

  async function exclusive(id, action) {
    // Guard as well as disabling the button: synthetic/native duplicate events
    // must not create a second insertion while the first request is pending.
    if (pending.has(id)) return;
    pending.add(id);
    $(id).disabled = true;
    try { await act(action); }
    finally { pending.delete(id); $(id).disabled = !settings || pendingKeyId !== null; }
  }

  function invalidateOutput() {
    encodedCache = null;
    $('output').value = '';
    $('result-kind').textContent = '';
  }
  $('message').addEventListener('input', invalidateOutput);
  $('key-override').addEventListener('input', () => { invalidateOutput(); renderKeyContext(); });

  $('encode').addEventListener('click', () => act(() => { makeEncoded(); status(codecStatus('Encoded')); }));
  $('decode').addEventListener('click', () => act(() => {
    try {
      const decoded = decodeBishiki($('message').value, messageKey());
      // BSK1 has no key authentication. Reject control-byte output as a likely wrong key.
      if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/u.test(decoded)) throw new Error('Invalid decoded text.');
      $('output').value = `${decoded} (Decoded with Typelocker™)`;
      $('result-kind').textContent = '· decoded';
      status(codecStatus('Decoded'));
    } catch (_) {
      $('output').value = 'Typelocker™ Private Content';
      $('result-kind').textContent = '· unavailable';
      status('Unable to decode. Check the key and complete BSK1 message.', true);
    }
  }));
  $('copy').addEventListener('click', () => exclusive('copy', async () => {
    await navigator.clipboard.writeText(makeEncoded());
    status('Encoded message copied.');
  }));
  $('send').addEventListener('click', () => exclusive('send', async () => {
    const encoded = makeEncoded();
    // The composition owns the request ID so a completed native duplicate click
    // or retry can also be recognized by the content script.
    const requestId = encodedCache.requestId;
    const expiresAt = encodedCache.expiresAt;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No active website tab.');
    if (Number.isFinite(expiresAt) && expiresAt <= Date.now()) {
      refreshExpiredKeys();
      throw new Error('The selected temporary key expired before insertion. Choose a key and encode again.');
    }
    let result;
    try { result = await chrome.tabs.sendMessage(tab.id, { type: 'TYPELOCKER_INSERT', encoded, requestId }); }
    catch (_) { throw new Error('Open a supported website, refresh it, and select a text field. You can also copy the encoded message.'); }
    if (!result?.ok) throw new Error(result?.error || 'Select a compatible website text field first.');
    status('Inserted into the selected field. Publish or send from the website when ready.');
  }));
  $('key-select').addEventListener('change', () => {
    if (pendingKeyId !== null) return;
    const selectedKeyId = $('key-select').value;
    // A deliberate profile selection supersedes the one-message override.
    // Clear both immediately so a pending storage write cannot leave stale output usable.
    $('key-override').value = '';
    invalidateOutput();
    pendingKeyId = selectedKeyId;
    renderKeys();
    act(async () => {
      let expected;
      let notice;
      let selectedName;
      try {
        settings = await TypelockerSettings.update(latest => ({ ...latest, selectedKeyId }));
        expected = { selectedKeyId: settings.selectedKeyId, enabled: settings.enabled };
        selectedName = keyName(settings.selectedKeyId);
        notice = status(`Selected key saved: ${selectedName}. Checking active page settings…`);
      } finally {
        pendingKeyId = null;
        renderKeys();
      }
      // Popup codec actions are available as soon as persistence completes; a
      // slow or unsupported page must not hold them disabled.
      const confirmed = await resyncActiveTab(expected);
      if (statusRevision !== notice || settings.selectedKeyId !== expected.selectedKeyId || settings.enabled !== expected.enabled) return;
      status(confirmed
        ? `Selected key saved: ${selectedName}. Active page settings refreshed.`
        : `Selected key saved: ${selectedName}. Page update not confirmed; refresh the supported site to apply it.`);
    });
  });
  $('manage').addEventListener('click', () => { $('key-management').open = !$('key-management').open; });
  $('key-management').addEventListener('toggle', () => { $('manage').setAttribute('aria-expanded', String($('key-management').open)); });
  $('save-key').addEventListener('click', () => act(async () => {
    const name = $('key-name').value.trim();
    const value = $('key-override').value;
    if (!name || !value) throw new Error('Enter a key name and an override value to save.');
    const id = crypto.randomUUID();
    settings = await TypelockerSettings.update(latest => ({ ...latest, keys: [...latest.keys, { id, name, value }], selectedKeyId: id }));
    $('key-name').value = '';
    $('key-override').value = '';
    invalidateOutput();
    renderKeys();
    status('Custom key saved and selected.');
  }));
  $('delete-key').addEventListener('click', () => {
    const deletedId = $('key-select').value;
    if (deletedId === 'default') return;
    act(async () => {
      settings = await TypelockerSettings.update(latest => ({ ...latest, keys: latest.keys.filter(key => key.id !== deletedId), selectedKeyId: latest.selectedKeyId === deletedId ? 'default' : latest.selectedKeyId }));
      invalidateOutput();
      renderKeys();
      status('Custom key deleted.');
    });
  });
  $('settings').addEventListener('click', () => act(() => chrome.runtime.openOptionsPage()));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) act(async () => {
      settings = await TypelockerSettings.load();
      invalidateOutput();
      renderKeys();
    });
  });
  act(async () => {
    settings = await TypelockerSettings.load();
    renderKeys();
    // Reconcile an already-selected key when a long-lived tab missed its event.
    void resyncActiveTab({ selectedKeyId: settings.selectedKeyId, enabled: settings.enabled });
  });
})();
