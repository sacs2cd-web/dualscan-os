/* Runs only on the official invitation page; never imports without review. */
(() => {
  'use strict';
  if (globalThis.__typelockerInvitationBridge) return;
  globalThis.__typelockerInvitationBridge = true;
  const token = new URLSearchParams(location.hash.slice(1)).get('tli');
  let opening = false;
  function status(text) {
    const target = document.getElementById('extension-status');
    if (target) target.textContent = text;
  }
  async function open() {
    if (opening) return;
    if (!token || token.length > 12288 || !/^[A-Za-z0-9_-]+$/.test(token)) { status('This invitation link is missing or invalid. Ask the sender for a new link.'); return; }
    opening = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: 'TYPELOCKER_OPEN_INVITATION', token });
      if (!result?.ok) throw new Error(result?.error || 'The invitation could not be opened.');
      // Remove the bearer key from this landing page’s current history entry.
      history.replaceState(null, '', location.pathname);
      status('The invitation is open in Typelocker™ Chat. Review it there and accept to start your seven days.');
    } catch (error) { status(error.message || 'Reload this invitation after updating Typelocker™ Chat to 1.2.0 or later.'); }
    finally { opening = false; }
  }
  document.addEventListener('click', event => {
    if (event.target instanceof Element && event.target.closest('#open-in-extension')) { event.preventDefault(); open(); }
  });
  function ready() {
    if (!token) { status('Open the full invitation link from your email to continue.'); return; }
    status('Opening your invitation in Typelocker™ Chat…');
    open();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, { once: true });
  else ready();
})();
