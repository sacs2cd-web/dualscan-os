/* Typelocker™ Chat — local page display and explicitly requested insertion. */
(() => {
  'use strict';

  // Keep a reinjected script from registering a second insertion listener.
  if (globalThis.__typelockerContentLoaded) return;
  globalThis.__typelockerContentLoaded = true;

  const MARKER = 'data-typelocker-rendered';
  const SKIP = 'script,style,noscript,template,textarea,input,select,option';
  const glyphClass = ALPHA.join('');
  const canonicalToken = new RegExp(`^BSK1·[${glyphClass}]{6}·[${glyphClass}]*·[${glyphClass}]{6}$`, 'u');
  // The fallback also marks truncated or damaged BSK1-prefixed strings as private.
  const candidateToken = new RegExp(`BSK1·[^\\s·]*·[^\\s·]*·[^\\s·]{0,6}(?![${glyphClass}])|BSK1·[^\\s]*`, 'gu');
  const originalTokens = new WeakMap();
  const insertionReceipts = new WeakMap();
  const rendered = new Set();
  const pendingRoots = new Set();
  let settings = null;
  let settingsRevision = 0;
  let scanTimer = null;
  let expiryTimer = null;
  let lastEditor = null;
  let lastRange = null;
  let lastTextSelection = null;

  function editorFor(target) {
    if (!(target instanceof Element)) return null;
    if (target.matches('textarea,input')) {
      const supported = target instanceof HTMLTextAreaElement ||
        ['text', 'search'].includes(target.type);
      return supported && !target.disabled && !target.readOnly ? target : null;
    }
    if (!target.isContentEditable) return null;
    let editor = target;
    while (editor.parentElement?.isContentEditable) editor = editor.parentElement;
    return editor.getAttribute('aria-disabled') === 'true' ? null : editor;
  }

  function rangeInside(range, editor) {
    return editor.contains(range.startContainer) && editor.contains(range.endContainer);
  }

  function rememberSelection() {
    const editor = editorFor(document.activeElement);
    if (!editor) return;
    if (lastEditor !== editor) {
      lastRange = null;
      lastTextSelection = null;
    }
    lastEditor = editor;
    if (editor.isContentEditable) {
      const selection = document.getSelection();
      if (selection?.rangeCount && rangeInside(selection.getRangeAt(0), editor)) {
        lastRange = selection.getRangeAt(0).cloneRange();
      }
    } else {
      lastTextSelection = {
        start: editor.selectionStart ?? editor.value.length,
        end: editor.selectionEnd ?? editor.value.length
      };
    }
  }

  document.addEventListener('focusin', rememberSelection, true);
  document.addEventListener('selectionchange', rememberSelection, true);
  document.addEventListener('select', rememberSelection, true);
  document.addEventListener('input', rememberSelection, true);
  document.addEventListener('keyup', rememberSelection, true);
  document.addEventListener('pointerup', rememberSelection, true);

  const nextFrame = () => new Promise(resolve => requestAnimationFrame(resolve));
  const tokenCount = (text, token) => text.split(token).length - 1;

  function usesControlledPaste(editor) {
    return /(^|\.)(x|twitter)\.com$/i.test(location.hostname) || Boolean(editor.closest('.DraftEditor-root'));
  }

  async function insertControlledPaste(editor, encoded) {
    // Draft keeps a model selection. Let its onSelect observe the restored DOM range.
    await nextFrame();
    const selection = document.getSelection();
    if (!editor.isConnected || !selection?.rangeCount || !rangeInside(selection.getRangeAt(0), editor)) {
      throw new Error('The editor selection changed. Select the target field and try again.');
    }
    const expectedCount = tokenCount(editor.textContent, encoded) - tokenCount(selection.getRangeAt(0).toString(), encoded) + 1;
    const transfer = new DataTransfer();
    transfer.setData('text/plain', encoded);
    const paste = new ClipboardEvent('paste', { bubbles: true, cancelable: true, composed: true, clipboardData: transfer });
    // Synthetic paste has no browser default insertion and never reads the system clipboard.
    // The controlled editor must accept and apply this one event through its own model.
    editor.dispatchEvent(paste);
    if (!paste.defaultPrevented) {
      throw new Error('This editor did not accept insertion. Use Copy Encoded Message.');
    }
    await nextFrame();
    await nextFrame();
    if (!editor.isConnected || tokenCount(editor.textContent, encoded) !== expectedCount) {
      throw new Error('The editor could not confirm one insertion. Check the field and use Copy Encoded Message.');
    }
  }

  function insertEncoded(encoded, requestId) {
    if (typeof encoded !== 'string' || !canonicalToken.test(encoded)) {
      throw new Error('The message is not a complete BSK1 token. Encode it first.');
    }
    const activeEditor = editorFor(document.activeElement);
    if (activeEditor) rememberSelection();
    const editor = activeEditor || lastEditor;
    if (!editor?.isConnected || editorFor(editor) !== editor) {
      throw new Error('Click inside a compatible text field before opening Typelocker™ Chat.');
    }
    const receiptId = typeof requestId === 'string' && requestId.length > 0 && requestId.length <= 128 ? requestId : null;
    const receipts = insertionReceipts.get(editor) || new Map();
    const previous = receiptId && receipts.get(receiptId);
    if (previous) {
      if (!previous.pending) return;
      return previous.completion.then(outcome => {
        if (!outcome.ok) throw new Error(outcome.error);
      });
    }
    let complete;
    const receipt = receiptId ? { pending: true, completion: new Promise(resolve => { complete = resolve; }) } : null;
    if (receipt) {
      // Reserve before focus or event dispatch so reentrant and repeated messages share it.
      receipts.set(receiptId, receipt);
      insertionReceipts.set(editor, receipts);
    }
    const success = () => {
      if (receipt) {
        receipt.pending = false;
        complete({ ok: true });
        for (const [id, entry] of receipts) {
          if (receipts.size <= 64) break;
          if (!entry.pending) receipts.delete(id);
        }
      }
      rememberSelection();
      // Never click a site button or dispatch Enter, submit, or change events.
    };
    const failure = error => {
      if (receipt) {
        receipts.delete(receiptId);
        complete({ ok: false, error: error.message });
      }
      throw error;
    };
    try {
      const savedRange = lastEditor === editor && lastRange ? lastRange.cloneRange() : null;
      const savedTextSelection = lastEditor === editor ? lastTextSelection : null;
      editor.focus({ preventScroll: true });
      if (editor.isContentEditable) {
        const selection = document.getSelection();
        if (!selection) throw new Error('This editor does not expose a text selection. Use Copy Encoded Message.');
        const range = savedRange && rangeInside(savedRange, editor) ? savedRange : document.createRange();
        if (!savedRange || !rangeInside(savedRange, editor)) {
          range.selectNodeContents(editor);
          range.collapse(false);
        }
        selection.removeAllRanges();
        selection.addRange(range);
        if (usesControlledPaste(editor)) return insertControlledPaste(editor, encoded).then(success, failure);
        // Native editing preserves the undo buffer for generic rich text fields.
        if (!document.execCommand('insertText', false, encoded)) {
          throw new Error('This editor did not accept insertion. Use Copy Encoded Message.');
        }
      } else {
        const start = Math.min(savedTextSelection?.start ?? editor.value.length, editor.value.length);
        const end = Math.min(savedTextSelection?.end ?? start, editor.value.length);
        const before = new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: encoded
        });
        if (!editor.dispatchEvent(before)) throw new Error('The text field declined insertion. Use Copy Encoded Message.');
        const prototype = editor instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
        setter.call(editor, editor.value.slice(0, start) + encoded + editor.value.slice(end));
        editor.setSelectionRange(start + encoded.length, start + encoded.length);
        editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: encoded }));
      }
      success();
    } catch (error) {
      failure(error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.type !== 'TYPELOCKER_INSERT') return;
    try {
      const insertion = insertEncoded(message.encoded, message.requestId);
      if (insertion && typeof insertion.then === 'function') {
        insertion.then(() => reply({ ok: true }), error => reply({ ok: false, error: error.message }));
        // Promise-returning listeners are not available in the minimum supported Chrome.
        return true;
      }
      reply({ ok: true });
    } catch (error) {
      reply({ ok: false, error: error.message });
    }
  });

  function decodedText(token) {
    try {
      if (!canonicalToken.test(token)) return null;
      const parts = token.split('·');
      // Reject ignored characters or noncanonical padding without altering BSK1.
      if (parts.slice(1).some(part => bytesToGlyphs(glyphsToBytes(part)) !== part)) return null;
      const decoded = decodeBishiki(token, TypelockerSettings.activeKey(settings));
      // The original checksum cannot authenticate keys; reject unlikely control-byte output.
      if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/u.test(decoded)) return null;
      return decoded;
    } catch {
      return null;
    }
  }

  function renderToken(span, token) {
    const text = decodedText(token);
    span.textContent = text === null ? 'Typelocker™ Private Content' : `${text} (Decoded with Typelocker™)`;
    span.title = text === null ? 'Unable to decode with the selected key' : 'Decoded locally with the selected key';
    span.style.cssText = 'display:inline;white-space:pre-wrap;overflow-wrap:anywhere;background:rgba(83,104,230,.12);border-radius:4px;padding:1px 3px;';
  }

  function excluded(node) {
    const parent = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return !parent || parent.isContentEditable || Boolean(parent.closest(`${SKIP},[${MARKER}],[contenteditable]:not([contenteditable="false"])`));
  }

  function processText(node) {
    const text = node.nodeValue;
    if (!node.isConnected || !text?.includes('BSK1·') || excluded(node)) return;
    candidateToken.lastIndex = 0;
    const matches = Array.from(text.matchAll(candidateToken));
    if (!matches.length) return;
    const fragment = document.createDocumentFragment();
    let cursor = 0;
    for (const match of matches) {
      fragment.append(document.createTextNode(text.slice(cursor, match.index)));
      const span = document.createElement('span');
      span.setAttribute(MARKER, '1');
      originalTokens.set(span, match[0]);
      rendered.add(span);
      renderToken(span, match[0]);
      fragment.append(span);
      cursor = match.index + match[0].length;
    }
    fragment.append(document.createTextNode(text.slice(cursor)));
    node.replaceWith(fragment);
  }

  function scanRoot(root) {
    if (!root?.isConnected || excluded(root)) return;
    if (root.nodeType === Node.TEXT_NODE) {
      processText(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        return node.nodeValue?.includes('BSK1·') && !excluded(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(processText);
  }

  function queueScan(root) {
    if (!settings?.enabled || !root) return;
    pendingRoots.add(root);
    if (scanTimer !== null) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      const roots = Array.from(pendingRoots);
      const rootSet = new Set(roots);
      pendingRoots.clear();
      if (!settings?.enabled) return;
      for (const candidate of roots) {
        // A queued ancestor covers nested mutations in the same batch.
        let parent = candidate.parentNode;
        while (parent && !rootSet.has(parent)) parent = parent.parentNode;
        if (!parent) scanRoot(candidate);
      }
      for (const span of rendered) if (!span.isConnected) rendered.delete(span);
    }, 80);
  }

  const observer = new MutationObserver(records => {
    for (const record of records) {
      if (record.type === 'characterData') queueScan(record.target);
      else if (!excluded(record.target)) for (const node of record.addedNodes) queueScan(node);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  function updateRenderedContent() {
    for (const span of rendered) {
      if (!span.isConnected) {
        rendered.delete(span);
        continue;
      }
      const token = originalTokens.get(span);
      if (settings.enabled) renderToken(span, token);
      else {
        span.replaceWith(document.createTextNode(token));
        rendered.delete(span);
      }
    }
    if (settings.enabled) queueScan(document.body);
  }

  function scheduleKeyExpiry() {
    if (expiryTimer !== null) clearTimeout(expiryTimer);
    expiryTimer = null;
    const expirations = settings.keys.map(key => key.expiresAt).filter(Number.isFinite);
    if (!expirations.length) return;
    const delay = Math.min(60_000, Math.max(0, Math.min(...expirations) - Date.now()) + 1);
    expiryTimer = setTimeout(() => { expiryTimer = null; refreshExpiredKeys(); }, delay);
  }

  function refreshExpiredKeys() {
    if (!settings) return;
    if (!settings.keys.some(key => Number.isFinite(key.expiresAt) && key.expiresAt <= Date.now())) {
      scheduleKeyExpiry();
      return;
    }
    // Expired plaintext disappears even if extension storage is temporarily
    // unavailable after suspend or an extension reload.
    settings = TypelockerSettings.pruneExpired(settings, Date.now());
    updateRenderedContent();
    scheduleKeyExpiry();
    // Site content scripts never mutate extension settings under a site-origin
    // lock. The service worker owns persisted expiry cleanup.
    try {
      const cleanup = chrome.runtime.sendMessage?.({ type: 'TYPELOCKER_EXPIRE_KEYS' });
      cleanup?.catch?.(() => {});
    } catch { /* An extension update can invalidate an existing content context. */ }
    refreshSettings();
  }

  async function refreshSettings() {
    const revision = ++settingsRevision;
    try {
      const next = await TypelockerSettings.load();
      if (revision !== settingsRevision) return;
      settings = next;
      updateRenderedContent();
      scheduleKeyExpiry();
    } catch {
      // A reloaded extension may invalidate an existing tab; its original content remains.
    }
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshExpiredKeys(); });
  window.addEventListener('focus', refreshExpiredKeys);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) refreshSettings();
  });
  rememberSelection();
  refreshSettings();
})();
