/* Versioned diary metadata. No network, permissions, or storage side effects. */
(() => {
  'use strict';
  const KIND = 'typelocker-diary-access';
  const MAX_BYTES = 64 * 1024 * 1024;
  const MAX_TOKEN_LENGTH = 24576;
  const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
  function contentURL(value) {
    if (typeof value !== 'string' || value.length > 4096 || /[\s\u0000-\u001f\u007f]/u.test(value)) throw new Error('Invalid diary content URL.');
    let url;
    try { url = new URL(value); } catch (_) { throw new Error('Invalid diary content URL.'); }
    const host = url.hostname.toLowerCase();
    const local = url.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(host);
    const publicDNS = host.includes('.') && !host.endsWith('.') && !/^[0-9.]+$/.test(host) &&
      !/(^|\.)(localhost|local|internal|test|invalid)$/.test(host) &&
      host.split('.').every(label => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label));
    if ((!local && !(url.protocol === 'https:' && publicDNS)) || url.username || url.password || url.search || url.hash || value.includes('?') || value.includes('#') || !/^\/d\/[A-Za-z0-9_-]{43}\/content$/.test(url.pathname)) {
      throw new Error('Use a public HTTPS diary endpoint or a local HTTP development endpoint, without credentials, query or fragment.');
    }
    return url;
  }
  function validate(value) {
    if (!value || Array.isArray(value) || value.kind !== KIND || value.version !== 1) throw new Error('Unsupported diary access link.');
    const invitation = TypelockerInvitations.validate(value.invitation);
    const diary = value.diary;
    if (!diary || !uuid.test(diary.clientId) || !uuid.test(diary.diaryId)) throw new Error('Invalid diary identifiers.');
    if (typeof diary.title !== 'string' || !diary.title.trim() || diary.title.trim().length > 200) throw new Error('Invalid diary title.');
    if (!Number.isSafeInteger(diary.byteLength) || diary.byteLength < 1 || diary.byteLength > MAX_BYTES) throw new Error('Diary downloads must be between 1 byte and 64 MiB.');
    if (typeof diary.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(diary.sha256) || !Number.isSafeInteger(diary.expiresAt) || diary.expiresAt <= 0) throw new Error('Invalid diary integrity or expiry metadata.');
    const url = contentURL(diary.contentUrl);
    return { kind: KIND, version: 1, invitation, diary: { clientId: diary.clientId.toLowerCase(), diaryId: diary.diaryId.toLowerCase(), title: diary.title.trim(), contentUrl: url.href, byteLength: diary.byteLength, sha256: diary.sha256, expiresAt: diary.expiresAt } };
  }
  function encode(value) {
    const bytes = new TextEncoder().encode(JSON.stringify(validate(value)));
    const token = btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
    if (token.length > MAX_TOKEN_LENGTH) throw new Error('Diary access metadata is too large.');
    return token;
  }
  function decode(token) {
    if (typeof token !== 'string' || !token || token.length > MAX_TOKEN_LENGTH || !/^[A-Za-z0-9_-]+$/.test(token)) throw new Error('Invalid diary access token.');
    let parsed;
    try {
      const binary = atob(token.replaceAll('-', '+').replaceAll('_', '/'));
      parsed = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(binary, char => char.charCodeAt(0))));
    } catch (_) { throw new Error('Invalid diary access token.'); }
    const value = validate(parsed);
    if (encode(value) !== token) throw new Error('Noncanonical diary access token.');
    return value;
  }
  function permissionOrigin(value) {
    const url = contentURL(value);
    // Chrome host match patterns do not support port scoping. The fetch itself
    // still uses the validated, exact origin and URL, with redirects forbidden.
    return `${url.protocol}//${url.hostname}/*`;
  }
  globalThis.TypelockerDiaryAccess = Object.freeze({ KIND, MAX_BYTES, MAX_TOKEN_LENGTH, contentURL, validate, encode, decode, permissionOrigin });
})();
