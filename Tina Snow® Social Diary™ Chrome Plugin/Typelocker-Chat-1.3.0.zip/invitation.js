/* Bundled invitation review: fragment data is never sent as a network request. */
(() => {
  'use strict';
  const fragment = location.hash;
  // Remove the invitation payload before loading or rendering any invitation data.
  try { history.replaceState(null, '', location.pathname + location.search); } catch (_) {}
  const token = /^#tli=([A-Za-z0-9_-]+)$/.exec(fragment)?.[1] || null;
  const dateLabel = value => new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  let invitation = null;
  let pending = false;
  let cancelled = false;

  document.addEventListener('DOMContentLoaded', async () => {
    const $ = id => document.getElementById(id);
    const status = (message, error = false) => {
      $('invitation-status').textContent = message;
      $('invitation-status').classList.toggle('error', error);
    };
    $('cancel-invitation').addEventListener('click', () => {
      if (pending) return;
      cancelled = true;
      invitation = null;
      $('accept-invitation').disabled = true;
      $('cancel-invitation').disabled = true;
      status('Invitation cancelled. No key was saved by this page. You can close this tab.');
    });
    $('accept-invitation').addEventListener('click', async () => {
      if (!invitation || pending || cancelled) return;
      pending = true;
      $('accept-invitation').disabled = true;
      $('cancel-invitation').disabled = true;
      try {
        const settings = await TypelockerInvitations.accept(invitation);
        const accepted = settings.keys.find(key => key.invitationId === invitation.id) || settings.keys.find(key => key.id === settings.selectedKeyId);
        status(accepted?.expiresAt
          ? `Key accepted and selected until ${dateLabel(accepted.expiresAt)}. Reopening this invitation does not extend that deadline.`
          : 'Key accepted and selected. Reopening this invitation does not extend its original seven-day deadline.');
        $('accept-invitation').textContent = 'Key selected';
      } catch (error) {
        status(error.message || 'The invitation could not be accepted.', true);
        $('accept-invitation').disabled = false;
        $('cancel-invitation').disabled = false;
      } finally {
        pending = false;
      }
    });
    try {
      if (!token) throw new Error('This page needs a complete invitation link. Open the link you received.');
      invitation = TypelockerInvitations.validate(TypelockerInvitations.decode(token));
      $('review-name').textContent = invitation.name;
      $('review-created').textContent = dateLabel(invitation.issuedAt);
      $('review-accept-by').textContent = dateLabel(invitation.acceptBy);
      $('invitation-review').hidden = false;
      const settings = await TypelockerSettings.load();
      if (cancelled) return;
      const existing = settings.keys.find(key => key.invitationId === invitation.id && key.expiresAt > Date.now());
      if (existing) {
        $('review-existing').textContent = `Already accepted in this Chrome profile. The existing key expires ${dateLabel(existing.expiresAt)}. Selecting it again will not extend that deadline.`;
        $('review-existing').hidden = false;
        $('accept-invitation').textContent = 'Select accepted key';
      }
      $('accept-invitation').disabled = false;
      status('Review the invitation, then choose whether to accept and select this key. Nothing has been saved by this page.');
    } catch (error) {
      invitation = null;
      $('accept-invitation').disabled = true;
      status(error.message || 'This invitation is invalid.', true);
    }
  });
})();
