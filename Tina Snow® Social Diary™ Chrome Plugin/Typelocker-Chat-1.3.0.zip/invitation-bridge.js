/* Runs only on the official invitation page; never imports without review. */
(() => {
  'use strict';
  if (globalThis.__typelockerInvitationBridge) return;
  globalThis.__typelockerInvitationBridge = true;
  const diary = /^#tld=([A-Za-z0-9_-]+)$/.exec(location.hash);
  const isDiary = Boolean(diary);
  const token = isDiary ? diary[1] : new URLSearchParams(location.hash.slice(1)).get('tli');
  let opening = false;
  function status(text) {
    const target = document.getElementById('extension-status');
    if (target) target.textContent = text;
  }
  async function open() {
    if (opening) return;
    if (!token || token.length > (isDiary ? 24576 : 12288) || !/^[A-Za-z0-9_-]+$/.test(token)) { status('This invitation link is missing or invalid. Ask the sender for a new link.'); return; }
    opening = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: isDiary ? 'TYPELOCKER_OPEN_DIARY_ACCESS' : 'TYPELOCKER_OPEN_INVITATION', token });
      if (!result?.ok) throw new Error(result?.error || 'The invitation could not be opened.');
      // Remove the bearer key from this landing page’s current history entry.
      history.replaceState(null, '', location.pathname);
      status(isDiary ? 'The diary is open in Typelocker™ Chat. Review the key and server there before downloading.' : 'The invitation is open in Typelocker™ Chat. Review it there and accept to start your seven days.');
    } catch (error) { status(error.message || 'Reload this invitation after updating Typelocker™ Chat to 1.3.0 or later.'); }
    finally { opening = false; }
  }
  document.addEventListener('click', event => {
    if (event.target instanceof Element && event.target.closest('#open-in-extension')) { event.preventDefault(); open(); }
  });
  function ready() {
    if (!token) { status('Open the full invitation link from your email to continue.'); return; }
    status('Opening your invitation in Typelocker™ Chat…');
    open();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, { once: true });
  else ready();
})();
