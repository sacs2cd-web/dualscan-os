(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let settings;
  let pendingImport = null;
  let generatedInvitation = null;
  let expiryTimer = null;
  const dateLabel = value => new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  const active = key => typeof key.expiresAt !== 'number' || key.expiresAt > Date.now();
  const keyLabel = key => typeof key.expiresAt === 'number' ? `${key.name} — expires ${dateLabel(key.expiresAt)}` : key.name;
  const status = (text, error = false) => { $('status').textContent = text; $('status').classList.toggle('error', error); };
  async function act(action) { try { await action(); } catch (error) { status(error.message || 'Settings could not be saved.', true); } }
  function render() {
    const available = settings.keys.filter(active);
    $('key-select').replaceChildren(new Option('Original default key', 'default'), ...available.map(key => new Option(keyLabel(key), key.id)));
    const selected = available.find(key => key.id === settings.selectedKeyId);
    $('key-select').value = selected?.id || 'default';
    $('enabled').checked = settings.enabled;
    $('delete-key').disabled = !selected;
    $('key-summary').textContent = selected?.expiresAt
      ? `Temporary invitation key. Expires ${dateLabel(selected.expiresAt)}. Reopening its invitation does not extend this deadline.`
      : selected ? 'Permanent custom key selected.' : 'Original default key selected.';
    const temporaryCount = available.filter(key => typeof key.expiresAt === 'number').length;
    $('temporary-key-count').textContent = `${temporaryCount} / 100 active invitation keys saved. Permanent custom keys are kept separately. Choose any saved key manually.`;
    for (const id of ['key-select', 'enabled', 'add-key', 'import', 'export', 'use-selected-key', 'generate-invitation-key', 'create-invitation']) $(id).disabled = false;
    clearTimeout(expiryTimer);
    const nextExpiry = available.filter(key => typeof key.expiresAt === 'number').reduce((nearest, key) => Math.min(nearest, key.expiresAt), Infinity);
    if (Number.isFinite(nextExpiry)) expiryTimer = setTimeout(() => act(async () => { settings = await TypelockerSettings.load(); render(); }), Math.min(Math.max(nextExpiry - Date.now() + 10, 1), 2147483647));
  }
  async function update(mutator) { settings = await TypelockerSettings.update(mutator); render(); }
  $('enabled').addEventListener('change', () => {
    const enabled = $('enabled').checked;
    act(async () => {
      await update(latest => ({ ...latest, enabled }));
      status(enabled ? 'Automatic decoding enabled.' : 'Automatic decoding disabled. Original BSK1 messages are shown.');
    });
  });
  $('key-select').addEventListener('change', () => {
    const selectedKeyId = $('key-select').value;
    act(async () => { await update(latest => ({ ...latest, selectedKeyId })); status('Selected key saved.'); });
  });
  $('add-key-form').addEventListener('submit', event => {
    event.preventDefault();
    act(async () => {
      const name = $('key-name').value.trim();
      const value = $('key-value').value;
      if (!name || !value) throw new Error('Enter a key name and value.');
      const id = crypto.randomUUID();
      await update(latest => ({ ...latest, keys: [...latest.keys, { id, name, value }], selectedKeyId: id }));
      $('add-key-form').reset();
      status('Custom key saved and selected.');
    });
  });
  $('delete-key').addEventListener('click', () => {
    const deletedId = $('key-select').value;
    if (deletedId === 'default') return;
    act(async () => {
      await update(latest => ({ ...latest, keys: latest.keys.filter(key => key.id !== deletedId), selectedKeyId: latest.selectedKeyId === deletedId ? 'default' : latest.selectedKeyId }));
      status('Custom key deleted.');
    });
  });
  function updateEmailDraft() {
    if (!generatedInvitation) return;
    const recipient = $('invitation-recipient').value.trim();
    const subject = `Key invitation: ${generatedInvitation.name}`;
    const body = [
      `You are invited to use ${generatedInvitation.name} with Typelocker™ Chat.`,
      '', $('invitation-link').value, '',
      'Review and first accept this invitation within seven days of creation. Your key lasts exactly seven days from your first acceptance in your Chrome profile. Reopening the same invitation never extends it.',
      '', 'This link contains a readable shared key. Share only with intended recipients. BSK1 is reversible text obfuscation, not secure encryption.'
    ].join('\n');
    $('invitation-email').href = `mailto:${encodeURIComponent(recipient)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }
  $('use-selected-key').addEventListener('click', () => act(async () => {
    settings = await TypelockerSettings.load();
    $('invitation-value').value = TypelockerSettings.activeKey(settings);
    status('Selected key copied into the invitation form. Review the invitation name before creating a link.');
  }));
  $('generate-invitation-key').addEventListener('click', () => {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    $('invitation-value').value = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    status('A new random key is ready in the invitation form. It is not saved as a permanent key.');
  });
  $('invitation-form').addEventListener('submit', event => {
    event.preventDefault();
    act(() => {
      const name = $('invitation-name').value.trim();
      const value = $('invitation-value').value;
      if (!name || !value) throw new Error('Enter an invitation name and a shared key.');
      const invitation = TypelockerInvitations.create({ name, value });
      const link = TypelockerInvitations.link(invitation);
      generatedInvitation = invitation;
      $('invitation-link').value = link;
      $('invitation-summary').textContent = `${invitation.name}: first acceptance is available until ${dateLabel(invitation.acceptBy)}. The client’s seven days begin when they first accept.`;
      $('invitation-result').hidden = false;
      updateEmailDraft();
      status('Invitation link created locally. Copy it or open an unsent email draft for review.');
    });
  });
  $('copy-invitation').addEventListener('click', () => act(async () => {
    if (!generatedInvitation) return;
    await navigator.clipboard.writeText($('invitation-link').value);
    status('Invitation link copied. It contains a readable shared-key configuration.');
  }));
  $('invitation-recipient').addEventListener('input', updateEmailDraft);
  $('invitation-email').addEventListener('click', event => {
    if (!$('invitation-recipient').checkValidity()) {
      event.preventDefault();
      status('Enter a valid client email address, or leave it blank to choose one in your email app.', true);
    }
  });
  $('export').addEventListener('click', () => act(() => {
    const blob = new Blob([JSON.stringify(settings, null, 2) + '\n'], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'typelocker-chat-keys.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    status('Configuration exported. The file contains readable key values.');
  }));
  $('import').addEventListener('click', () => { $('import-file').value = ''; $('import-file').click(); });
  $('import-file').addEventListener('change', () => act(async () => {
    const file = $('import-file').files[0];
    if (!file) return;
    pendingImport = null;
    $('import-preview').hidden = true;
    // Storage has a browser-managed quota; avoid reading unbounded files into the options page.
    const quota = chrome.storage.local.QUOTA_BYTES || 10 * 1024 * 1024;
    if (file.size > quota) throw new Error('This configuration file exceeds Chrome’s local settings quota.');
    let parsed;
    try { parsed = JSON.parse(await file.text()); } catch (_) { throw new Error('Choose a valid JSON configuration file.'); }
    pendingImport = TypelockerSettings.validate(parsed);
    $('import-summary').textContent = `Ready to import ${pendingImport.keys.length} custom key(s). This will replace your current keys and settings.`;
    $('import-preview').hidden = false;
    status('Review the import, then choose Replace configuration.');
  }));
  $('confirm-import').addEventListener('click', () => act(async () => {
    if (!pendingImport) return;
    settings = await TypelockerSettings.save(pendingImport);
    pendingImport = null;
    $('import-preview').hidden = true;
    render();
    status('Configuration imported and saved locally.');
  }));
  $('cancel-import').addEventListener('click', () => { pendingImport = null; $('import-preview').hidden = true; status('Import cancelled.'); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) act(async () => { settings = await TypelockerSettings.load(); render(); });
  });
  act(async () => { settings = await TypelockerSettings.load(); render(); });
})();
