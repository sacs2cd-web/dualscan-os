/* Local, versioned bearer-key invitations. No network requests or remote code. */
(() => {
  'use strict';
  const KIND = 'typelocker-key-invitation';
  const LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;
  const INVITE_ORIGIN = 'https://typelocker-chat-support.alleong.chatgpt.site';
  const DEFAULT_NAME = 'Tina Snow® Social Diary™ - Beyonce';
  const MAX_TOKEN_LENGTH = 12288;
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const timestamp = value => Number.isSafeInteger(value) && value > 0;

  function validate(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.kind !== KIND || value.version !== 1) throw new Error('Unsupported key invitation.');
    if (typeof value.id !== 'string' || !uuid.test(value.id)) throw new Error('Invalid invitation ID.');
    if (typeof value.name !== 'string' || !value.name.trim() || value.name.trim().length > 200) throw new Error('Use a product name of 1–200 characters.');
    if (typeof value.value !== 'string' || !value.value.length || new TextEncoder().encode(value.value).length > 1024) throw new Error('Use a key of 1–1024 UTF-8 bytes.');
    if (!timestamp(value.issuedAt) || !timestamp(value.acceptBy) || value.acceptBy - value.issuedAt !== LIFETIME_MS) throw new Error('Invalid invitation acceptance dates.');
    return { kind: KIND, version: 1, id: value.id.toLowerCase(), name: value.name.trim(), value: value.value, issuedAt: value.issuedAt, acceptBy: value.acceptBy };
  }

  function generateKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return 'tlk1_' + Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  function create({ name = DEFAULT_NAME, value = generateKey() } = {}) {
    const issuedAt = Date.now();
    return validate({ kind: KIND, version: 1, id: crypto.randomUUID(), name, value, issuedAt, acceptBy: issuedAt + LIFETIME_MS });
  }

  function encode(invitation) {
    const bytes = new TextEncoder().encode(JSON.stringify(validate(invitation)));
    return btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
  }

  function decode(token) {
    if (typeof token !== 'string' || !token || token.length > MAX_TOKEN_LENGTH || !/^[A-Za-z0-9_-]+$/.test(token)) throw new Error('Invalid invitation link.');
    let parsed;
    try {
      const binary = atob(token.replaceAll('-', '+').replaceAll('_', '/'));
      parsed = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(binary, char => char.charCodeAt(0))));
    } catch (_) { throw new Error('Invalid invitation link.'); }
    const invitation = validate(parsed);
    if (encode(invitation) !== token) throw new Error('Invalid invitation encoding.');
    return invitation;
  }

  function link(invitation) { return `${INVITE_ORIGIN}/invite#tli=${encode(invitation)}`; }

  async function accept(value) {
    const invitation = validate(value);
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(encode(invitation)));
    const fingerprint = Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('');
    return TypelockerSettings.update(latest => {
      const now = Date.now();
      if (invitation.issuedAt > now + 5 * 60 * 1000) throw new Error('This invitation is dated in the future. Check this device’s clock.');
      const receipts = latest.invitationReceipts || [];
      let receipt = receipts.find(item => item.id === invitation.id);
      const existing = latest.keys.find(key => key.invitationId === invitation.id);
      if (receipt && receipt.fingerprint !== fingerprint) throw new Error('This link conflicts with an earlier invitation.');
      if (existing && (existing.name !== invitation.name || existing.value !== invitation.value)) throw new Error('This link conflicts with a saved invitation.');
      // Existing accepted keys can be selected after the invitation deadline,
      // until their own seven-day lifetime ends. Opening never resets it.
      if (!receipt && existing) receipt = { id: invitation.id, acceptedAt: existing.createdAt, expiresAt: existing.expiresAt, acceptBy: invitation.acceptBy, fingerprint };
      if (!receipt) {
        if (invitation.acceptBy <= now) throw new Error('This invitation has expired. Ask the sender for a new invitation.');
        receipt = { id: invitation.id, acceptedAt: now, expiresAt: now + LIFETIME_MS, acceptBy: invitation.acceptBy, fingerprint };
      }
      if (receipt.expiresAt <= now) throw new Error('This seven-day key has expired. Ask the sender for a new invitation.');
      const id = existing?.id || `invite-${invitation.id}`;
      if (!existing && latest.keys.filter(key => key.expiresAt !== undefined).length >= TypelockerSettings.MAX_TEMP_KEYS) throw new Error('All 100 seven-day key slots are in use. Delete an entry or wait for one to expire.');
      const key = { id, name: invitation.name, value: invitation.value, invitationId: invitation.id, createdAt: receipt.acceptedAt, expiresAt: receipt.expiresAt };
      return { ...latest, keys: existing ? latest.keys : [...latest.keys, key], selectedKeyId: id,
        invitationReceipts: [...receipts.filter(item => item.id !== invitation.id), receipt] };
    });
  }

  globalThis.TypelockerInvitations = Object.freeze({ KIND, LIFETIME_MS, INVITE_ORIGIN, DEFAULT_NAME, MAX_TOKEN_LENGTH, validate, generateKey, create, encode, decode, link, accept });
})();
