/* Local settings shared by the popup, options page and isolated content script. */
(() => {
  'use strict';
  const DEFAULT_KEY = '0xd125A6515F5280cb424cBCe36BE8213C5C6db406';
  const STORAGE_KEY = 'typelockerSettings';
  const KEY_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;
  const MAX_TEMP_KEYS = 100;
  const defaults = () => ({ version: 1, keys: [], selectedKeyId: 'default', enabled: true });
  const timestamp = value => Number.isSafeInteger(value) && value > 0;

  function validate(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid key configuration.');
    if (value.version !== undefined && value.version !== 1) throw new Error('Unsupported configuration version.');
    if (!Array.isArray(value.keys)) throw new Error('The configuration must include a keys array.');
    const ids = new Set();
    const keys = value.keys.map(key => {
      if (!key || typeof key.id !== 'string' || !key.id || key.id === 'default' || ids.has(key.id)) throw new Error('Custom keys must have unique IDs.');
      if (typeof key.name !== 'string' || !key.name.trim()) throw new Error('Each key needs a name.');
      if (typeof key.value !== 'string' || !key.value.length) throw new Error('Each key needs a value.');
      ids.add(key.id);
      const clean = { id: key.id, name: key.name.trim(), value: key.value };
      if (['invitationId', 'createdAt', 'expiresAt'].some(field => key[field] !== undefined)) {
        if (typeof key.invitationId !== 'string' || !key.invitationId || !timestamp(key.createdAt) || !timestamp(key.expiresAt) || key.expiresAt - key.createdAt !== KEY_LIFETIME_MS) throw new Error('Temporary keys must expire exactly seven days after acceptance.');
        Object.assign(clean, { invitationId: key.invitationId, createdAt: key.createdAt, expiresAt: key.expiresAt });
      }
      return clean;
    });
    if (keys.filter(key => key.expiresAt !== undefined).length > MAX_TEMP_KEYS) throw new Error('Up to 100 active seven-day keys can be stored.');
    const invitationIds = keys.filter(key => key.invitationId).map(key => key.invitationId);
    if (new Set(invitationIds).size !== invitationIds.length) throw new Error('Invitation IDs must be unique.');
    const selectedKeyId = value.selectedKeyId ?? 'default';
    if (selectedKeyId !== 'default' && !ids.has(selectedKeyId)) throw new Error('The selected key is missing.');
    if (value.enabled !== undefined && typeof value.enabled !== 'boolean') throw new Error('Automatic decoding must be true or false.');
    const clean = { version: 1, keys, selectedKeyId, enabled: value.enabled ?? true };
    if (value.invitationReceipts !== undefined) {
      if (!Array.isArray(value.invitationReceipts)) throw new Error('Invalid invitation receipts.');
      const receipts = new Set();
      clean.invitationReceipts = value.invitationReceipts.map(receipt => {
        if (!receipt || typeof receipt.id !== 'string' || !receipt.id || receipts.has(receipt.id) || !timestamp(receipt.acceptedAt) || !timestamp(receipt.expiresAt) || !timestamp(receipt.acceptBy) || receipt.expiresAt - receipt.acceptedAt !== KEY_LIFETIME_MS || !/^[a-f0-9]{64}$/.test(receipt.fingerprint)) throw new Error('Invalid invitation receipt.');
        receipts.add(receipt.id);
        return { id: receipt.id, acceptedAt: receipt.acceptedAt, expiresAt: receipt.expiresAt, acceptBy: receipt.acceptBy, fingerprint: receipt.fingerprint };
      });
    }
    return clean;
  }

  function pruneExpired(value, now = Date.now()) {
    const settings = validate(value);
    settings.keys = settings.keys.filter(key => key.expiresAt === undefined || key.expiresAt > now);
    if (settings.selectedKeyId !== 'default' && !settings.keys.some(key => key.id === settings.selectedKeyId)) settings.selectedKeyId = 'default';
    if (settings.invitationReceipts) {
      settings.invitationReceipts = settings.invitationReceipts.filter(receipt => Math.max(receipt.expiresAt, receipt.acceptBy) > now);
      if (!settings.invitationReceipts.length) delete settings.invitationReceipts;
    }
    return settings;
  }

  let mutationTail = Promise.resolve();
  const LOCK_NAME = 'typelocker-chat-local-settings';

  function serialized(action) {
    const run = () => {
      // Extension popup and options documents share an origin, and therefore
      // this lock. The promise chain also protects contexts without Web Locks.
      const locks = globalThis.navigator?.locks;
      return locks?.request ? locks.request(LOCK_NAME, { mode: 'exclusive' }, action) : action();
    };
    const result = mutationTail.then(run, run);
    mutationTail = result.catch(() => {});
    return result;
  }

  async function persist(value) {
    const settings = pruneExpired(value);
    await chrome.storage.local.set({ [STORAGE_KEY]: settings });
    return settings;
  }

  async function readStored() {
    return chrome.storage.local.get([STORAGE_KEY, 'defaultKey', 'additionalKeys', 'enabled']);
  }

  const hasLegacy = stored => ['defaultKey', 'additionalKeys', 'enabled'].some(key => stored[key] !== undefined);

  async function readLatest() {
    const stored = await readStored();
    if (stored[STORAGE_KEY]) return pruneExpired(stored[STORAGE_KEY]);
    // A content script reading fresh defaults must not overwrite a popup edit
    // with an unnecessary initialization write.
    if (!hasLegacy(stored)) return defaults();
    const settings = defaults();
    const oldKeys = [];
    if (typeof stored.defaultKey === 'string' && stored.defaultKey && stored.defaultKey !== DEFAULT_KEY) oldKeys.push(stored.defaultKey);
    if (Array.isArray(stored.additionalKeys)) oldKeys.push(...stored.additionalKeys.filter(key => typeof key === 'string' && key && key !== DEFAULT_KEY));
    settings.keys = [...new Set(oldKeys)].map((value, index) => ({ id: `migrated-${index + 1}`, name: index === 0 && value === stored.defaultKey ? 'Previous custom key' : `Imported key ${index + 1}`, value }));
    if (stored.defaultKey && stored.defaultKey !== DEFAULT_KEY && settings.keys.length) settings.selectedKeyId = settings.keys[0].id;
    settings.enabled = typeof stored.enabled === 'boolean' ? stored.enabled : true;
    // Called inside the mutation lock. Do not recursively call save().
    await persist(settings);
    await chrome.storage.local.remove(['defaultKey', 'additionalKeys', 'enabled']);
    return settings;
  }

  async function load() {
    const stored = await readStored();
    if (stored[STORAGE_KEY]) return pruneExpired(stored[STORAGE_KEY]);
    if (!hasLegacy(stored)) return defaults();
    // Re-read after acquiring the lock: a different extension document might
    // already have migrated or changed the configuration in the meantime.
    return serialized(readLatest);
  }

  function save(value) {
    // save() intentionally replaces the whole configuration (for import).
    // Copy and validate at invocation so a queued caller cannot change it.
    let next;
    try { next = pruneExpired(value); } catch (error) { return Promise.reject(error); }
    return serialized(async () => {
      // Imports replace keys/preferences, but cannot renew an invitation that
      // this Chrome profile has already accepted or deliberately deleted.
      const latest = await readLatest();
      const receipts = new Map((next.invitationReceipts || []).map(receipt => [receipt.id, receipt]));
      for (const receipt of latest.invitationReceipts || []) {
        const imported = receipts.get(receipt.id);
        if (imported && imported.fingerprint !== receipt.fingerprint) throw new Error('This invitation conflicts with an earlier acceptance.');
        if (!imported || receipt.acceptedAt < imported.acceptedAt) receipts.set(receipt.id, receipt);
      }
      const merged = { ...next };
      if (receipts.size) merged.invitationReceipts = [...receipts.values()];
      merged.keys = merged.keys.map(key => {
        const receipt = receipts.get(key.invitationId);
        return receipt ? { ...key, createdAt: receipt.acceptedAt, expiresAt: receipt.expiresAt } : key;
      });
      return persist(merged);
    });
  }

  function purgeExpired() {
    return serialized(async () => {
      const stored = await readStored();
      if (!stored[STORAGE_KEY]) return readLatest();
      const clean = pruneExpired(stored[STORAGE_KEY]);
      if (JSON.stringify(clean) !== JSON.stringify(stored[STORAGE_KEY])) await chrome.storage.local.set({ [STORAGE_KEY]: clean });
      return clean;
    });
  }

  function update(mutator) {
    if (typeof mutator !== 'function') return Promise.reject(new Error('A settings update function is required.'));
    return serialized(async () => {
      const latest = await readLatest();
      const result = await mutator(latest);
      return persist(result === undefined ? latest : result);
    });
  }

  function activeKey(settings) {
    return settings.keys.find(key => key.id === settings.selectedKeyId && (key.expiresAt === undefined || key.expiresAt > Date.now()))?.value ?? DEFAULT_KEY;
  }

  globalThis.TypelockerSettings = Object.freeze({ DEFAULT_KEY, STORAGE_KEY, KEY_LIFETIME_MS, MAX_TEMP_KEYS, defaults, validate, pruneExpired, purgeExpired, load, save, update, activeKey });
})();
