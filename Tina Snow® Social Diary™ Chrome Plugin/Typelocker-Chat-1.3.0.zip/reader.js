/* Bundled, explicit-consent diary reader. Never transmits plaintext or keys. */
(() => {
  'use strict';
  const fragment = location.hash;
  try { history.replaceState(null, '', location.pathname + location.search); } catch (_) {}
  const token = /^#tld=([A-Za-z0-9_-]+)$/.exec(fragment)?.[1];
  let access = null;
  let acceptedKey = null;
  let pending = false;
  let controller = null;
  let expiryTimer = null;
  let generation = 0;
  const label = milliseconds => new Date(milliseconds).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

  document.addEventListener('DOMContentLoaded', async () => {
    const $ = id => document.getElementById(id);
    const status = (message, error = false) => { $('status').textContent = message; $('status').classList.toggle('error', error); };
    function clearPlaintext() { $('plaintext').textContent = ''; $('decoded-section').hidden = true; }
    function deadline() { return Math.min(acceptedKey?.expiresAt || Infinity, access?.diary.expiresAt || 0); }
    function valid() { return acceptedKey && deadline() > Date.now(); }
    function ensureValid() { if (!valid()) throw new Error('Diary access or the accepted key has expired.'); }
    function expire() {
      if (!access) return;
      if (access.diary.expiresAt <= Date.now() || (acceptedKey && acceptedKey.expiresAt <= Date.now())) {
        generation++;
        controller?.abort();
        acceptedKey = null;
        clearPlaintext();
        $('download').disabled = true;
        $('accept').disabled = true;
        status('Diary access or the accepted key has expired. Decoded content has been cleared.', true);
      } else scheduleExpiry();
    }
    function scheduleExpiry() {
      if (expiryTimer !== null) clearTimeout(expiryTimer);
      expiryTimer = null;
      const until = deadline();
      if (Number.isFinite(until) && until > 0) expiryTimer = setTimeout(expire, Math.min(60_000, Math.max(1, until - Date.now())));
    }
    $('cancel').addEventListener('click', () => {
      generation++;
      controller?.abort();
      clearPlaintext();
      $('progress').hidden = true;
      $('download').disabled = !valid();
      status('Download cancelled and decoded content cleared. Accepted keys remain in your local settings.');
    });
    $('accept').addEventListener('click', async () => {
      if (!access || pending) return;
      if (access.diary.expiresAt <= Date.now()) { expire(); return; }
      pending = true;
      $('accept').disabled = true;
      try {
        const saved = await TypelockerInvitations.accept(access.invitation);
        acceptedKey = saved.keys.find(key => key.invitationId === access.invitation.id);
        ensureValid();
        $('key-expiry').textContent = label(acceptedKey.expiresAt);
        $('accept').textContent = 'Key accepted';
        $('download').disabled = false;
        scheduleExpiry();
        status('Key accepted and selected. Choose Download and Decode to allow the displayed server.');
      } catch (error) {
        acceptedKey = null;
        status(error.message || 'The invitation could not be accepted.', true);
        $('accept').disabled = false;
      } finally { pending = false; }
    });
    $('download').addEventListener('click', async () => {
      if (!access || !acceptedKey || pending) return;
      const current = ++generation;
      pending = true;
      $('download').disabled = true;
      clearPlaintext();
      controller = new AbortController();
      const signal = controller.signal;
      try {
        ensureValid();
        // Request only the displayed host and only within this button gesture.
        const granted = await chrome.permissions.request({ origins: [TypelockerDiaryAccess.permissionOrigin(access.diary.contentUrl)] });
        if (!granted) throw new Error('Server permission was declined. No diary was downloaded.');
        if (current !== generation) return;
        ensureValid();
        status('Downloading encoded BSK1 diary…');
        $('progress').hidden = false;
        $('progress').max = access.diary.byteLength;
        $('progress').value = 0;
        const response = await fetch(access.diary.contentUrl, { method: 'GET', credentials: 'omit', redirect: 'error', referrerPolicy: 'no-referrer', cache: 'no-store', signal });
        if (!response.ok || response.redirected || (response.url && response.url !== access.diary.contentUrl)) throw new Error('The diary server refused the download or returned an unexpected destination.');
        const lengthHeader = response.headers.get('content-length');
        if (lengthHeader !== null && (!/^\d+$/.test(lengthHeader) || Number(lengthHeader) !== access.diary.byteLength)) throw new Error('The diary download size does not match its access link.');
        if (!response.body?.getReader) throw new Error('This response does not provide a readable diary stream.');
        const bytes = new Uint8Array(access.diary.byteLength);
        const utf8 = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
        const pieces = [];
        let text = '';
        let received = 0;
        const stream = response.body.getReader();
        try {
          while (true) {
            ensureValid();
            if (signal.aborted || current !== generation) throw new DOMException('Cancelled', 'AbortError');
            const { done, value } = await stream.read();
            if (done) break;
            ensureValid();
            if (!(value instanceof Uint8Array) || received + value.byteLength > bytes.byteLength) throw new Error('The diary download exceeded its declared size.');
            bytes.set(value, received);
            received += value.byteLength;
            text += utf8.decode(value, { stream: true });
            if (text.length >= 65_536) { pieces.push(text); text = ''; }
            $('progress').value = received;
          }
          if (received !== access.diary.byteLength) throw new Error('The diary download ended before its declared size.');
          text += utf8.decode();
          pieces.push(text);
        } catch (error) { await stream.cancel().catch(() => {}); throw error; }
        finally { stream.releaseLock(); }
        ensureValid();
        const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), byte => byte.toString(16).padStart(2, '0')).join('');
        if (hash !== access.diary.sha256) throw new Error('The diary integrity check failed. Nothing was decoded.');
        const plaintext = decodeBishiki(pieces.join(''), acceptedKey.value);
        if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/u.test(plaintext)) throw new Error('This diary could not be decoded with the accepted key.');
        ensureValid();
        if (signal.aborted || current !== generation) return;
        $('plaintext').textContent = plaintext + ' (Decoded with Typelocker™)';
        $('decoded-section').hidden = false;
        scheduleExpiry();
        const acknowledgementURL = access.diary.contentUrl.replace(/\/content$/, '/ack');
        try {
          ensureValid();
          const acknowledgement = await fetch(acknowledgementURL, { method: 'POST', credentials: 'omit', redirect: 'error', referrerPolicy: 'no-referrer', cache: 'no-store', signal,
            headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sha256: hash, outcome: 'decoded' }) });
          ensureValid();
          if (current !== generation) return;
          status(acknowledgement.ok ? 'Decoded locally. A client-reported decode acknowledgement was recorded; it does not prove human reading.' : 'Decoded locally. The server did not confirm the client-reported acknowledgement.');
        } catch (_) { if (current === generation && valid()) status('Decoded locally. The client-reported acknowledgement could not be confirmed.'); }
      } catch (error) {
        if (current === generation) {
          clearPlaintext();
          status(error.name === 'AbortError' ? 'Download cancelled.' : (error.message || 'The diary could not be read.'), true);
        }
      } finally {
        if (current === generation) {
          pending = false;
          controller = null;
          $('download').disabled = !valid();
          $('progress').hidden = true;
        } else pending = false;
      }
    });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) expire(); });
    window.addEventListener('focus', expire);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !acceptedKey || !changes[TypelockerSettings.STORAGE_KEY]) return;
      TypelockerSettings.load().then(saved => {
        if (acceptedKey && !saved.keys.some(key => key.invitationId === access.invitation.id && key.value === acceptedKey.value && key.expiresAt > Date.now())) {
          generation++;
          controller?.abort();
          acceptedKey = null;
          clearPlaintext();
          $('download').disabled = true;
          status('The accepted key is no longer available. Decoded content has been cleared.', true);
        }
      }).catch(() => {});
    });
    try {
      if (!token) throw new Error('Open a complete diary access link to use this reader.');
      access = TypelockerDiaryAccess.decode(token);
      $('diary-title').textContent = access.diary.title;
      $('invitation-name').textContent = access.invitation.name;
      $('diary-server').textContent = new URL(access.diary.contentUrl).origin;
      $('diary-size').textContent = `${access.diary.byteLength.toLocaleString()} bytes (maximum 64 MiB)`;
      $('diary-expiry').textContent = label(access.diary.expiresAt);
      $('review').hidden = false;
      $('accept').disabled = access.diary.expiresAt <= Date.now();
      scheduleExpiry();
      if ($('accept').disabled) expire();
      else status('Review the diary and server. Nothing has been accepted or downloaded.');
    } catch (error) { access = null; status(error.message || 'Invalid diary access link.', true); }
  });
})();
