/* A local expiry alarm and a narrowly scoped invitation handoff. */
importScripts('settings.js', 'invitations.js', 'diary-access.js');
(() => {
  'use strict';
  const ALARM = 'typelocker-expire-seven-day-keys';
  let cleanupTail = Promise.resolve();
  function cleanup() {
    const work = async () => {
      const settings = await TypelockerSettings.purgeExpired();
      const next = settings.keys.filter(key => key.expiresAt).map(key => key.expiresAt)
        .concat((settings.invitationReceipts || []).map(receipt => Math.max(receipt.expiresAt, receipt.acceptBy)));
      await chrome.alarms.clear(ALARM);
      if (next.length) {
        // Chrome 109 returns void from create(). Alarms can be delayed; key
        // validity is checked independently by settings and every UI context.
        chrome.alarms.create(ALARM, { when: Math.max(Date.now() + 60_000, Math.min(...next)) });
      }
    };
    const result = cleanupTail.then(work, work);
    cleanupTail = result.catch(() => {});
    return result;
  }
  function isInvitationPage(sender) {
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || !sender.tab) return false;
    try {
      const url = new URL(sender.url);
      return url.origin === TypelockerInvitations.INVITE_ORIGIN && !url.search && !url.username && !url.password && ['/invite', '/invite/', '/invite.html'].includes(url.pathname);
    } catch (_) { return false; }
  }
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (message?.type === 'TYPELOCKER_EXPIRE_KEYS') {
      cleanup().then(() => reply({ ok: true }), () => reply({ ok: false, error: 'Local cleanup could not complete.' }));
      return true;
    }
    if (!['TYPELOCKER_OPEN_INVITATION', 'TYPELOCKER_OPEN_DIARY_ACCESS'].includes(message?.type)) return false;
    if (!isInvitationPage(sender)) { reply({ ok: false, error: 'Open invitations from the official support page.' }); return false; }
    const isDiary = message.type === 'TYPELOCKER_OPEN_DIARY_ACCESS';
    const protocol = isDiary ? TypelockerDiaryAccess : TypelockerInvitations;
    let token;
    try { token = protocol.encode(protocol.decode(message.token)); }
    catch (_) { reply({ ok: false, error: 'Invalid invitation link.' }); return false; }
    // The destination is always bundled extension UI, never a caller URL.
    chrome.tabs.create({ url: chrome.runtime.getURL(isDiary ? 'reader.html' : 'invitation.html') + (isDiary ? '#tld=' : '#tli=') + token })
      .then(() => reply({ ok: true }), () => reply({ ok: false, error: 'The invitation could not be opened.' }));
    return true;
  });
  chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM) cleanup().catch(() => {}); });
  chrome.runtime.onStartup.addListener(() => cleanup().catch(() => {}));
  chrome.runtime.onInstalled.addListener(() => cleanup().catch(() => {}));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[TypelockerSettings.STORAGE_KEY]) cleanup().catch(() => {});
  });
  // Recreate alarms after every service worker restart as well as browser startup.
  cleanup().catch(() => {});
})();
