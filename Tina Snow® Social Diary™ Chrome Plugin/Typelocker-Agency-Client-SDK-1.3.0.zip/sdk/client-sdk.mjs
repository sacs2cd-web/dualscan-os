// Browser/Node 20+ agency SDK. Keep invitations.js beside this sdk directory.
// This module creates local invitation data; it never sends email or requests.
import '../invitations.js';
const protocol = globalThis.TypelockerInvitations;

export const DEFAULT_PRODUCT_NAME = protocol.DEFAULT_NAME;
export const KEY_LIFETIME_DAYS = 7;
export const SDK_VERSION = '1.3.0';
export const PLUGIN_CAPABILITIES = Object.freeze({ minimumExtensionVersion: '1.3.0', minimumInvitationExtensionVersion: '1.2.0', invitationProtocolVersion: 1,
  temporaryKeyLimit: 100, keyLifetimeStarts: 'first-local-acceptance',
  diaryDescriptorVersion: 1, diaryAccessProtocolVersion: 1, maximumDiaryBytes: 64 * 1024 * 1024, remoteDiaryReader: 'configured-gateway-supported' });

export function generateKey() { return protocol.generateKey(); }

export function createClientAccess({ productName = DEFAULT_PRODUCT_NAME, key } = {}) {
  const invitation = protocol.create({ name: productName, ...(key === undefined ? {} : { value: key }) });
  return Object.freeze({ invitation: Object.freeze(invitation), invitationUrl: protocol.link(invitation),
    acceptBy: new Date(invitation.acceptBy).toISOString(), lifetimeDays: KEY_LIFETIME_DAYS });
}

export function readInvitationLink(link) {
  let url;
  try { url = new URL(link); } catch (_) { throw new Error('Choose a complete invitation URL.'); }
  if (url.username || url.password || url.origin !== protocol.INVITE_ORIGIN || !['/invite', '/invite/', '/invite.html'].includes(url.pathname) || url.search || !/^#tli=[A-Za-z0-9_-]+$/.test(url.hash)) throw new Error('Choose an official Typelocker invitation URL.');
  return protocol.decode(url.hash.slice(5));
}

const modes = new Set(['public', 'private', 'invitation', 'paid']);
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/.test(value);

function httpsUrl(value) {
  let url;
  try { url = new URL(value); } catch (_) { throw new Error('Use a complete HTTPS platform URL.'); }
  const host = url.hostname.toLowerCase();
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || host.endsWith('.') || !host.includes('.') || /[:\[\]]/.test(host) || /^[0-9.]+$/.test(host) || /(^|\.)(localhost|local|internal|test|invalid)$/.test(host)) throw new Error('Use a public HTTPS hostname without credentials or a fragment.');
  return url;
}

function origin(value) {
  const url = httpsUrl(value);
  if (url.pathname !== '/' || url.search) throw new Error('Configure an HTTPS origin without a path or query.');
  return url.origin;
}

/** Prepare one private grant record and one short email URL. No delivery/fetch. */
export async function createServerAccess({ platformOrigin, clientId, diaryId, recipientId, productName = DEFAULT_PRODUCT_NAME, key, mode = 'invitation' } = {}) {
  const base = origin(platformOrigin);
  if (!identifier(clientId) || !identifier(diaryId)) throw new Error('Use opaque clientId and diaryId values of 1–128 characters.');
  if (recipientId !== undefined && !identifier(recipientId)) throw new Error('Use an opaque recipientId, not an email address.');
  if (!modes.has(mode)) throw new Error('Choose public, private, invitation, or paid access.');
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token));
  const tokenSha256 = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  const local = createClientAccess({ productName, key });
  const keyRef = crypto.randomUUID();
  const serverRecord = Object.freeze({ kind: 'typelocker-server-access', version: 1, grantId: crypto.randomUUID(),
    clientId, diaryId, ...(recipientId === undefined ? {} : { recipientId }), mode, tokenSha256, keyRef, invitationId: local.invitation.id });
  return Object.freeze({ emailUrl: `${base}/d/${token}`, serverRecord,
    keyMaterial: Object.freeze({ keyRef, invitation: local.invitation }), extensionHandoffUrl: local.invitationUrl });
}

/** Metadata contract for future platform readers; never includes diary bytes. */
export function validateDiaryDescriptor(value, { platformOrigin, storageOrigins = [] } = {}) {
  const allowed = new Set([origin(platformOrigin), ...storageOrigins.map(origin)]);
  if (!value || value.kind !== 'typelocker-diary' || value.version !== 1 || value.format !== 'BSK1') throw new Error('Unsupported diary descriptor.');
  if (![value.clientId, value.diaryId, value.grantId].every(identifier)) throw new Error('Invalid diary identifiers.');
  if (typeof value.title !== 'string' || !value.title.trim() || value.title.trim().length > 200) throw new Error('Use a diary title of 1–200 characters.');
  if (['body', 'data', 'ciphertext', 'payload'].some(field => value[field] !== undefined)) throw new Error('Keep diary payloads on the server, outside descriptors and email URLs.');
  const content = value.content;
  if (content && ['body', 'data', 'ciphertext', 'payload'].some(field => content[field] !== undefined)) throw new Error('Keep diary payloads on the server, outside descriptors and email URLs.');
  if (!content || typeof content.url !== 'string' || content.url.length > 4096 || !Number.isSafeInteger(content.byteLength) || content.byteLength < 1 || typeof content.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(content.sha256)) throw new Error('Invalid diary content metadata.');
  const url = httpsUrl(content.url);
  if (!allowed.has(url.origin)) throw new Error('The diary content origin is not configured.');
  return Object.freeze({ kind: 'typelocker-diary', version: 1, clientId: value.clientId, diaryId: value.diaryId,
    grantId: value.grantId, title: value.title.trim(), format: 'BSK1',
    content: Object.freeze({ url: url.href, byteLength: content.byteLength, sha256: content.sha256 }) });
}
