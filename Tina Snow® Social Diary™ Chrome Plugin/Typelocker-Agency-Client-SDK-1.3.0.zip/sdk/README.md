# Typelocker™ Chat agency Client SDK 1.3.0

Pure browser/Node 20+ helpers for agency key invitations and configured-gateway data preparation. Keep `sdk` beside `invitations.js` and `diary-access.js`. The SDK makes no fetch, email, extension-storage or permission calls. Native Mac application, server deployment and listmonk delivery are separate components.

```js
import { createClientAccess, createServerAccess } from './sdk/client-sdk.mjs';
const local = createClientAccess({ productName: 'Tina Snow® Social Diary™ - Beyonce' });
// Omit key for a fresh random 32-byte key; pass key to share an existing content key.
const prepared = await createServerAccess({
  platformOrigin: configuredHTTPSOrigin,
  clientId: tenantUuid,
  diaryId: diaryUuid,
  recipientId: opaqueFanId,
  productName: 'Tina Snow® Social Diary™ - Beyonce',
  mode: 'invitation'
});
// Email template: prepared.emailUrl (short opaque URL only).
// Backend metadata: prepared.serverRecord (hash and opaque references; no raw key).
// Mac key vault / deliberate authorized delivery: prepared.keyMaterial.
// Existing key-only handoff: prepared.extensionHandoffUrl (contains a readable key).
```

`generateKey()` returns `tlk1_` plus 64 hexadecimal characters from 32 random bytes. `createClientAccess()` returns a frozen v1 invitation, full invitation URL, acceptance deadline and seven-day lifetime. `readInvitationLink()` parses only canonical official key-only routes. Default product name is **Tina Snow® Social Diary™ - Beyonce**; extension branding stays Typelocker™ Chat.

## Compatibility and first acceptance

Key-only v1 invitations work with extension **1.2.0+**. Explicit first acceptance starts seven days in that Chrome profile; reopening/deleting/reaccepting never resets the original deadline. First acceptance must occur within seven days of creation. Up to 100 active temporary keys are manually selectable beside permanent keys. Chrome resume checks catch up after sleep. Local expiry cannot revoke copied keys/content or establish identity, payment or server authorization.

Reader protocol v1 requires extension **1.3.0+** and a configured compatible gateway. `PLUGIN_CAPABILITIES` distinguishes `minimumExtensionVersion:'1.3.0'`, `minimumInvitationExtensionVersion:'1.2.0'`, and `remoteDiaryReader:'configured-gateway-supported'`. The reader's maximum is 64 MiB encoded bytes.

## Opaque server preparation

`createServerAccess({platformOrigin,clientId,diaryId,recipientId?,productName?,key?,mode?})` returns a short HTTPS `/d/<43-character random token>` URL. The server record stores SHA-256 of the exact UTF-8 token string, grant UUID, opaque tenant/diary/optional fan IDs, mode, key reference and invitation ID. It includes no raw invitation/key, email address or diary payload. `keyMaterial` is a separate frozen secret-bearing object. `extensionHandoffUrl` is a readable bearer key; do not put it in tracking attributes or general server logs.

Platform origin is explicit and must be a public HTTPS DNS origin without credentials, path, query or fragment. No host is inferred or contacted. Modes `public`, `private`, `invitation`, `paid` are data labels; an actual configured backend must enforce its own identity/access/payment policy. Preparing a record neither creates that backend nor authorizes a recipient.

`validateDiaryDescriptor(value,{platformOrigin,storageOrigins?})` validates a generic v1 metadata descriptor with IDs/title, format BSK1, exact configured HTTPS content origin, positive safe-integer byte length and SHA-256. It rejects inline diary payloads and performs no download. Generic descriptor size support is not the concrete reader's 64 MiB envelope limit.

## Canonical reader metadata

A compatible gateway emits the separate `typelocker-diary-access` envelope documented in [DIARY-READER-PROTOCOL.md](../docs/DIARY-READER-PROTOCOL.md). To encode a prepared envelope with the same implementation used by the extension:

```js
import './sdk/client-sdk.mjs'; // loads the existing invitation protocol
import './diary-access.js';
const token = globalThis.TypelockerDiaryAccess.encode(accessEnvelope);
// Deliberately deliver via the documented official /invite#tld= handoff.
```

The envelope contains a v1 invitation and bounded server content metadata; no diary payload. The complete handoff carries the readable key and bearer content URL. The short email URL remains only an opaque resolver token. Keep key-bearing handoffs out of listmonk analytics and untrusted logs.

The bundled reader reviews metadata, accepts a key, separately requests user permission for the displayed host, streams credential-free encoded bytes, verifies size/SHA-256 and decodes locally. It may report only digest/outcome to the grant's acknowledgement endpoint. That is a client-reported decode event, not proof of human reading. BSK1 remains reversible obfuscation, not secure encryption.

See [Mac integration](../docs/MACOS-INTEGRATION.md) and [invitation protocol](../docs/INVITATION-PROTOCOL.md). This SDK performs no deployment, buyer import, SMTP sending, payment processing or capacity test.
