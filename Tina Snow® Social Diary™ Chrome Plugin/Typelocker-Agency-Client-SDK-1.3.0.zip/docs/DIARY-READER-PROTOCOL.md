# Diary reader protocol v1 — extension 1.3.0

This additive protocol keeps original BSK1 and v1 key invitations unchanged. `diary-access.js` is the canonical encoder/validator. No validation operation fetches content, accepts an invitation or requests permissions.

## Envelope and handoff

The complete access object is encoded as UTF-8 canonical JSON, then unpadded base64url, and placed in the official support route fragment `https://typelocker-chat-support.alleong.chatgpt.site/invite#tld=TOKEN`. A short email URL may first resolve through a separately configured gateway. The short URL contains only an opaque token; it is not the payload-bearing handoff URL.

```json
{
  "kind": "typelocker-diary-access",
  "version": 1,
  "invitation": {
    "kind": "typelocker-key-invitation",
    "version": 1,
    "id": "11111111-1111-4111-8111-111111111111",
    "name": "Diary key",
    "value": "shared-content-key",
    "issuedAt": 1793044800000,
    "acceptBy": 1793649600000
  },
  "diary": {
    "clientId": "22222222-2222-4222-8222-222222222222",
    "diaryId": "33333333-3333-4333-8333-333333333333",
    "title": "Diary title",
    "contentUrl": "https://diary.example.com/d/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/content",
    "byteLength": 100,
    "sha256": "abababababababababababababababababababababababababababababababab",
    "expiresAt": 1793649600000
  }
}
```

This illustrates structure, not a valid live grant or hash for an actual diary. Encode using `TypelockerDiaryAccess.encode(value)` to obtain exact canonical field order, normalized identifiers and base64url; decoding rejects noncanonical/unknown fields and malformed UTF-8. The invitation follows [its existing protocol](INVITATION-PROTOCOL.md). `clientId` and `diaryId` are UUID strings. Title is trimmed to 1–200 characters, `byteLength` is a positive safe integer at most 67,108,864, `sha256` is 64 lowercase hexadecimal characters, and `expiresAt` is a positive integer Unix timestamp in milliseconds. Tokens are bounded to 24,576 characters.

The only accepted content path is `/d/<43 base64url characters>/content`. Public HTTPS DNS hostnames are accepted; development may use HTTP `127.0.0.1` or `localhost`. Credentials, queries, fragments, private IP HTTPS destinations, reserved/local DNS suffixes, malformed hosts and other paths are rejected. The extension does not infer a provider from an email address or trust arbitrary redirects. URLs and metadata are bearer data, not signed identity assertions.

The official top-frame landing bridge sends `TYPELOCKER_OPEN_DIARY_ACCESS` to the worker. The worker independently validates the envelope and exact official route before opening only bundled `reader.html#tld=TOKEN`; caller-supplied destinations are ignored. Fragments are removed from the landing/current reader history entry after handoff/before review. A handoff opens review UI without accepting or downloading.

## Explicit acceptance and server permission

Accept and select key invokes the original invitation lifecycle: seven days starts at first local acceptance and never renews on reopening. Download and Decode is a separate user action. It asks `chrome.permissions.request` for the actual hostname pattern, then fetches the already validated exact URL. Chrome match patterns do not scope ports; the reader retains exact URL/port matching itself. Denial performs no download. Optional hosts are not mandatory all-site access and do not add content scripts to gateway sites.

## Retrieval, decode and expiry

GET uses `credentials:'omit'`, `redirect:'error'`, `referrerPolicy:'no-referrer'` and `cache:'no-store'`. A readable response stream is required. Each chunk is counted against the declared/maximum size and checked with a fatal streaming UTF-8 decoder, including glyphs split across chunks. Exact final byte count and SHA-256 of encoded bytes must match before BSK1 decoding. The reader keeps a bounded encoded buffer and complete-token text for the original codec; this is not an unbounded streaming codec.

Only the accepted invitation key is used, even if another saved key is selected elsewhere. Key deletion or expiry clears the reader. The earlier of local acceptance expiry and server expiry governs display. In-progress downloads check that deadline repeatedly; timers and focus/visibility changes clear displayed plaintext and abort on expiry. Local clock manipulation and copies retained outside the extension cannot be revoked by these controls.

Plaintext is rendered via `textContent`, never HTML execution, and is not stored. Cancel/Clear aborts the transfer and clears display. It leaves the explicitly accepted key in local settings for its original lifetime.

## Client-reported acknowledgement

Only after successful integrity validation and local decode, POST to the same URL with `/content` replaced by `/ack`:

```json
{"sha256":"<the encoded object digest>","outcome":"decoded"}
```

The same credential/referrer/redirect restrictions apply. No plaintext, key or email address is sent. A failed decode does not produce an acknowledgement. The server can associate this bearer request with its grant, but the event remains client-reported: it does not prove an untampered decoder, a particular person's identity, or human reading. Failed acknowledgement delivery does not masquerade as recorded success.

## Gateway responsibilities

The provider controls its HTTPS endpoint, content storage, CORS, grant validity, policy, availability and retention. Content and acknowledgement responses must allow the extension's credential-free requests; admin routes must not inherit public CORS. Server authorization and any buyer/payment binding remain provider responsibilities. A short link must not grant access merely because an email scanner or tracking pixel requested it. Existing v1 key-only invitations remain compatible with extension 1.2.0+.
