# macOS / configured gateway integration — extension and SDK 1.3.0

Typelocker™ Chat now includes a bundled reader for configured compatible gateways. The extension still performs BSK1 encoding/decoding locally. It does not deploy servers, configure SMTP, send marketing email or create payment/identity integrations. Native Mac application and gateway deployment are separate deliverables; preparing this extension release does not establish that a particular host is installed or reachable.

## Available contracts

| API or module | Responsibility |
| --- | --- |
| SDK `createClientAccess`, `generateKey`, `readInvitationLink` | Pure local v1 key invitation creation/parsing; key-only links remain compatible with 1.2.0+. |
| SDK `createServerAccess` | Prepares a short opaque email URL, hash/opaque-reference server record, and separate local key material. It does not contact or create a server. |
| SDK `validateDiaryDescriptor` | Generic metadata-only server descriptor with exact configured HTTPS origins and positive safe-integer sizes. It does not fetch/authorize and is distinct from the bounded reader envelope. |
| `diary-access.js` | Canonical v1 `typelocker-diary-access` encoder/validator for the new reader, bounded to 64 MiB encoded bytes. |
| Bundled `reader.html` | Explicit key acceptance and optional per-server permission; stream/integrity checks; local decode; expiry/cancel; client-reported digest/outcome acknowledgement. |

`PLUGIN_CAPABILITIES` declares SDK 1.3.0, reader minimum extension 1.3.0, key-only minimum 1.2.0 and `remoteDiaryReader:'configured-gateway-supported'`. A capability declaration does not configure a host, authenticate recipients or imply a deployment has been tested.

## Identity and key boundaries

`clientId` identifies the celebrity/agency tenant; optional `recipientId` identifies a fan through an opaque backend ID. Keep email addresses, listmonk subscriber mappings, purchases and identity evidence privately in the appropriate backend. A browser-provided tenant ID is data to validate, not authorization.

`createServerAccess()` returns three distinct areas:

- `emailUrl`: HTTPS `/d/<43-character random token>`, with no email, raw key, product title or diary payload.
- `serverRecord`: grant UUID, tenant/diary/optional recipient IDs, mode, SHA-256 of the token string, key reference and invitation ID. It contains no raw key or invitation object.
- `keyMaterial` plus `extensionHandoffUrl`: local secret-bearing material for a Mac key vault and deliberate key-delivery integration. Keep it out of general listmonk attributes, server logs and configuration bundles.

The generic SDK record supports `public`, `private`, `invitation` and `paid` mode labels. Those labels do not implement authentication, payment confirmation or entitlement enforcement by themselves. A configured provider must enforce its authoritative policy when resolving grants and serving bytes.

## Reader flow

The configured gateway resolves a short link to canonical metadata following [DIARY-READER-PROTOCOL.md](DIARY-READER-PROTOCOL.md), with the approved content key delivered in the handoff invitation. Diary payload bytes remain on the server. The official support bridge opens the bundled reader, where first acceptance and Download and Decode are explicit separate actions.

The reader accepts only a validated `/d/<opaque-token>/content` URL, requests optional access to its actual hostname, omits cookies/credentials/referrers, rejects redirects, and checks UTF-8, exact byte count and SHA-256 before decoding original BSK1. It never uploads the plaintext or key. It buffers at most 64 MiB encoded bytes for the original complete-token codec, rather than claiming unlimited large-diary streaming.

An acknowledgement to the same grant's `/ack` endpoint contains only `{sha256,outcome:'decoded'}`. It is a client report associated with a bearer grant. It is not human-read verification, proof of an untampered client, a delivery receipt, payment evidence or a renewal event. listmonk delivery/open/click/bounce/unsubscribe signals remain distinct from explicit key acceptance and diary decode reports.

## Mac-hosted or remote Docker deployment

A configured gateway can run on an always-on Mac or a separate selected container host. Remote users need a reachable HTTPS address and correctly configured content/ack CORS. The extension permits HTTP localhost/127.0.0.1 only for development. A local Docker port binding is not automatically publicly reachable; HTTPS/reverse proxy, router/firewall and availability require explicit host configuration.

Keep database/listmonk/admin interfaces private. Client stacks should have dedicated data volumes, secrets and ownership labels. Configuration archives should contain versioned manifests, checksums, templates and secret references; actual API tokens, SMTP credentials and diary encryption keys belong in Keychain or the destination's separate secret store. Do not copy one client's credentials/data into another client's stack. Endpoint rotation must preserve immutable key versions needed to read existing diaries and use client-scoped idempotency, rather than silently replacing shared content keys.

The separate Mac workspace adds native management, CSV and listmonk integration. Use the official [listmonk API](https://listmonk.app/docs/apis/apis/) and [import API](https://listmonk.app/docs/apis/import/) for a configured instance; SMTP/provider configuration is separate. A native CSV preview or a local fixture is not a live marketing delivery test. Subscriber-count targets, sending rates, database capacity, bandwidth, deliverability and availability require realistic infrastructure/load testing. No ten-million-subscriber performance claim follows from this SDK or reader release.

## Validation boundary

The extension's controlled-clock, Chrome-API and fetch-stream tests cover pure protocol validation, explicit consent, safe output, corruption/size/UTF-8 failures, expiry and acknowledgements. They do not establish actual installed-extension host permission prompts, a configured host's authentication/paid policy, live Mac/Docker networking, public HTTPS/CORS, SMTP delivery or load capacity. See release QA for exactly what was executed.
