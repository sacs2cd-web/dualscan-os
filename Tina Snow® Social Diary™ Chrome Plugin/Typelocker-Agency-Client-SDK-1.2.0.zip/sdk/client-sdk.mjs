// Browser/Node 20+ agency SDK. Keep invitations.js beside this sdk directory.
// This module creates local invitation data; it never sends email or requests.
import '../invitations.js';
const protocol = globalThis.TypelockerInvitations;

export const DEFAULT_PRODUCT_NAME = protocol.DEFAULT_NAME;
export const KEY_LIFETIME_DAYS = 7;

export function generateKey() { return protocol.generateKey(); }

export function createClientAccess({ productName = DEFAULT_PRODUCT_NAME, key } = {}) {
  const invitation = protocol.create({ name: productName, ...(key === undefined ? {} : { value: key }) });
  return Object.freeze({ invitation: Object.freeze(invitation), invitationUrl: protocol.link(invitation),
    acceptBy: new Date(invitation.acceptBy).toISOString(), lifetimeDays: KEY_LIFETIME_DAYS });
}

export function readInvitationLink(link) {
  let url;
  try { url = new URL(link); } catch (_) { throw new Error('Choose a complete invitation URL.'); }
  if (url.username || url.password || url.origin !== protocol.INVITE_ORIGIN || !['/invite', '/invite/', '/invite.html'].includes(url.pathname) || url.search || !/^#tli=[A-Za-z0-9_-]+$/.test(url.hash)) throw new Error('Choose an official Typelocker invitation URL.');
  return protocol.decode(url.hash.slice(5));
}
