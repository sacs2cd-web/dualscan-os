# Typelocker™ Chat agency Client SDK

An additional tool for agency content-key invitations. Existing Typelocker™ Chat features and BSK1 encoding are unchanged. The SDK generates a fresh 32-byte random key and an invitation URL locally. It uses Web Crypto in a secure browser context or Node.js 20+. Keep this `sdk` directory with the adjacent `invitations.js` file from the source release.

```js
import { createClientAccess } from './sdk/client-sdk.mjs';

const access = createClientAccess({
  productName: 'Tina Snow® Social Diary™ - Beyonce'
});

// Your agency application can place this in its own email template:
const clientLink = access.invitationUrl;
// The agency can use access.invitation.value as the shared BSK1 content key.
```

An optional `key` argument shares an existing content key instead of generating a new one. Omit it for a distinct client key. The sender must encode content using the same key the client receives; unique client keys require separately encoded content. The SDK provides `generateKey()` and `readInvitationLink(url)` as well.

The client needs Typelocker™ Chat **1.2.0 or later** in desktop Chrome. The email URL opens the official invitation page and then the extension’s local review page. Accepting stores and selects a key for exactly 604,800,000 milliseconds from that Chrome profile’s first acceptance. There are up to 100 active temporary keys, manually selectable alongside existing permanent custom keys. Reopening or deleting/reaccepting the same invitation keeps the original expiry. An invitation must first be accepted within seven days of its creation; this deadline does not shorten the client’s seven days after acceptance.

Expired keys are excluded immediately on use and removed from local extension settings by cleanup. Chrome alarms can run late while the browser sleeps; startup and resume checks catch up. This is local key availability, not subscription enforcement, remote revocation, DRM, or an email identity check. A different Chrome profile has a separate first-acceptance record. Local clock/storage modifications and copies saved elsewhere are outside this mechanism. Bearer links contain the readable shared key; do not log them or put them in URL shorteners/analytics. BSK1 remains reversible text obfuscation, not secure encryption.

No CSV parsing, buyer database, payments, macOS application, email delivery, or bulk marketing logic is included. A future agency app can call this SDK and handle those workflows separately. Nothing is sent by the SDK.

Full wire format and lifecycle: `docs/INVITATION-PROTOCOL.md`.
