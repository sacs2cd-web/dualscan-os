# Typelocker key invitation protocol v1

Supplemental agency tooling for Typelocker™ Chat 1.2.0+. All original BSK1 messages, default/custom key behavior, free features, and extension branding remain intact.

## Email URL

`https://typelocker-chat-support.alleong.chatgpt.site/invite#tli=TOKEN`

TOKEN is unpadded canonical base64url of UTF-8 JSON, in this property order:

```json
{
  "kind": "typelocker-key-invitation",
  "version": 1,
  "id": "76f3f7e8-7a41-4db6-a927-a09c2e438f88",
  "name": "Tina Snow® Social Diary™ - Beyonce",
  "value": "a shared BSK1 key",
  "issuedAt": 1793030400000,
  "acceptBy": 1793635200000
}
```

Example dates above illustrate structure only. The SDK fills current millisecond timestamps and a fresh UUID v4. `acceptBy` must equal `issuedAt + 604800000`. Names contain 1–200 characters, and keys 1–1024 UTF-8 bytes. The token is limited to 12,288 characters. Unknown properties, noncanonical encodings, malformed UTF-8, and unsupported versions are rejected. Tokens are bearer data, not signed identity assertions. Before accepting, the client reviews the supplied name; a name does not authenticate its sender.

The HTTPS fragment is omitted from HTTP requests. The static page contains no analytics or third-party executable code. Only that official origin’s exact invite routes can ask the installed extension to open its bundled review page. The worker validates the message, sender and token, then opens a fixed extension URL; it cannot open a caller-supplied destination. The extension page clears the token from its current history entry before rendering, never inserts the key into its review DOM, and requires explicit acceptance.

## Acceptance and expiry

1. The first acceptance in a Chrome profile stores a temporary key with `invitationId`, `createdAt = acceptedAt`, and `expiresAt = acceptedAt + 604800000`, then selects it. No acceptance means no saved key.
2. A receipt stores only invitation ID, acceptance/expiry/deadline timestamps, and a SHA-256 fingerprint of the canonical invitation. Reopening selects the existing key without changing timestamps. Deleting and reaccepting may restore the key only until that original deadline. Configuration imports preserve an earlier local receipt, preventing renewal through an older backup.
3. At most 100 unexpired temporary keys can coexist. Expired entries free slots; existing permanent custom keys and the original default remain available. Keys are selected manually; the extension does not cycle through other keys to guess a match.
4. At expiry, the key cannot be selected or used. A selected expired entry falls back to the original default and cached popup output is cleared. Page text is rerendered without the expired key. A local Chrome alarm, startup checks, and open-page timers remove expired entries and their values from local settings. A sleeping/closed browser cannot execute deletion; cleanup occurs when Chrome runs again. Receipts disappear once both the key expiry and invitation acceptance deadline have passed.

Seven days starts at first acceptance, not email delivery or link creation. A new invitation has a new ID and represents a new grant. No buyer identity, sales entitlement, or payment is validated. Expiry depends on the local device clock and profile storage; this mechanism cannot revoke already disclosed keys, exports, emails, or readable content. BSK1’s original security limitations remain unchanged.

## Agency integration

Use `sdk/client-sdk.mjs` to generate a key and invitation automatically. Pair it with the client’s address in your own application; do not add addresses to the invitation payload. Encode shared content with the same key sent to its intended readers. CSV import, commercial decisions, email delivery, and a future macOS app are separate systems.
