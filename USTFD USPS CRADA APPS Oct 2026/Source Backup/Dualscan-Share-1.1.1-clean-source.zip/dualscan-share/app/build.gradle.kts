plugins { alias(libs.plugins.android.application); alias(libs.plugins.kotlin.compose) }
android {
 namespace = "com.dualscan.share"
 compileSdk = 36
 defaultConfig { applicationId = "com.dualscan.share"; minSdk = 26; targetSdk = 36; versionCode = 4; versionName = "1.1.1"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 flavorDimensions += "edition"
 productFlavors {
  create("lite") { dimension = "edition"; applicationIdSuffix = ".lite"; manifestPlaceholders["appLabel"] = "Dualscan Share Lite"; buildConfigField("boolean", "OEM_EDITION", "false") }
  create("oem") { dimension = "edition"; manifestPlaceholders["appLabel"] = "Dualscan Share"; buildConfigField("boolean", "OEM_EDITION", "true") }
 }
 buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { compose = true; buildConfig = true }
}
dependencies {
 implementation(project(":interchange-core"))
 implementation(libs.androidx.core.ktx)
 implementation(libs.androidx.lifecycle.runtime.ktx)
 implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.1")
 implementation(libs.androidx.activity.compose)
 implementation(platform(libs.androidx.compose.bom))
 implementation(libs.androidx.compose.ui)
 implementation(libs.androidx.compose.ui.graphics)
 implementation(libs.androidx.compose.ui.tooling.preview)
 implementation(libs.androidx.compose.material3)
 implementation("androidx.compose.material:material-icons-extended")
 implementation("androidx.documentfile:documentfile:1.0.1")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
 debugImplementation(libs.androidx.compose.ui.tooling)
 testImplementation(libs.junit)
 testImplementation("org.json:json:20240303")
 androidTestImplementation(libs.androidx.junit)
 androidTestImplementation("androidx.test:runner:1.5.2")
}
