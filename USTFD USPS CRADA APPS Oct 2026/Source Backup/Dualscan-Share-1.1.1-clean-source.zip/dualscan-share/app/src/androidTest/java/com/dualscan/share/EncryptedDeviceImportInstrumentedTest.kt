package com.dualscan.share

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.accessibility.AccessibilityNodeInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.share.core.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Exercises the actual shared-storage provider with a real user folder grant. */
@RunWith(AndroidJUnit4::class)
class EncryptedDeviceImportInstrumentedTest {
    @Test fun completePhotoImageSavesThroughRealSafMusicFolderWithoutGalleryPublication() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val app = instrumentation.targetContext
        val tree = obtainMusicFolderGrant()
        val bitmap = Bitmap.createBitmap(intArrayOf(0xffff00fe.toInt(), 0xff00ffff.toInt(), 0xff000000.toInt(), 0xffffffff.toInt()), 2, 2, Bitmap.Config.ARGB_8888)
        val photo = try { ByteArrayOutputStream().use { output -> assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)); output.toByteArray() } } finally { bitmap.recycle() }
        val source = File(app.cacheDir, "saf-encrypted-photo-${System.nanoTime()}.dshare")
        val returned = File(app.cacheDir, "saf-returned-image-${System.nanoTime()}.dshare")
        fun galleryRows() = app.contentResolver.query(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), arrayOf(MediaStore.Images.Media._ID), null, null, null)?.use { cursor -> buildSet { while(cursor.moveToNext()) add(cursor.getLong(0)) } }.orEmpty()
        val before = galleryRows()
        try {
            val request = BundleRequest("Encrypted SAF photo fixture", device = DeviceIdentity("Dualscan", "Android QA", "test", "16", 36, "public-test", "2026-10-01"))
            val info = ArchiveEngine.create(source, request, listOf(BundleInput("photo.png", "image/png", "Pictures/Album/photo.png") { photo.inputStream() }))
            val result = EncryptedImageImporter.copyToDevice(app, source, info.archiveSha256, tree)
            assertTrue(result.name.endsWith(".dshare")); assertFalse(result.name.endsWith(".part"))
            assertEquals(info.archiveSha256, result.sha256); assertEquals(info.archiveBytes, result.bytes)
            val folder = DocumentFile.fromTreeUri(app, tree)!!.findFile("DualscanShare")!!
            assertNotNull(folder.findFile(".nomedia"))
            assertNotNull(folder.findFile(result.name))
            assertTrue(folder.listFiles().none { it.name?.endsWith(".part") == true || it.name == "photo.png" })
            app.contentResolver.openInputStream(result.uri)!!.use { input -> returned.outputStream().use(input::copyTo) }
            assertArrayEquals(source.readBytes(), returned.readBytes())
            assertEquals(info.archiveSha256, ArchiveEngine.sha256(source))
            app.contentResolver.openInputStream(result.uri)!!.use { assertNull(BitmapFactory.decodeStream(it)) }
            assertEquals(before, galleryRows())
            MediaArray.open(returned).use { player ->
                val bytes = player.openEntry(player.catalog.entries.single().id).use { it.readBytes() }
                assertArrayEquals(photo, bytes)
                val shown = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                try { assertEquals(0xffff00fe.toInt(), shown.getPixel(0, 0)) } finally { shown.recycle(); bytes.fill(0) }
            }
            assertEquals(before, galleryRows())
            // Default media distribution is one independently encrypted file per item,
            // transferred through the actual shared-folder production copier.
            val originals = linkedMapOf("Music/Album/cover.png" to photo, "Pictures/Album/photo.png" to photo,
                "Documents/notes.txt" to "Public fixture document\n".toByteArray())
            val staging = File(app.cacheDir, "saf-batch-${System.nanoTime()}")
            val batch = EncryptedMediaBatch.create(staging, request, originals.map { (path, bytes) ->
                BundleInput(path.substringAfterLast('/'), if (path.endsWith(".png")) "image/png" else "text/plain", path) { bytes.inputStream() }
            })
            val savedBatch = try {
                val saved = EncryptedBatchTransfer.saveToDevice(app, batch, tree)
                assertEquals(3, saved.files)
                val batchFolder = DocumentFile.fromTreeUri(app, tree)!!.findFile(saved.folderName)!!
                assertNotNull(batchFolder.findFile(".nomedia"))
                batch.items.forEach { item ->
                    var document = batchFolder
                    item.relativePath.split('/').forEach { name -> document = document.findFile(name) ?: throw AssertionError("Missing encrypted hierarchy: ${item.relativePath}") }
                    assertTrue(document.name!!.endsWith(".diamond"))
                    app.contentResolver.openInputStream(document.uri)!!.use { input -> returned.outputStream().use(input::copyTo) }
                    assertArrayEquals(item.file.readBytes(), returned.readBytes())
                    assertNull(BitmapFactory.decodeFile(returned.path))
                    MediaArray.open(returned).use { reader ->
                        val entry = reader.catalog.entries.single()
                        assertArrayEquals(originals.getValue(requireNotNull(entry.relativePath)), reader.openEntry(entry.id).use { it.readBytes() })
                    }
                }
                assertEquals(before, galleryRows())
                // Tampering must fail before another public destination is created.
                val childrenBefore = DocumentFile.fromTreeUri(app, tree)!!.listFiles().mapNotNull { it.name }.toSet()
                batch.items.first().file.appendBytes(byteArrayOf(1))
                try { EncryptedBatchTransfer.saveToDevice(app, batch, tree); fail("Changed source was copied") } catch (_: IllegalArgumentException) { }
                assertEquals(childrenBefore, DocumentFile.fromTreeUri(app, tree)!!.listFiles().mapNotNull { it.name }.toSet())
                saved
            } finally { staging.deleteRecursively() }
            File(app.filesDir, "verification-device-import.json").writeText(JSONObject()
                .put("result", "PASS").put("androidApi", android.os.Build.VERSION.SDK_INT)
                .put("treeUri", tree.toString()).put("savedUri", result.uri.toString()).put("savedName", result.name)
                .put("ciphertextSha256", result.sha256).put("ciphertextBytes", result.bytes)
                .put("unchangedCiphertext", true).put("originalSourceUnchanged", true)
                .put("nomediaMarker", true).put("galleryRowsUnchanged", true).put("ordinaryImageDecoderRejected", true)
                .put("perItemEncryptedFiles", savedBatch.files).put("perItemBatchFolderUri", savedBatch.folderUri.toString())
                .put("perItemHierarchyPreserved", true).put("perItemCiphertextIdentical", true).put("tamperedBatchRejectedBeforeDestination", true)
                .put("diamondReaderExactPixels", true).put("realSafPickerGrant", true).put("physicalUsbTested", false).toString(2))
            // The one public encrypted fixture intentionally remains for UI inspection.
        } finally { source.delete(); returned.delete(); photo.fill(0) }
    }

    private fun obtainMusicFolderGrant(): Uri {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val app = instrumentation.targetContext
        val existing = app.contentResolver.persistedUriPermissions.firstOrNull { permission ->
            permission.isReadPermission && permission.isWritePermission && permission.uri.authority == UsbAccessPolicy.AUTHORITY &&
                runCatching { DocumentsContract.getTreeDocumentId(permission.uri) == "primary:Music" }.getOrDefault(false)
        }
        if (existing != null) return existing.uri
        val activity = instrumentation.startActivitySync(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        val complete = CountDownLatch(1); val chosen = AtomicReference<Uri?>(); val failure = AtomicReference<Throwable?>()
        instrumentation.runOnMainSync {
            val launcher = activity.activityResultRegistry.register("encrypted-import-folder-test", ActivityResultContracts.OpenDocumentTree()) { uri ->
                try {
                    requireNotNull(uri) { "Folder selection was cancelled." }
                    app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    chosen.set(uri)
                } catch (error: Throwable) { failure.set(error) }
                finally { complete.countDown() }
            }
            launcher.launch(DocumentsContract.buildDocumentUri(UsbAccessPolicy.AUTHORITY, "primary:Music"))
        }
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(25)
        while (complete.count > 0 && System.nanoTime() < deadline) {
            val root = instrumentation.uiAutomation.rootInActiveWindow
            if (root != null) {
                listOf("Use this folder", "USE THIS FOLDER", "Allow", "ALLOW").forEach { text ->
                    root.findAccessibilityNodeInfosByText(text).filter { it.text?.toString()?.equals(text, ignoreCase = true) == true }.forEach { node -> click(node) }
                }
            }
            complete.await(150, TimeUnit.MILLISECONDS)
        }
        failure.get()?.let { throw AssertionError("Could not retain the actual folder picker grant", it) }
        check(complete.count == 0L) { "The actual Android folder picker did not return a Music folder grant." }
        val tree = requireNotNull(chosen.get())
        check(DocumentsContract.getTreeDocumentId(tree) == "primary:Music") { "The test requires the actual local Music folder." }
        instrumentation.runOnMainSync { activity.finish() }
        return tree
    }

    private fun click(node: AccessibilityNodeInfo) {
        var target: AccessibilityNodeInfo? = node
        repeat(6) {
            val item = target ?: return
            if (item.isClickable && item.isEnabled) { item.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
            target = item.parent
        }
    }
}
