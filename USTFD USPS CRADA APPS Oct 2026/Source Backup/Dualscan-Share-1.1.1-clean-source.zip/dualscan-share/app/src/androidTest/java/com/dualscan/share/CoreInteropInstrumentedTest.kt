package com.dualscan.share

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.share.core.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File

/** Actual Android crypto and copy paths must never publish decoded photos to Gallery. */
@RunWith(AndroidJUnit4::class)
class CoreInteropInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val app get() = instrumentation.targetContext
    private val request get() = BundleRequest("Encrypted photos", device = DeviceIdentity("Dualscan", "Android QA", "test", "16", 36, "public-test", "2026-10-01"))
    private fun photo(): ByteArray = ByteArrayOutputStream().use { output ->
        val bitmap = Bitmap.createBitmap(intArrayOf(0xffff00fe.toInt(), 0xff00ffff.toInt(), 0xff000000.toInt(), 0xffffffff.toInt()), 2, 2, Bitmap.Config.ARGB_8888)
        try { assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)); output.toByteArray() } finally { bitmap.recycle() }
    }
    private fun fresh(name: String) = File(app.cacheDir, "$name-${System.nanoTime()}.dshare")
    private fun galleryRows(): Set<Long> = app.contentResolver.query(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), arrayOf(MediaStore.Images.Media._ID), null, null, null)?.use { cursor ->
        buildSet { while(cursor.moveToNext()) add(cursor.getLong(0)) }
    }.orEmpty()

    @Test fun copiedPhotoImageRemainsCiphertextAndCreatesNoGalleryItem() {
        val bytes = photo(); val source = fresh("encrypted-photo"); val destination = fresh("device-copy")
        val before = galleryRows()
        try {
            val info = ArchiveEngine.create(source, request, listOf(BundleInput("photo.png", "image/png", "Pictures/Album/photo.png") { bytes.inputStream() }))
            val result = EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { destination.outputStream() }, { destination.inputStream() })
            assertEquals(info.archiveSha256, result.sha256); assertArrayEquals(source.readBytes(), destination.readBytes())
            assertNull(BitmapFactory.decodeFile(destination.path))
            assertEquals(before, galleryRows())
            MediaArray.open(destination).use { player ->
                val plain = player.openEntry(player.catalog.entries.single().id).use { it.readBytes() }
                assertArrayEquals(bytes, plain)
                val shown = BitmapFactory.decodeByteArray(plain, 0, plain.size)
                try { assertEquals(2, shown.width); assertEquals(0xffff00fe.toInt(), shown.getPixel(0, 0)) } finally { shown.recycle(); plain.fill(0) }
            }
            assertEquals(before, galleryRows())
        } finally { source.delete(); destination.delete() }
    }

    @Test fun passwordProtectionIsRetainedDuringEncryptedDeviceCopy() {
        val bytes = photo(); val source = fresh("password-photo"); val destination = fresh("password-copy"); val password = "Private photo fixture 2026".toCharArray()
        try {
            val info = ArchiveEngine.create(source, request, listOf(BundleInput("photo.png", "image/png") { bytes.inputStream() }), password)
            EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { destination.outputStream() }, { destination.inputStream() })
            try { ArchiveEngine.inspect(destination); fail("Password stripped during copy") } catch (_: PasswordRequiredException) { }
            MediaArray.open(destination, password).use { array -> assertArrayEquals(bytes, array.openEntry(array.catalog.entries.single().id).use { it.readBytes() }) }
        } finally { password.fill('\u0000'); source.delete(); destination.delete() }
    }

    @Test fun legacyHostPasswordArchiveIsRejectedWithoutPlaintextStaging() {
        val source = fresh("legacy-rejected")
        instrumentation.context.assets.open("crypto/host-encrypted.dshare").use { input -> source.outputStream().use(input::copyTo) }
        val before = app.cacheDir.listFiles()!!.map { it.name }.toSet()
        try {
            try { ArchiveEngine.inspect(source, "A legacy password".toCharArray()); fail("Legacy input accepted") } catch (_: IllegalArgumentException) { }
            assertEquals(before, app.cacheDir.listFiles()!!.map { it.name }.toSet())
            assertTrue(app.cacheDir.listFiles()!!.none { it.name.startsWith(".dualscan-unlocked-") })
        } finally { source.delete() }
    }

    @Test fun productionDeviceImporterRejectsPlainPhotoBeforeCreatingAnyDestination() {
        // USB broadcasts have no data URI; volume broadcasts require file://.
        // Separate native filters are necessary when the manual refresh action is absent.
        val usbFilter = UsbStorageMonitor.usbEvents()
        val mediaFilter = UsbStorageMonitor.volumeEvents()
        assertEquals(0, usbFilter.countDataSchemes())
        assertTrue(usbFilter.hasAction(android.hardware.usb.UsbManager.ACTION_USB_DEVICE_ATTACHED))
        assertTrue(usbFilter.hasAction(android.hardware.usb.UsbManager.ACTION_USB_DEVICE_DETACHED))
        assertTrue(mediaFilter.hasDataScheme("file"))
        assertTrue(mediaFilter.hasAction(android.content.Intent.ACTION_MEDIA_MOUNTED))
        assertTrue(mediaFilter.hasAction(android.content.Intent.ACTION_MEDIA_EJECT))
        assertTrue(mediaFilter.hasAction(android.content.Intent.ACTION_MEDIA_UNMOUNTED))
        assertFalse(usbFilter.hasDataScheme("file"))
        var initialCallback = 0
        UsbStorageMonitor.observe(app) { initialCallback++ }.use { assertTrue(initialCallback >= 1) }
        val source = fresh("plain-photo"); source.writeBytes(photo())
        try {
            val tree = DocumentsContract.buildTreeDocumentUri(UsbAccessPolicy.AUTHORITY, "primary:Music")
            try { EncryptedImageImporter.copyToDevice(app, source, ArchiveEngine.sha256(source), tree); fail("Plain photo imported") }
            catch (failure: IllegalArgumentException) { assertTrue(failure.message.orEmpty().contains("Create a new encrypted image")) }
        } finally { source.delete() }
    }
}
