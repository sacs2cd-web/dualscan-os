package com.dualscan.share

import android.graphics.Bitmap
import android.os.Build
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.share.core.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** Public synthetic per-file producer fixtures for Diamond's real shared-folder reader. */
@RunWith(AndroidJUnit4::class)
class LooseMediaInteropInstrumentedTest {
    @Test fun shareAuthorsIndependentDiamondFilesForOrdinaryFoldersAndUsbDistribution() {
        val app = InstrumentationRegistry.getInstrumentation().targetContext
        val output = File(app.filesDir, "exports/loose-fixtures").apply { deleteRecursively(); check(mkdirs()) }
        val staging = File(app.cacheDir, "loose-global-${System.nanoTime()}")
        val protectedStaging = File(app.cacheDir, "loose-protected-${System.nanoTime()}")
        val passwordText = "Dualscan loose fixture 2026"
        val password = passwordText.toCharArray()
        val request = BundleRequest("Diamond loose media fixture", device = DeviceIdentity(Build.MANUFACTURER,
            Build.MODEL, Build.DEVICE, Build.VERSION.RELEASE, Build.VERSION.SDK_INT, Build.FINGERPRINT, Build.VERSION.SECURITY_PATCH))
        val first = "Music/Interop Album/01 Interop.wav"
        val second = "Music/Interop Album/02 Interop.wav"
        val cover = "Music/Interop Album/cover.png"
        val photo = "Pictures/Interop/photo.png"
        val pcm1 = ByteArray(19_200 * 6) { ((it * 17 + it / 6) and 255).toByte() }
        val pcm2 = ByteArray(19_200 * 6) { ((it * 29 + it / 6 + 71) and 255).toByte() }
        val pixels = intArrayOf(0xffff00fe.toInt(), 0xff00ffff.toInt(), 0xff000000.toInt(), 0xffffffff.toInt())
        val png = ByteArrayOutputStream().use { bytes ->
            val bitmap = Bitmap.createBitmap(pixels, 2, 2, Bitmap.Config.ARGB_8888)
            try { assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes)); bytes.toByteArray() }
            finally { bitmap.recycle() }
        }
        val sources = linkedMapOf(first to wav(pcm1), second to wav(pcm2), cover to png, photo to png)
        fun input(path: String, bytes: ByteArray) = BundleInput(path.substringAfterLast('/'), if (path.endsWith(".wav")) "audio/wav" else "image/png", path) { bytes.inputStream() }
        fun persist(batch: AuthoredMediaBatch, originals: Map<String, ByteArray>): JSONArray = JSONArray().apply {
            batch.items.forEach { item ->
                val target = File(output, item.relativePath)
                check(target.parentFile!!.exists() || target.parentFile!!.mkdirs())
                val receipt = EncryptedImageTransfer.copyVerified(item.file, item.inspection.archiveSha256,
                    { target.outputStream() }, { target.inputStream() })
                assertArrayEquals(item.file.readBytes(), target.readBytes())
                val entry = item.inspection.manifest.entries.single()
                val originalPath = requireNotNull(entry.relativePath)
                val clear = originals.getValue(originalPath)
                val json = JSONObject().put("file", item.relativePath).put("relativePath", originalPath)
                    .put("displayName", entry.displayName).put("mimeType", entry.mimeType)
                    .put("encryptedSha256", receipt.sha256).put("encryptedBytes", receipt.bytes)
                    .put("sha256", sha(clear)).put("sizeBytes", clear.size)
                if (entry.mimeType == "audio/wav") {
                    val pcm = if (originalPath == first) pcm1 else pcm2
                    json.put("audio", JSONObject().put("pcmSha256", sha(pcm)).put("pcmBytes", pcm.size)
                        .put("bitDepth", 24).put("sampleRateHz", 192_000).put("channelCount", 2))
                } else json.put("image", JSONObject().put("width", 2).put("height", 2).put("pixels", JSONArray(pixels.toList())))
                put(json)
            }
        }
        try {
            val batch = EncryptedMediaBatch.create(staging, request, sources.map { (path, bytes) -> input(path, bytes) })
            val items = persist(batch, sources)
            batch.items.forEach { item -> MediaArray.open(item.file).use { array ->
                assertEquals(1, array.catalog.entries.size)
                val entry = array.catalog.entries.single()
                assertArrayEquals(sources.getValue(requireNotNull(entry.relativePath)), array.openEntry(entry.id).use { it.readBytes() })
            } }
            val privatePath = "Protected/private.png"
            val protectedSources = mapOf(privatePath to png)
            val protectedBatch = EncryptedMediaBatch.create(protectedStaging, request,
                listOf(input(privatePath, png)), password)
            val passwordItems = persist(protectedBatch, protectedSources)
            val manifest = JSONObject().put("schemaVersion", 1).put("title", request.title).put("password", passwordText)
                .put("items", items).put("passwordItems", passwordItems)
                .put("gapless", JSONObject().put("relativePaths", JSONArray(listOf(first, second)))
                    .put("pcmSha256", sha(pcm1 + pcm2)).put("pcmBytes", pcm1.size + pcm2.size))
            File(output, "fixture.json").writeText(manifest.toString(2))
            assertEquals(5, output.walkTopDown().count { it.isFile && it.extension == "diamond" })
            assertTrue(output.walkTopDown().none { it.isFile && it.extension in setOf("wav", "png", "jpg") })
        } finally { password.fill('\u0000'); staging.deleteRecursively(); protectedStaging.deleteRecursively() }
    }

    private fun wav(pcm: ByteArray): ByteArray = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN).apply {
        put("RIFF".toByteArray()); putInt(36 + pcm.size); put("WAVEfmt ".toByteArray()); putInt(16)
        putShort(1); putShort(2); putInt(192_000); putInt(192_000 * 6); putShort(6); putShort(24)
        put("data".toByteArray()); putInt(pcm.size); put(pcm)
    }.array()
    private fun sha(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
}
