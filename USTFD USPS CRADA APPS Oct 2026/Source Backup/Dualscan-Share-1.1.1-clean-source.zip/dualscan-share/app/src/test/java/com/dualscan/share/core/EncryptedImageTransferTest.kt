package com.dualscan.share.core

import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException

class EncryptedImageTransferTest {
    @get:Rule val temporary = TemporaryFolder()
    private val request = BundleRequest("Photo collection", device = DeviceIdentity("Dualscan", "Test", "test", "16", 36, "public-test", "2026-10-01"))
    private val photo = byteArrayOf(0x89.toByte(), 0x50, 0x4e, 0x47) + "Private photo data never written as a photo".toByteArray()
    private fun create(password: CharArray? = null): Pair<File, BundleInspection> {
        val file = File(temporary.root, "image-${System.nanoTime()}.dshare")
        return file to ArchiveEngine.create(file, request, listOf(BundleInput("photo.png", "image/png", "Pictures/photo.png") { photo.inputStream() }), password)
    }

    @Test fun byteIdenticalCiphertextMovesToASecondDeviceWithoutExtractingMedia() {
        val (source, info) = create(); val destination = File(temporary.root, "second-device.dshare")
        val result = EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { destination.outputStream() }, { destination.inputStream() })
        assertEquals(info.archiveSha256, result.sha256); assertEquals(info.archiveBytes, result.bytes)
        assertArrayEquals(source.readBytes(), destination.readBytes())
        assertFalse(destination.readBytes().toString(Charsets.ISO_8859_1).contains("Private photo data"))
        assertEquals(setOf(source.name, destination.name), temporary.root.listFiles()!!.map { it.name }.toSet())
        MediaArray.open(destination).use { player -> assertArrayEquals(photo, player.openEntry(player.catalog.entries.single().id).use { it.readBytes() }) }
    }

    @Test fun optionalPasswordProtectionSurvivesWholeImageCopy() {
        val password = "Private photo password 2026".toCharArray()
        try {
            val (source, info) = create(password); val destination = File(temporary.root, "password-device.dshare")
            EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { destination.outputStream() }, { destination.inputStream() })
            try { ArchiveEngine.inspect(destination); fail("Password was removed by copying") } catch (_: PasswordRequiredException) { }
            MediaArray.open(destination, password).use { player -> assertArrayEquals(photo, player.openEntry(player.catalog.entries.single().id).use { it.readBytes() }) }
        } finally { password.fill('\u0000') }
    }

    @Test fun plainLegacyAndOldEncryptedHeadersAreRejectedBeforeAnyOutputByte() {
        listOf("PK\u0003\u0004", "DSHP0001", "DSMP0001", "DSMP9999", "").forEach { signature ->
            val output = ByteArrayOutputStream()
            rejected { EncryptedImageTransfer.receive((signature.toByteArray() + ByteArray(256)).inputStream(), output) }
            assertEquals(signature, 0, output.size())
            val file = File(temporary.root, "old-${System.nanoTime()}.dshare").apply { writeBytes(signature.toByteArray() + ByteArray(256)) }
            var opened = false
            rejected { EncryptedImageTransfer.copyVerified(file, ArchiveEngine.sha256(file), { opened = true; output }, { output.toByteArray().inputStream() }) }
            assertFalse(opened)
        }
    }

    @Test fun modifiedPreviouslyAuthenticatedImageNeverOpensDestination() {
        val (source, info) = create()
        source.writeBytes(source.readBytes().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() })
        var opened = false
        rejected { EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { opened = true; ByteArrayOutputStream() }, { byteArrayOf().inputStream() }) }
        assertFalse(opened)
    }

    @Test fun failedReadBackDoesNotReportSuccessfulCopy() {
        val (source, info) = create(); val output = ByteArrayOutputStream()
        rejected { EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { output }, { output.toByteArray().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }.inputStream() }) }
    }

    @Test fun disconnectedAndStalledProvidersFailClearly() {
        val (source, info) = create()
        rejected { EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { throw IOException("Disconnected") }, { source.inputStream() }) }
        val header = "DSMP0002".toByteArray()
        val stalled = object : ByteArrayInputStream(header + ByteArray(120)) {
            override fun read(buffer: ByteArray, off: Int, len: Int): Int = if (pos < header.size) super.read(buffer, off, minOf(len, header.size-pos)) else 0
        }
        rejected { EncryptedImageTransfer.receive(stalled, ByteArrayOutputStream()) }
    }

    @Test fun cancellationStopsBeforeDestinationCreation() {
        val (source, info) = create(); var opened = false
        try {
            Thread.currentThread().interrupt()
            rejected { EncryptedImageTransfer.copyVerified(source, info.archiveSha256, { opened = true; ByteArrayOutputStream() }, { source.inputStream() }) }
        } finally { Thread.interrupted() }
        assertFalse(opened)
    }

    private fun rejected(block: () -> Unit) { try { block() } catch (_: Exception) { return }; throw AssertionError("Unsafe encrypted transfer was accepted") }
}
