package com.dualscan.share

import org.junit.Assert.*
import org.junit.Test

class EncryptedBatchTransferPathTest {
    @Test fun ordinarySystemFolderLayoutAndEncryptedFileSuffixArePreserved() {
        assertEquals(listOf("Music", "Album", "01 Song.flac.diamond"), EncryptedBatchTransfer.checkedPath("Music/Album/01 Song.flac.diamond"))
        assertEquals(listOf("Pictures", "東京", "photo.png.diamond"), EncryptedBatchTransfer.checkedPath("Pictures/東京/photo.png.diamond"))
    }

    @Test fun traversalAbsoluteControlAndPrivateAppPathsAreRejected() {
        listOf("../photo.diamond", "/Music/photo.diamond", "Music//photo.diamond", "Music/./photo.diamond", "Music\\photo.diamond", "Music/line\n.diamond", "Android/data/private.diamond", "Android/OBB/file.diamond").forEach { path -> rejected { EncryptedBatchTransfer.checkedPath(path) } }
    }

    @Test fun alreadyProtectedSourcesUseImportInsteadOfDoubleEncryption() {
        listOf("song.flac.diamond", "photo.JPG.DIAMOND", "old.dshare", "old.DMPA").forEach { name ->
            assertTrue(GenericFilePolicy.isProtected(name))
            rejected { GenericFilePolicy.requireUnprotectedSource(name) }
        }
        assertFalse(GenericFilePolicy.isProtected("song.flac")); GenericFilePolicy.requireUnprotectedSource("song.flac")
    }

    @Test fun Utf8FilesystemNameAndDepthLimitsAreEnforced() {
        EncryptedBatchTransfer.checkedPath("Music/" + "x".repeat(240) + ".diamond")
        rejected { EncryptedBatchTransfer.checkedPath("Music/" + "界".repeat(90) + ".diamond") }
        rejected { EncryptedBatchTransfer.checkedPath((List(32) { "folder" } + "photo.diamond").joinToString("/")) }
    }

    private fun rejected(block: () -> Unit) { try { block() } catch (_: Exception) { return }; throw AssertionError("Unsafe encrypted destination was accepted") }
}
