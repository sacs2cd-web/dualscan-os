package com.dualscan.share.core

import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException

class EncryptedMediaBatchTest {
    @get:Rule val temporary = TemporaryFolder()
    private val request = BundleRequest("Portable media", device = DeviceIdentity("Dualscan", "Test", "test", "16", 36, "public", "2026-10-01"))
    private val originals = linkedMapOf(
        "Music/Album/01 Song.wav" to "RIFF original private audio".toByteArray(),
        "Music/Album/cover.jpg" to byteArrayOf(0xff.toByte(), 0xd8.toByte(), 11, 19),
        "Pictures/旅/photo.png" to "Original private photograph".toByteArray())
    private fun inputs() = originals.map { (path, bytes) -> BundleInput(path.substringAfterLast('/'), when {
        path.endsWith("wav") -> "audio/wav"; path.endsWith("jpg") -> "image/jpeg"; else -> "image/png"
    }, path) { bytes.inputStream() } }

    @Test fun eachSourceBecomesItsOwnPortableEncryptedFileWithFoldersAndOriginalBytes() {
        val directory = File(temporary.root, "batch")
        val batch = EncryptedMediaBatch.create(directory, request, inputs())
        assertEquals(originals.keys.map { "$it.diamond" }, batch.items.map { it.relativePath })
        assertEquals(originals.values.sumOf { it.size }.toLong(), batch.payloadBytes)
        assertEquals(batch.items.sumOf { it.file.length() }, batch.archiveBytes)
        assertEquals(3, directory.listFiles()!!.size)
        for (item in batch.items) {
            assertEquals("DSMP0002", item.file.inputStream().use { String(it.readNBytes(8), Charsets.US_ASCII) })
            assertTrue(item.inspection.encrypted)
            assertFalse(item.inspection.passwordProtected)
            MediaArray.open(item.file).use { player ->
                player.verifyAll()
                val entry = player.catalog.entries.single()
                assertEquals(item.relativePath.removeSuffix(".diamond"), entry.relativePath)
                assertArrayEquals(originals.getValue(requireNotNull(entry.relativePath)), player.openEntry(entry.id).use { it.readBytes() })
            }
        }
    }

    @Test fun optionalPasswordProtectsEveryItemAndEachItemUsesIndependentRandomEncryption() {
        val password = "A shared optional batch password".toCharArray()
        val bytes = "Same original bytes".toByteArray()
        try {
            val batch = EncryptedMediaBatch.create(File(temporary.root, "protected"), request,
                listOf("one.wav", "two.wav").map { name -> BundleInput(name, "audio/wav") { bytes.inputStream() } }, password)
            assertFalse(batch.items[0].file.readBytes().contentEquals(batch.items[1].file.readBytes()))
            batch.items.forEach { item ->
                try { MediaArray.open(item.file).close(); fail("Password was bypassed") } catch (_: PasswordRequiredException) { }
                MediaArray.open(item.file, password).use { player ->
                    assertArrayEquals(bytes, player.openEntry(player.catalog.entries.single().id).use { it.readBytes() })
                }
            }
        } finally { password.fill('\u0000') }
    }

    @Test fun failureOnLaterSourceRemovesTheIncompleteBatchAndPreservesOriginals() {
        val original = File(temporary.root, "original.wav").apply { writeText("Keep this original") }
        val directory = File(temporary.root, "failed")
        rejected {
            EncryptedMediaBatch.create(directory, request, listOf(
                BundleInput(original.name, "audio/wav") { original.inputStream() },
                BundleInput("missing.png", "image/png") { throw IOException("Drive disconnected") }))
        }
        assertFalse(directory.exists())
        assertEquals("Keep this original", original.readText())
    }

    @Test fun duplicateCasefoldUnicodeAndFileFolderPathsAreRejectedBeforeOutput() {
        for (paths in listOf(listOf("Album/é.wav", "Album/e\u0301.wav"),
            listOf("Album/One.wav", "album/one.wav"), listOf("Album/SS.wav", "Album/ß.wav"), listOf("folder", "folder.diamond/song.wav"),
            listOf("../escape.wav"))) {
            val directory = File(temporary.root, "rejected-${System.nanoTime()}")
            rejected { EncryptedMediaBatch.create(directory, request, paths.map { path -> BundleInput(path.substringAfterLast('/'), "audio/wav", path) { byteArrayOf(1).inputStream() } }) }
            assertFalse(directory.exists())
        }
    }

    @Test fun existingDirectoriesAndTheirFilesAreNeverOverwrittenOrDeleted() {
        val directory = temporary.newFolder("existing")
        val prior = File(directory, "keep.txt").apply { writeText("Existing user file") }
        rejected { EncryptedMediaBatch.create(directory, request, inputs()) }
        assertEquals("Existing user file", prior.readText())
    }

    @Test fun alreadyEncryptedItemsAreNotWrappedAgainAndLongFolderSegmentsFailBeforeAuthoring() {
        for (path in listOf("song.flac.diamond", "backup.dshare", "album.dmpa", "楽".repeat(100) + "/track.wav")) {
            val directory = File(temporary.root, "no-double-wrap-${System.nanoTime()}")
            rejected { EncryptedMediaBatch.create(directory, request, listOf(BundleInput(path.substringAfterLast('/'), "audio/wav", path) { byteArrayOf(1).inputStream() })) }
            assertFalse(directory.exists())
        }
    }

    @Test fun interruptedAuthoringLeavesNoBatchAndOriginalSourcesRemain() {
        val directory = File(temporary.root, "interrupted")
        try {
            Thread.currentThread().interrupt()
            rejected { EncryptedMediaBatch.create(directory, request, inputs()) }
        } finally { Thread.interrupted() }
        assertFalse(directory.exists())
    }

    @Test fun veryLongUnicodePublicFilenameIsBoundedButAuthenticatedOriginalNameIsPreserved() {
        val name = "楽".repeat(100) + ".wav"
        val input = BundleInput(name, "audio/wav", "Album/$name") { byteArrayOf(1, 2, 3).inputStream() }
        val batch = EncryptedMediaBatch.create(File(temporary.root, "unicode"), request, listOf(input))
        val item = batch.items.single()
        assertTrue(item.relativePath.substringAfterLast('/').toByteArray(Charsets.UTF_8).size <= 240)
        assertTrue(item.relativePath.endsWith(".diamond"))
        MediaArray.open(item.file).use { assertEquals(name, it.catalog.entries.single().displayName) }
    }

    private fun rejected(block: () -> Unit) { try { block() } catch (_: Exception) { return }; throw AssertionError("Unsafe authoring accepted") }
}
