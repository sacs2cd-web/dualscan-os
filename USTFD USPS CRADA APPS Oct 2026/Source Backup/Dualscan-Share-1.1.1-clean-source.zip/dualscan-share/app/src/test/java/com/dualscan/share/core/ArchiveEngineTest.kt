package com.dualscan.share.core

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ArchiveEngineTest {
    @get:Rule val temporary = TemporaryFolder()

    private val device = DeviceIdentity("Dualscan", "Test phone", "test_device", "14", 34,
        "dualscan/test/device:14/test:user/release-keys", "2026-10-01")
    private val request get() = BundleRequest("My selected content", device = device)
    private val oem get() = OemImageMetadata("Dualscan", "test_device", "DS-2026.10", "AOSP_OTA", "ab".repeat(32))
    private val sampleContents = linkedMapOf(
        "Résumé 東京 📱.txt" to "Unicode content: Καλημέρα / 日本語 / café\n".toByteArray(),
        "camera.bin" to ByteArray(262_151) { ((it * 67 + 13) and 255).toByte() },
        "empty.dat" to byteArrayOf()
    )

    @Test fun encryptedImageKeepsExactBinaryUnicodeAndEmptyPayloadsForPlayer() {
        val archive = create(); val inspection = ArchiveEngine.inspect(archive)
        assertTrue(inspection.encrypted)
        assertEquals("DSMP0002", archive.inputStream().use { String(it.readNBytes(8)) })
        com.dualscan.mp.core.MediaArray.open(archive).use { array ->
            array.verifyAll()
            array.catalog.entries.forEach { entry -> assertArrayEquals(sampleContents.getValue(entry.displayName), array.openEntry(entry.id).use { it.readBytes() }) }
        }
        assertEquals(sampleContents.values.sumOf { it.size.toLong() }, inspection.totalPayloadBytes)
        assertEquals(hash(archive.readBytes()), inspection.archiveSha256)
        assertEquals(archive.length(), inspection.archiveBytes)
        inspection.manifest.entries.forEach { entry -> assertEquals(hash(sampleContents.getValue(entry.displayName)), entry.sha256) }
        assertTrue(temporary.root.listFiles()!!.all { it.extension == "dshare" })
    }

    @Test fun noPlaintextRestoreOrPerEntryExportApiExists() {
        assertTrue(ArchiveEngine::class.java.methods.none { it.name.contains("restore", true) || it.name.contains("extract", true) })
        for (name in listOf("com.dualscan.share.MediaStoreRestorer", "com.dualscan.share.FolderRestorer", "com.dualscan.share.core.ProtectedArchive")) {
            try { Class.forName(name); fail("Plaintext path remains compiled: $name") } catch (_: ClassNotFoundException) { }
        }
    }

    @Test fun legacyPlainAndPasswordZipFamiliesAreRejectedWithoutStaging() {
        val candidates = listOf("PK\u0003\u0004", "DSHP0001", "DSMP0001", "DSMP9999")
        candidates.forEach { prefix ->
            val file = newFile().also { it.writeBytes(prefix.toByteArray() + ByteArray(256)) }
            val before = temporary.root.listFiles()!!.map { it.name }.toSet()
            val failure = rejected { ArchiveEngine.inspect(file, "old password 2026".toCharArray()) }
            assertTrue(failure.message.orEmpty().contains("Create a new encrypted image"))
            assertEquals(before, temporary.root.listFiles()!!.map { it.name }.toSet())
        }
    }

    @Test fun encryptedHeaderCatalogAndLastPayloadTamperAllPreventAcceptance() {
        val valid = create().readBytes()
        listOf(8, 111, 120, valid.lastIndex).forEach { offset ->
            val bad = newFile().also { it.writeBytes(valid.clone().also { data -> data[offset] = (data[offset].toInt() xor 1).toByte() }) }
            rejected { ArchiveEngine.inspect(bad) }
        }
    }

    @Test fun truncatedAndAppendedEncryptedImagesAreRejected() {
        val valid = create().readBytes()
        listOf(byteArrayOf(), "DSMP0002".toByteArray(), valid.copyOf(111), valid.copyOf(valid.size-1), valid + byteArrayOf(1)).forEach { bytes ->
            rejected { ArchiveEngine.inspect(newFile().also { it.writeBytes(bytes) }) }
        }
    }

    @Test fun unsafeNamesAreRejectedBeforeSourcesOpen() {
        listOf("../outside", "dir/file", "dir\\file", ".", "..", "", "\u0000name", "line\nname", "delete\u007f").forEach { name ->
            var opened = false; val file = newFile()
            rejected { ArchiveEngine.create(file, request, listOf(BundleInput(name) { opened = true; byteArrayOf(1).inputStream() })) }
            assertFalse(opened); assertFalse(file.exists())
        }
    }

    @Test fun oemPackageKeepsOpaquePayloadEncryptedAndCannotClaimPersonalInventory() {
        val imageRequest = request.copy(kind = BundleKind.OEM_IMAGE, oem = oem)
        rejected { ArchiveEngine.create(newFile(), imageRequest.copy(apps = listOf(AppInventoryItem("com.example.privateapp", "1", 1))), listOf(input("payload.bin", byteArrayOf(1)))) }
        val image = newFile(); val info = ArchiveEngine.create(image, imageRequest, listOf(input("payload.bin", byteArrayOf(1, 2, 3))))
        assertTrue(info.encrypted); assertEquals(oem, info.manifest.oem)
    }

    @Test fun providerFailureClosesInputAndRemovesPartialArchive() {
        var closed = false
        val broken = BundleInput("unavailable.bin", "application/octet-stream") {
            object : InputStream() {
                var calls = 0
                override fun read(): Int = throw UnsupportedOperationException()
                override fun read(bytes: ByteArray, offset: Int, length: Int): Int {
                    if (calls++ > 0) throw IOException("Disconnected USB-C document provider")
                    bytes.fill(0x42, offset, offset + minOf(1024, length)); return minOf(1024, length)
                }
                override fun close() { closed = true }
            }
        }
        val output = newFile()
        val failure = rejected { ArchiveEngine.create(output, request, listOf(broken)) }
        assertTrue(failure is IOException)
        assertTrue(closed)
        assertFalse(output.exists())
    }

    @Test fun stalledProviderDoesNotSpinOrLeavePartialArchive() {
        val output = newFile()
        rejected { ArchiveEngine.create(output, request, listOf(BundleInput("stalled.bin") {
            object : ByteArrayInputStream(byteArrayOf(1)) {
                override fun read(bytes: ByteArray, offset: Int, length: Int): Int = 0
            }
        })) }
        assertFalse(output.exists())
    }

    @Test fun existingOutputIsNeverOverwrittenOrDeleted() {
        val original = byteArrayOf(0x13, 0x37, 0, 0xff.toByte())
        val output = newFile().also { it.writeBytes(original) }
        rejected { ArchiveEngine.create(output, request, listOf(input("file.txt", byteArrayOf(1)))) }
        assertArrayEquals(original, output.readBytes())
    }

    @Test fun appInventoryOnlyBackupIsAllowedAndMarkedPortable() {
        val apps = listOf(AppInventoryItem("com.example.reader", "2.4", 24))
        val inspection = ArchiveEngine.create(newFile(), request.copy(apps = apps), emptyList())
        assertEquals(BundleKind.PORTABLE_BACKUP, inspection.manifest.kind)
        assertEquals(apps, inspection.manifest.apps)
        assertEquals(0, inspection.manifest.entries.size)
        assertEquals(0L, inspection.totalPayloadBytes)
    }

    @Test fun emptyBackupAndDuplicateInventoryAreRejected() {
        rejected { ArchiveEngine.create(newFile(), request, emptyList()) }
        val app = AppInventoryItem("com.example.reader", "2.4", 24)
        rejected { ArchiveEngine.create(newFile(), request.copy(apps = listOf(app, app)), emptyList()) }
    }

    @Test fun oemImageRequiresTargetMetadataAndPayload() {
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE), listOf(input("payload.bin", byteArrayOf(1)))) }
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE, oem = oem.copy(deviceCodename = "")), listOf(input("payload.bin", byteArrayOf(1)))) }
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE, oem = oem), emptyList()) }
        rejected { ArchiveEngine.create(newFile(), request.copy(oem = oem), listOf(input("file.txt", byteArrayOf(1)))) }
    }

    private fun create(): File = newFile().also { output -> ArchiveEngine.create(output, request, sampleContents.map { (name, bytes) -> input(name, bytes) }) }
    private fun input(name: String, bytes: ByteArray) = BundleInput(name, "application/octet-stream") { bytes.inputStream() }
    private fun newFile() = File(temporary.root, "archive-${java.util.UUID.randomUUID()}.dshare")
    private fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun rejected(block: () -> Unit): Throwable {
        try { block() } catch (failure: Exception) { return failure }
        throw AssertionError("Unsafe or unsupported image operation was accepted")
    }
}
