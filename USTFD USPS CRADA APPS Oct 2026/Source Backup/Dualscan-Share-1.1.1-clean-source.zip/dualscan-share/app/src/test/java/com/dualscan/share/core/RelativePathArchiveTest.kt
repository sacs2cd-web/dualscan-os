package com.dualscan.share.core

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Public-folder layout is archive metadata; ZIP payload names never become paths. */
class RelativePathArchiveTest {
    @get:Rule val temporary = TemporaryFolder()
    private val device = DeviceIdentity("Dualscan", "Test", "test", "14", 34, "test-build", "2026-10-01")
    private val request get() = BundleRequest("Public folders", device = device)

    @Test fun nestedUnicodeAndSameBasenamePathsStayInEncryptedCatalogForPlayer() {
        val files = linkedMapOf("Documents/Research/東京 résumé.txt" to "Καλημέρα".toByteArray(), "Documents/settings.json" to byteArrayOf(1), "Download/settings.json" to byteArrayOf(2))
        val archive = newFile(); val info = ArchiveEngine.create(archive, request, files.map { (path, bytes) -> input(path, bytes) })
        assertEquals(files.keys.toList(), info.manifest.entries.map { it.relativePath })
        com.dualscan.mp.core.MediaArray.open(archive).use { array ->
            array.catalog.entries.forEach { entry -> assertArrayEquals(files.getValue(requireNotNull(entry.relativePath)), array.openEntry(entry.id).use { it.readBytes() }) }
        }
        assertTrue(temporary.root.listFiles()!!.all { it.extension == "dshare" })
    }
    @Test fun casefoldAndUnicodeCollisionsAreRejectedBeforeOpeningInputs() {
        listOf(listOf("Documents/report.txt", "documents/REPORT.txt"), listOf("Documents/résumé.txt", "Documents/re\u0301sume\u0301.txt")).forEach { paths ->
            var opens = 0; val output = newFile()
            rejected { ArchiveEngine.create(output, request, paths.map { path -> BundleInput(path.substringAfterLast('/'), "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }) }
            assertEquals(0, opens); assertFalse(output.exists())
        }
    }
    @Test fun traversalAbsoluteControlAndMismatchedBasenamePathsAreRejected() {
        val invalid = listOf("../report.txt", "Documents/../report.txt", "/Documents/report.txt", "Documents//report.txt", "./report.txt", "Documents/./report.txt", "Documents\\report.txt", "Documents/\n/report.txt", "Documents/\u007f/report.txt", "", "Documents/report.txt/", "Documents/different.txt")
        invalid.forEach { path ->
            var opened = false; val output = newFile()
            rejected { ArchiveEngine.create(output, request, listOf(BundleInput("report.txt", "text/plain", path) { opened = true; byteArrayOf(1).inputStream() })) }
            assertFalse(opened); assertFalse(output.exists())
        }
    }
    @Test fun duplicateEffectivePathsAreRejectedBeforeOpeningAnyInputOrCreatingOutput() {
        val duplicates = listOf(
            listOf("Documents/report.txt", "Documents/report.txt"),
            listOf(null, "report.txt")
        )
        duplicates.forEach { paths ->
            var opens = 0
            val output = newFile()
            val sources = paths.map { path -> BundleInput("report.txt", "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }
            rejected { ArchiveEngine.create(output, request, sources) }
            assertEquals("Duplicate effective paths must be preflighted", 0, opens)
            assertFalse(output.exists())
        }
    }

    @Test fun aFileCannotAlsoBeAnotherEntriesParentDirectory() {
        listOf(
            listOf("Documents/report.txt", "Documents/report.txt/child.txt"),
            listOf("Documents/REPORT.txt", "documents/report.txt/child.txt")
        ).forEach { paths ->
            var opens = 0
            val sources = paths.map { path -> BundleInput(path.substringAfterLast('/'), "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, sources) }
            assertEquals(0, opens)
            assertFalse(output.exists())
        }
    }

    @Test fun pathsBeyondLengthOrDepthLimitAreRejected() {
        val tooDeep = (List(32) { "folder" } + "report.txt").joinToString("/")
        val tooLong = "folder/" + "x".repeat(1010) + "/report.txt"
        assertTrue(tooLong.length > 1024)
        listOf(tooDeep, tooLong).forEach { path ->
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, listOf(BundleInput("report.txt", "text/plain", path) { byteArrayOf(1).inputStream() })) }
            assertFalse(output.exists())
        }
    }

    @Test fun maximumSupportedDepthIsAccepted() {
        val path = (List(31) { "folder" } + "report.txt").joinToString("/")
        val inspection = ArchiveEngine.create(newFile(), request, listOf(input(path, byteArrayOf(1))))
        assertEquals(path, inspection.manifest.entries.single().relativePath)
    }

    @Test fun publicFolderArchiveCanExceedFormer512EntryLimit() {
        val inputs = (1..513).map { index -> input("Documents/folder/item-$index.txt", byteArrayOf(index.toByte())) }
        val inspection = ArchiveEngine.create(newFile(), request, inputs)
        assertEquals(513, inspection.manifest.entries.size)
        assertEquals(513L, inspection.totalPayloadBytes)
    }

    @Test fun moreThanTenThousandEntriesIsRejectedBeforeSourcesOpen() {
        var opens = 0
        val inputs = (1..10_001).map { index -> BundleInput("item-$index.txt", "text/plain", "Documents/item-$index.txt") { opens++; byteArrayOf().inputStream() } }
        val output = newFile()
        rejected { ArchiveEngine.create(output, request, inputs) }
        assertEquals(0, opens)
        assertFalse(output.exists())
    }

    private fun input(path: String, bytes: ByteArray) = BundleInput(path.substringAfterLast('/'), "application/octet-stream", path) { bytes.inputStream() }
    private fun newFile() = File(temporary.root, "paths-${UUID.randomUUID()}.dshare")
    private fun rejected(block: () -> Unit) { try { block() } catch (_: Exception) { return }; throw AssertionError("Unsafe path was accepted") }
}
