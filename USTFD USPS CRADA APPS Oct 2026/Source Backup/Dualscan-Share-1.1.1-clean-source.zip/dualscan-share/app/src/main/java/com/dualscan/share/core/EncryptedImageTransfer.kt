package com.dualscan.share.core

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/** Copies only complete ciphertext containers. There is deliberately no entry export API. */
object EncryptedImageTransfer {
    private val magic = "DSMP0002".toByteArray(Charsets.US_ASCII)
    private const val REAUTHOR = "This is an older or unsupported image. Create a new encrypted image from the original files using the latest Dualscan Share."

    fun requirePortable(file: File) {
        require(file.isFile && file.length() in 112..ArchiveEngine.MAX_ENCRYPTED_BYTES) { REAUTHOR }
        file.inputStream().use { requireHeader(it) }
    }

    /** Used to receive a USB image into app-private storage before authentication. */
    fun receive(input: InputStream, output: OutputStream): CiphertextCopy {
        val header = requireHeader(input)
        val digest = MessageDigest.getInstance("SHA-256")
        output.write(header); digest.update(header)
        var total = header.size.toLong()
        val buffer = ByteArray(128 * 1024)
        while (true) {
            interrupted()
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) throw IOException("The storage provider stopped producing image data.")
            require(count <= ArchiveEngine.MAX_ENCRYPTED_BYTES - total) { "This image exceeds the supported size limit." }
            output.write(buffer, 0, count); digest.update(buffer, 0, count); total += count
        }
        require(total >= 112) { "The encrypted image is incomplete." }
        output.flush()
        return CiphertextCopy(total, hex(digest.digest()))
    }

    /** The caller authenticates the source first, and deletes a new destination on failure. */
    fun copyVerified(source: File, authenticatedSha256: String, destination: () -> OutputStream, readBack: () -> InputStream): CiphertextCopy {
        requirePortable(source)
        require(authenticatedSha256.matches(Regex("[0-9a-f]{64}")) && ArchiveEngine.sha256(source) == authenticatedSha256) {
            "The image changed after validation. Reopen the original image before copying."
        }
        val copy = source.inputStream().use { input -> destination().use { output -> receive(input, output) } }
        require(copy.bytes == source.length() && copy.sha256 == authenticatedSha256) { "The image changed during copying." }
        val checked = readBack().use { input ->
            val digest = MessageDigest.getInstance("SHA-256"); var count = 0L
            val buffer = ByteArray(128 * 1024)
            while (true) {
                interrupted()
                val n = input.read(buffer)
                if (n < 0) break
                if (n == 0) throw IOException("The storage provider could not read back the saved image.")
                require(n <= ArchiveEngine.MAX_ENCRYPTED_BYTES - count) { "The saved image is too large." }
                count += n; digest.update(buffer, 0, n)
            }
            CiphertextCopy(count, hex(digest.digest()))
        }
        require(checked == copy) { "The saved image failed exact ciphertext read-back verification." }
        return copy
    }

    private fun requireHeader(input: InputStream): ByteArray {
        val header = ByteArray(magic.size); var count = 0
        while (count < header.size) {
            interrupted()
            val n = input.read(header, count, header.size - count)
            require(n > 0) { REAUTHOR }; count += n
        }
        require(MessageDigest.isEqual(header, magic)) { REAUTHOR }
        return header
    }
    private fun interrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Image transfer cancelled.") }
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
}

data class CiphertextCopy(val bytes: Long, val sha256: String)
