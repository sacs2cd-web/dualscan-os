package com.dualscan.share

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.dualscan.share.core.*
import java.io.File
import java.io.IOException
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

/** Moves independently encrypted files while preserving their portable folder layout. */
object EncryptedBatchTransfer {
    fun saveToUsb(context: Context, batch: AuthoredMediaBatch, tree: Uri): SavedEncryptedBatch {
        UsbStorageAccess.requireUsbDocument(context, tree)
        return save(context, batch, tree)
    }

    fun saveToDevice(context: Context, batch: AuthoredMediaBatch, tree: Uri): SavedEncryptedBatch {
        LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
        require(tree.authority == UsbAccessPolicy.AUTHORITY && DocumentsContract.getTreeDocumentId(tree).startsWith("primary:")) {
            "Choose a shared folder on this device, such as Music, Pictures or Movies."
        }
        return save(context, batch, tree)
    }

    private fun save(context: Context, batch: AuthoredMediaBatch, tree: Uri): SavedEncryptedBatch {
        require(batch.items.isNotEmpty() && batch.items.size <= ArchiveEngine.MAX_ENTRIES) { "Open or create encrypted files first." }
        val paths = batch.items.map { checkedPath(it.relativePath) }
        require(paths.map(::key).toSet().size == paths.size) { "Two encrypted files have conflicting destination paths." }
        batch.items.forEach { item ->
            interrupted(); EncryptedImageTransfer.requirePortable(item.file)
            require(item.inspection.encrypted && ArchiveEngine.sha256(item.file) == item.inspection.archiveSha256) { "An encrypted file changed after verification. Open the original again." }
        }
        val parent = DocumentFile.fromTreeUri(context, tree) ?: throw IOException("The selected folder is unavailable.")
        require(parent.canWrite()) { "The selected folder is not writable." }
        val folderName = "DualscanShare-${UUID.randomUUID().toString().take(12)}"
        val folder = parent.createDirectory(folderName) ?: throw IOException("Could not create a new encrypted media folder.")
        try {
            try { folder.createFile("application/octet-stream", ".nomedia")?.let { context.contentResolver.openOutputStream(it.uri, "w")?.close() } } catch (_: Exception) { }
            val directories = hashMapOf("" to folder)
            var bytes = 0L
            batch.items.forEachIndexed { index, item ->
                interrupted()
                val parts = paths[index]; var destination = folder; var prefix = ""
                for (name in parts.dropLast(1)) {
                    prefix = if (prefix.isEmpty()) name else "$prefix/$name"
                    destination = directories[key(prefix)] ?: destination.createDirectory(name)?.also { directories[key(prefix)] = it }
                        ?: throw IOException("A nested encrypted media folder could not be created.")
                }
                val pending = destination.createFile("application/octet-stream", ".DS-${UUID.randomUUID()}.part") ?: throw IOException("An encrypted file could not be created.")
                val result = EncryptedImageTransfer.copyVerified(item.file, item.inspection.archiveSha256,
                    { context.contentResolver.openOutputStream(pending.uri, "wt") ?: throw IOException("The destination could not open an encrypted file.") },
                    { context.contentResolver.openInputStream(pending.uri) ?: throw IOException("The saved encrypted file could not be read back.") })
                require(pending.renameTo(parts.last())) { "An encrypted file could not be finalized." }
                bytes = Math.addExact(bytes, result.bytes)
            }
            return SavedEncryptedBatch(folder.uri, folderName, batch.items.size, bytes)
        } catch (failure: Throwable) {
            val removed = try { folder.delete() } catch (_: Exception) { false }
            throw IOException("Encrypted file transfer stopped. " + if (removed) "The new incomplete folder was removed; source files are unchanged." else "An incomplete $folderName folder may remain. Its files are still encrypted.", failure)
        }
    }

    /** The output directory is app-private transient ciphertext, removed when the session closes. */
    fun receiveUsbFolder(context: Context, tree: Uri, directory: File, password: CharArray? = null): AuthoredMediaBatch {
        UsbStorageAccess.requireUsbDocument(context, tree)
        require(!directory.exists() && directory.mkdirs()) { "Could not create a temporary encrypted transfer directory." }
        val resolver = context.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val title = DocumentFile.fromTreeUri(context, tree)?.name?.take(160)?.ifBlank { null } ?: "USB media"
        val items = mutableListOf<AuthoredMediaItem>(); val directories = hashSetOf<String>(); var scanned = 0; var payload = 0L; var encrypted = 0L
        try {
            fun walk(id: String, parent: String, depth: Int) {
                interrupted()
                require(depth <= 32 && directories.add(id)) { "The USB folder is too deep or contains a repeated directory." }
                val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
                resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { cursor ->
                    while (cursor.moveToNext()) {
                        interrupted(); require(++scanned <= ArchiveEngine.MAX_ENTRIES) { "Choose a USB folder containing at most ${ArchiveEngine.MAX_ENTRIES} items." }
                        require(!cursor.isNull(0) && !cursor.isNull(1)) { "A USB folder item has no readable name or identity." }
                        val childId = cursor.getString(0); val name = cursor.getString(1)
                        if (name.startsWith('.')) continue
                        require(childId.startsWith(if (rootId.endsWith(':')) rootId else "$rootId/") && childId != rootId) { "A USB item is outside the selected folder." }
                        val path = listOf(parent, name).filter { it.isNotEmpty() }.joinToString("/"); checkedPath(path)
                        if (cursor.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) { walk(childId, path, depth + 1); continue }
                        if (name.substringAfterLast('.', "").lowercase(Locale.ROOT) !in setOf("diamond", "dshare", "dmpa")) continue
                        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, childId)
                        val copy = File(directory, "${(items.size + 1).toString().padStart(6, '0')}.diamond")
                        resolver.openInputStream(uri)?.use { input -> copy.outputStream().use { output -> EncryptedImageTransfer.receive(input, output) } }
                            ?: throw IOException("A USB encrypted file could not be opened.")
                        val info = ArchiveEngine.inspect(copy, password)
                        require(info.totalPayloadBytes <= ArchiveEngine.MAX_PAYLOAD_BYTES - payload) { "The selected encrypted files exceed the 32 GiB limit." }
                        payload += info.totalPayloadBytes; encrypted = Math.addExact(encrypted, info.archiveBytes)
                        items += AuthoredMediaItem(copy, path, info)
                    }
                } ?: throw IOException("The USB folder is no longer readable.")
            }
            walk(rootId, "", 0)
            require(items.isNotEmpty()) { "No supported encrypted Diamond files were found in this USB folder." }
            require(items.map { key(checkedPath(it.relativePath)) }.toSet().size == items.size) { "The USB folder contains conflicting portable paths." }
            UsbStorageAccess.requireUsbDocument(context, tree)
            return AuthoredMediaBatch(title, items.toList(), payload, encrypted)
        } catch (failure: Throwable) { directory.deleteRecursively(); throw failure }
    }

    internal fun checkedPath(path: String): List<String> {
        require(path.isNotBlank() && path.length <= 2048 && !path.startsWith('/') && !path.contains('\\')) { "An encrypted file has an unsafe relative path." }
        return path.split('/').also { parts ->
            require(parts.size <= 32 && parts.all { it.isNotBlank() && it !in setOf(".", "..") && it.toByteArray(Charsets.UTF_8).size <= 255 && it.none { c -> c.code < 32 || c.code == 127 } }) { "An encrypted filename or folder is too long, too deep or unsafe." }
            require(parts.zipWithNext().none { (a, b) -> a.equals("Android", true) && b.lowercase(Locale.ROOT) in setOf("data", "obb", "sandbox") }) { "Android private app directories are not media destinations." }
        }
    }
    private fun key(path: String) = Normalizer.normalize(path, Normalizer.Form.NFC).uppercase(Locale.ROOT).lowercase(Locale.ROOT)
    private fun key(path: List<String>) = key(path.joinToString("/"))
    private fun interrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Encrypted media transfer stopped.") }
}

data class SavedEncryptedBatch(val folderUri: Uri, val folderName: String, val files: Int, val bytes: Long)
