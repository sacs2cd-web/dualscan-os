package com.dualscan.share

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dualscan.share.core.*
import com.dualscan.mp.core.PasswordRequiredException
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class ShareViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    val exports = File(app.filesDir, "exports").apply { mkdirs() }
    var selectedFiles by mutableStateOf<List<SelectedDocument>>(emptyList()); private set
    var currentFile by mutableStateOf<File?>(null); private set
    var currentBatch by mutableStateOf<AuthoredMediaBatch?>(null); private set
    var inspection by mutableStateOf<BundleInspection?>(null); private set
    var busy by mutableStateOf(false); private set
    var status by mutableStateOf("Choose local shared files or folders. Media transfer uses USB-C only."); private set
    var error by mutableStateOf<String?>(null); private set
    var usbReady by mutableStateOf(false); private set
    var usbLabel by mutableStateOf("Connect a drive"); private set
    var title by mutableStateOf("My media")
    var description by mutableStateOf("")
    var passwordText by mutableStateOf("")
    var passwordConfirmation by mutableStateOf("")
    var passwordRequiredUri by mutableStateOf<Uri?>(null); private set
    var passwordRequiredFolder by mutableStateOf(false); private set
    var oemManufacturer by mutableStateOf("Dualscan")
    var oemCodename by mutableStateOf("")
    var oemBuildId by mutableStateOf("")
    var oemFormat by mutableStateOf("OEM_SUPPLIED")
    var oemSigningKey by mutableStateOf("")
    private var currentPassword: CharArray? = null
    private var sourceUsbUri: Uri? = null
    val archiveFromUsb get() = sourceUsbUri != null
    private var operationJob: Job? = null
    private var operationWorker: AtomicReference<Thread?>? = null
    val device = DeviceIdentity(Build.MANUFACTURER, Build.MODEL, Build.DEVICE, Build.VERSION.RELEASE,
        Build.VERSION.SDK_INT, Build.FINGERPRINT, Build.VERSION.SECURITY_PATCH)
    val isDeviceOwner: Boolean get() = (app.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isDeviceOwnerApp(app.packageName)
    private val maintenance = viewModelScope.async(Dispatchers.IO) {
        app.cacheDir.listFiles()?.filter { it.name.startsWith("contacts-") || it.name.startsWith(".dualscan-unlocked-") }?.forEach { it.delete() }
        exports.listFiles()?.filter { it.isFile && (it.name.startsWith(".dualscan-unlocked-") || it.name.endsWith(".part") || it.extension in setOf("dshare", "diamond")) }?.forEach { it.delete() }
        exports.listFiles()?.filter { it.isDirectory && (it.name.startsWith("Media-batch-") || it.name.startsWith("USB-batch-")) }?.forEach { it.deleteRecursively() }
    }
    init { refreshUsb() }

    fun refreshUsb() {
        val state = try { UsbStorageAccess.snapshot(app) } catch (_: Exception) { null }
        usbReady = state?.ready == true
        usbLabel = if (usbReady) "Drive connected" else "Connect a drive"
    }

    fun selectDocuments(uris: List<Uri>, oem: Boolean = false) {
        if (busy || uris.isEmpty()) return
        runTask("Checking the selected local files.") {
            require(uris.distinct().size <= ArchiveEngine.MAX_ENTRIES) { "Select at most ${ArchiveEngine.MAX_ENTRIES} files per archive." }
            val selected = uris.distinct().map { uri ->
                LocalMediaSourcePolicy.requireLocal(uri.authority.orEmpty(), uri.path.orEmpty())
                try { app.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { /* Use the current foreground grant. */ }
                var name = uri.lastPathSegment ?: "Document"; var size: Long? = null
                app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) ?: name }
                        c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) }
                    }
                }
                if (!oem) GenericFilePolicy.requireUnprotectedSource(name)
                val mime = app.contentResolver.getType(uri)
                GenericFilePolicy.requireAllowed(name, mime)
                SelectedDocument(uri, name, mime, size)
            }
            withContext(Dispatchers.Main) { selectedFiles = mergeSelection(selectedFiles, selected)
                status = "${selectedFiles.size} local file(s) selected. Apps and private app data are not included." }
        }
    }
    fun selectFolder(tree: Uri) {
        if (busy) return
        runTask("Reading the accessible local folder and its subfolders.") {
            LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
            try { app.contentResolver.takePersistableUriPermission(tree, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            val folder = LocalFolderEnumerator.enumerate(app, tree)
            withContext(Dispatchers.Main) {
                selectedFiles = mergeSelection(selectedFiles, folder.files)
                status = "Added ${folder.files.size} files from ${folder.name}, preserving relative folders. ${folder.skippedPackages} application package/runtime files and ${folder.skippedProtected} already-protected files skipped. ${selectedFiles.size} files selected in total."
            }
        }
    }
    private fun mergeSelection(existing: List<SelectedDocument>, added: List<SelectedDocument>): List<SelectedDocument> {
        val merged = (existing + added).associateBy { document ->
            val id = try { DocumentsContract.getDocumentId(document.uri) } catch (_: Exception) { document.uri.toString() }
            "${document.uri.authority}:$id"
        }.values.toList()
        require(merged.size <= ArchiveEngine.MAX_ENTRIES) { "One image supports at most ${ArchiveEngine.MAX_ENTRIES} files. Clear some sources or choose a smaller folder." }
        return merged
    }
    fun clearSelection() { if (!busy) selectedFiles = emptyList() }

    fun createBundle(oem: Boolean) {
        if (busy) return
        val sources = selectedFiles.toList(); val bundleTitle = title.trim(); val bundleDescription = description.trim()
        val pass = passwordText.takeIf { it.isNotEmpty() }?.toCharArray(); val match = passwordText == passwordConfirmation
        val metadata = if (oem) OemImageMetadata(oemManufacturer.trim(), oemCodename.trim(), oemBuildId.trim(), oemFormat.trim(), oemSigningKey.trim()) else null
        runTask("Encrypting and verifying the selected files. Keep the drive connected.") {
            try {
                UsbStorageAccess.requireAvailable(app)
                require(!oem || BuildConfig.OEM_EDITION) { "OEM images require the OEM edition." }
                require(sources.isNotEmpty()) { "Choose accessible local files or folders first." }
                require(bundleTitle.isNotBlank()) { "Give this collection a title." }
                require(pass == null || pass.size in 8..256) { "Use a password with 8 to 256 characters, or leave both password fields empty." }
                require(match) { "The passwords do not match." }
                sources.forEach { LocalMediaSourcePolicy.requireLocal(it.uri.authority.orEmpty(), it.uri.path.orEmpty()); GenericFilePolicy.requireAllowed(it.name, it.mimeType); if (!oem) GenericFilePolicy.requireUnprotectedSource(it.name) }
                val request = BundleRequest(bundleTitle, bundleDescription, if (oem) BundleKind.OEM_IMAGE else BundleKind.PORTABLE_BACKUP, device, emptyList(), metadata)
                val inputs = sources.map { doc -> BundleInput(doc.name, doc.mimeType, doc.relativePath) {
                    app.contentResolver.openInputStream(doc.uri) ?: throw IOException("The local provider could not open ${doc.name}.")
                } }
                if (oem) {
                    val out = File(exports, "Dualscan-OEM-${stamp()}-${UUID.randomUUID().toString().take(8)}.dshare")
                    val result = ArchiveEngine.create(out, request, inputs, pass)
                    withContext(Dispatchers.Main) {
                        activate(out, result, pass, null); passwordText = ""; passwordConfirmation = ""
                        status = "OEM package verified. Save it to USB-C to finish."
                    }
                } else {
                    val batch = EncryptedMediaBatch.create(File(exports, "Media-batch-${stamp()}-${UUID.randomUUID().toString().take(8)}"), request, inputs, pass)
                    withContext(Dispatchers.Main) {
                        activateBatch(batch, pass, null); passwordText = ""; passwordConfirmation = ""
                        status = "${batch.items.size} Diamond files verified. Save the files to USB-C. Your original files are unchanged."
                    }
                }
            } finally { pass?.fill('\u0000') }
        }
    }

    fun importArchive(uri: Uri, password: CharArray? = null) {
        if (busy) { password?.fill('\u0000'); return }
        runTask("Reading the USB archive and verifying its complete contents.") {
            val imported = File(exports, "USB-Import-${stamp()}-${UUID.randomUUID().toString().take(8)}.dshare")
            try {
                UsbStorageAccess.requireUsbDocument(app, uri)
                app.contentResolver.openInputStream(uri)?.use { input -> imported.outputStream().use { output ->
                    EncryptedImageTransfer.receive(input, output)
                } } ?: throw IOException("The USB drive could not open this image.")
                val result = try { ArchiveEngine.inspect(imported, password) }
                catch (failure: PasswordRequiredException) {
                    withContext(Dispatchers.Main) { passwordRequiredUri = uri; passwordRequiredFolder = false; status = "This file needs its password." }
                    imported.delete()
                    return@runTask
                }
                if (!BuildConfig.OEM_EDITION) {
                    require(result.manifest.kind == BundleKind.PORTABLE_BACKUP) { "Use Dualscan Share OEM for firmware packages. Lite carries encrypted files and media." }
                    result.manifest.entries.forEach { GenericFilePolicy.requireAllowed(it.displayName, it.mimeType) }
                    require(result.manifest.apps.isEmpty()) { "Lite does not import app inventories or application backups." }
                }
                val sourceName = app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                    ?.takeIf { runCatching { EncryptedBatchTransfer.checkedPath(it) }.isSuccess } ?: "Media-${UUID.randomUUID()}.diamond"
                withContext(Dispatchers.Main) {
                    if (result.manifest.kind == BundleKind.PORTABLE_BACKUP && result.manifest.entries.size == 1) {
                        activateBatch(AuthoredMediaBatch(result.manifest.title, listOf(AuthoredMediaItem(imported, sourceName, result)), result.totalPayloadBytes, result.archiveBytes), password, uri)
                    } else activate(imported, result, password, uri)
                    passwordRequiredUri = null; passwordRequiredFolder = false; refreshUsb()
                    status = "USB files verified. Save them to a shared folder on this device, then open that folder in Diamond Player."
                }
            } catch (failure: Exception) { imported.delete(); throw failure }
            finally { password?.fill('\u0000') }
        }
    }

    fun importUsbFolder(tree: Uri, password: CharArray? = null) {
        if (busy) { password?.fill('\u0000'); return }
        runTask("Reading and verifying Diamond files from USB-C.") {
            val directory = File(exports, "USB-batch-${stamp()}-${UUID.randomUUID().toString().take(8)}")
            try {
                try { app.contentResolver.takePersistableUriPermission(tree, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
                val batch = try { EncryptedBatchTransfer.receiveUsbFolder(app, tree, directory, password) }
                catch (failure: PasswordRequiredException) {
                    withContext(Dispatchers.Main) { passwordRequiredUri = tree; passwordRequiredFolder = true; status = "The USB folder contains password-protected files." }
                    return@runTask
                }
                if (!BuildConfig.OEM_EDITION) batch.items.forEach { item ->
                    require(item.inspection.manifest.kind == BundleKind.PORTABLE_BACKUP && item.inspection.manifest.apps.isEmpty()) { "Lite carries shared files and media only." }
                    item.inspection.manifest.entries.forEach { GenericFilePolicy.requireAllowed(it.displayName, it.mimeType) }
                }
                withContext(Dispatchers.Main) {
                    activateBatch(batch, password, tree); passwordRequiredUri = null; passwordRequiredFolder = false
                    status = "${batch.items.size} USB files verified. Save them to a shared Music, Pictures or Movies folder on this device."
                }
            } catch (failure: Throwable) { directory.deleteRecursively(); throw failure }
            finally { password?.fill('\u0000') }
        }
    }

    fun exportBatchToUsbTree(tree: Uri) {
        if (busy) return
        val batch = currentBatch ?: return
        runTask("Saving Diamond files to USB-C and verifying each copy.") {
            val result = EncryptedBatchTransfer.saveToUsb(app, batch, tree)
            withContext(Dispatchers.Main) { status = "Saved ${result.files} Diamond files (${formatBytes(result.bytes)}) to ${result.folderName}. Every copy passed exact read-back verification. Eject the USB drive before removing it." }
        }
    }

    fun cancelCurrentTransfer() { status = "Stopping the current operation safely…"; operationJob?.cancel(); operationWorker?.get()?.interrupt() }
    fun saveEncryptedToDevice(tree: Uri) {
        if (busy) return
        val batch = currentBatch
        if (batch != null) {
            val source = sourceUsbUri ?: return
            runTask("Saving Diamond files to this device without changing their encryption.") {
                UsbStorageAccess.requireUsbDocument(app, source)
                val result = EncryptedBatchTransfer.saveToDevice(app, batch, tree)
                withContext(Dispatchers.Main) { status = "Saved ${result.files} Diamond files to ${result.folderName}. In Diamond Player, open this shared folder to play your files." }
            }
            return
        }
        val file = currentFile ?: return; val source = sourceUsbUri ?: return
        val checked = inspection ?: return
        runTask("Saving the encrypted image to this device. Files stay inside the image.") {
            UsbStorageAccess.requireUsbDocument(app, source)
            val result = EncryptedImageImporter.copyToDevice(app, file, checked.archiveSha256, tree)
            withContext(Dispatchers.Main) {
                status = "Saved ${formatBytes(result.bytes)} as DualscanShare/${result.name}. The complete encrypted image passed exact read-back verification. Open this .dshare image in Diamond Player."
            }
        }
    }

    fun exportToUsbTree(tree: Uri, file: File) {
        if (busy) return
        runTask("Saving the encrypted image to USB storage. Keep the drive connected until read-back verification finishes.") {
            // Validate the selected provider and volume before creating or opening anything.
            UsbStorageAccess.requireUsbDocument(app, tree)
            val checked = ArchiveEngine.inspect(file, currentPassword)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val uri = DocumentsContract.createDocument(app.contentResolver, parent, "application/octet-stream", file.name)
                ?: throw IOException("The USB folder could not create the image file.")
            writeUsbExport(uri, file, checked.archiveSha256)
        }
    }
    private suspend fun writeUsbExport(uri: Uri, file: File, authenticatedSha256: String) {
        try {
            val result = EncryptedImageTransfer.copyVerified(file, authenticatedSha256,
                { app.contentResolver.openOutputStream(uri, "wt") ?: throw IOException("The USB provider could not open the image destination.") },
                { app.contentResolver.openInputStream(uri) ?: throw IOException("The USB provider could not read back the image.") })
            withContext(Dispatchers.Main) { status = "Saved ${formatBytes(result.bytes)} to USB-C. The complete encrypted image passed exact SHA-256 read-back verification. Eject the drive before removing it." }
        } catch (failure: Exception) {
            val deleted = removePartialExport(uri)
            throw IOException("USB copy stopped. " + if (deleted) "The incomplete image was removed." else "An incomplete encrypted image may remain; remove it before retrying.", failure)
        }
    }
    private fun removePartialExport(uri: Uri) = try { DocumentsContract.deleteDocument(app.contentResolver, uri) } catch (_: Exception) { false }
    fun dismissError() { error = null }
    fun dismissPasswordRequest() { passwordRequiredUri = null; passwordRequiredFolder = false }
    fun closeArchive() {
        if (busy) return
        clearWorkingCopy(); passwordText = ""; passwordConfirmation = ""; passwordRequiredUri = null; passwordRequiredFolder = false
        status = "Closed. Temporary encrypted transfer files and the session password were removed. Your saved files are unchanged."
    }
    private fun clearWorkingCopy() {
        currentPassword?.fill('\u0000'); currentPassword = null
        currentFile?.delete()
        currentBatch?.items?.forEach { it.file.delete() }
        currentBatch?.items?.firstOrNull()?.file?.parentFile?.takeIf { it != exports && it.parentFile == exports }?.delete()
        currentFile = null; currentBatch = null; sourceUsbUri = null; inspection = null
    }
    private fun activate(file: File, info: BundleInspection, password: CharArray?, source: Uri?) {
        clearWorkingCopy()
        currentPassword = if (info.passwordProtected) password?.copyOf() else null
        currentFile = file; inspection = info; sourceUsbUri = source
    }
    private fun activateBatch(batch: AuthoredMediaBatch, password: CharArray?, source: Uri?) {
        clearWorkingCopy()
        currentPassword = if (batch.items.any { it.inspection.passwordProtected }) password?.copyOf() else null
        currentBatch = batch; sourceUsbUri = source
    }
    override fun onCleared() { operationJob?.cancel(); operationWorker?.get()?.interrupt(); currentPassword?.fill('\u0000'); passwordText = ""; passwordConfirmation = ""; super.onCleared() }
    private fun runTask(message: String, task: suspend () -> Unit) {
        busy = true; status = message; error = null
        val worker = AtomicReference<Thread?>(); operationWorker = worker
        val dispatcher = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "DualscanTransfer").apply { worker.set(this) } }.asCoroutineDispatcher()
        val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
            var transfer: TransferService.Session? = null
            try {
                transfer = TransferService.begin(app) { error = "Android's transfer time limit was reached. Inspect any partial output before retrying."; operationJob?.cancel(); worker.get()?.interrupt() }
                transfer.awaitStarted()
                maintenance.await()
                withContext(dispatcher) { task() }
            }
            catch (failure: CancellationException) { status = "Transfer stopped before completion. Source files were unchanged."; throw failure }
            catch (failure: Exception) { error = failure.message ?: "The operation could not be completed."; status = "Operation stopped. Review the message and try again." }
            finally { transfer?.close(); dispatcher.close(); busy = false; operationWorker = null; operationJob = null; refreshUsb() }
        }
        operationJob = job
        job.start()
    }
}
data class SelectedDocument(val uri: Uri, val name: String, val mimeType: String?, val sizeBytes: Long?, val relativePath: String? = null)
fun formatBytes(bytes: Long): String = when { bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f GiB", bytes / (1024.0 * 1024 * 1024)); bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MiB", bytes / (1024.0 * 1024)); bytes >= 1024 -> String.format(Locale.US, "%.1f KiB", bytes / 1024.0); else -> "$bytes B" }
private fun stamp() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("The transfer was interrupted.") }
