package com.dualscan.share

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import androidx.core.content.ContextCompat

/** Native hotplug and mount events keep the foreground controls current without a refresh action. */
object UsbStorageMonitor {
    fun observe(context: Context, changed: () -> Unit): AutoCloseable {
        val app = context.applicationContext
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { changed() }
        }
        try {
            ContextCompat.registerReceiver(app, receiver, usbEvents(), ContextCompat.RECEIVER_NOT_EXPORTED)
            // A data scheme on the USB filter would exclude attachment events with no URI.
            ContextCompat.registerReceiver(app, receiver, volumeEvents(), ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (failure: Exception) {
            runCatching { app.unregisterReceiver(receiver) }
            throw failure
        }
        changed()
        return AutoCloseable { app.unregisterReceiver(receiver) }
    }

    internal fun usbEvents() = IntentFilter().apply {
        addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
    }

    internal fun volumeEvents() = IntentFilter().apply {
        addAction(Intent.ACTION_MEDIA_MOUNTED)
        addAction(Intent.ACTION_MEDIA_UNMOUNTED)
        addAction(Intent.ACTION_MEDIA_EJECT)
        addAction(Intent.ACTION_MEDIA_REMOVED)
        addAction(Intent.ACTION_MEDIA_BAD_REMOVAL)
        addAction(Intent.ACTION_MEDIA_UNMOUNTABLE)
        addAction(Intent.ACTION_MEDIA_CHECKING)
        addAction(Intent.ACTION_MEDIA_SHARED)
        addDataScheme("file")
    }
}
