package com.dualscan.share

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.dualscan.share.core.ArchiveEngine
import com.dualscan.share.core.EncryptedImageTransfer
import java.io.File
import java.io.IOException
import java.util.UUID

/** Saves an unchanged encrypted image, never a decoded photo, audio or video file. */
object EncryptedImageImporter {
    fun copyToDevice(context: Context, archive: File, authenticatedSha256: String, tree: Uri): SavedEncryptedImage {
        LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
        require(tree.authority == UsbAccessPolicy.AUTHORITY && DocumentsContract.getTreeDocumentId(tree).startsWith("primary:")) {
            "Choose an accessible folder on this device, such as Music. Cloud and removable-drive destinations are not accepted for a device copy."
        }
        // Reject an old/plain image before creating any public destination.
        EncryptedImageTransfer.requirePortable(archive)
        require(ArchiveEngine.sha256(archive) == authenticatedSha256) { "The image changed. Open it again before copying." }
        val root = DocumentFile.fromTreeUri(context, tree) ?: throw IOException("The local folder is unavailable.")
        require(root.canWrite()) { "The local folder is not writable." }
        val folder = root.findFile("DualscanShare")?.also { require(it.isDirectory) { "DualscanShare is not a folder." } }
            ?: root.createDirectory("DualscanShare") ?: throw IOException("Could not create the device image folder.")
        // This supplements the encrypted extension; encryption is what prevents ordinary media playback.
        if (folder.findFile(".nomedia") == null) try {
            folder.createFile("application/octet-stream", ".nomedia")?.let { marker -> context.contentResolver.openOutputStream(marker.uri, "w")?.close() }
        } catch (_: Exception) { /* Ciphertext is still not decodable/indexable media. */ }
        val name = "Dualscan-${UUID.randomUUID()}.dshare"
        val pending = folder.createFile("application/octet-stream", ".$name.part") ?: throw IOException("Could not create the encrypted device image.")
        try {
            val result = EncryptedImageTransfer.copyVerified(archive, authenticatedSha256,
                { context.contentResolver.openOutputStream(pending.uri, "wt") ?: throw IOException("Could not open the device image for copying.") },
                { context.contentResolver.openInputStream(pending.uri) ?: throw IOException("Could not verify the copied device image.") })
            require(pending.renameTo(name)) { "The encrypted image could not be finalized." }
            return SavedEncryptedImage(pending.uri, name, result.bytes, result.sha256)
        } catch (failure: Throwable) {
            val deleted = try { pending.delete() } catch (_: Exception) { false }
            throw IOException("Device copy stopped. " + if (deleted) "The incomplete image was removed." else "An incomplete encrypted .part image may remain.", failure)
        }
    }
}

data class SavedEncryptedImage(val uri: Uri, val name: String, val bytes: Long, val sha256: String)
