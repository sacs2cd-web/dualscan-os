package com.dualscan.share.core

import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale

/** One portable encrypted file per source. No decoded output or private-vault dependency. */
object EncryptedMediaBatch {
    fun create(directory: File, request: BundleRequest, inputs: List<BundleInput>, password: CharArray? = null): AuthoredMediaBatch {
        require(request.kind == BundleKind.PORTABLE_BACKUP && request.apps.isEmpty() && request.oem == null) {
            "Individual encrypted files contain shared files and media only."
        }
        require(inputs.isNotEmpty() && inputs.size <= ArchiveEngine.MAX_ENTRIES) { "Choose between 1 and ${ArchiveEngine.MAX_ENTRIES} files." }
        require(request.title.isNotBlank() && request.title.length <= 160 && request.description.length <= 4000) { "Enter a valid collection title." }
        val paths = inputs.map(::encryptedRelativePath)
        val keys = paths.map { Normalizer.normalize(it, Normalizer.Form.NFC).uppercase(Locale.ROOT).lowercase(Locale.ROOT) }
        require(keys.toSet().size == paths.size) { "Two selected files have the same portable path. Choose their parent folders or rename them." }
        val all = keys.toSet()
        keys.forEach { path ->
            var index = path.indexOf('/')
            while (index >= 0) {
                require(path.substring(0, index) !in all) { "A portable path is declared as a file and a folder." }
                index = path.indexOf('/', index + 1)
            }
        }
        require(!directory.exists()) { "Choose a new output directory." }
        require(directory.mkdirs()) { "The encrypted output directory could not be created." }
        val items = mutableListOf<AuthoredMediaItem>()
        var payload = 0L
        var encrypted = 0L
        try {
            inputs.forEachIndexed { index, source ->
                interrupted()
                val remaining = ArchiveEngine.MAX_PAYLOAD_BYTES - payload
                val bounded = source.copy(open = { BudgetedSource(source.open(), remaining) })
                val output = File(directory, "${(index + 1).toString().padStart(6, '0')}.diamond")
                val info = ArchiveEngine.create(output, request.copy(title = source.displayName.take(160)), listOf(bounded), password)
                require(info.manifest.entries.size == 1 && info.encrypted) { "Each media file must have its own encrypted container." }
                payload += info.totalPayloadBytes
                encrypted = Math.addExact(encrypted, info.archiveBytes)
                items += AuthoredMediaItem(output, paths[index], info)
            }
            return AuthoredMediaBatch(request.title, items.toList(), payload, encrypted)
        } catch (failure: Throwable) {
            // This directory was created by this call. Original inputs are never modified.
            directory.deleteRecursively()
            throw failure
        }
    }

    fun encryptedRelativePath(source: BundleInput): String {
        require(source.displayName.substringAfterLast('.', "").lowercase(Locale.ROOT) !in setOf("diamond", "dshare", "dmpa")) {
            "This file is already protected. Use Import to copy it without re-authoring."
        }
        val original = source.relativePath ?: source.displayName
        require(original.isNotBlank() && original.length <= 1024 && !original.startsWith('/') && !original.contains('\\')) { "A selected file has an unsafe relative path." }
        val parts = original.split('/')
        require(parts.size <= 32 && parts.last() == source.displayName) { "A selected file has an invalid relative path." }
        parts.forEach { name ->
            require(name.isNotBlank() && name.length <= 240 && name !in setOf(".", "..") && name.none { it.code < 32 || it.code == 127 }) { "A selected file has an unsafe portable name." }
        }
        require(parts.dropLast(1).all { it.toByteArray(Charsets.UTF_8).size <= 255 }) { "A source folder name is too long for portable storage." }
        var filename = source.displayName + ".diamond"
        if (filename.toByteArray(Charsets.UTF_8).size > 240) {
            val hash = MessageDigest.getInstance("SHA-256").digest(source.displayName.toByteArray(Charsets.UTF_8))
                .take(6).joinToString("") { "%02x".format(it.toInt() and 255) }
            var stem = source.displayName
            while (stem.toByteArray(Charsets.UTF_8).size > 210) stem = stem.dropLast(if (stem.last().isLowSurrogate()) 2 else 1)
            filename = "$stem-$hash.diamond"
        }
        return (parts.dropLast(1) + filename).joinToString("/").also {
            require(it.length <= 1024) { "A selected folder path is too long for portable encrypted files." }
        }
    }

    private fun interrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Media authoring was stopped.") }

    private class BudgetedSource(input: InputStream, private val maximum: Long) : FilterInputStream(input) {
        private var count = 0L
        private fun counted(amount: Int): Int {
            if (amount > 0) {
                require(amount.toLong() <= maximum - count) { "The selected files exceed the 32 GiB batch limit." }
                count += amount
            }
            return amount
        }
        override fun read(): Int = `in`.read().also { if (it >= 0) counted(1) }
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int = counted(`in`.read(buffer, offset, length))
    }
}

data class AuthoredMediaItem(val file: File, val relativePath: String, val inspection: BundleInspection)
data class AuthoredMediaBatch(val title: String, val items: List<AuthoredMediaItem>, val payloadBytes: Long, val archiveBytes: Long)
