"""Bind current Share/Player Android evidence to exact APKs and actual producer files."""
import argparse, hashlib, json, re
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--diamond-project',type=Path)
a=p.parse_args()
share=Path(__file__).resolve().parents[1]
player=a.diamond_project or share.parent/'dualscan-mp'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path): return json.loads(path.read_text())
producer=load(share/'verification/android-ciphertext-api36.json')
consumer=load(player/'verification/android-ciphertext-api36.json')
for project,meta,apk in ((share,producer,'app/build/outputs/apk/lite/debug/app-lite-debug.apk'),(player,consumer,'app/build/outputs/apk/debug/app-debug.apk')):
    record=project/'verification/android-ciphertext-api36.txt'
    text=record.read_text()
    counts=re.findall(r'OK \((\d+) tests?\)',text)
    assert counts and 'FAILURES!!!' not in text
    assert meta['result']=='PASS' and meta['tests']==int(counts[-1]) and meta['androidApi']==36
    assert meta['recordSha256']==sha(record) and meta['testedApkSha256']==sha(project/apk)
vector=load(share/'verification/portable-fixtures/share-fixture.json')
for name,field in (('share-global.dshare','globalSha256'),('share-password.dshare','passwordSha256')):
    source=share/'verification/portable-fixtures'/name
    assert source.read_bytes()[:8]==b'DSMP0002'
    assert sha(source)==vector[field]
    assert source.read_bytes()==(player/'app/src/androidTest/assets/interop'/name).read_bytes()
assert vector==load(player/'app/src/androidTest/assets/interop/share-fixture.json')
node=load(share/'verification/portable-fixtures/node-verification.json')
assert node['result']=='PASS' and node['format']=='DSMP0002'
assert node['global']['fileSha256']==vector['globalSha256']
assert node['password']['fileSha256']==vector['passwordSha256']
loose=load(share/'verification/loose-fixtures/fixture.json')
loose_node=load(share/'verification/loose-fixtures/node-loose-verification.json')
assert loose_node['result']=='PASS' and loose_node['publicKeyId']==node['publicKeyId']
for item in loose['items']+loose['passwordItems']:
    source=share/'verification/loose-fixtures'/item['file']
    assert source.read_bytes()[:8]==b'DSMP0002' and sha(source)==item['encryptedSha256']
    assert source.read_bytes()==(player/'app/src/androidTest/assets/loose'/item['file']).read_bytes()
assert loose==load(player/'app/src/androidTest/assets/loose/fixture.json')
ui_share=load(share/'verification/ui-ciphertext-api36.json')
ui_player=load(player/'verification/ui-ciphertext-api36.json')
assert ui_share['result']=='PASS' and ui_share['testedApkSha256']==producer['testedApkSha256']
assert ui_player['result']=='PASS' and ui_player['testedApkSha256']==consumer['testedApkSha256']
report={'result':'PASS','format':'DSMP0002','androidApi':36,
    'producer':'Dualscan Share Lite 1.1.1','consumer':'Diamond Player 1.2.1',
    'producerApkSha256':producer['testedApkSha256'],'consumerApkSha256':consumer['testedApkSha256'],
    'producerTests':producer['tests'],'consumerTests':consumer['tests'],
    'producerRecordSha256':producer['recordSha256'],'consumerRecordSha256':consumer['recordSha256'],
    'publicKeyId':node['publicKeyId'],'globalImageSha256':vector['globalSha256'],'passwordImageSha256':vector['passwordSha256'],
    'retentionScope':['One protected .diamond file per source media item','Normal shared folders and USB-C',
        'Direct shared-folder library without permanent private vault','Cross-file native audio queue',
        'Whole encrypted-container transfers/copies','No Share extraction or media publication',
        'Gallery does not receive standalone decoded photos','Diamond photo pixels and native PCM decrypt in memory',
        'External UID denied plaintext provider access','Original files and prior plaintext copies left unchanged'],
    'shareUi':ui_share,'playerUi':ui_player,'independentHostVerifier':node,
    'looseFileVerifier':loose_node,'looseFixture':loose,'physicalUsbTested':False}
text=json.dumps(report,indent=2)+'\n'
for project in (share,player): (project/'verification/ciphertext-cross-app.json').write_text(text)
print(json.dumps({k:report[k] for k in ('result','producerTests','consumerTests','producerApkSha256','consumerApkSha256')},indent=2))
