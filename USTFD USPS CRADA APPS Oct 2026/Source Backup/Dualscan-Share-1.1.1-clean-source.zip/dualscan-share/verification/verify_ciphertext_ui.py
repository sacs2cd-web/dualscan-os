"""Capture current Share UI on the task-owned Android16 emulator; no USB bypass."""
import hashlib,json,re,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
P=Path(__file__).resolve().parents[1]; OUT=P/'verification'
OEM='--oem' in sys.argv
PKG='com.dualscan.share' if OEM else 'com.dualscan.share.lite'
PREFIX='ui-oem-' if OEM else 'ui-'
ADB=['/Users/williamgrecia/Library/Android/sdk/platform-tools/adb','-s','emulator-5580']
def call(*args): return subprocess.check_output(ADB+list(args),timeout=60)
def state():
    call('shell','uiautomator','dump','/sdcard/share-ciphertext.xml')
    data=call('exec-out','cat','/sdcard/share-ciphertext.xml')
    return data,E.fromstring(data)
def texts(root): return [n.get(k) for n in root.iter('node') for k in ('text','content-desc') if n.get(k)]
def tap(label):
    _,root=state()
    n=next(n for n in root.iter('node') if n.get('text')==label or n.get('content-desc')==label)
    a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')))
    call('shell','input','tap',str((a+c)//2),str((b+d)//2))
def capture(name):
    data,root=state()
    (OUT/(name+'.xml')).write_bytes(data)
    (OUT/(name+'.png')).write_bytes(call('exec-out','screencap','-p'))
    labels=texts(root)
    assert 'USB-C' in labels,labels
    assert not any('refresh' in t.lower() or 'decrypt media' in t.lower() or 'restore selected' in t.lower() for t in labels),labels
    return labels
call('shell','am','force-stop',PKG)
call('shell','am','start','-W','-n',PKG+'/com.dualscan.share.MainActivity')
labels=capture(PREFIX+'create-ciphertext-api36')
assert 'Create' in labels and 'Import' in labels,labels
assert 'Create Diamond files' in labels and 'One file per item · USB-C only' in labels,labels
assert 'Connected' not in labels,labels
tap('Import')
labels=capture(PREFIX+'import-ciphertext-api36')
assert 'Open file from USB-C' in labels and 'No files open' in labels,labels
assert 'Open folder from USB-C' in labels,labels
_,root=state()
button=next(n for n in root.iter('node') if n.get('text')=='Open file from USB-C')
# Compose may expose enabled state on the containing clickable node.
assert any(n.get('enabled')=='false' and n.get('clickable')=='true' for n in root.iter('node')),texts(root)
report={'result':'PASS','androidApi':36,
    'testedApkSha256':hashlib.sha256((P/('app/build/outputs/apk/oem/debug/app-oem-debug.apk' if OEM else 'app/build/outputs/apk/lite/debug/app-lite-debug.apk')).read_bytes()).hexdigest(),
    'edition':'OEM' if OEM else 'Lite',
    'observed':['One Diamond file per media item','Create and Import tabs','Simple USB-C medium row','No refresh card/action','No decrypt or per-file restore controls','USB open remains disabled without attached storage'],
    'physicalUsbTested':False,
    'scope':'Actual UI screenshots; encrypted import helper and Gallery isolation exercised by current instrumentation, not physical USB UI',
    'evidence':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob(PREFIX+'*-ciphertext-api36.*')) if p.suffix in ('.png','.xml') and (OEM or not p.name.startswith('ui-oem-'))]}
(OUT/('ui-oem-ciphertext-api36.json' if OEM else 'ui-ciphertext-api36.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
