"""Package already-built Dualscan Share 1.1.1 candidates; never signs/rebuilds.

Requires final build/lint/JVM and actual API36 instrumentation evidence. Only
allowlisted source/config/docs/reproducer scripts enter the source ZIP. The
external content key, generated source, SDK paths, caches and signing keys do not.
"""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

VERSION = "1.1.1"
VERSION_CODE = 4
project = Path(__file__).resolve().parents[1]
dist = project / f"dist-{VERSION}"
dist.mkdir(exist_ok=True)
sdk = Path(os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or
           Path.home() / "Library/Android/sdk")
build_tools = sdk / "build-tools/36.0.0"
aapt, apksigner = build_tools / "aapt", build_tools / "apksigner"
key_file = Path(os.environ.get("DUALSCAN_ECOSYSTEM_KEY_FILE") or
                Path.home() / ".local/share/dualscan-research/keys/ecosystem-v1.key").expanduser()
key_bytes = key_file.read_bytes()
assert len(key_bytes) == 32, "Provision the same 32-byte ecosystem build key used by both apps"
key_id = hashlib.sha256(key_bytes).hexdigest()[:32]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*arguments, allow_failure=False):
    result = subprocess.run([str(arg) for arg in arguments], capture_output=True, text=True)
    if not allow_failure:
        result.check_returncode()
    return result


def tests(module, task, minimum):
    suites = []
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    for file in sorted((project / module / "build/test-results" / task).glob("TEST-*.xml")):
        root = ET.parse(file).getroot()
        counts = {name: int(root.attrib[name]) for name in totals}
        suites.append({"suite": root.attrib["name"], **counts})
        for name, count in counts.items():
            totals[name] += count
    assert totals["tests"] >= minimum, (module, task, totals)
    assert totals["failures"] == totals["errors"] == totals["skipped"] == 0, (module, task, totals)
    return {"module": module, "task": task, "totals": totals, "suites": suites}


units = {variant: tests("app", f"test{variant.title()}DebugUnitTest", 40)
         for variant in ("lite", "oem")}
units["interchange-core"] = tests("interchange-core", "testDebugUnitTest", 15)
units["tella-keys-core"] = tests("tella-keys-core", "test", 7)
build_log = project / "verification/build-ciphertext-1.1.1.txt"
statuses = re.findall(r"BUILD (SUCCESSFUL|FAILED)", build_log.read_text())
assert statuses and statuses[-1] == "SUCCESSFUL", "Final build record must end in BUILD SUCCESSFUL"

lint = {}
for variant in ("lite", "oem"):
    path = project / f"app/build/reports/lint-results-{variant}Debug.xml"
    issues = ET.parse(path).getroot().findall("issue")
    severities = collections.Counter(issue.attrib["severity"] for issue in issues)
    assert not (severities["Error"] or severities["Fatal"]), (variant, severities)
    lint[variant] = {"severityCounts": dict(severities),
                     "warningIds": dict(collections.Counter(issue.attrib["id"] for issue in issues))}

# Enumerate only explicit source roots. Never recursively package whole modules:
# interchange-core/build contains the generated embedded-key implementation.
fixed = [".gitignore", "README.txt", "build.gradle.kts", "settings.gradle.kts",
         "gradle.properties", "gradlew", "gradlew.bat", "app/build.gradle.kts",
         "app/proguard-rules.pro", "interchange-core/build.gradle.kts",
         "interchange-core/FORMAT.md", "tella-keys-core/build.gradle.kts"]
roots = ("app/src", "gradle", "docs", "oem-integration/contracts",
         "interchange-core/src", "tella-keys-core/src", "third_party/tella")
allowed = {Path(name) for name in fixed}
for root in roots:
    allowed.update(path.relative_to(project) for path in (project / root).rglob("*") if path.is_file())
allowed.update(path.relative_to(project) for path in (project / "verification").rglob("*")
               if path.is_file() and path.suffix in (".py", ".mjs", ".js", ".sh"))
for relative in allowed:
    assert not (project / relative).is_symlink(), relative
    assert not any(part in ("build", ".gradle", ".kotlin", ".git", "node_modules") for part in relative.parts), relative
    assert relative.name not in ("local.properties", "EcosystemBuildKey.kt", "EcosystemBuildKey.java", "ecosystem-v1.key"), relative
    assert relative.suffix.lower() not in (".apk", ".key", ".jks", ".keystore", ".pem", ".p12", ".pfx"), relative
source = {str(path): (project / path).read_bytes() for path in sorted(allowed)}
for name, data in source.items():
    assert key_bytes not in data, f"Raw ecosystem key must not enter source archive: {name}"
    assert not re.search(rb"(?m)^\s*internal\s+object\s+EcosystemBuildKey\b", data), f"Generated key source must not enter source archive: {name}"
# Generator references are allowed; generated object definitions under build/ are not.
compiled_tella = {str(path.relative_to(project / "tella-keys-core/src/main/java"))
                  for path in (project / "tella-keys-core/src/main/java").rglob("*") if path.is_file()}
assert compiled_tella == {"org/hzontal/tella/keys/key/MainKey.java", "org/hzontal/tella/keys/util/Wiper.java"}
tella_license = source["third_party/tella/LICENSE"]
assert tella_license.startswith(b"MIT License") and b"2025 Horizontal" in tella_license
assert source["app/src/main/assets/legal/TELLA-LICENSE"] == tella_license
assert source["app/src/main/assets/legal/TELLA-NOTICE.txt"] == source["third_party/tella/NOTICE.txt"]
assert "b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc" in source["third_party/tella/PROVENANCE.md"].decode()
assert {"interchange-core/src/main/java/com/dualscan/mp/core/MediaArray.kt",
        "interchange-core/src/main/java/com/dualscan/mp/core/MediaArrayModels.kt"} <= source.keys()
assert "include(\":interchange-core\"" in source["settings.gradle.kts"].decode()
assert "include(\":interchange-core\", \":tella-keys-core\")" in source["settings.gradle.kts"].decode()
production_paths = [project / name for name in source if
                    name.startswith(("app/src/main/", "interchange-core/src/main/", "tella-keys-core/src/main/")) or
                    name in ("app/build.gradle.kts", "interchange-core/build.gradle.kts", "tella-keys-core/build.gradle.kts",
                             "build.gradle.kts", "settings.gradle.kts", "gradle.properties", "gradle/libs.versions.toml")]
newest_production = max([path.stat().st_mtime_ns for path in production_paths] + [key_file.stat().st_mtime_ns])
generated_key_source = project / "interchange-core/build/generated/ecosystemKey/com/dualscan/mp/core/EcosystemBuildKey.java"
generated_array = re.search(r"new\s+byte\[\]\s*\{([-0-9,\s]+)\}", generated_key_source.read_text())
assert generated_array, "Generated build-key source is missing or unsupported"
assert bytes(int(value.strip()) & 255 for value in generated_array.group(1).split(",")) == key_bytes, "Generated build key differs from the provisioned key"

artifacts = []
for variant in ("lite", "oem"):
    for kind in ("debug", "release"):
        suffix = "-unsigned" if kind == "release" else ""
        original = project / f"app/build/outputs/apk/{variant}/{kind}/app-{variant}-{kind}{suffix}.apk"
        assert original.stat().st_mtime_ns >= newest_production, f"Rebuild stale {original}"
        destination = dist / f"Dualscan-Share-{variant.title()}-{VERSION}-{'development' if kind == 'debug' else 'release-unsigned'}.apk"
        shutil.copy2(original, destination)
        data = destination.read_bytes()
        badging = run(aapt, "dump", "badging", destination).stdout
        manifest = run(aapt, "dump", "xmltree", destination, "AndroidManifest.xml").stdout
        permissions = re.findall(r"^uses-permission: name='([^']+)'", badging, re.MULTILINE)
        assert "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging
        assert "android.permission.INTERNET" not in permissions
        assert re.search(r"android:allowBackup.*=\(type 0x12\)0x0", manifest)
        expected_id = "com.dualscan.share.lite" if variant == "lite" else "com.dualscan.share"
        assert f"package: name='{expected_id}' versionCode='{VERSION_CODE}' versionName='{VERSION}'" in badging
        with zipfile.ZipFile(destination) as apk:
            assert apk.read("assets/legal/TELLA-LICENSE") == tella_license
            assert apk.read("assets/legal/TELLA-NOTICE.txt") == source["third_party/tella/NOTICE.txt"]
            assert apk.read("assets/legal/DUALSCAN-INTERCHANGE-NOTICE.txt") == source["app/src/main/assets/legal/DUALSCAN-INTERCHANGE-NOTICE.txt"]
            for entry in apk.infolist():
                assert not entry.filename.endswith((".key", "EcosystemBuildKey.kt", "EcosystemBuildKey.java")), entry.filename
                if not entry.is_dir() and not entry.filename.endswith(".dex"):
                    assert key_bytes not in apk.read(entry), f"No raw ecosystem-key asset allowed: {entry.filename}"
        signature = run(apksigner, "verify", "--print-certs", destination, allow_failure=True)
        if kind == "debug":
            assert signature.returncode == 0
            certificate = re.search(r"certificate SHA-256 digest: ([0-9a-f]{64})", signature.stdout).group(1)
        else:
            assert signature.returncode != 0 and "Signer #" not in signature.stdout
            with zipfile.ZipFile(destination) as apk:
                assert not any(re.match(r"META-INF/.*\.(RSA|DSA|EC)$", name) for name in apk.namelist())
            certificate = None
        artifacts.append({"file": destination.name, "bytes": len(data), "sha256": sha(data),
                          "edition": variant, "applicationId": expected_id, "versionCode": VERSION_CODE, "versionName": VERSION,
                          "minSdk": 26, "targetSdk": 36, "permissions": permissions, "allowBackup": False,
                          "signature": "verified-development-signature" if kind == "debug" else "unsigned-requires-ODM-signing",
                          "signerCertificateSha256": certificate, "installableAsDelivered": kind == "debug"})

source_manifest = (json.dumps({"schemaVersion": 1, "files": [
    {"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in sorted(source.items())
]}, indent=2) + "\n").encode()
source_archive = dist / f"Dualscan-Share-{VERSION}-clean-source.zip"
with zipfile.ZipFile(source_archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted({**source, "SOURCE-MANIFEST.json": source_manifest}.items()):
        entry = zipfile.ZipInfo("dualscan-share/" + name, date_time=(2026, 10, 16, 12, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = (0o100755 if name in ("gradlew", "gradlew.bat") else 0o100644) << 16
        bundle.writestr(entry, data)
with zipfile.ZipFile(source_archive) as bundle:
    assert bundle.testzip() is None and len(bundle.namelist()) == len(source) + 1
    for name, data in source.items():
        assert sha(bundle.read("dualscan-share/" + name)) == sha(data), name
    assert sha(bundle.read("dualscan-share/SOURCE-MANIFEST.json")) == sha(source_manifest)
for name, data in source.items():
    assert (project / name).read_bytes() == data, f"Source changed during packaging: {name}"
artifacts.append({"file": source_archive.name, "bytes": source_archive.stat().st_size,
                  "sha256": sha(source_archive.read_bytes()), "sourceFiles": len(source),
                  "sourceManifestSha256": sha(source_manifest), "zipCrcAndPerFileSha256": "PASS",
                  "allowlist": [*roots, "explicit module/root build configuration", "README.txt", "interchange-core/FORMAT.md", "verification reproducer scripts only"],
                  "excludes": ["local.properties", "caches", "build outputs", "generated ecosystem key source", "raw ecosystem key", "private signing keys",
                               "reference APKs", "reference-analysis evidence", "verification runtime outputs"],
                  "externalBuildKeyRequired": True, "externalBuildKeyId": key_id})

current_lite_sha = next(item["sha256"] for item in artifacts if item["file"] == f"Dualscan-Share-Lite-{VERSION}-development.apk")
# Current runtime records are tied to this APK. Historical restore evidence is
# deliberately not included in the new encrypted-only delivery.
evidence_names = {build_log.name}
android_record = project / "verification/android-ciphertext-api36.txt"
tested_apk_file = project / "verification/android-ciphertext-api36.json"
tested_apk = json.loads(tested_apk_file.read_text())
counts = re.findall(r"OK \((\d+) tests?\)", android_record.read_text())
assert counts and "FAILURES!!!" not in android_record.read_text(), android_record
android_tests = int(counts[-1])
assert android_tests >= 9, "Require per-file authoring, real SAF batch destination, lifecycle and producer regressions"
assert tested_apk.get("result") == "PASS" and tested_apk.get("tests") == android_tests
assert tested_apk.get("androidApi") == 36 and tested_apk.get("testedApkSha256") == current_lite_sha
assert tested_apk.get("recordSha256") == sha(android_record.read_bytes())
evidence_names.update((android_record.name, tested_apk_file.name))
for item in tested_apk.get("fixtures", []) + tested_apk.get("looseFixtures", []):
    path = project / item["file"]
    assert any(path.resolve().is_relative_to((project / "verification" / name).resolve()) for name in ("portable-fixtures", "loose-fixtures"))
    assert path.is_file() and sha(path.read_bytes()) == item["sha256"]
    evidence_names.add(str(path.relative_to(project / "verification")))
if tested_apk.get("producerRefreshRecord"):
    path = project / tested_apk["producerRefreshRecord"]
    assert path.resolve().is_relative_to((project / "verification").resolve())
    assert "OK (2 tests)" in path.read_text() and tested_apk["producerRefreshTests"] == 2
    assert tested_apk["producerRefreshRecordSha256"] == sha(path.read_bytes())
    evidence_names.add(str(path.relative_to(project / "verification")))
device_record = project / tested_apk["deviceImportRecord"]
assert device_record.resolve().is_relative_to((project / "verification").resolve())
assert tested_apk["deviceImportRecordSha256"] == sha(device_record.read_bytes())
device_import = json.loads(device_record.read_text())
assert device_import["result"] == "PASS" and device_import["realSafPickerGrant"]
assert all(device_import[name] for name in ("unchangedCiphertext", "galleryRowsUnchanged", "ordinaryImageDecoderRejected", "diamondReaderExactPixels"))
evidence_names.add(str(device_record.relative_to(project / "verification")))
test_build = project / "verification/build-ciphertext-androidtest-1.1.1.txt"
assert "BUILD SUCCESSFUL" in test_build.read_text()
evidence_names.add(test_build.name)

ui_file = project / "verification/ui-ciphertext-api36.json"
ui = json.loads(ui_file.read_text())
assert ui["result"] == "PASS" and ui["testedApkSha256"] == current_lite_sha
for item in ui["evidence"]:
    path = project / "verification" / item["file"]
    assert path.resolve().is_relative_to((project / "verification").resolve())
    assert sha(path.read_bytes()) == item["sha256"]
    evidence_names.add(item["file"])
evidence_names.add(ui_file.name)

cross_file = project / "verification/ciphertext-cross-app.json"
cross = json.loads(cross_file.read_text())
assert cross["result"] == "PASS" and cross["producerApkSha256"] == current_lite_sha
assert cross["producerRecordSha256"] == sha(android_record.read_bytes())
assert cross["publicKeyId"] == key_id
assert cross["globalImageSha256"] == sha((project / "verification/portable-fixtures/share-global.dshare").read_bytes())
assert cross["passwordImageSha256"] == sha((project / "verification/portable-fixtures/share-password.dshare").read_bytes())
assert re.fullmatch(r"[0-9a-f]{64}", cross["consumerApkSha256"])
evidence_names.add(cross_file.name)
node_file = project / "verification/portable-fixtures/node-verification.json"
node = json.loads(node_file.read_text())
assert node["result"] == "PASS" and node["format"] == "DSMP0002" and node["publicKeyId"] == key_id
for mode, filename in (("global", "share-global.dshare"), ("password", "share-password.dshare")):
    assert node[mode]["fileSha256"] == sha((node_file.parent / filename).read_bytes())
evidence_names.add(str(node_file.relative_to(project / "verification")))
loose_root = project / "verification/loose-fixtures"
loose_fixture = json.loads((loose_root / "fixture.json").read_text())
loose_node = json.loads((loose_root / "node-loose-verification.json").read_text())
assert loose_node["result"] == "PASS" and loose_node["publicKeyId"] == key_id and loose_node["plaintextFilesWritten"] is False
assert len(loose_node["items"]) == len(loose_fixture["items"]) + len(loose_fixture["passwordItems"]) == 5
for item in loose_fixture["items"] + loose_fixture["passwordItems"]:
    path = loose_root / item["file"]
    assert path.resolve().is_relative_to(loose_root.resolve()) and path.suffix == ".diamond"
    assert sha(path.read_bytes()) == item["encryptedSha256"] and path.stat().st_size == item["encryptedBytes"]
    evidence_names.add(str(path.relative_to(project / "verification")))
evidence_names.update(("loose-fixtures/fixture.json", "loose-fixtures/node-loose-verification.json"))
oem_record = project / "verification/android-oem-ciphertext-api36.txt"
oem_meta_file = project / "verification/android-oem-ciphertext-api36.json"
oem_meta = json.loads(oem_meta_file.read_text())
oem_sha = next(item["sha256"] for item in artifacts if item["file"] == f"Dualscan-Share-Oem-{VERSION}-development.apk")
oem_counts = re.findall(r"OK \((\d+) tests?\)", oem_record.read_text())
assert oem_counts and int(oem_counts[-1]) >= 9 and "FAILURES!!!" not in oem_record.read_text()
assert oem_meta["result"] == "PASS" and oem_meta["testedApkSha256"] == oem_sha
assert oem_meta["tests"] == int(oem_counts[-1]) and oem_meta["recordSha256"] == sha(oem_record.read_bytes())
evidence_names.update((oem_record.name, oem_meta_file.name))
for field in ("producerRefreshRecord", "deviceImportRecord"):
    path = project / oem_meta[field]
    assert path.resolve().is_relative_to((project / "verification").resolve())
    assert sha(path.read_bytes()) == oem_meta[field + "Sha256"]
    evidence_names.add(str(path.relative_to(project / "verification")))
assert oem_meta["producerRefreshTests"] == 2
for item in oem_meta["fixtures"] + oem_meta["looseFixtures"]:
    path = project / item["file"]
    assert any(path.resolve().is_relative_to((project / "verification" / name).resolve()) for name in ("oem-portable-fixtures", "oem-loose-fixtures"))
    assert sha(path.read_bytes()) == item["sha256"] and path.stat().st_size == item["bytes"]
    evidence_names.add(str(path.relative_to(project / "verification")))
oem_node_path = project / "verification/oem-loose-fixtures/node-loose-verification.json"
oem_node = json.loads(oem_node_path.read_text())
assert oem_node["result"] == "PASS" and oem_node["publicKeyId"] == key_id and len(oem_node["items"]) == 5
evidence_names.add(str(oem_node_path.relative_to(project / "verification")))
oem_ui_path = project / "verification/ui-oem-ciphertext-api36.json"
oem_ui = json.loads(oem_ui_path.read_text())
assert oem_ui["result"] == "PASS" and oem_ui["testedApkSha256"] == oem_sha
for item in oem_ui["evidence"]:
    path = project / "verification" / item["file"]
    assert path.resolve().is_relative_to((project / "verification").resolve())
    assert sha(path.read_bytes()) == item["sha256"]
    evidence_names.add(item["file"])
evidence_names.add(oem_ui_path.name)

# No plaintext restore implementation may ship, even behind a hidden UI.
for name in ("MediaStoreRestorer.kt", "FolderRestorer.kt", "ProtectedArchive.kt"):
    assert not any(p.name == name for p in (project / "app/src/main").rglob("*")), name
main_activity = (project / "app/src/main/java/com/dualscan/share/MainActivity.kt").read_text()
assert "Decrypt media to" not in main_activity and "Refresh USB storage" not in main_activity
for module, task in (("app", "testLiteDebugUnitTest"), ("app", "testOemDebugUnitTest"),
                     ("interchange-core", "testDebugUnitTest"), ("tella-keys-core", "test")):
    for path in sorted((project / module / "build/test-results" / task).glob("TEST-*.xml")):
        # Evidence may be copied from build outputs, but source ZIP never includes them.
        label = f"jvm/{module}/{task}/{path.name}"
        target = project / "verification" / label
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        evidence_names.add(label)
for variant in ("lite", "oem"):
    path = project / f"app/build/reports/lint-results-{variant}Debug.xml"
    label = f"lint/{path.name}"
    target = project / "verification" / label
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    evidence_names.add(label)

evidence = {name: (project / "verification" / name).read_bytes() for name in sorted(evidence_names)}
for name, data in evidence.items():
    assert key_bytes not in data, f"No raw ecosystem key allowed in evidence: {name}"
evidence_manifest = (json.dumps({"schemaVersion": 1, "files": [
    {"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in evidence.items()
]}, indent=2) + "\n").encode()
evidence_zip = dist / f"Dualscan-Share-{VERSION}-verification.zip"
with zipfile.ZipFile(evidence_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted({**evidence, "EVIDENCE-MANIFEST.json": evidence_manifest}.items()):
        entry = zipfile.ZipInfo("Verification/" + name, date_time=(2026, 10, 16, 12, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        bundle.writestr(entry, data)
with zipfile.ZipFile(evidence_zip) as bundle:
    assert bundle.testzip() is None and len(bundle.namelist()) == len(evidence) + 1
    for name, data in evidence.items():
        assert sha(bundle.read("Verification/" + name)) == sha(data), name
for name, data in evidence.items():
    assert (project / "verification" / name).read_bytes() == data
artifacts.append({"file": evidence_zip.name, "bytes": evidence_zip.stat().st_size,
                  "sha256": sha(evidence_zip.read_bytes()), "evidenceFiles": len(evidence),
                  "evidenceManifestSha256": sha(evidence_manifest), "zipCrcAndPerFileSha256": "PASS"})
report = {
    "schemaVersion": 3, "versionName": VERSION, "versionCode": VERSION_CODE,
    "preparedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "releaseStatus": "OEM/ODM integration candidate; NOT Golden Master approved or certified",
    "build": {"result": "PASS", "record": str(build_log.relative_to(project)), "sha256": sha(build_log.read_bytes())},
    "jvmTests": units, "lint": lint,
    "ciphertextRetention": {"newImagesEncrypted": True, "plaintextRestoreAvailable": False,
        "normalMediaLayout": "One independently encrypted .diamond file per source media item; ordinary shared folders",
        "mediaStorePlaintextPublication": False, "legacyZipInputsAccepted": False,
        "usbAndLocalCopies": "Independent authenticated DSMP0002 files; paths preserved; exact ciphertext read-back verification",
        "localDestination": "User-selected shared folder; no required permanent app vault; .nomedia; no payload extraction",
        "originalSourceFilesDeleted": False, "existingPlaintextFromPreviousVersionsDeleted": False},
    "format": {"created": "DSMP0002", "extensions": [".diamond", ".dshare"], "accepted": ["DSMP0002"], "passwordOptional": True,
        "ecosystemKeyId": key_id, "plaintextZipStaging": False,
        "boundary": "Shared application key is extractable; optional password adds private user protection; no DRM claim"},
    "sourceBuild": {"sameExternalEcosystemKeyRequired": True, "rawKeyIncluded": False,
        "generatedKeySourceIncluded": False, "handoff": "docs/OFFLINE-INTERCHANGE-HANDOFF.txt"},
    "thirdParty": {"tellaLicense": "MIT", "copyright": "2025 Horizontal",
        "commit": "b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc", "compiledScope": sorted(compiled_tella),
        "legacyUnauthenticatedCtrCompiled": False, "packagedLicenseChecked": True},
    "androidRuntimeEvidence": {**tested_apk, "record": str(android_record.relative_to(project)),
        "ui": ui, "crossApp": cross, "independentHostVerifier": node,
        "oemApkRuntimeQualified": True, "oemMediaRuntime": oem_meta, "oemUi": oem_ui,
        "looseFileHostVerifier": loose_node, "oemLooseFileHostVerifier": oem_node,
        "qualificationScope": "Standard media-file operations on Lite/OEM editions; no privileged firmware qualification",
        "physicalUsbTested": False},
    "unverified": ["physical USB-C/OTG transfer and filesystem durability", "OEM/ODM integration and production signing",
        "physical DAC bit identity", "independent security audit and production signoff"],
    "artifacts": artifacts}
serialized = json.dumps(report, indent=2) + "\n"
(project / f"verification/delivery-verification-{VERSION}.json").write_text(serialized)
(dist / "DELIVERY-VERIFICATION.json").write_text(serialized)
(dist / "READ-ME-FIRST.txt").write_text(
    f"Dualscan Share {VERSION} — encrypted-only development/OEM integration candidate\n\n"
    "Install the Lite development APK on ordinary Android; release APKs need ODM signing.\n"
    "Lite and OEM author one encrypted .diamond file per media item by default.\n"
    "Ordinary Music/Pictures/Movies folders and USB-C can hold these portable files.\n"
    "Diamond reads the selected shared folders directly with no permanent private vault.\n"
    "Existing .dshare albums remain readable; OEM firmware packaging stays separate.\n"
    "USB-C is the operations medium. Optional passwords remain supported.\n"
    "Import copies COMPLETE encrypted files and their folders onto the device.\n"
    "No plaintext restore/decrypt-to-folder or media-library publication exists.\n"
    "Legacy ZIP/DSHP images are rejected; author a new image from original sources.\n"
    "Original source files and plaintext already restored by older versions are\n"
    "not removed. Updating cannot revoke those existing copies.\n\n"
    f"JVM tests: Lite {units['lite']['totals']['tests']}, OEM {units['oem']['totals']['tests']}, "
    f"core {units['interchange-core']['totals']['tests']}, Tella {units['tella-keys-core']['totals']['tests']}.\n"
    f"Build/lint and {android_tests} Lite/{oem_meta['tests']} OEM Android16 tests passed.\n"
    "Physical USB-C and OEM hardware remain unqualified; this is not a certified GM.\n\n"
    "Back up BOTH source ZIPs and the separate private 32-byte ecosystem-key file.\n"
    "The key/generated implementation and private signing keys are excluded here.\n"
    "Use the same ecosystem key for compatible future builds. APK keys can be\n"
    "extracted; optional passwords add privacy. This is not device-bound DRM.\n")
(dist / "SHA256SUMS.txt").write_text("".join(f"{sha(file.read_bytes())}  {file.name}\n" for file in sorted(dist.iterdir())
    if file.is_file() and file.name != "SHA256SUMS.txt"))
print(json.dumps({"dist": str(dist), "jvmTests": {name: entry["totals"]["tests"] for name, entry in units.items()},
                  "androidTests": android_tests, "artifacts": artifacts}, indent=2))
