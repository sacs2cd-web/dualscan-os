// Independent Node/OpenSSL verifier for public one-item-per-file Android-produced .diamond fixtures.
// Never writes plaintext or prints the ecosystem key. Not a general archive extractor.
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { createHash, createDecipheriv, hkdfSync, pbkdf2Sync, timingSafeEqual } from 'node:crypto';
import assert from 'node:assert/strict';

const directory = process.argv[2] || 'verification/loose-fixtures';
const keyPath = process.env.DUALSCAN_ECOSYSTEM_KEY_FILE || join(homedir(), '.local/share/dualscan-research/keys/ecosystem-v1.key');
const globalKey = readFileSync(keyPath);
assert.equal(globalKey.length, 32);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const vector = JSON.parse(readFileSync(join(directory, 'fixture.json'), 'utf8'));
const nonce = (header, counter) => {
  const bytes = Buffer.from(header.subarray(24, 36));
  bytes.writeBigUInt64BE(bytes.readBigUInt64BE(4) ^ counter, 4);
  return bytes;
};
const decrypt = (key, header, counter, aad, encrypted) => {
  assert(encrypted.length >= 16);
  const cipher = createDecipheriv('aes-256-gcm', key, nonce(header, counter));
  cipher.setAAD(aad);
  cipher.setAuthTag(encrypted.subarray(-16));
  return Buffer.concat([cipher.update(encrypted.subarray(0, -16)), cipher.final()]);
};
function open(bytes, password, item) {
  assert(bytes.length > 128 && bytes.length < 32 * 1024 * 1024, 'Fixture size is bounded');
  assert.equal(bytes.subarray(0, 8).toString('ascii'), 'DSMP0002');
  const header = bytes.subarray(0, 112), prefix = header.subarray(0, 64);
  const mode = header[44], rounds = header.readInt32BE(36), manifestLength = header.readInt32BE(40);
  assert(mode === 0 || mode === 1);
  assert.equal(rounds, mode === 0 ? 0 : 600000);
  assert(header.subarray(45, 48).every(x => x === 0));
  assert(timingSafeEqual(header.subarray(48, 64), createHash('sha256').update(globalKey).digest().subarray(0, 16)));
  assert(manifestLength > 16 && manifestLength <= 16 * 1024 * 1024 + 16 && 112 + manifestLength <= bytes.length);
  if (mode === 1) assert(typeof password === 'string' && password.length >= 8, 'Password required');
  const extra = mode === 1 ? pbkdf2Sync(password, header.subarray(8, 24), rounds, 32, 'sha256') : Buffer.alloc(0);
  const input = Buffer.concat([globalKey, extra]);
  const wrapping = Buffer.from(hkdfSync('sha256', input, header.subarray(8, 24), Buffer.from('Dualscan portable container v2 key wrapping', 'ascii'), 32));
  input.fill(0); extra.fill(0);
  let dataKey;
  try { dataKey = decrypt(wrapping, header, 0x7fffffffffffffffn, Buffer.concat([prefix, Buffer.from([2])]), header.subarray(64, 112)); }
  finally { wrapping.fill(0); }
  assert.equal(dataKey.length, 32);
  try {
    const clear = decrypt(dataKey, header, 0n, Buffer.concat([header, Buffer.from([0])]), bytes.subarray(112, 112 + manifestLength));
    const catalog = JSON.parse(clear.toString('utf8')); clear.fill(0);
    assert.equal(catalog.format, 'dualscan-portable'); assert.equal(catalog.schemaVersion, 2);
    assert.equal(catalog.chunkBytes, 1048576); assert.equal(catalog.title, item.displayName.slice(0, 160));
    assert(catalog.entries.length <= 10000);
    let counter = 1n, offset = 0;
    const entries = catalog.entries.map((entry, index) => {
      assert.equal(entry.index, index); assert.equal(entry.dataOffset, offset);
      assert.equal(BigInt(entry.firstCounter), counter);
      assert.equal(entry.chunkCount, Math.ceil(entry.sizeBytes / 1048576));
      let length = 0;
      const digest = createHash('sha256');
      for (let chunk = 0; chunk < entry.chunkCount; chunk++) {
        const count = Math.min(1048576, entry.sizeBytes - length);
        const aad = Buffer.alloc(header.length + 17); header.copy(aad); aad[header.length] = 1;
        aad.writeInt32BE(index, header.length + 1); aad.writeBigUInt64BE(BigInt(chunk), header.length + 5); aad.writeInt32BE(count, header.length + 13);
        const start = 112 + manifestLength + offset;
        const plain = decrypt(dataKey, header, counter, aad, bytes.subarray(start, start + count + 16));
        digest.update(plain); plain.fill(0); length += count; offset += count + 16; counter++;
      }
      assert.equal(length, entry.sizeBytes); assert.equal(digest.digest('hex'), entry.sha256);
      const expected = item;
      assert.equal(entry.relativePath, expected.relativePath); assert.equal(entry.displayName, expected.displayName); assert.equal(entry.mimeType, expected.mimeType);
      assert(expected, entry.relativePath); assert.equal(entry.sha256, expected.sha256); assert.equal(entry.sizeBytes, expected.sizeBytes);
      return { relativePath: entry.relativePath, bytes: entry.sizeBytes, sha256: entry.sha256 };
    });
    assert.equal(entries.length, 1);
    assert.equal(112 + manifestLength + offset, bytes.length);
    return { mode: mode === 0 ? 'global' : 'global-plus-password', entries };
  } finally { dataKey.fill(0); }
}
try {
  assert.equal(vector.schemaVersion, 1);
  const checked = [];
  for (const [items, password] of [[vector.items, undefined], [vector.passwordItems, vector.password]]) {
    assert(Array.isArray(items) && items.length > 0 && items.length <= 10000);
    for (const item of items) {
      assert(typeof item.file === 'string' && !item.file.startsWith('/') && !item.file.includes('\\') && !item.file.split('/').some(p => !p || p === '.' || p === '..'));
      assert(item.file.endsWith('.diamond'));
      const bytes = readFileSync(join(directory, item.file));
      assert.equal(bytes.length, item.encryptedBytes); assert.equal(sha(bytes), item.encryptedSha256);
      const result = open(bytes, password, item);
      assert.equal(result.mode, password ? 'global-plus-password' : 'global');
      checked.push({file:item.file, encryptedSha256:sha(bytes), encryptedBytes:bytes.length, ...result});
      const altered = Buffer.from(bytes); altered[altered.length - 1] ^= 1;
      assert.throws(() => open(altered, password, item));
      assert.throws(() => open(bytes.subarray(0, -1), password, item));
      if (password) {
        assert.throws(() => open(bytes, undefined, item));
        assert.throws(() => open(bytes, 'Wrong password 2026', item));
        const downgrade = Buffer.from(bytes); downgrade[44] = 0; downgrade.writeInt32BE(0, 36);
        assert.throws(() => open(downgrade, undefined, item));
      }
    }
  }
  const report = {result:'PASS', verifier:'Independent Node/OpenSSL', format:'DSMP0002',
    layout:'One encrypted .diamond file per original media item', publicKeyId:sha(globalKey).slice(0,32),
    items:checked, plaintextFilesWritten:false,
    rejected:['missing password','wrong password','password downgrade','payload corruption','truncation']};
  writeFileSync(join(directory,'node-loose-verification.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({result:report.result,files:checked.length,plaintextFilesWritten:false},null,2));
} finally {globalKey.fill(0);}
