DUALSCAN SHARE 1.1.1 — DEVELOPMENT RELEASE CANDIDATE

Share authors one encrypted .diamond file per selected source for Diamond Player.
For example, 01 Song.flac becomes 01 Song.flac.diamond and cover.jpg becomes
cover.jpg.diamond. Original folders are preserved around those encrypted files.
After authoring, USB-C transfers and on-device imports copy each complete
encrypted file unchanged; an album need not become a private app vault.
Share has no file extraction, plaintext restore or MediaStore publishing path.
Store files in normal accessible Music, Pictures, Movies or Documents folders,
or keep them on USB-C. Diamond opens granted folders directly, across multiple
encrypted files in one library/queue. Photos, audio and video are opened in
memory and are not written as ordinary Gallery, Music or Video files.

Leaving the optional password empty uses the shared Dualscan application key;
adding an 8–256 character password adds a password-derived key requirement.
The shared key provides offline interoperability, not private user-only
protection or a DRM boundary: it is distributed in both APKs and can be extracted.
Use the optional password for private backups. Forgotten passwords cannot be
recovered. DSMP0002 is an authenticated AES-GCM application format; it is not
the upstream Tella vault-file format and no Tella certification is claimed.

Minimum Android 8.0 (API 26); target API 36. No Internet permission.

EDITIONS
- Lite: com.dualscan.share.lite, label Dualscan Share Lite.
  Selected accessible local files/folders, including documents and media;
  no applications, app inventories or private app data.
- OEM: com.dualscan.share, label Dualscan Share.
  Same encrypted-file workflow plus packaging already-built OEM update artifacts.
  Does not capture protected partitions, sign firmware or install firmware.

BUILD (JDK 21, Android SDK 36)
  ./gradlew :app:testLiteDebugUnitTest :app:testOemDebugUnitTest
  ./gradlew :interchange-core:testDebugUnitTest :tella-keys-core:test
  ./gradlew :app:assembleLiteDebug :app:assembleOemDebug
  ./gradlew :app:assembleLiteDebugAndroidTest :app:lintLiteDebug :app:lintOemDebug
  ./gradlew :app:assembleLiteRelease :app:assembleOemRelease

Installable development APKs:
  app/build/outputs/apk/lite/debug/app-lite-debug.apk
  app/build/outputs/apk/oem/debug/app-oem-debug.apk
Unsigned OEM release candidates:
  app/build/outputs/apk/lite/release/app-lite-release-unsigned.apk
  app/build/outputs/apk/oem/release/app-oem-release-unsigned.apk
Development APKs use Android's development certificate. Production/OEM signing
and hardware acceptance are still required; this is not Golden Master approval.

USB-C WORKFLOW
1. Install Lite on a normal Android device; OEM privileges are not needed.
2. Choose local files or an accessible folder and subfolders. Documents, Music,
   Movies, Pictures, DCIM and other granted shared folders are supported;
   relative folders are preserved in the encrypted output tree. Known cloud
   providers and photo-picker cloud routes are rejected. APK/APKM/APKS/XAPK/AAB
   and app runtime files are excluded. Folder scans report skipped packages.
   Android 11+ restricts roots, the Download root and Android/data/obb in the
   folder picker. Accessible individual Downloads files and permitted subfolders
   can still be selected. Android's actual grants determine coverage.
3. Attach/mount a USB-C/OTG storage drive. Optionally set and confirm a password,
   or leave both fields empty for direct Diamond Player access. Create the files.
   USB-C status updates from native attachment and mount/eject events; no manual
   refresh card or action is required.
   Each .diamond file contains one original source in a DSMP0002 container.
   Its catalog and payload are encrypted from the initial write;
   no plaintext ZIP or extracted files are staged.
4. Save the encrypted files to USB-C. A fresh DualscanShare-<id> folder preserves
   the source hierarchy and contains separate .diamond files. The removable
   destination must use Android's external
   storage document provider, a mounted removable volume UUID and an attached
   USB mass-storage interface. Cloud/internal archive export destinations fail.
5. Keep the drive attached through SHA-256 destination read-back verification.
   Read-back failure stops the transfer; success requires a matching copy.
   Interrupted or invalid app-created outputs are removed when the provider
   permits deletion. Use Android's eject control before removing the drive.
6. On another device, open the USB media folder in Share to copy its encrypted
   files, or open that folder directly in Diamond for playback. A password is
   needed only for files authored with one. Share authenticates all chunks and
   verifies payload hashes before transferring them. Only DSMP0002 is accepted;
   plain ZIP/DSHP0001 input is rejected without plaintext extraction. Existing
   Share DSMP0002 .dshare backups remain usable as whole encrypted containers.
   Diamond also opens its own .dmpa collections; Share import requires Share
   backup metadata, so not every Diamond-authored .dmpa is a Share backup.
7. Keep the files on USB-C or copy the encrypted tree to an accessible local
   folder. Each saved .diamond file is checked by size and exact ciphertext
   SHA-256. A fresh DualscanShare-<id> output folder avoids overwriting existing
   files. Share attempts a .nomedia marker there; ciphertext protects the
   contents even when marker creation fails or the marker is removed. No decoded
   photo, song, video or document is written. Existing album backup imports also
   stay intact rather than being extracted.
8. In Diamond, use Open media folder for local or USB-C folders. Separate files
   join a single sorted music/video/photo library; track numbers and album folder
   hierarchy are respected. Encrypted cover.jpg/cover.png files in the physical
   album folder supply artwork. Playback and picture display use authenticated
   in-memory reads; native audio can queue across separate encrypted tracks.
   Optional-password files remain locked until entered for this session. Normal
   documents and OEM payloads are not playback items. No permanent app-private
   vault or mandatory local copy is required for Diamond playback.
9. Close Share to remove its temporary encrypted working copies and clear its
   password. Saved local/USB encrypted files are retained in normal folders.

EXISTING FILES
Authoring does not delete or encrypt the user's original source files in place.
Original photos or media remain available to the apps that could already open
them. Previous versions' plaintext restore outputs are also left unchanged.
This update cannot revoke copies already shared or remove files from other
devices. Review and remove unwanted old plaintext copies yourself, after
verifying a retained encrypted image. No automatic source cleanup is performed.

BOUNDARIES
- No Internet, cloud, general share sheet, app inventory, private app data,
  account/credential capture or ordinary-app protected partition access.
- Lite encrypts selected shared files, not a complete OS/phone-state image.
  OEM wraps supplied artifacts; hashes do not establish firmware authenticity.
- Public APIs cannot reliably map each removable volume to USB versus SD while
  USB is attached, or prove the physical connector is USB-C. Choose the attached
  USB drive explicitly; an ODM-owned mapping is needed for stricter assurance.
- New copies remain ciphertext at rest. Diamond must decrypt bounded data in
  memory to render it. APK key extraction, a modified/rooted environment, screen
  capture or recording are not prevented by this format. No exclusive-app or
  exclusive-device DRM claim is made.
- App data is excluded from cloud/device backup. Long operations use a dataSync
  foreground service and bounded wake lock; source checks and completion wait
  for foreground acknowledgement. Process death, drive removal and platform
  time limits can interrupt work. Interrupted work is not resumed.
- Maximum authoring batch payload: 32 GiB and 10,000 sources. Temporary private
  ciphertext working copies and local file imports require sufficient free
  space. Those copies are not a playback vault. Share relative paths
  are limited to 32 segments/1024 characters; backup metadata is capped at 8 MiB.
  FAT32 drives have a lower single-file limit. Keep multiple verified copies.

ARTWORK
Original supplied artwork is preserved at:
  app/src/main/res/drawable-nodpi/dualscan_share_artwork.png
Launcher art uses a centered full-color image and an adaptive-mask safe inset.
No reference-APK branding or components are included.

VERIFICATION AND HANDOFF
See DELIVERY-VERIFICATION.json for the exact delivered APK hashes, executed
unit/instrumentation tests, current UI evidence and unqualified hardware scope.
Test source alone is not evidence of a passing run. Historical release reports
remain in their original delivery folders and do not qualify this release.
Current regression sources cover encrypted-only import/copy, rejection of plaintext and
legacy inputs, no public extraction path, source preservation, optional-password
isolation, tamper rejection and foreground-service lifecycle behavior.
Public synthetic interoperability fixtures include separately authored encrypted
tracks, encrypted artwork, known PNG pixels, text and existing album containers.
They are test-only; no demo library is loaded at startup. Consumer regressions
cover exact PCM/artwork, colliding per-file entry IDs, unified cross-file queues,
bounded source lifetimes, session-only passwords and encrypted-copy behavior.
Emulator checks do not qualify physical USB-C, DACs or OEM firmware integration.

The interchange-core and tella-keys-core modules are included. Compatible future
builds require the same separate 32-byte ecosystem key for Share and Diamond:
  -PdualscanEcosystemKeyFile=/absolute/path/to/key
or DUALSCAN_ECOSYSTEM_KEY_FILE. Default:
  ~/.local/share/dualscan-research/keys/ecosystem-v1.key
Source ZIPs exclude the raw key and generated build source. Back up BOTH source
ZIPs and the separate private key. A replacement key would make old DSMP0002
images unreadable by the replacement build. Maintain APK upgrade-signing keys
separately. The embedded content key is extractable from APKs.

Compiled Tella-derived scope is MainKey/Wiper under MIT, copyright 2025
Horizontal. Upstream unauthenticated AES-CTR code is an audit reference only and
is not compiled. License, notices and pinned provenance are retained in
third_party/tella and the application legal assets.

See docs/OFFLINE-INTERCHANGE-HANDOFF.txt for build-key provisioning and format
boundaries, and docs/OEM-ODM-INTEGRATION.txt for proposed OEM integration.
