@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import com.dualscan.mp.core.MediaEntry
import com.dualscan.mp.core.UnlockedMediaArray
import java.io.IOException

class EncryptedMediaDataSource(
    private val array: UnlockedMediaArray,
    private val entries: Map<String, MediaEntry>
) : BaseDataSource(false) {
    private var current: MediaEntry? = null
    private var currentUri: Uri? = null
    private var position = 0L
    private var remaining = 0L
    private var opened = false
    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        require(dataSpec.uri.scheme == "dualscan-mp") { "Only an unlocked local collection can be played." }
        val id = dataSpec.uri.lastPathSegment ?: throw IOException("Missing media entry.")
        val entry = entries[id] ?: throw IOException("This item is no longer available.")
        if (dataSpec.position < 0 || dataSpec.position > entry.sizeBytes) throw IOException("Playback position is outside this item.")
        current = entry; currentUri = dataSpec.uri; position = dataSpec.position
        remaining = if (dataSpec.length == C.LENGTH_UNSET.toLong()) entry.sizeBytes - position else minOf(dataSpec.length, entry.sizeBytes - position)
        opened = true; transferStarted(dataSpec)
        return remaining
    }
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val entry = current ?: throw IOException("The collection has been closed.")
        val count = array.readAt(entry.id, position, buffer, offset, minOf(length.toLong(), remaining).toInt())
        if (count < 0) throw IOException("The encrypted item ended before its catalog size.")
        if (count == 0) throw IOException("The encrypted item could not produce data.")
        position += count; remaining -= count; bytesTransferred(count)
        return count
    }
    override fun getUri(): Uri? = currentUri
    override fun close() { current = null; currentUri = null; remaining = 0; if (opened) { opened = false; transferEnded() } }
    class Factory(private val array: UnlockedMediaArray) : DataSource.Factory {
        private val entries = array.catalog.entries.associateBy { it.id }
        override fun createDataSource(): DataSource = EncryptedMediaDataSource(array, entries)
    }
}
