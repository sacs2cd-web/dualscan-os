package com.dualscan.mp.audio

import android.content.ContentProvider
import android.content.ContentValues
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Binder
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.ProxyFileDescriptorCallback
import android.os.storage.StorageManager
import android.provider.OpenableColumns
import android.system.ErrnoException
import android.system.OsConstants
import com.dualscan.mp.core.MediaEntry
import com.dualscan.mp.core.UnlockedMediaArray
import java.io.FileNotFoundException
import java.util.UUID

/** No exported grants, persistent plaintext, socket, or network playback endpoint. */
object EncryptedMediaRegistry {
    private data class Session(val array: UnlockedMediaArray, val entries: Map<String, MediaEntry>)
    private val sessions=mutableMapOf<String,Session>()
    @Synchronized fun register(array: UnlockedMediaArray,entries: List<MediaEntry>): String {
        val id=UUID.randomUUID().toString()
        sessions[id]=Session(array,entries.associateBy { it.id });return id
    }
    @Synchronized fun unregister(session: String) { sessions.remove(session) }
    @Synchronized fun resolve(uri: Uri): Pair<UnlockedMediaArray,MediaEntry> {
        val path=uri.pathSegments
        if(path.size != 2) throw FileNotFoundException("Media unavailable")
        val session=sessions[path[0]] ?: throw FileNotFoundException("Library locked")
        return session.array to (session.entries[path[1]] ?: throw FileNotFoundException("Media unavailable"))
    }
    fun uri(packageName: String,session: String,entry: MediaEntry): Uri = Uri.Builder().scheme("content")
        .authority("$packageName.internal-media").appendPath(session).appendPath(entry.id).build()
}

class EncryptedMediaProvider: ContentProvider() {
    private val worker=HandlerThread("MpAuthenticatedReads").apply { start() }
    private val handler=Handler(worker.looper)
    override fun onCreate()=true
    private fun requireOwner() { if(Binder.getCallingUid()!=Process.myUid()) throw SecurityException("Private media") }
    override fun openFile(uri: Uri,mode: String): ParcelFileDescriptor {
        requireOwner();if(mode!="r")throw FileNotFoundException("Read only")
        val (array,entry)=EncryptedMediaRegistry.resolve(uri)
        val storage=context!!.getSystemService(StorageManager::class.java)
        return storage.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY,object:ProxyFileDescriptorCallback(){
            override fun onGetSize()=entry.sizeBytes
            override fun onRead(offset: Long,size: Int,data: ByteArray): Int = try {
                val (current,currentEntry)=EncryptedMediaRegistry.resolve(uri)
                if(current !== array || currentEntry.id != entry.id)throw FileNotFoundException("Library locked")
                val count=current.readAt(currentEntry.id,offset,data,0,minOf(size,data.size))
                if(count<0)0 else count
            } catch(_:Exception) { throw ErrnoException("authenticated media read",OsConstants.EIO) }
            override fun onWrite(offset:Long,size:Int,data:ByteArray):Int { throw ErrnoException("read only",OsConstants.EBADF) }
            override fun onRelease()=Unit
        },handler)
    }
    override fun openAssetFile(uri:Uri,mode:String):AssetFileDescriptor {
        requireOwner();val (_,entry)=EncryptedMediaRegistry.resolve(uri)
        return AssetFileDescriptor(openFile(uri,mode),0,entry.sizeBytes)
    }
    override fun query(uri:Uri,projection:Array<out String>?,selection:String?,selectionArgs:Array<out String>?,sortOrder:String?):Cursor {
        requireOwner();val (_,entry)=EncryptedMediaRegistry.resolve(uri)
        val columns=projection?:arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE)
        return MatrixCursor(columns).apply { addRow(columns.map { when(it){OpenableColumns.DISPLAY_NAME->entry.displayName;OpenableColumns.SIZE->entry.sizeBytes;else->null} }) }
    }
    override fun getType(uri:Uri):String { requireOwner();return EncryptedMediaRegistry.resolve(uri).second.mimeType }
    override fun insert(uri:Uri,values:ContentValues?):Uri? { throw UnsupportedOperationException("Read only") }
    override fun update(uri:Uri,values:ContentValues?,selection:String?,selectionArgs:Array<out String>?)=0
    override fun delete(uri:Uri,selection:String?,selectionArgs:Array<out String>?)=0
    override fun shutdown(){worker.quitSafely();super.shutdown()}
}
