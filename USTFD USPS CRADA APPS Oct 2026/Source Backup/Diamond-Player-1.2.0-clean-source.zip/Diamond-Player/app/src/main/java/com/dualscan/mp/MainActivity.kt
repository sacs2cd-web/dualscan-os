@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.dualscan.mp.core.MediaEntry
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val model: MpViewModel = viewModel()
            val accent = Color(0xFFFF00FE)
            val colors = if (model.dark) darkColorScheme(primary = accent, secondary = accent, tertiary = accent, primaryContainer = accent, onPrimary = Color.Black, onPrimaryContainer = Color.Black, background = Color.Black, surface = Color(0xFF101010), surfaceVariant = Color(0xFF202020), onSurface = Color.White)
                else lightColorScheme(primary = accent, secondary = accent, tertiary = accent, primaryContainer = accent, onPrimary = Color.Black, onPrimaryContainer = Color.Black, background = Color(0xFFFDFDFD), surface = Color.White, surfaceVariant = Color(0xFFEDEFF0), onSurface = Color(0xFF101010))
            SideEffect {
                window.statusBarColor = colors.background.toArgb()
                window.navigationBarColor = colors.background.toArgb()
                WindowInsetsControllerCompat(window, window.decorView).apply { isAppearanceLightStatusBars = !model.dark; isAppearanceLightNavigationBars = !model.dark }
            }
            MaterialTheme(colorScheme = colors) { MpApp(model) }
        }
    }
}
private class CollectionPicker : ActivityResultContracts.OpenDocument() {
    override fun createIntent(context: Context, input: Array<String>): Intent = super.createIntent(context, input).apply {
        putExtra(DocumentsContract.EXTRA_INITIAL_URI, UsbStorageAccess.initialRoot(context)
            ?: DocumentsContract.buildDocumentUri(UsbAccessPolicy.AUTHORITY, "primary:Music"))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MpApp(model: MpViewModel) {
    var unlockPassword by remember(model.passwordRequestUri) { mutableStateOf("") }
    var saveDialog by remember { mutableStateOf(false) }
    var savePhone by remember { mutableStateOf(false) }
    var about by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }
    var importDialog by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(CollectionPicker()) { uri -> uri?.let { model.openCollection(it) } }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { model.prepareSources(it) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(model::prepareFolder) }
    val destination = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { model.saveTo(it, savePhone) } }
    val open = { model.refreshUsb(); picker.launch(arrayOf("*/*")) }
    val create = { importDialog = true }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { TopAppBar(title = { Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.diamond_fidelity_original), contentDescription = null, modifier = Modifier.width(32.dp).height(27.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(9.dp))
            Text("Diamond™ Player", fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1, color = MaterialTheme.colorScheme.primary)
        } }, actions = {
            IconButton(onClick = model::toggleTheme) { Icon(if (model.dark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, "Switch light or dark appearance", tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = { about = true }) { Icon(Icons.Rounded.MoreVert, "About") }
        }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)) },
        bottomBar = {
            if (model.busy || model.status.isNotBlank()) Surface(color = MaterialTheme.colorScheme.surface) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (model.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(model.status, style = MaterialTheme.typography.bodySmall)
            } }
        }
    ) { insets ->
        if (model.array == null) {
            Column(Modifier.fillMaxSize().padding(insets).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Disc(Icons.Rounded.MusicNote, 112)
                Spacer(Modifier.height(28.dp))
                Text("Your library is empty", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(15.dp))
                Text("Add music, videos or photos, or open a collection.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(34.dp))
                Button(onClick = create, enabled = !model.busy, modifier = Modifier.fillMaxWidth().height(52.dp)) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(9.dp)); Text("Add media") }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = open, enabled = !model.busy, modifier = Modifier.fillMaxWidth().height(52.dp)) { Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(10.dp)); Text("Open collection") }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(insets)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(model.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(model.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { saveDialog = true; model.refreshUsb() }, enabled = !model.busy) { Icon(Icons.Rounded.Download, "Save collection") }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        TextButton(onClick = { sortMenu = true }, enabled = !model.busy) { Icon(Icons.Rounded.Sort, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(sortLabel(model.sortOrder)) }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            MediaSortOrder.entries.forEach { order -> DropdownMenuItem(text = { Text(sortLabel(order)) }, onClick = { model.setSortOrder(order); sortMenu = false }, trailingIcon = { if (model.sortOrder == order) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary) }) }
                        }
                    }
                    IconButton(onClick = open, enabled = !model.busy) { Icon(Icons.Rounded.FolderOpen, "Open another collection") }
                    IconButton(onClick = create, enabled = !model.busy) { Icon(Icons.Rounded.Add, "New collection") }
                }
                model.current?.let { item -> PlayerPane(model, item) }
                val filters = listOf("All", "Music", "Video", "Photos")
                TabRow(selectedTabIndex = filter, containerColor = MaterialTheme.colorScheme.background) { filters.forEachIndexed { i, text -> Tab(selected = filter == i, onClick = { filter = i }, text = { Text(text, fontSize = 12.sp) }) } }
                val visible = model.visibleEntries.filter { entry -> when (filter) { 1 -> entry.mimeType.startsWith("audio/"); 2 -> entry.mimeType.startsWith("video/"); 3 -> entry.mimeType.startsWith("image/"); else -> true } }
                if (model.entries.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f).padding(28.dp), contentAlignment = Alignment.Center) {
                    Text("No playable media in this image.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                if (model.entries.isNotEmpty()) LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(visible, key = { _, entry -> entry.id }) { index, entry -> MediaRow(entry, entry.id == model.current?.id, model.sortOrder == MediaSortOrder.FOLDERS, trackNumber(entry.displayName, index + 1)) { model.play(entry) } }
                }
            }
        }
    }
    if (importDialog) AlertDialog(onDismissRequest = { importDialog = false }, title = { Text("Add media") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { importDialog = false; mediaPicker.launch(arrayOf("audio/*", "video/*", "image/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.AudioFile, null); Spacer(Modifier.width(8.dp)); Text("Choose files") }
        OutlinedButton(onClick = { importDialog = false; folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Choose a folder") }
    } }, confirmButton = { TextButton(onClick = { importDialog = false }) { Text("Cancel") } })
    model.passwordRequestUri?.let { uri ->
        val dismiss = { model.dismissPasswordRequest(); if (!model.busy) unlockPassword = "" }
        AlertDialog(onDismissRequest = dismiss, title = { Text("Enter password") }, text = {
            OutlinedTextField(unlockPassword, { unlockPassword = it.take(256) }, label = { Text("Collection password") }, enabled = !model.busy, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
        }, confirmButton = { TextButton(onClick = { val pass = unlockPassword.toCharArray(); unlockPassword = ""; model.openCollection(uri, pass) }, enabled = !model.busy && unlockPassword.isNotEmpty()) { Text("Open") } }, dismissButton = { TextButton(onClick = dismiss, enabled = !model.busy) { Text("Cancel") } })
    }
    if (model.creationOpen) AlertDialog(onDismissRequest = model::cancelCreation, title = { Text("Make it yours") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(model.draftTitle, { model.draftTitle = it }, label = { Text("Collection name") }, enabled = !model.busy, singleLine = true)
        OutlinedTextField(model.draftPassword, { model.draftPassword = it.take(256); if (it.isEmpty()) model.draftConfirmation = "" }, label = { Text("Password (optional)") }, enabled = !model.busy, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
        if (model.draftPassword.isNotEmpty()) OutlinedTextField(model.draftConfirmation, { model.draftConfirmation = it.take(256) }, label = { Text("Confirm password") }, enabled = !model.busy, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
        if (model.draftPassword.isNotEmpty()) Text("Keep your password safe. It cannot be recovered.", style = MaterialTheme.typography.bodySmall)
    } }, confirmButton = { TextButton(onClick = model::createCollection, enabled = !model.busy) { Text("Create") } }, dismissButton = { TextButton(onClick = model::cancelCreation, enabled = !model.busy) { Text("Cancel") } })
    if (saveDialog) AlertDialog(onDismissRequest = { saveDialog = false }, title = { Text("Take your collection") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = { savePhone = true; saveDialog = false; destination.launch(DocumentsContract.buildDocumentUri(UsbAccessPolicy.AUTHORITY, "primary:Music")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Smartphone, null); Spacer(Modifier.width(8.dp)); Text("Save on phone") }
        OutlinedButton(onClick = { savePhone = false; saveDialog = false; destination.launch(UsbStorageAccess.initialRoot(context)) }, enabled = model.usbReady, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Usb, null); Spacer(Modifier.width(8.dp)); Text("Save to USB") }
        Text(if (model.usbReady) "Your saved copy stays encrypted." else "Connect a USB drive to save there.", style = MaterialTheme.typography.bodySmall)
    } }, confirmButton = { TextButton(onClick = { saveDialog = false }) { Text("Done") } })
    model.error?.let { message -> AlertDialog(onDismissRequest = model::dismissError, title = { Text("Let's try that again") }, text = { Text(message) }, confirmButton = { TextButton(onClick = model::dismissError) { Text("OK") } }) }
    if (about) {
        val license = remember { context.assets.open("legal/TELLA-LICENSE").bufferedReader().use { it.readText() } }
        AlertDialog(onDismissRequest = { about = false }, title = { Text("Diamond™ Player", color = MaterialTheme.colorScheme.primary) }, text = { Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) { Text("Music. Video. Photos.\nVersion ${BuildConfig.VERSION_NAME}\n\nLicenses\n\n$license", style = MaterialTheme.typography.bodySmall) } }, confirmButton = { TextButton(onClick = { about = false }) { Text("Close") } })
    }
}

@Composable
private fun PlayerPane(model: MpViewModel, entry: MediaEntry) {
    var showArtwork by remember(entry.id) { mutableStateOf(false) }
    val artwork = model.artwork?.takeIf { model.artworkKey == entry.id }
    val preview = if (entry.mimeType.startsWith("image/")) model.picture else artwork
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            entry.mimeType.startsWith("image/") -> model.picture?.let { Image(it.asImageBitmap(), "Artwork for ${displayTitle(entry.displayName)}", Modifier.fillMaxWidth().height(220.dp).clickable(onClickLabel = "View full-screen artwork") { showArtwork = true }, contentScale = ContentScale.Fit) } ?: Box(Modifier.height(220.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            entry.mimeType.startsWith("video/") -> Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                AndroidView(factory = { context -> PlayerView(context).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; keepScreenOn = true } }, update = { it.player = model.player }, modifier = Modifier.fillMaxSize(), onRelease = { it.player = null })
                if (!model.playing) artwork?.let { Image(it.asImageBitmap(), "Artwork for ${displayTitle(entry.displayName)}", Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).clickable(onClickLabel = "View full-screen artwork") { showArtwork = true }, contentScale = ContentScale.Fit) }
            }
            else -> if (artwork != null) {
                Image(artwork.asImageBitmap(), "Artwork for ${displayTitle(entry.displayName)}", Modifier.size(150.dp).clip(RoundedCornerShape(12.dp)).clickable(onClickLabel = "View full-screen artwork") { showArtwork = true }, contentScale = ContentScale.Fit)
            } else Disc(Icons.Rounded.MusicNote, 112)
        }
        Spacer(Modifier.height(12.dp))
        Text(displayTitle(entry.displayName), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (!entry.mimeType.startsWith("image/")) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(model.output, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (model.bitPerfect) Text("· Bit-perfect", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            var dragging by remember(entry.id) { mutableStateOf(false) }
            var seek by remember(entry.id) { mutableFloatStateOf(0f) }
            val duration = model.durationMs.coerceAtLeast(0)
            Slider(value = if (dragging) seek else if (duration > 0) (model.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                onValueChange = { dragging = true; seek = it }, onValueChangeFinished = { model.seek((seek * duration).toLong()); dragging = false }, enabled = duration > 0)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(time(model.positionMs), style = MaterialTheme.typography.labelSmall); Text(time(duration), style = MaterialTheme.typography.labelSmall) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            IconButton(onClick = { model.skip(-1) }) { Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(30.dp)) }
            if (!entry.mimeType.startsWith("image/")) FilledIconButton(onClick = model::togglePlay, modifier = Modifier.size(56.dp)) { Icon(if (model.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (model.playing) "Pause" else "Play", Modifier.size(32.dp)) }
            IconButton(onClick = { model.skip(1) }) { Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(30.dp)) }
        }
        if (entry.mimeType.startsWith("audio/") && model.fidelityText.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            if (!model.bitPerfect) Text("Source fidelity", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Surface(shape = RoundedCornerShape(50), color = Color(0xFF191919)) {
                Text(model.fidelityText, color = Color(0xFFE6C46D), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 9.dp))
            }
        }
    }
    if (showArtwork && preview != null) {
        ArtworkDialog(preview, displayTitle(entry.displayName)) { showArtwork = false }
    }
}

@Composable
private fun ArtworkDialog(bitmap: android.graphics.Bitmap, title: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close artwork", tint = Color.White) }
            }
            Image(bitmap.asImageBitmap(), "Full-screen artwork for $title", Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp, vertical = 16.dp), contentScale = ContentScale.Fit)
        }
    }
}
@Composable
private fun Disc(icon: ImageVector, size: Int) { Box(Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Box(Modifier.size((size * 0.74f).dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) { Icon(icon, null, Modifier.size((size * 0.42f).dp), tint = MaterialTheme.colorScheme.primary) } } }
@Composable
private fun MediaRow(entry: MediaEntry, active: Boolean, showFolder: Boolean, number: Int, play: () -> Unit) { Row(Modifier.fillMaxWidth().clickable(onClick = play).padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
    if (entry.mimeType.startsWith("audio/")) Text(number.toString().padStart(2, '0'), modifier = Modifier.width(32.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    else Icon(if (entry.mimeType.startsWith("video/")) Icons.Rounded.PlayCircle else Icons.Rounded.Image, null, Modifier.size(32.dp), tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(displayTitle(entry.displayName), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal); Text(if (showFolder) entry.relativePath?.substringBeforeLast('/', "")?.ifBlank { "Collection" } ?: "Collection" else entry.displayName.substringAfterLast('.', "").uppercase(Locale.ROOT), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
} }
private fun time(ms: Long): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(Locale.ROOT, seconds / 60, seconds % 60) }

private fun sortLabel(order: MediaSortOrder): String = when (order) { MediaSortOrder.TRACKS -> "Tracks"; MediaSortOrder.FOLDERS -> "Folders"; MediaSortOrder.NAME -> "Name" }

private fun displayTitle(filename: String): String = filename.substringBeforeLast('.', filename).replace(Regex("^\\s*(?:\\d{1,3}\\s*[-_.]\\s*|0\\d\\s+)"), "").ifBlank { filename }
private fun trackNumber(filename: String, fallback: Int): Int = Regex("^\\s*(\\d{1,3})(?:[\\s._-])").find(filename)?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it > 0 } ?: fallback
