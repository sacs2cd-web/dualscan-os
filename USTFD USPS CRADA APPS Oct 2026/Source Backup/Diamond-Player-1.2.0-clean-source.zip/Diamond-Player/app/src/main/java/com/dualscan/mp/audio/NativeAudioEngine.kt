package com.dualscan.mp.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.media.AudioRouting
import android.media.AudioTrack
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

sealed interface NativeCommand {
    data class Load(val queue: List<NativeQueueItem>, val startPositionUs: Long = 0, val selectedDeviceId: Int? = null, val strictUsb: Boolean = false, val startIndex: Int = 0) : NativeCommand
    data class Play(val index: Int? = null) : NativeCommand
    data object Pause : NativeCommand
    data object Stop : NativeCommand
    data object Next : NativeCommand
    data object Previous : NativeCommand
    data class Seek(val positionUs: Long) : NativeCommand
    data class SelectDevice(val id: Int?) : NativeCommand
    data class Strict(val enabled: Boolean) : NativeCommand
    data class Focus(val change: Int) : NativeCommand
    data object DevicesChanged : NativeCommand
    data class Invalidated(val reason: String, val generation: Long) : NativeCommand
}

/** Optional synchronous observer of bytes actually accepted by AudioTrack; used by verification. */
data class NativePcmWrite(val audioTrackSessionId: Int, val queueIndex: Int, val firstFrame: Long,
    val underrunCount: Int, val bytes: ByteBuffer)

/** Owns source decoding, untouched PCM writes, focus, routing and preference cleanup on one thread. */
@androidx.annotation.RequiresApi(34)
class NativeAudioEngine(
    private val context: Context,
    initialState: NativePlaybackState,
    private val pcmObserver: ((NativePcmWrite) -> Unit)? = null,
    private val publish: (NativePlaybackState) -> Unit
) : AutoCloseable {
    private val manager = context.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val commands = LinkedBlockingQueue<NativeCommand>()
    private val mediaAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private var state = initialState.copy(playing = false, loading = false, resourcesReleased = true, bitPerfectContractActive = false)
    private var source: NativePcmSource? = null
    private var renderIndex = -1
    private data class Segment(val index: Int, val firstFrame: Long, val baseUs: Long,
        val info: NativeTrackInfo, val format: PcmFormat, val decoderFormat: PcmFormat?)
    private val segments = ArrayDeque<Segment>()
    private val preparation = NativeQueuePreparation(::openSource)
    private var nextTicket: NativeQueuePreparation.Ticket? = null
    private var stagedNext: PreparedNativeTrack? = null
    private var transitionFailure: Exception? = null
    private var outputSerial = 0L
    @Volatile private var track: AudioTrack? = null
    @Volatile private var preferredDevice: AudioDeviceInfo? = null
    @Volatile private var preferredMixer: AudioMixerAttributes? = null
    private var pending = ByteBuffer.allocateDirect(1).apply { limit(0) }
    private var endOfSource = false
    private var writtenFrames = 0L
    private var basePositionUs = 0L
    private var lastHead = 0L
    private var headWraps = 0L
    private var lastPublishMs = 0L
    private var resumeOnFocus = false
    private var focusHeld = false
    @Volatile private var running = true
    @Volatile private var invalidation: NativeCommand.Invalidated? = null
    @Volatile private var trackGeneration = 0L
    private val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(mediaAttributes)
        .setWillPauseWhenDucked(true)
        .setOnAudioFocusChangeListener({ send(NativeCommand.Focus(it)) }, main)
        .build()
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) { send(NativeCommand.DevicesChanged) }
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            val selected = preferredDevice?.id
            if (removedDevices.any { it.id == selected }) invalidate("The selected output was disconnected.")
            send(NativeCommand.DevicesChanged)
        }
    }
    private val routingListener = AudioRouting.OnRoutingChangedListener { routing ->
        if (routing !== track) return@OnRoutingChangedListener
        if ((routing as AudioTrack).playState != AudioTrack.PLAYSTATE_PLAYING) return@OnRoutingChangedListener
        val actual = actualRoutedDevices(routing).map { it.id }
        val expected = preferredDevice?.id
        if (expected != null && !selectedOutputMatches(actual, expected)) invalidate("The AudioTrack route no longer matches the selected output.")
    }
    private val mixerListener = AudioManager.OnPreferredMixerAttributesChangedListener { attributes, device, mixer ->
        val expected = preferredMixer
        if (attributes.usage == AudioAttributes.USAGE_MEDIA && device.id == preferredDevice?.id && expected != null &&
            mixer != expected && manager.getPreferredMixerAttributes(mediaAttributes, device) != expected) {
            invalidate("The platform USB mixer preference changed.")
        }
    }
    private val worker = Thread(::run, "DualscanMpNativePcm").apply { start() }

    init {
        manager.registerAudioDeviceCallback(deviceCallback, main)
        manager.addOnPreferredMixerAttributesChangedListener(context.mainExecutor, mixerListener)
        send(NativeCommand.DevicesChanged)
    }

    fun send(command: NativeCommand) { if (running) commands.offer(command) }

    private fun invalidate(reason: String) {
        val event = NativeCommand.Invalidated(reason, trackGeneration)
        invalidation = event
        send(event)
    }

    private fun run() {
        try {
            while (running) {
                val command = commands.poll(if (state.playing) 0 else 100, TimeUnit.MILLISECONDS)
                try {
                    if (command != null) handle(command)
                    if (state.playing) renderStep()
                } catch (failure: Exception) {
                    releasePlayback()
                    state = state.copy(playing = false, loading = false, status = "Playback stopped", error = failure.message ?: failure.javaClass.simpleName)
                    emit()
                }
            }
        } catch (_: InterruptedException) {
            // Service shutdown interrupts the loop; cleanup always runs below.
        } finally {
            releasePlayback()
            state = state.copy(playing = false, loading = false, status = "Playback stopped")
            emit()
        }
    }

    private fun handle(command: NativeCommand) {
        when (command) {
            is NativeCommand.Load -> {
                require(command.queue.isEmpty() || command.startIndex in command.queue.indices) { "Invalid audio queue position." }
                releasePlayback()
                outputSerial = 0
                state = state.copy(queue = command.queue.toList(), queueIndex = command.startIndex, selectedDeviceId = command.selectedDeviceId, strictUsb = command.strictUsb, positionUs = 0, source = null, rawDecoderFormat = null, decodedPcmFormat = null, pcmFormat = null, error = null,
                    gaplessTransitions = 0, outputGeneration = 0, outputFramesWritten = 0, outputUnderrunCount = 0)
                if (command.queue.isNotEmpty()) { startTrack(command.startIndex); if (command.startPositionUs > 0) seek(command.startPositionUs) }
            }
            is NativeCommand.Play -> {
                resumeOnFocus = false
                val index = command.index ?: state.queueIndex
                if (source == null || index != state.queueIndex) startTrack(index)
                else resumePlayback()
            }
            NativeCommand.Pause -> { resumeOnFocus = false; pausePlayback("Paused") }
            NativeCommand.Stop -> { releasePlayback(); state = state.copy(playing = false, loading = false, status = "Playback stopped", error = null); emit() }
            NativeCommand.Next -> if (state.queueIndex + 1 < state.queue.size) startTrack(state.queueIndex + 1)
            NativeCommand.Previous -> if (state.positionUs > 3_000_000 && source != null) seek(0) else startTrack((state.queueIndex - 1).coerceAtLeast(0))
            is NativeCommand.Seek -> seek(command.positionUs)
            is NativeCommand.SelectDevice -> {
                releasePlayback()
                state = state.copy(selectedDeviceId = command.id, playing = false, status = "Output selected. Press play.", error = null)
                emit()
            }
            is NativeCommand.Strict -> {
                releasePlayback()
                state = state.copy(strictUsb = command.enabled, playing = false,
                    status = if (command.enabled) "Strict USB mode requires an exact supported bit-perfect mixer." else "Native PCM mode · bit-perfect output unverified", error = null)
                emit()
            }
            is NativeCommand.Focus -> when (command.change) {
                AudioManager.AUDIOFOCUS_LOSS -> { resumeOnFocus = false; pausePlayback("Paused: audio focus lost"); focusHeld = false }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                    resumeOnFocus = state.playing
                    pausePlayback("Paused for another audio source")
                }
                AudioManager.AUDIOFOCUS_GAIN -> if (resumeOnFocus) { resumeOnFocus = false; resumePlayback() }
            }
            NativeCommand.DevicesChanged -> {
                state = state.copy(devices = connectedOutputDevices(manager))
                emit()
            }
            is NativeCommand.Invalidated -> if (command.generation == trackGeneration && track != null) error(command.reason)
        }
    }

    private fun openSource(item: NativeQueueItem): NativePcmSource {
        val uri = Uri.parse(item.uri)
        return if (WavPcmSource.isWave(context, uri)) WavPcmSource(context, uri, item.name) else CodecPcmSource(context, uri, item.name)
    }

    private fun scheduleNext() {
        nextTicket?.let(preparation::cancel)
        nextTicket = null
        val index = renderIndex + 1
        state.queue.getOrNull(index)?.let { nextTicket = preparation.prepare(index, it) }
    }

    private fun cancelPreparation() {
        nextTicket?.let(preparation::cancel)
        nextTicket = null
        stagedNext?.close(); stagedNext = null
        transitionFailure = null
    }

    private fun startTrack(index: Int, prepared: PreparedNativeTrack? = null) {
        val item = state.queue.getOrNull(index) ?: return
        releasePlayback()
        state = state.copy(queueIndex = index, playing = false, loading = true, positionUs = 0, durationUs = 0, source = null, rawDecoderFormat = null, decodedPcmFormat = null, pcmFormat = null,
            status = "Opening audio…", error = null)
        emit()
        val opened = prepared?.source ?: openSource(item)
        source = opened
        renderIndex = index
        pending = prepared?.prefix ?: ByteBuffer.allocateDirect(1).apply { limit(0) }
        state = state.copy(source = opened.info, rawDecoderFormat = opened.decoderFormat, decodedPcmFormat = opened.format, durationUs = opened.info.durationUs)
        emit()
        scheduleNext()
        val selectedId = state.selectedDeviceId
        val device = selectedId?.let { id -> manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == id } }
        check(selectedId == null || device != null) { "The selected output is no longer connected." }
        preferredDevice = device
        if (state.strictUsb) {
            strictPrecisionFailure(opened.info, opened.format)?.let { error(it) }
            check(device != null && isUsbAudioDevice(device.type)) { "Strict mode requires a selected USB DAC. Headphone/internal routes are unverified; switch strict mode off to use them." }
            val mixer = findExactBitPerfectMixer(manager, device, opened.format)
                ?: error("This USB DAC/platform does not advertise bit-perfect mixing for this exact PCM encoding, rate and channel layout.")
            check(manager.setPreferredMixerAttributes(mediaAttributes, device, mixer)) { "Android rejected the exact USB mixer preference." }
            preferredMixer = mixer
            check(manager.getPreferredMixerAttributes(mediaAttributes, device) == mixer) { "Android did not retain the requested USB mixer preference." }
        }
        val audioFormat = opened.format.toAudioFormat()
        val minimum = AudioTrack.getMinBufferSize(opened.format.sampleRateHz, opened.format.channelMask, opened.format.encoding)
        check(minimum > 0) { "Android does not accept this exact PCM format." }
        val frameSize = opened.format.bytesPerFrame
        val desired = maxOf(minimum, opened.format.sampleRateHz / 4 * frameSize)
        val size = (desired + frameSize - 1) / frameSize * frameSize
        val output = AudioTrack.Builder().setAudioAttributes(mediaAttributes).setAudioFormat(audioFormat)
            .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(size).build()
        track = output
        check(output.state == AudioTrack.STATE_INITIALIZED) { "AudioTrack could not initialize the source PCM format." }
        check(mixerFormatMatches(opened.format, output.format.encoding, output.sampleRate, output.format.channelMask)) {
            "AudioTrack changed the requested PCM format."
        }
        state = state.copy(pcmFormat = PcmFormat(output.sampleRate, output.channelCount, output.format.encoding, output.format.channelMask),
            audioTrackSessionId = output.audioSessionId, outputGeneration = ++outputSerial)
        if (device != null) check(output.setPreferredDevice(device)) { "Android rejected the selected output device." }
        output.addOnRoutingChangedListener(routingListener, main)
        pending = prepared?.prefix ?: ByteBuffer.allocateDirect(maxOf(size, 64 * 1024) / frameSize * frameSize).apply { limit(0) }
        endOfSource = prepared?.ended ?: false
        basePositionUs = 0
        writtenFrames = 0
        lastHead = 0
        headWraps = 0
        segments.add(Segment(index, 0, 0, opened.info, opened.format, opened.decoderFormat))
        invalidation = null
        resumePlayback()
    }

    private fun requestFocus() {
        if (!focusHeld) {
            check(manager.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { "Another app holds audio focus." }
            focusHeld = true
        }
    }

    private fun resumePlayback() {
        val output = track ?: return
        requestFocus()
        output.play()
        if (preferredDevice != null) {
            // Establish and inspect the playing route before sending any source PCM bytes.
            var attempts = 0
            while (actualRoutedDevices(output).isEmpty() && attempts++ < 100 && running) Thread.sleep(10)
            checkSelectedRoute()
        }
        if (state.strictUsb) checkStrictContract()
        state = state.copy(playing = true, loading = false, error = null)
        updatePosition(force = true)
    }

    private fun pausePlayback(reason: String) {
        track?.pause()
        updatePosition(force = false)
        state = state.copy(playing = false, loading = false, bitPerfectContractActive = false, status = reason)
        emit()
    }

    private fun seek(positionUs: Long) {
        // The decoder may be ahead of the audible track. Seeking acts on the
        // audible queue item, discarding queued-ahead PCM explicitly.
        if (source != null && renderIndex != state.queueIndex) {
            val wasPlaying = state.playing
            startTrack(state.queueIndex)
            if (!wasPlaying) pausePlayback("Paused")
        }
        val input = source ?: return
        val output = track ?: return
        val wasPlaying = state.playing
        output.pause()
        output.flush()
        basePositionUs = input.seekTo(positionUs.coerceIn(0, state.durationUs.coerceAtLeast(0)))
        cancelPreparation()
        pending.clear(); pending.limit(0)
        endOfSource = false
        writtenFrames = 0
        lastHead = 0
        headWraps = 0
        segments.clear()
        segments.add(Segment(renderIndex, 0, basePositionUs, input.info, input.format, input.decoderFormat))
        scheduleNext()
        state = state.copy(positionUs = basePositionUs, bitPerfectContractActive = false)
        if (wasPlaying) resumePlayback() else emit()
    }

    private fun renderStep() {
        val input = checkNotNull(source)
        val output = checkNotNull(track)
        checkSelectedRoute()
        if (state.strictUsb) checkStrictContract()
        if (!pending.hasRemaining() && !endOfSource) {
            pending.clear()
            val read = input.read(pending)
            pending.flip()
            endOfSource = read < 0
        }
        if (pending.hasRemaining()) {
            val before = pending.position()
            val result = output.write(pending, pending.remaining(), AudioTrack.WRITE_NON_BLOCKING)
            check(result >= 0) { "AudioTrack write failed ($result)." }
            check(result % input.format.bytesPerFrame == 0) { "AudioTrack accepted a partial PCM frame." }
            if (result > 0) pcmObserver?.invoke(NativePcmWrite(output.audioSessionId, renderIndex, writtenFrames,
                output.underrunCount, pending.asReadOnlyBuffer().apply { position(before); limit(before + result) }))
            writtenFrames += result / input.format.bytesPerFrame
            if (result == 0) Thread.sleep(5)
        } else if (endOfSource) {
            if (renderIndex + 1 < state.queue.size) {
                transitionToNext()
                updatePosition(force = false)
                return
            }
            if (playedFrames() >= writtenFrames) {
                updatePosition(force = true)
                releasePlayback(); state = state.copy(playing = false, positionUs = state.durationUs, status = "Queue finished"); emit()
                return
            }
            Thread.sleep(5)
        }
        updatePosition(force = false)
    }

    private fun transitionToNext() {
        if (stagedNext == null && transitionFailure == null) {
            val result = nextTicket?.take()
            if (result == null) { Thread.sleep(1); return }
            nextTicket = null
            stagedNext = result.prepared
            transitionFailure = result.failure
        }
        val next = stagedNext
        val old = checkNotNull(source)
        if (next != null && next.source.format == old.format) {
            // Validate every new source even when a previously verified USB
            // output remains open. No next-source bytes are written beforehand.
            if (state.strictUsb) {
                strictPrecisionFailure(next.source.info, next.source.format)?.let { transitionFailure = IllegalStateException(it) }
                if (transitionFailure == null) checkStrictContract(next.source)
            }
            if (transitionFailure == null) {
                preparation.retire(old)
                source = next.source
                pending = next.prefix
                endOfSource = next.ended
                renderIndex = next.index
                segments.add(Segment(next.index, writtenFrames, 0, next.source.info, next.source.format, next.source.decoderFormat))
                stagedNext = null
                state = state.copy(gaplessTransitions = state.gaplessTransitions + 1, nextTrackReady = false)
                scheduleNext()
                updatePosition(force = true)
                return
            }
        }
        // Different formats require an explicit output reconfiguration. Finish
        // old PCM first; never resample or insert a fade to disguise the change.
        if (playedFrames() < writtenFrames) { Thread.sleep(2); return }
        transitionFailure?.let { throw it }
        if (next != null) {
            stagedNext = null
            startTrack(next.index, next)
        }
    }

    private fun checkStrictContract(input: NativePcmSource = checkNotNull(source)) {
        invalidation?.takeIf { it.generation == trackGeneration }?.let { error(it.reason) }
        strictPrecisionFailure(input.info, input.format)?.let { error(it) }
        val output = checkNotNull(track)
        val device = checkNotNull(preferredDevice)
        val mixer = checkNotNull(preferredMixer)
        check(selectedOutputMatches(actualRoutedDevices(output).map { it.id }, device.id)) { "The actual AudioTrack route does not match only the selected USB DAC." }
        check(manager.getPreferredMixerAttributes(mediaAttributes, device) == mixer) { "The exact USB mixer preference is no longer active." }
        check(mixerFormatMatches(input.format, output.format.encoding, output.sampleRate, output.format.channelMask)) {
            "The AudioTrack PCM format changed."
        }
    }

    private fun checkSelectedRoute() {
        invalidation?.takeIf { it.generation == trackGeneration }?.let { error(it.reason) }
        preferredDevice?.let { device ->
            check(selectedOutputMatches(track?.let(::actualRoutedDevices).orEmpty().map { it.id }, device.id)) { "The actual AudioTrack route does not match only the selected output. Playback stopped to prevent fallback." }
        }
    }

    private fun playedFrames(): Long {
        val head = track?.playbackHeadPosition?.toLong()?.and(0xffffffffL) ?: 0
        if (head < lastHead) headWraps++
        lastHead = head
        return head + (headWraps shl 32)
    }

    private fun updatePosition(force: Boolean) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && now - lastPublishMs < 250) return
        lastPublishMs = now
        val output = track
        val played = if (output != null) playedFrames() else 0L
        while (segments.size > 1 && played >= segments.elementAt(1).firstFrame) segments.removeFirst()
        val segment = segments.firstOrNull()
        val position = if (segment != null) segment.baseUs + (played - segment.firstFrame).coerceAtLeast(0) * 1_000_000L / segment.format.sampleRateHz else state.positionUs
        val actual = output?.let(::actualRoutedDevices).orEmpty()
        val verified = state.playing && state.strictUsb && preferredMixer != null &&
            preferredDevice?.let { selectedOutputMatches(actual.map { route -> route.id }, it.id) } == true &&
            invalidation?.generation != trackGeneration
        val duration = segment?.info?.durationUs ?: state.durationUs
        state = state.copy(queueIndex = segment?.index ?: state.queueIndex, source = segment?.info ?: state.source,
            rawDecoderFormat = if (segment != null) segment.decoderFormat else state.rawDecoderFormat, decodedPcmFormat = segment?.format ?: state.decodedPcmFormat,
            durationUs = duration, positionUs = if (duration > 0) position.coerceIn(0, duration) else position.coerceAtLeast(0),
            outputFramesWritten = writtenFrames, outputUnderrunCount = output?.underrunCount ?: state.outputUnderrunCount,
            nextTrackReady = nextTicket?.isReady() == true || stagedNext != null,
            actualRoute = actual.joinToString { outputDeviceLabel(it) }.ifEmpty { "Route not reported while paused or inactive" },
            bitPerfectContractActive = verified,
            status = if (verified) "Android USB BIT_PERFECT mixer active" else if (state.playing) "Native PCM · bit-perfect output unverified" else state.status)
        emit()
    }

    private fun releasePlayback() {
        cancelPreparation()
        trackGeneration++
        val old = track
        if (old != null) state = state.copy(outputFramesWritten = writtenFrames, outputUnderrunCount = old.underrunCount)
        track = null
        preferredMixer = null // Ignore callbacks caused by our own cleanup.
        old?.let {
            runCatching { it.removeOnRoutingChangedListener(routingListener) }
            runCatching { it.pause() }
            runCatching { it.flush() }
            runCatching { it.release() }
        }
        source?.let { runCatching { it.close() } }
        source = null
        renderIndex = -1
        segments.clear()
        wipePcmBuffer(pending); pending.clear(); pending.limit(0)
        preferredDevice?.let { device -> runCatching { manager.clearPreferredMixerAttributes(mediaAttributes, device) } }
        preferredDevice = null
        invalidation = null
        if (focusHeld) manager.abandonAudioFocusRequest(focusRequest)
        focusHeld = false
        resumeOnFocus = false
        state = state.copy(playing = false, pcmFormat = null, bitPerfectContractActive = false, resourcesReleased = true, actualRoute = "None — playback stopped", nextTrackReady = false)
    }

    private fun emit() {
        val snapshot = state.copy(resourcesReleased = track == null && source == null)
        state = snapshot
        main.post { publish(snapshot) }
    }

    override fun close() {
        running = false
        worker.interrupt()
        manager.unregisterAudioDeviceCallback(deviceCallback)
        manager.removeOnPreferredMixerAttributesChangedListener(mixerListener)
        worker.join(1500)
        preparation.close()
    }
}
