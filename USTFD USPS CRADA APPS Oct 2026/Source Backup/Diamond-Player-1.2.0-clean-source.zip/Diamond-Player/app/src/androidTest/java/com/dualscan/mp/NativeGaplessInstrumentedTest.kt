package com.dualscan.mp

import android.os.SystemClock
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SdkSuppress
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.audio.EncryptedMediaRegistry
import com.dualscan.mp.audio.NativeAudioEngine
import com.dualscan.mp.audio.NativeCommand
import com.dualscan.mp.audio.NativePcmWrite
import com.dualscan.mp.audio.NativePlaybackState
import com.dualscan.mp.audio.NativeQueueItem
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import com.dualscan.mp.core.UnlockedMediaArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/** Verifies the PCM writer boundary and AudioTrack lifetime, not physical DAC timing. */
@RunWith(AndroidJUnit4::class)
@SdkSuppress(minSdkVersion = 34)
class NativeGaplessInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val assets get() = instrumentation.context.assets

    @Test fun adjacentEncryptedWavTracksWriteContinuousPcmToOneAudioTrack() {
        val rate = 48_000
        val trackFrames = rate * 3 / 4
        val pcm = ByteBuffer.allocate(trackFrames * 2 * 4).order(ByteOrder.LITTLE_ENDIAN).apply {
            repeat(trackFrames * 2) { frame ->
                val sample = (sin(2 * PI * 997 * frame / rate) * 900).roundToInt().toShort()
                putShort(sample); putShort(sample)
            }
        }.array()
        val first = wave(pcm.copyOfRange(0, trackFrames * 4), rate)
        val second = wave(pcm.copyOfRange(trackFrames * 4, pcm.size), rate)
        val file = File.createTempFile("gapless-encrypted-", ".dmpa", context.cacheDir).apply { delete() }
        val password = "Public gapless fixture 2026".toCharArray()
        try {
            MediaArray.create(file, "Continuous encrypted album", listOf(
                MediaInput("01.wav", "audio/wav") { first.inputStream() },
                MediaInput("02.wav", "audio/wav") { second.inputStream() }
            ), password).use { array -> verifyQueue(array, pcm, trackFrames.toLong(), 4, "wav-16-48") }
        } finally { password.fill('\u0000'); file.delete(); pcm.fill(0); first.fill(0); second.fill(0) }
    }

    @Test fun encryptedWavToFlacBoundaryPreservesEvery24BitPcmByte() {
        val vector = assets.open("arrays/flac-media-vector.json").bufferedReader().use { JSONObject(it.readText()) }
        val file = File.createTempFile("gapless-flac-encrypted-", ".dmpa", context.cacheDir)
        val password = vector.getString("password").toCharArray()
        try {
            assets.open("arrays/flac-media.dmpa").use { input -> file.outputStream().use { input.copyTo(it) } }
            val original = assets.open("arrays/source-24-96.wav").use { it.readBytes() }
            val pcm = original.copyOfRange(44, original.size)
            val combined = pcm + pcm
            original.fill(0)
            try {
                MediaArray.open(file, password).use { array -> verifyQueue(array, combined, 288_000, 6, "wav-flac-24-96") }
            } finally { pcm.fill(0); combined.fill(0) }
        } finally { password.fill('\u0000'); file.delete() }
    }

    private fun verifyQueue(array: UnlockedMediaArray, expected: ByteArray, firstTrackFrames: Long, bytesPerFrame: Int, label: String) {
        val session = EncryptedMediaRegistry.register(array, array.catalog.entries)
        val queue = array.catalog.entries.map { NativeQueueItem(EncryptedMediaRegistry.uri(context.packageName, session, it).toString(), it.displayName) }
        val complete = CountDownLatch(1)
        val failure = AtomicReference<String?>()
        val states = Collections.synchronizedList(mutableListOf<NativePlaybackState>())
        val accepted = MessageDigest.getInstance("SHA-256")
        val outputSessions = mutableSetOf<Int>()
        var submittedFrames = 0L
        var previousUnderruns = -1
        var boundaryUnderruns = -1
        var firstNextFrame = -1L
        val engine = NativeAudioEngine(context, NativePlaybackState(strictUsb = false), pcmObserver = { event: NativePcmWrite ->
            check(event.firstFrame == submittedFrames) { "Writer inserted or overlapped PCM frames." }
            check(event.bytes.remaining() % bytesPerFrame == 0)
            outputSessions.add(event.audioTrackSessionId)
            if (event.queueIndex == 0) previousUnderruns = event.underrunCount
            else if (firstNextFrame < 0) { firstNextFrame = event.firstFrame; boundaryUnderruns = event.underrunCount }
            submittedFrames += event.bytes.remaining() / bytesPerFrame
            accepted.update(event.bytes.duplicate())
        }) { state ->
            states.add(state)
            if (state.error != null) { failure.set(state.error); complete.countDown() }
            if (state.status == "Queue finished") complete.countDown()
        }
        try {
            engine.send(NativeCommand.Load(queue, strictUsb = false))
            assertTrue("Encrypted queue did not finish", complete.await(20, TimeUnit.SECONDS))
            assertNull("Audio engine failure", failure.get())
            val snapshots = synchronized(states) { states.toList() }
            val final = snapshots.last { it.status == "Queue finished" }
            assertEquals("Both tracks use the same AudioTrack session", 1, outputSessions.size)
            assertEquals("No output recreation between same-format tracks", 1L, final.outputGeneration)
            assertEquals("One automatic seamless transition", 1, final.gaplessTransitions)
            assertEquals("Next track starts at the exact previous frame boundary", firstTrackFrames, firstNextFrame)
            assertEquals("No boundary underrun was reported by AudioTrack", previousUnderruns, boundaryUnderruns)
            assertEquals(expected.size.toLong() / bytesPerFrame, submittedFrames)
            assertEquals("Accepted PCM equals the original tracks concatenated without inserted silence", hash(expected), hex(accepted.digest()))
            assertEquals("The visible queue follows the playback head", 1, final.queueIndex)
            assertTrue(snapshots.any { it.queueIndex == 1 && it.playing })
            File(context.filesDir, "verification-gapless-$label.json").writeText(JSONObject()
                .put("test", label).put("pcmBytes", expected.size).put("pcmSha256", hash(expected))
                .put("audioTrackSessions", outputSessions.toList()).put("outputGenerations", final.outputGeneration)
                .put("gaplessTransitions", final.gaplessTransitions).put("nextFirstFrame", firstNextFrame)
                .put("underrunsBeforeBoundary", previousUnderruns).put("underrunsAtBoundary", boundaryUnderruns)
                .put("finishedAtMs", SystemClock.elapsedRealtime()).toString(2) + "\n")
        } finally { engine.close(); EncryptedMediaRegistry.unregister(session) }
    }

    private fun wave(pcm: ByteArray, rate: Int): ByteArray = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN).apply {
        put("RIFF".toByteArray()); putInt(36 + pcm.size); put("WAVEfmt ".toByteArray()); putInt(16)
        putShort(1); putShort(2); putInt(rate); putInt(rate * 4); putShort(4); putShort(16)
        put("data".toByteArray()); putInt(pcm.size); put(pcm)
    }.array()
    private fun hash(bytes: ByteArray) = hex(MessageDigest.getInstance("SHA-256").digest(bytes))
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
}
