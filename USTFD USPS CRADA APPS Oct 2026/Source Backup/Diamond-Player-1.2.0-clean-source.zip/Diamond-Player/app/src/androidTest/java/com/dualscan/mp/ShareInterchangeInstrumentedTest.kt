@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.DataSpec
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SdkSuppress
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.audio.EncryptedMediaRegistry
import com.dualscan.mp.audio.WavPcmSource
import com.dualscan.mp.audio.strictPrecisionFailure
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.mp.core.UnlockedMediaArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest

/** Consumes actual ArchiveEngine exports made by the separate Share Android app. */
@RunWith(AndroidJUnit4::class)
class ShareInterchangeInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val assets get() = instrumentation.context.assets
    private val vector get() = assets.open("interop/share-fixture.json").bufferedReader().use { JSONObject(it.readText()) }

    @Test fun shareDefaultImageOpensWithoutPasswordAndPreservesEveryEntryAndCoverPixel() {
        withFixture("share-global.dshare") { file ->
            val encryptedHash = file.sha256()
            val before = privateFiles()
            MediaArray.open(file).use { array ->
                assertTrue(array.isPortable)
                assertFalse(array.passwordProtected)
                assertCatalogAndBytes(array)
                val expectedCover = vector.getJSONObject("cover")
                val media = MediaLibraryIndex.playable(array.catalog.entries)
                assertTrue("Fixture must include a document excluded from playback", media.size < array.catalog.entries.size)
                val audio = media.single { it.relativePath == vector.getJSONObject("audio").getString("relativePath") }
                val cover = requireNotNull(MediaLibraryIndex.coverFor(audio, media))
                assertEquals(expectedCover.getString("relativePath"), cover.relativePath)
                EncryptedPictureDecoder.decode(array, cover).let { bitmap ->
                    try {
                        assertEquals(expectedCover.getInt("width"), bitmap.width)
                        assertEquals(expectedCover.getInt("height"), bitmap.height)
                        val pixels = IntArray(bitmap.width * bitmap.height)
                        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                        val expected = expectedCover.getJSONArray("pixels")
                        assertArrayEquals(IntArray(expected.length()) { expected.getLong(it).toInt() }, pixels)
                    } finally { bitmap.recycle() }
                }

                // Media3 reads the same authenticated payload, including precise range seeks.
                val source = EncryptedMediaDataSource.Factory(array).createDataSource()
                val offset = 61L
                val length = minOf(4097L, audio.sizeBytes - offset).toInt()
                assertTrue(length > 0)
                try {
                    assertEquals(length.toLong(), source.open(DataSpec.Builder()
                        .setUri(Uri.parse("dualscan-mp://entry/${audio.id}"))
                        .setPosition(offset).setLength(length.toLong()).build()))
                    val actual = ByteArray(length); var position = 0
                    while (position < actual.size) {
                        val count = source.read(actual, position, minOf(103, actual.size - position))
                        assertTrue(count > 0); position += count
                    }
                    val direct = ByteArray(length); var directPosition = 0
                    while (directPosition < direct.size) {
                        val count = array.readAt(audio.id, offset + directPosition, direct, directPosition, direct.size - directPosition)
                        assertTrue(count > 0); directPosition += count
                    }
                    assertArrayEquals(direct, actual)
                    assertEquals(C.RESULT_END_OF_INPUT, source.read(ByteArray(1), 0, 1))
                    actual.fill(0); direct.fill(0)
                } finally { source.close() }
            }
            assertEquals("Opening and playback adapters leave ciphertext unchanged", encryptedHash, file.sha256())
            assertEquals("No plaintext playback staging file is created", before, privateFiles())
        }
    }

    @Test fun shareProtectedImageRequiresItsPasswordAndDoesNotFallBackToGlobalKey() {
        withFixture("share-password.dshare") { file ->
            try {
                MediaArray.open(file).close()
                fail("Protected Share image opened without its password")
            } catch (_: PasswordRequiredException) { }
            val wrong = "Incorrect public fixture password".toCharArray()
            try {
                try {
                    MediaArray.open(file, wrong).close()
                    fail("Protected image accepted an incorrect password")
                } catch (_: IOException) { }
            } finally { wrong.fill('\u0000') }
            val password = vector.getString("password").toCharArray()
            try {
                MediaArray.open(file, password).use { array ->
                    assertTrue(array.isPortable)
                    assertTrue(array.passwordProtected)
                    assertCatalogAndBytes(array)
                }
            } finally { password.fill('\u0000') }
        }
    }

    @Test @SdkSuppress(minSdkVersion = 34)
    fun share192k24BitMusicReachesNativePcmProviderWithoutChangingSamples() {
        withFixture("share-global.dshare") { file ->
            val before = privateFiles()
            MediaArray.open(file).use { array ->
                val expected = vector.getJSONObject("audio")
                val entry = array.catalog.entries.single { it.relativePath == expected.getString("relativePath") }
                val session = EncryptedMediaRegistry.register(array, listOf(entry))
                try {
                    WavPcmSource(context, EncryptedMediaRegistry.uri(context.packageName, session, entry), entry.displayName).use { source ->
                        assertEquals(expected.getInt("bitDepth"), source.info.sourceBitDepth)
                        assertEquals(expected.getInt("sampleRateHz"), source.info.sourceSampleRateHz)
                        assertEquals(expected.getInt("channelCount"), source.info.sourceChannelCount)
                        assertNull(strictPrecisionFailure(source.info, source.format))
                        val digest = MessageDigest.getInstance("SHA-256")
                        val buffer = ByteBuffer.allocateDirect(96 * 1024)
                        val bytes = ByteArray(buffer.capacity()); var total = 0L
                        try {
                            while (true) {
                                buffer.clear()
                                val count = source.read(buffer)
                                if (count < 0) break
                                assertTrue(count > 0 && count % source.format.bytesPerFrame == 0)
                                assertEquals(count, buffer.position())
                                buffer.flip(); buffer.get(bytes, 0, count)
                                digest.update(bytes, 0, count); bytes.fill(0); total += count
                            }
                            assertEquals(expected.getLong("pcmBytes"), total)
                            assertEquals(expected.getString("pcmSha256"), hex(digest.digest()))
                        } finally { bytes.fill(0) }
                    }
                } finally { EncryptedMediaRegistry.unregister(session) }
            }
            assertEquals("Native playback reads ciphertext without plaintext files", before, privateFiles())
        }
    }

    private fun assertCatalogAndBytes(array: UnlockedMediaArray) {
        val expected = vector
        assertEquals(expected.getString("title"), array.catalog.title)
        assertNotNull("Share backup manifest remains authenticated in the shared container", array.catalog.backupMetadata)
        val entries = expected.getJSONArray("entries")
        assertEquals(entries.length(), array.catalog.entries.size)
        for (index in 0 until entries.length()) {
            val item = entries.getJSONObject(index)
            val entry = array.catalog.entries.single { it.relativePath == item.getString("relativePath") }
            assertEquals(item.getLong("sizeBytes"), entry.sizeBytes)
            assertEquals(item.getString("sha256"), entry.sha256)
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = ByteArray(8191); var position = 0L
            try {
                while (position < entry.sizeBytes) {
                    val count = array.readAt(entry.id, position, bytes, 0, minOf(bytes.size.toLong(), entry.sizeBytes - position).toInt())
                    assertTrue(count > 0); digest.update(bytes, 0, count); position += count
                }
                assertEquals(entry.sha256, hex(digest.digest()))
                assertEquals(-1, array.readAt(entry.id, entry.sizeBytes, bytes, 0, 1))
            } finally { bytes.fill(0) }
        }
    }

    private fun withFixture(name: String, action: (File) -> Unit) {
        val file = File.createTempFile("share-interop-encrypted-", ".dshare", context.cacheDir)
        try {
            assets.open("interop/$name").use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            action(file)
        } finally { file.delete() }
    }
    private fun File.sha256(): String = inputStream().use { input ->
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = ByteArray(64 * 1024)
        while (true) { val count = input.read(bytes); if (count < 0) break; digest.update(bytes, 0, count) }
        hex(digest.digest())
    }
    private fun privateFiles(): Set<String> = listOf(context.filesDir, context.cacheDir).flatMap { root ->
        root.walkTopDown().filter { it.isFile }.map { "${root.name}/${it.relativeTo(root).path}" }.toList()
    }.toSet()
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
}
