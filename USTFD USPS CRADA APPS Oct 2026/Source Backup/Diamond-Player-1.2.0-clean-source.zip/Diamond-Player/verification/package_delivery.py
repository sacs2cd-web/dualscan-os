"""Package already-built Diamond™ Player artifacts. Never builds, signs or runs UI.

Usage (after root-owned final build):
  python3 verification/package_delivery.py --build-log verification/build-delivery.txt
  Add --android-record verification/android-final.txt only after actual tests pass.

Requires SDK 36 build tools. Source ZIP is an explicit allowlist; runtime outputs,
local SDK configuration, caches, private keys and unrelated projects are omitted.
Public synthetic Android test fixtures and their generators are included.
"""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*arguments, allow_failure=False):
    result = subprocess.run([str(arg) for arg in arguments], capture_output=True, text=True)
    if not allow_failure:
        result.check_returncode()
    return result


def suite_summary(folder, minimum):
    suites = []
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    for file in sorted(folder.glob("TEST-*.xml")):
        root = ET.parse(file).getroot()
        counts = {key: int(root.attrib[key]) for key in totals}
        suites.append({"suite": root.attrib["name"], **counts})
        for key in totals:
            totals[key] += counts[key]
    assert totals["tests"] >= minimum, (folder, totals)
    assert totals["failures"] == totals["errors"] == totals["skipped"] == 0, (folder, totals)
    return {"totals": totals, "suites": suites}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-log", required=True, help="Successful current final build record, relative to project")
    parser.add_argument("--android-record", help="Actual successful Android instrumentation text record, relative to project")
    parser.add_argument("--ecosystem-key-file", default=os.environ.get("DUALSCAN_ECOSYSTEM_KEY_FILE") or
                        str(Path.home() / ".local/share/dualscan-research/keys/ecosystem-v1.key"),
                        help="External build key, audited for exclusion; never copied into the source delivery")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    dist = project / "dist-diamond-1.2.0"
    dist.mkdir(exist_ok=True)
    sdk = Path(os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or Path.home() / "Library/Android/sdk")
    tools = sdk / "build-tools/36.0.0"
    aapt, apksigner = tools / "aapt", tools / "apksigner"
    build_log = project / args.build_log
    assert "BUILD SUCCESSFUL" in build_log.read_text(), "Final build did not succeed"
    jvm = {"app": suite_summary(project / "app/build/test-results/testDebugUnitTest", 44),
           "interchangeCore": suite_summary(project / "interchange-core/build/test-results/testDebugUnitTest", 15),
           "tellaKeys": suite_summary(project / "tella-keys-core/build/test-results/test", 7)}
    lint = {}
    for variant in ("debug", "release"):
        path = project / f"app/build/reports/lint-results-{variant}.xml"
        if not path.is_file():
            lint[variant] = {"status": "NOT_RECORDED"}
            continue
        issues = ET.parse(path).getroot().findall("issue")
        severities = collections.Counter(issue.attrib["severity"] for issue in issues)
        assert not (severities["Error"] or severities["Fatal"]), (variant, severities)
        lint[variant] = {"status": "PASS", "severityCounts": dict(severities),
                         "warningIds": dict(collections.Counter(issue.attrib["id"] for issue in issues))}

    provenance_file = project / "third_party/tella/upstream-files.json"
    provenance = json.loads(provenance_file.read_text())
    for entry in provenance["files"]:
        upstream = project / "third_party/tella/upstream" / entry["path"]
        assert len(upstream.read_bytes()) == entry["bytes"] and sha(upstream.read_bytes()) == entry["sha256"], upstream
    for asset, notice in (("TELLA-LICENSE", "LICENSE"), ("TELLA-NOTICE.txt", "NOTICE.txt")):
        assert (project / "app/src/main/assets/legal" / asset).read_bytes() == (project / "third_party/tella" / notice).read_bytes()

    fixed = [".gitignore", "README.txt", "build.gradle.kts", "settings.gradle.kts", "gradle.properties",
             "gradlew", "gradlew.bat", "app/build.gradle.kts", "app/proguard-rules.pro", "tella-keys-core/build.gradle.kts",
             "interchange-core/build.gradle.kts", "interchange-core/FORMAT.md"]
    allowed = {Path(name) for name in fixed}
    for root in ("app/src", "interchange-core/src", "tella-keys-core/src", "gradle", "docs", "third_party/tella"):
        allowed.update(path.relative_to(project) for path in (project / root).rglob("*") if path.is_file())
    allowed.update(path.relative_to(project) for path in (project / "verification").rglob("*")
                   if path.is_file() and path.suffix in (".py", ".mjs", ".js", ".sh"))
    for relative in allowed:
        assert not (project / relative).is_symlink(), relative
        assert not any(part in ("build", ".gradle", ".kotlin", ".git", "node_modules", "__pycache__") for part in relative.parts), relative
        assert relative.name not in ("local.properties", "EcosystemBuildKey.kt", "EcosystemBuildKey.java"), relative
        assert relative.suffix.lower() not in (".apk", ".key", ".jks", ".keystore", ".pem", ".p12", ".pfx"), relative
        if relative.suffix.lower() in (".dmpa", ".dshare"):
            assert str(relative).startswith("app/src/androidTest/"), f"Collection fixture outside Android test source: {relative}"
    source = {str(path): (project / path).read_bytes() for path in sorted(allowed)}
    # Read the external key only to compare its safe identifier and reject accidental
    # raw-key inclusions. Never print the key, package it, or inspect build/generated.
    ecosystem_key = bytearray(Path(args.ecosystem_key_file).expanduser().read_bytes())
    try:
        assert len(ecosystem_key) == 32, "External ecosystem build key must contain 32 bytes"
        ecosystem_key_id = sha(ecosystem_key)[:32]
        for name, data in source.items():
            assert ecosystem_key not in data, f"Raw ecosystem key material included in source: {name}"
    finally:
        ecosystem_key[:] = b"\x00" * len(ecosystem_key)
    production = [project / path for path in allowed if str(path).startswith(("app/src/main/", "interchange-core/src/main/", "tella-keys-core/src/main/")) or
                  str(path) in ("app/build.gradle.kts", "interchange-core/build.gradle.kts", "tella-keys-core/build.gradle.kts", "build.gradle.kts", "settings.gradle.kts", "gradle.properties", "gradle/libs.versions.toml")]
    newest_production = max(path.stat().st_mtime_ns for path in production)
    assert not (project / "app/src/main/assets/demo").exists(), "Remove the shipping demo asset directory"
    assert not any(path.suffix.lower() in (".dmpa", ".dshare") for path in (project / "app/src/main").rglob("*")), "Do not bundle media collections or Share images in the app"
    for path in production:
        if path.suffix in (".kt", ".java", ".xml"):
            content = path.read_text()
            assert "Diamond demo 2026" not in content, f"Public demo password remains in production: {path}"
            assert not re.search(r"\bloadDemo\b", content), f"Demo loader remains in production: {path}"

    artifacts = []
    for variant, output_name in (("debug", "Diamond-Player-1.2.0-dev.apk"),
                                  ("release", "Diamond-Player-1.2.0-unsigned-release.apk")):
        original = project / f"app/build/outputs/apk/{variant}/app-{variant}{'-unsigned' if variant == 'release' else ''}.apk"
        assert original.stat().st_mtime_ns >= newest_production, f"Rebuild stale {original}"
        destination = dist / output_name
        shutil.copy2(original, destination)
        badging = run(aapt, "dump", "badging", destination).stdout
        manifest = run(aapt, "dump", "xmltree", destination, "AndroidManifest.xml").stdout
        permissions = re.findall(r"^uses-permission: name='([^']+)'", badging, re.MULTILINE)
        assert "package: name='com.dualscan.mp' versionCode='5' versionName='1.2.0'" in badging
        assert "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging
        assert "android.permission.INTERNET" not in permissions
        assert re.search(r"android:allowBackup.*=\(type 0x12\)0x0", manifest)
        with zipfile.ZipFile(destination) as apk:
            assert not any(name == "assets/demo" or name.startswith("assets/demo/") or
                           name.lower().endswith((".dmpa", ".dshare")) for name in apk.namelist()), "Shipping APK contains collection/image fixtures"
        signature = run(apksigner, "verify", "--print-certs", destination, allow_failure=True)
        if variant == "debug":
            assert signature.returncode == 0
            cert = re.search(r"certificate SHA-256 digest: ([0-9a-f]{64})", signature.stdout).group(1)
        else:
            assert signature.returncode != 0 and "Signer #" not in signature.stdout
            with zipfile.ZipFile(destination) as apk:
                assert not any(re.match(r"META-INF/.*\.(RSA|DSA|EC)$", name) for name in apk.namelist())
            cert = None
        artifacts.append({"file": output_name, "bytes": destination.stat().st_size,
                          "sha256": sha(destination.read_bytes()), "applicationId": "com.dualscan.mp",
                          "minSdk": 26, "targetSdk": 36, "permissions": permissions, "allowBackup": False,
                          "signature": "verified-development-signature" if variant == "debug" else "unsigned-requires-ODM-signing",
                          "signerCertificateSha256": cert, "installableAsDelivered": variant == "debug"})

    manifest_bytes = (json.dumps({"schemaVersion": 1, "files": [
        {"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in sorted(source.items())
    ]}, indent=2) + "\n").encode()
    source_zip = dist / "Diamond-Player-1.2.0-clean-source.zip"
    with zipfile.ZipFile(source_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in sorted({**source, "SOURCE-MANIFEST.json": manifest_bytes}.items()):
            entry = zipfile.ZipInfo("Diamond-Player/" + name, date_time=(2026, 10, 16, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = (0o100755 if name in ("gradlew", "gradlew.bat") else 0o100644) << 16
            bundle.writestr(entry, data)
    with zipfile.ZipFile(source_zip) as bundle:
        assert bundle.testzip() is None and len(bundle.namelist()) == len(source) + 1
        assert not any(Path(name).name in ("EcosystemBuildKey.kt", "EcosystemBuildKey.java") or Path(name).suffix.lower() == ".key" or
                       any(part in ("build", "generated", ".gradle") for part in Path(name).parts)
                       for name in bundle.namelist()), "Source ZIP includes private or generated key material"
        for name, data in source.items():
            assert sha(bundle.read("Diamond-Player/" + name)) == sha(data), name
        assert sha(bundle.read("Diamond-Player/SOURCE-MANIFEST.json")) == sha(manifest_bytes)
    for name, data in source.items():
        assert (project / name).read_bytes() == data, f"Source changed during packaging: {name}"
    artifacts.append({"file": source_zip.name, "bytes": source_zip.stat().st_size,
                      "sha256": sha(source_zip.read_bytes()), "sourceFiles": len(source),
                      "sourceManifestSha256": sha(manifest_bytes), "zipCrcAndPerFileSha256": "PASS",
                      "allowlist": ["app/src (including synthetic Android test fixtures only)",
                                    "interchange-core/build.gradle.kts, FORMAT.md and src only", "tella-keys-core/src",
                                    "gradle", "docs", "third_party/tella MIT sources/licenses/provenance",
                                    "explicit build configuration", "README.txt", "verification generator/reproducer scripts"],
                      "privateEcosystemKeyExcluded": True, "generatedKeySourceExcluded": True,
                      "excludes": ["local.properties", "caches", "build/generated key source", "build outputs",
                                   "external raw ecosystem key", "private signing keys", "unrelated reference APKs/evidence", "runtime logs"]})

    android = {"status": "PENDING actual Android instrumentation; no Share/Diamond result is borrowed"}
    if args.android_record:
        record = project / args.android_record
        match = re.search(r"OK \((\d+) tests?\)", record.read_text())
        assert match and int(match.group(1)) > 0, "Android record does not show a successful run"
        android = {"status": "PASS", "tests": int(match.group(1)), "record": args.android_record,
                   "recordSha256": sha(record.read_bytes()),
                   "scope": "Only tests in the supplied actual Android run; does not qualify physical USB/DAC output"}
    report = {
        "schemaVersion": 1, "preparedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "releaseStatus": "OEM/ODM engineering candidate; NOT Golden Master approved or certified",
        "build": {"status": "PASS", "record": args.build_log, "recordSha256": sha(build_log.read_bytes())},
        "jvmTests": jvm, "lint": lint, "androidRuntimeEvidence": android,
        "startup": {"bundledDemoMedia": False, "productionDemoLoader": False,
                    "initialLibrary": "empty; collection opening and media selection are user-initiated",
                    "shippingApkDemoAssetCheck": "PASS"},
        "format": {"extensions": [".dmpa", ".dshare"], "newWriterMagic": "DSMP0002",
                   "readFormats": ["DSMP0001 password-based media collections", "DSMP0002 shared portable images/collections"],
                   "newIndependentFormat": True, "legacyTellaCompatible": False,
                   "dualscanShareDshareCompatible": "New DSMP0002 Share exports only; legacy DSHP0001 requires re-export with updated Share",
                   "defaultMode": "Always encrypted, shared ecosystem key, opens without password",
                   "optionalPasswordMode": "Shared ecosystem key plus user password; no global fallback for a protected image",
                   "playbackSelection": "Only audio/video/images enter Player queues; documents and OEM payloads remain in the encrypted container",
                   "independentCryptoAudit": "UNVERIFIED", "drmClaim": False},
        "ecosystemKey": {"publicKeyId": ecosystem_key_id, "privateKeyInSourceZip": False,
                         "generatedKeySourceInSourceZip": False,
                         "rebuild": "Requires the separately retained external 32-byte ecosystem key; both apps must use the same key",
                         "securityBoundary": "Global key material is recoverable from apps that decrypt offline; global mode does not provide private user access control or device-bound DRM"},
        "audio": {"ordinaryInstallMinSdk": 26, "nativePcmMinSdk": 34,
                  "exactUsbBitPerfect": "Conditional on supported USB device, accepted mixer attributes, actual route and PCM format checks; physical output UNVERIFIED",
                  "headphoneSpeakerBluetooth": "Ordinary actual Android routing; no universal bit-perfect claim"},
        "tella": {"license": "MIT", "copyright": "2025 Horizontal", "repository": provenance["repository"],
                  "commit": provenance["commit"], "provenanceAndUpstreamHashes": "PASS",
                  "packagedLicenseNoticesMatch": True,
                  "compiledScope": "Adapted MainKey/Wiper only; legacy CTR not compiled"},
        "unverified": ["physical USB-C/OTG storage and filesystem/power-loss qualification",
                       "physical USB DAC/headphone digital bit identity",
                       "OEM preload/release signing and actual ODM hardware",
                       "independent cryptographic/application-security audit"],
        "boundaries": ["No INTERNET, cloud or general network sharing; external removable transfer is USB-gated",
                       "Local phone collection/image copies remain unchanged encrypted .dmpa/.dshare containers",
                       "Public APIs cannot reliably prove removable volume USB-vs-SD association or USB-C connector type",
                       "OEM installation/signing does not implement full OS image capture or OTA flashing"],
        "artifacts": artifacts
    }
    report_text = json.dumps(report, indent=2) + "\n"
    (project / "verification/delivery-verification.json").write_text(report_text)
    (dist / "DELIVERY-VERIFICATION.json").write_text(report_text)
    (dist / "READ-ME-FIRST.txt").write_text(
        "Diamond™ Player 1.2.0 — development/OEM engineering candidate\n\n"
        "Install Diamond-Player-1.2.0-dev.apk on standard Android 8+ to preview/use.\n"
        "Starts with an empty library. Tap Open collection or Add media to begin.\n"
        "No demo collection or automatic storage picker is bundled or launched.\n"
        "The unsigned release APK requires controlled ODM signing before install.\n"
        "New .dmpa collections and Share .dshare images use encrypted DSMP0002.\n"
        "Default images open directly. Only protected images request a password.\n"
        "Original password-based DSMP0001 Player collections remain readable.\n"
        "Old DSHP0001 Share images need a new export from the updated Share app.\n"
        "Documents and firmware in a Share image are not Player playback items.\n"
        "USB/removable transfers and local phone copies keep ciphertext. No Internet.\n"
        "Native exact USB audio requires API34+ and a supported actual device/route.\n"
        "No physical USB/DAC, OEM hardware or independent security audit is claimed.\n"
        "No DRM or full OS-image feature is implied. NOT a certified Golden Master.\n\n"
        "See DELIVERY-VERIFICATION.json for actual tests versus pending checks.\n"
        "Clean source contains MIT Tella license/notices, provenance and test fixtures.\n"
        "The external ecosystem key and generated key source are deliberately omitted.\n"
        "Keep the existing key backed up separately; use it when rebuilding BOTH apps.\n"
        "A different key cannot open earlier default images. See interchange-core/FORMAT.md.\n"
        "The global key is recoverable from offline apps; use an optional password\n"
        "for private access. Global encryption is not device-bound DRM.\n"
        "SOURCE-MANIFEST.json records source hashes; SHA256SUMS.txt covers delivery.\n"
    )
    sums = [f"{sha(file.read_bytes())}  {file.name}" for file in sorted(dist.iterdir())
            if file.is_file() and file.name != "SHA256SUMS.txt"]
    (dist / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n")
    print(json.dumps({"dist": str(dist), "jvmTests": {key: value["totals"] for key, value in jvm.items()},
                      "android": android, "artifacts": artifacts}, indent=2))


if __name__ == "__main__":
    main()
