# Engine integration and encrypted playback

`tella-keys-core` is a dependency-free Java 17 library. Add it as an implementation
dependency to the portable media module. Its package is deliberately retained
from Tella so the reused source remains identifiable.

```java
try (MainKey mainKey = MainKey.generate()) {
    SecretKeySpec ephemeral = mainKey.getKey();
    // Initialize AES-GCM for the authenticated portable container.
}
```

`MainKey(byte[])` defensively copies an existing AES key; `getKey()` returns an
independent AES provider key, or null after `wipe()`/`close()`. `setKey(null)`
also clears ownership. `Wiper.wipe(byte[])` and `Wiper.wipe(char[])` clear
caller-owned arrays. This is best-effort memory hygiene, not a guarantee that the
JVM, media decoder, display, audio hardware, swap, or provider holds no copies.

The new portable reader must authenticate each whole chunk before returning any
plaintext from it. Media3's `DataSource` uses byte offsets, and Android's
`MediaDataSource` uses `readAt(position, ...)`; both can seek directly through the
same authenticated reader without writing a decrypted media file. A source
provider that cannot seek must be copied as ciphertext into private storage
before opening, or rejected. Never silently spool plaintext to work around SAF.

Encryption preserves source media bytes but does not make an Android audio
output bit-perfect. The independent Diamond AudioTrack engine must still verify
the source PCM, supported rate/encoding/channel layout, selected route, and USB
bit-perfect mixer. Android 14+ USB support is conditional on device capability;
ordinary playback on other supported Android versions must remain honestly
labeled. Video/photos should decrypt bounded data directly to their codecs/UI.

Users must intentionally select and authorize USB and public-folder documents.
Ciphertext can be copied unchanged between USB-C and local Music, Movies,
Pictures, Documents or other granted folders. DSMP0002 default mode uses the
shared offline ecosystem key compiled into both apps; an optional user password
adds an independent secret and must be kept separately. The build key is supplied
externally and retained separately from source deliveries; see
../interchange-core/FORMAT.md. A key embedded for offline decryption is recoverable
from a compatible app/device, so global mode is not private user access control
or device-bound DRM. Decrypted playback cannot promise
protection from a compromised/rooted device or external recording.

No network permission, URI launching, cloud/provider credential collection,
plaintext export endpoint, or external decryption intent is needed for this
pipeline. User-facing controls stay limited to Add, Open, Copy, Play,
and Dark/Light. Cryptographic and implementation details belong in these build
documents and third-party notices.

Primary sources checked 2026-10-16:

- <https://f-droid.org/en/packages/org.hzontal.tellaFOSS/>
- <https://github.com/Horizontal-org/Tella-Android>
- <https://github.com/Horizontal-org/Tella-Android/blob/b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc/tella-vault/src/main/java/com/hzontal/tella_vault/CipherStreamUtils.java>
- <https://github.com/Horizontal-org/Tella-Android/blob/b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc/LICENSE>
