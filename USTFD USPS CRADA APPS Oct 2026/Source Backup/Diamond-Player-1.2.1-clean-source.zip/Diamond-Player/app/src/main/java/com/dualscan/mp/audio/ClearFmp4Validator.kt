package com.dualscan.mp.audio

import java.io.File
import java.io.RandomAccessFile

/** A deliberately narrow, independently checked clear FLAC/fMP4 handoff contract. */
data class ValidatedClearFmp4(val sampleRateHz: Int, val channels: Int, val bitDepth: Int,
    val durationUs: Long, val fragmentCount: Int, val byteCount: Long)

/**
 * Validates the saved bytes, not the WebView's claims. Only one unencrypted fLaC audio
 * track, one contiguous zero-based timeline and self-contained moof/mdat pairs qualify.
 * Unknown boxes, encrypted sample descriptions/auxiliary data, edits, missing samples,
 * nonzero composition offsets and absolute data offsets are rejected. This is intentionally
 * stricter than a general MP4 player. No decryption or browser PCM capture occurs here.
 */
fun validateClearFlacFmp4(file: File): ValidatedClearFmp4 = RandomAccessFile(file, "r").use { input ->
    ClearFmp4Parser(input).validate()
}

private data class Mp4Box(val type: String, val start: Long, val body: Long, val end: Long) {
    val bodySize: Long get() = end - body
}

private class ClearFmp4Parser(private val input: RandomAccessFile) {
    private var trackId = 0L
    private var timescale = 0L
    private var rate = 0
    private var channels = 0
    private var bits = 0
    private var defaultDuration = 0L
    private var defaultSize = 0L
    private var decodeEnd = 0L
    private var fragmentCount = 0
    private var previousSequence: Long? = null
    private var visitedBoxes = 0

    fun validate(): ValidatedClearFmp4 {
        require(input.length() in 1..256L * 1024 * 1024) { "The captured file exceeds the native validation limit." }
        val top = boxes(0, input.length())
        require(top.size >= 4 && top[0].type == "ftyp" && top[1].type == "moov") { "A fresh complete fMP4 initialization segment is required." }
        parseInit(top[1])
        var index = 2
        while (index < top.size) {
            val moof = top[index++]
            require(moof.type == "moof" && index < top.size) { "Only ordered complete movie-fragment/data pairs are supported." }
            val mdat = top[index++]
            require(mdat.type == "mdat") { "A movie fragment must be followed immediately by its complete sample data." }
            parseFragment(moof, mdat)
        }
        require(fragmentCount > 0 && decodeEnd > 0 && timescale > 0) { "The captured audio timeline is empty." }
        val duration = decodeEnd / timescale * 1_000_000 + decodeEnd % timescale * 1_000_000 / timescale
        return ValidatedClearFmp4(rate, channels, bits, duration, fragmentCount, input.length())
    }

    private fun parseInit(moov: Mp4Box) {
        val children = boxes(moov.body, moov.end)
        allowed(children, setOf("mvhd", "trak", "mvex"))
        val tracks = children.filter { it.type == "trak" }
        require(tracks.size == 1) { "Native capture requires exactly one audio track." }
        val track = boxes(tracks[0].body, tracks[0].end)
        allowed(track, setOf("tkhd", "mdia"))
        val tkhd = only(track, "tkhd")
        val trackVersion = u8(tkhd.body)
        require(trackVersion in 0..1) { "Unknown track header version." }
        trackId = u32(tkhd.body + if (trackVersion == 1) 20 else 12, tkhd.end)
        require(trackId > 0) { "Invalid audio track identifier." }
        val mdiaBox = only(track, "mdia")
        val mdia = boxes(mdiaBox.body, mdiaBox.end)
        allowed(mdia, setOf("mdhd", "hdlr", "minf"))
        val mdhd = only(mdia, "mdhd")
        val mediaVersion = u8(mdhd.body)
        require(mediaVersion in 0..1) { "Unknown media header version." }
        timescale = u32(mdhd.body + if (mediaVersion == 1) 20 else 12, mdhd.end)
        require(timescale > 0 && fourCc(only(mdia, "hdlr").body + 8) == "soun") { "The captured track is not a timed audio track." }
        val minf = only(mdia, "minf").let { boxes(it.body, it.end) }
        allowed(minf, setOf("smhd", "dinf", "stbl"))
        val dinf = only(minf, "dinf").let { boxes(it.body, it.end) }
        allowed(dinf, setOf("dref"))
        val dref = only(dinf, "dref")
        require(u32(dref.body + 4, dref.end) == 1L) { "External media references are unsupported." }
        val refs = boxes(dref.body + 8, dref.end)
        require(refs.size == 1 && refs[0].type == "url " && refs[0].bodySize == 4L && u32(refs[0].body, refs[0].end) == 1L) {
            "The audio data must be self-contained."
        }
        val stbl = only(minf, "stbl").let { boxes(it.body, it.end) }
        allowed(stbl, setOf("stsd", "stts", "stsc", "stsz", "stco", "co64"))
        stbl.filter { it.type in setOf("stts", "stsc", "stco", "co64") }.forEach {
            require(u32(it.body + 4, it.end) == 0L) { "Only fragmented audio sample tables are supported." }
        }
        stbl.firstOrNull { it.type == "stsz" }?.let {
            require(u32(it.body + 8, it.end) == 0L) { "Initialization data already contains audio samples." }
        }
        val stsd = only(stbl, "stsd")
        require(u32(stsd.body + 4, stsd.end) == 1L) { "Multiple audio descriptions are unsupported." }
        val entries = boxes(stsd.body + 8, stsd.end)
        require(entries.size == 1 && entries[0].type == "fLaC") { "Only an explicitly clear FLAC audio sample entry is accepted." }
        val entry = entries[0]
        require(entry.bodySize >= 28 && u16(entry.body + 6, entry.end) == 1 && u16(entry.body + 8, entry.end) == 0) {
            "Unsupported FLAC audio sample entry."
        }
        val entryChannels = u16(entry.body + 16, entry.end)
        val entryRate = (u32(entry.body + 24, entry.end) ushr 16).toInt()
        val extensions = boxes(entry.body + 28, entry.end)
        allowed(extensions, setOf("dfLa", "btrt"))
        val dfla = only(extensions, "dfLa")
        require(dfla.bodySize >= 42 && u32(dfla.body, dfla.end) == 0L) { "Invalid FLAC stream metadata." }
        // dfLa FullBox is followed by ordinary FLAC metadata blocks, without the fLaC marker.
        val metadata = ByteArray(42)
        "fLaC".toByteArray(Charsets.US_ASCII).copyInto(metadata)
        input.seek(dfla.body + 4)
        input.readFully(metadata, 4, 38)
        val flac = parseFlacStreamInfo(metadata) ?: error("The FLAC STREAMINFO block is invalid.")
        rate = flac.rate
        channels = flac.channels
        bits = flac.bits
        require(entryChannels == channels && entryRate == rate) { "FLAC metadata disagrees with the audio sample entry." }
        val mvex = only(children, "mvex").let { boxes(it.body, it.end) }
        allowed(mvex, setOf("trex", "mehd"))
        val trex = only(mvex, "trex")
        require(trex.bodySize == 24L && u32(trex.body + 4, trex.end) == trackId && u32(trex.body + 8, trex.end) == 1L) {
            "Invalid default fragment description."
        }
        defaultDuration = u32(trex.body + 12, trex.end)
        defaultSize = u32(trex.body + 16, trex.end)
    }

    private fun parseFragment(moof: Mp4Box, mdat: Mp4Box) {
        val children = boxes(moof.body, moof.end)
        allowed(children, setOf("mfhd", "traf"))
        val mfhd = only(children, "mfhd")
        require(mfhd.bodySize == 8L && u32(mfhd.body, mfhd.end) == 0L) { "Invalid fragment header." }
        val sequence = u32(mfhd.body + 4, mfhd.end)
        require(previousSequence == null || sequence == previousSequence!! + 1) { "Fragment sequence is discontinuous." }
        previousSequence = sequence
        val traf = only(children, "traf").let { boxes(it.body, it.end) }
        allowed(traf, setOf("tfhd", "tfdt", "trun"))
        val tfhd = only(traf, "tfhd")
        val headerFlags = u32(tfhd.body, tfhd.end)
        require(headerFlags and 0xff000000L == 0L && headerFlags and 0x020000L != 0L && headerFlags and 0x010001L == 0L &&
            headerFlags and (0x02003aL).inv() == 0L && u32(tfhd.body + 4, tfhd.end) == trackId) {
            "Only clear self-relative audio fragments are supported."
        }
        var cursor = tfhd.body + 8
        if (headerFlags and 2L != 0L) { require(u32(cursor, tfhd.end) == 1L); cursor += 4 }
        val duration = if (headerFlags and 8L != 0L) u32(cursor, tfhd.end).also { cursor += 4 } else defaultDuration
        val size = if (headerFlags and 16L != 0L) u32(cursor, tfhd.end).also { cursor += 4 } else defaultSize
        if (headerFlags and 32L != 0L) cursor += 4
        require(cursor == tfhd.end) { "Invalid audio fragment defaults." }
        val tfdt = only(traf, "tfdt")
        val version = u8(tfdt.body)
        require(version in 0..1 && u32(tfdt.body, tfdt.end) and 0xffffffL == 0L) { "Invalid fragment timeline." }
        val start = if (version == 1) u64(tfdt.body + 4, tfdt.end) else u32(tfdt.body + 4, tfdt.end)
        require(tfdt.bodySize == (if (version == 1) 12L else 8L) && start == decodeEnd) { "The captured timeline has a gap, overlap, seek or nonzero starting point." }
        val trun = only(traf, "trun")
        val flags = u32(trun.body, trun.end)
        require(flags ushr 24 in 0L..1L && flags and 1L != 0L && flags and 0xffffffL and 0x000f05L.inv() == 0L) { "Unsupported sample run layout." }
        val samples = u32(trun.body + 4, trun.end)
        require(samples in 1..1_000_000) { "Invalid fragment sample count." }
        cursor = trun.body + 8
        val offset = signed32(cursor, trun.end); cursor += 4
        require(offset >= 0 && moof.start + offset == mdat.body) { "Fragment data offsets do not match the saved sample data." }
        if (flags and 4L != 0L) cursor += 4
        var sampleBytes = 0L
        var sampleDuration = 0L
        repeat(samples.toInt()) {
            val itemDuration = if (flags and 0x100L != 0L) u32(cursor, trun.end).also { cursor += 4 } else duration
            val itemSize = if (flags and 0x200L != 0L) u32(cursor, trun.end).also { cursor += 4 } else size
            if (flags and 0x400L != 0L) cursor += 4
            if (flags and 0x800L != 0L) { require(u32(cursor, trun.end) == 0L) { "Audio composition offsets are unsupported." }; cursor += 4 }
            require(itemDuration > 0 && itemSize > 0) { "Empty or unknown fragment samples are unsupported." }
            sampleBytes += itemSize
            sampleDuration += itemDuration
        }
        require(cursor == trun.end && sampleBytes == mdat.bodySize) { "Fragment sample data is incomplete or has extra bytes." }
        require(sampleDuration <= Long.MAX_VALUE - decodeEnd) { "The captured timeline overflows." }
        decodeEnd += sampleDuration
        fragmentCount++
    }

    private fun boxes(start: Long, end: Long): List<Mp4Box> {
        val result = mutableListOf<Mp4Box>()
        var offset = start
        while (offset < end) {
            require(++visitedBoxes < 100_000 && end - offset >= 8) { "Invalid or excessive MP4 box layout." }
            val size32 = u32(offset, end)
            val type = fourCc(offset + 4)
            val header = if (size32 == 1L) 16L else 8L
            val size = if (size32 == 1L) u64(offset + 8, end) else size32
            require(size >= header && size <= end - offset) { "An MP4 box is truncated or has an unbounded size." }
            result.add(Mp4Box(type, offset, offset + header, offset + size))
            offset += size
        }
        return result
    }

    private fun allowed(boxes: List<Mp4Box>, allowed: Set<String>) {
        require(boxes.all { it.type in allowed }) { "Unknown, edited or protected MP4 structures cannot enter the native capture path." }
    }
    private fun only(boxes: List<Mp4Box>, type: String): Mp4Box = boxes.filter { it.type == type }.let {
        require(it.size == 1) { "Missing or duplicate $type audio structure." }; it[0]
    }
    private fun u8(offset: Long): Int { input.seek(offset); return input.readUnsignedByte() }
    private fun u16(offset: Long, end: Long): Int { require(offset >= 0 && end - offset >= 2); input.seek(offset); return input.readUnsignedShort() }
    private fun u32(offset: Long, end: Long): Long { require(offset >= 0 && end - offset >= 4); input.seek(offset); return input.readInt().toLong() and 0xffffffffL }
    private fun signed32(offset: Long, end: Long): Int = u32(offset, end).toInt()
    private fun u64(offset: Long, end: Long): Long { require(offset >= 0 && end - offset >= 8); input.seek(offset); return input.readLong().also { require(it >= 0) { "MP4 offsets exceed the native validation range." } } }
    private fun fourCc(offset: Long): String { val value = ByteArray(4); input.seek(offset); input.readFully(value); return String(value, Charsets.US_ASCII) }
}
