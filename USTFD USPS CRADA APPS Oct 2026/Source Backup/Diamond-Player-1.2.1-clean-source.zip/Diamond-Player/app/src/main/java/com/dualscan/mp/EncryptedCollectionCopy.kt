package com.dualscan.mp

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/** Copies the opaque encrypted container. Entry readers/decoders are never accepted here. */
object EncryptedCollectionCopy {
    data class Receipt(val sizeBytes: Long, val sha256: ByteArray)

    fun copy(source: InputStream, destination: OutputStream, checkCancelled: () -> Unit = {}): Receipt {
        val signature = ByteArray(8)
        var offset = 0
        while (offset < signature.size) {
            checkCancelled()
            val count = source.read(signature, offset, signature.size - offset)
            if (count < 0) throw IOException("Choose a complete encrypted collection.")
            if (count == 0) {
                val one = source.read()
                if (one < 0) throw IOException("Choose a complete encrypted collection.")
                signature[offset++] = one.toByte()
            } else offset += count
        }
        if (signature.toString(Charsets.US_ASCII) !in setOf("DSMP0001", "DSMP0002"))
            throw IOException("Only encrypted collections can be saved.")
        val digest = MessageDigest.getInstance("SHA-256")
        destination.write(signature); digest.update(signature)
        var total = signature.size.toLong()
        val buffer = ByteArray(128 * 1024)
        try {
            while (true) {
                checkCancelled()
                val count = source.read(buffer)
                if (count < 0) break
                if (count == 0) {
                    val one = source.read()
                    if (one < 0) break
                    destination.write(one); digest.update(one.toByte()); total++
                } else {
                    destination.write(buffer, 0, count); digest.update(buffer, 0, count); total += count
                }
            }
            return Receipt(total, digest.digest())
        } finally { buffer.fill(0); signature.fill(0) }
    }

    fun verify(source: InputStream, expected: Receipt, checkCancelled: () -> Unit = {}) {
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val buffer = ByteArray(128 * 1024)
        try {
            while (true) {
                checkCancelled()
                val count = source.read(buffer)
                if (count < 0) break
                if (count == 0) {
                    val one = source.read()
                    if (one < 0) break
                    digest.update(one.toByte()); total++
                } else { digest.update(buffer, 0, count); total += count }
            }
            if (total != expected.sizeBytes || !MessageDigest.isEqual(expected.sha256, digest.digest()))
                throw IOException("The saved collection did not pass verification.")
        } finally { buffer.fill(0) }
    }
}
