@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.exoplayer.ExoPlayer
import java.lang.ref.WeakReference

/** Foreground playback controls for Media3 audio/video; decrypted bytes stay inside the player. */
class Media3PlaybackService : Service() {
    private var session: MediaSession? = null
    private val main = Handler(Looper.getMainLooper())
    private val pulse = object : Runnable { override fun run() { update(); main.postDelayed(this, 1000) } }
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Media playback", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "Diamond™ Player").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { currentPlayer.get()?.play(); update() }
                override fun onPause() { currentPlayer.get()?.pause(); update() }
                override fun onStop() { currentPlayer.get()?.stop(); stopSelf() }
                override fun onSeekTo(pos: Long) { currentPlayer.get()?.seekTo(pos); update() }
            })
            isActive = true
        }
        startForeground(ID, notification())
        main.post(pulse)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) { "pause" -> currentPlayer.get()?.pause(); "play" -> currentPlayer.get()?.play(); "stop" -> { currentPlayer.get()?.stop(); stopSelf() } }
        update()
        return START_NOT_STICKY
    }
    private fun update() {
        val player = currentPlayer.get() ?: run { stopSelf(); return }
        session?.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, currentTitle).putLong(MediaMetadata.METADATA_KEY_DURATION, player.duration.coerceAtLeast(0)).build())
        session?.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP)
            .setState(if (player.isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, player.currentPosition.coerceAtLeast(0), if (player.isPlaying) 1f else 0f).build())
        getSystemService(NotificationManager::class.java).notify(ID, notification())
    }
    private fun notification(): Notification {
        val player = currentPlayer.get(); val playing = player?.playWhenReady == true
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val action = if (playing) "pause" else "play"
        val transport = PendingIntent.getService(this, 1, Intent(this, Media3PlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, Media3PlaybackService::class.java).setAction("stop"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_transfer_notification).setContentTitle(currentTitle.ifBlank { "Diamond™ Player" }).setContentText("Diamond™ Player")
            .setContentIntent(open).setOngoing(playing).setVisibility(Notification.VISIBILITY_PRIVATE)
            .addAction(Notification.Action.Builder(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, if (playing) "Pause" else "Play", transport).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build())
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1)).build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { main.removeCallbacksAndMessages(null); session?.release(); session = null; super.onDestroy() }
    companion object {
        private const val CHANNEL = "dualscan_mp_playback"
        private const val ID = 202
        private var currentPlayer = WeakReference<ExoPlayer>(null)
        private var currentTitle = ""
        fun begin(context: Context, player: ExoPlayer, title: String) { currentPlayer = WeakReference(player); currentTitle = title; ContextCompat.startForegroundService(context, Intent(context, Media3PlaybackService::class.java)) }
        fun end(context: Context) { context.stopService(Intent(context, Media3PlaybackService::class.java)); currentPlayer.clear(); currentTitle = "" }
    }
}
