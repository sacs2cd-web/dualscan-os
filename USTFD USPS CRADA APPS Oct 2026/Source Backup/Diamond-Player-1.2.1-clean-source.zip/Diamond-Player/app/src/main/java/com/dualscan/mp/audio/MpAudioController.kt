package com.dualscan.mp.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.dualscan.mp.core.MediaEntry
import com.dualscan.mp.core.UnlockedMediaArray
import com.dualscan.mp.ReadableMediaLibrary
import com.dualscan.mp.SingleMediaLibrary

data class MpAudioDevice(val id:Int,val name:String)
data class MpAudioState(
    val playing:Boolean=false,val positionMs:Long=0,val durationMs:Long=0,val strict:Boolean=false,
    val strictActive:Boolean=false,val error:String?=null,val devices:List<MpAudioDevice> = emptyList(),
    val selectedDeviceId:Int?=null,val output:String="Android",val loading:Boolean=false,
    val queueIndex:Int=-1,
    val sourceBitDepth:Int?=null,val sourceSampleRateHz:Int?=null,val decodedBitDepth:Int?=null
)

/** Automatic routes; strict USB writes are guarded by the PCM engine's exact mixer contract. */
@androidx.annotation.RequiresApi(34)
class MpAudioController(context:Context,private val publish:(MpAudioState)->Unit):AutoCloseable {
    private val app=context.applicationContext
    private val manager=app.getSystemService(AudioManager::class.java)
    private val main=Handler(Looper.getMainLooper())
    private var session:String?=null
    private var entries:List<MediaEntry> = emptyList()
    private var index=0
    private var closed=false
    private var loaded=false
    private var desiredDevice:Int?=usbDevice()?.id
    private var lastLoadedDevice:Int?=null
    private val callback=object:AudioDeviceCallback(){
        override fun onAudioDevicesAdded(addedDevices:Array<out AudioDeviceInfo>){reconsiderRoute()}
        override fun onAudioDevicesRemoved(removedDevices:Array<out AudioDeviceInfo>){reconsiderRoute()}
    }
    private val poll=object:Runnable{
        override fun run(){ if(closed)return;publishState();main.postDelayed(this,200) }
    }
    init {
        require(Build.VERSION.SDK_INT>=34)
        manager.registerAudioDeviceCallback(callback,main)
        main.post(poll)
    }
    fun load(array: UnlockedMediaArray, entries: List<MediaEntry>) = load(SingleMediaLibrary(array, false), entries)
    fun load(array:ReadableMediaLibrary,entries:List<MediaEntry>){
        require(entries.all { it.mimeType.startsWith("audio/") })
        stop();this.entries=entries.toList();index=0;loaded=false
        session?.let(EncryptedMediaRegistry::unregister)
        session=EncryptedMediaRegistry.register(array,entries)
    }
    fun play(index:Int=0){
        if(closed || entries.isEmpty())return
        require(index in entries.indices)
        val state=NativePlaybackStore.state
        val usb=usbDevice()
        val routeMatches=state.selectedDeviceId==usb?.id && state.strictUsb==(usb!=null)
        if(loaded && this.index==index && !state.resourcesReleased && routeMatches){
            NativePlaybackService.command(app,NativePlaybackService.ACTION_PLAY)
        } else {
            val ended=state.durationUs>0 && state.positionUs>=state.durationUs
            val position=if(loaded && this.index==index && !ended)state.positionUs/1000 else 0
            this.index=index;loadTrack(position)
        }
    }
    fun pause(){ if(loaded)NativePlaybackService.command(app,NativePlaybackService.ACTION_PAUSE) }
    fun stop(){
        if(loaded)NativePlaybackService.command(app,NativePlaybackService.ACTION_STOP)
        loaded=false
    }
    fun seekTo(positionMs:Long){
        if(loaded)NativePlaybackService.command(app,NativePlaybackService.ACTION_SEEK){it.putExtra(NativePlaybackService.EXTRA_POSITION,positionMs.coerceAtLeast(0)*1000)}
    }
    /** Retained facade methods for controllers; output policy remains automatic. */
    fun setStrict(enabled:Boolean){reconsiderRoute()}
    fun selectDevice(id:Int?){reconsiderRoute()}
    private fun loadTrack(positionMs:Long){
        if(index !in entries.indices)return
        val activeSession=session?:return
        val device=usbDevice();desiredDevice=device?.id;lastLoadedDevice=device?.id
        NativePlaybackService.command(app,NativePlaybackService.ACTION_LOAD){ intent ->
            intent.putStringArrayListExtra(NativePlaybackService.EXTRA_URIS,ArrayList(entries.map { EncryptedMediaRegistry.uri(app.packageName,activeSession,it).toString() }))
            intent.putStringArrayListExtra(NativePlaybackService.EXTRA_NAMES,ArrayList(entries.map { it.displayName }))
            intent.putExtra(NativePlaybackService.EXTRA_INDEX,index)
            intent.putExtra(NativePlaybackService.EXTRA_POSITION,positionMs*1000)
            intent.putExtra(NativePlaybackService.EXTRA_DEVICE,device?.id?:-1)
            intent.putExtra(NativePlaybackService.EXTRA_STRICT,device!=null)
        }
        loaded=true
    }
    private fun reconsiderRoute(){
        val next=usbDevice()?.id
        if(next==desiredDevice)return
        val previous=desiredDevice;desiredDevice=next
        if(loaded){
            val state=NativePlaybackStore.state
            if(next!=null && state.playing) loadTrack(state.positionUs/1000)
            else if(previous!=null && next==null) stop()
        }
        publishState()
    }
    private fun usbDevice()=manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { isUsbAudioDevice(it.type) }
    private fun publishState(){
        val s=NativePlaybackStore.state
        val activeSession=session
        val ownsQueue=activeSession!=null && s.queue.size==entries.size && s.queue.indices.all { i ->
            s.queue[i].uri==EncryptedMediaRegistry.uri(app.packageName,activeSession,entries[i]).toString()
        }
        if(ownsQueue && s.queueIndex in entries.indices)index=s.queueIndex
        if(!ownsQueue){
            publish(MpAudioState())
            return
        }
        val usb=usbDevice()
        // A DAC may arrive while a decoder is still preparing the previous route.
        if(loaded && s.playing && !s.loading && s.error==null && usb!=null &&
            s.selectedDeviceId!=usb.id && lastLoadedDevice!=usb.id){
            loadTrack(s.positionUs/1000)
        }
        val devices=manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val output=when{
            s.actualRoute.startsWith("USB ") && !s.resourcesReleased->"USB DAC"
            s.actualRoute.contains("Bluetooth",true)->"Bluetooth"
            else->"Android"
        }
        publish(MpAudioState(s.playing,s.positionUs/1000,s.durationUs/1000,s.strictUsb,s.bitPerfectContractActive,
            if(s.error!=null)"This track cannot play on the current output." else null,
            devices.map { MpAudioDevice(it.id,it.productName.toString()) },s.selectedDeviceId,output,s.loading,
            if(ownsQueue)s.queueIndex else -1,
            s.source?.sourceBitDepth,s.source?.sourceSampleRateHz?.takeIf { it>0 },s.decodedPcmFormat?.containerBits))
    }
    override fun close(){
        if(closed)return
        stop();closed=true;main.removeCallbacks(poll);manager.unregisterAudioDeviceCallback(callback)
        session?.let(EncryptedMediaRegistry::unregister);session=null;entries=emptyList()
    }
}
