package com.dualscan.mp

/** Android Files can open a named protected media document, never a remote URL or raw media. */
object MediaOpenPolicy {
    const val DIAMOND_MIME = "application/vnd.dualscan.diamond"
    fun accepts(action: String?, scheme: String?, authority: String?, path: String?, mimeType: String?): Boolean =
        action == "android.intent.action.VIEW" && scheme == "content" &&
            authority == "com.android.externalstorage.documents" &&
            path?.endsWith(".diamond", ignoreCase = true) == true &&
            mimeType in setOf("application/octet-stream", DIAMOND_MIME)
}
