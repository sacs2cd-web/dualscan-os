package com.dualscan.mp

/** Displays measured source metadata only; it makes no output-device fidelity claim. */
object FidelityFormatter {
    fun source(bitDepth: Int?, sampleRateHz: Int?): String {
        if (bitDepth == null || sampleRateHz == null || bitDepth <= 0 || sampleRateHz <= 0) return "Unavailable"
        val khz = sampleRateHz.toBigDecimal().movePointLeft(3).stripTrailingZeros()
        val rate = khz.setScale(maxOf(1, khz.scale())).toPlainString()
        return "$bitDepth-bit $rate kHz"
    }
}
