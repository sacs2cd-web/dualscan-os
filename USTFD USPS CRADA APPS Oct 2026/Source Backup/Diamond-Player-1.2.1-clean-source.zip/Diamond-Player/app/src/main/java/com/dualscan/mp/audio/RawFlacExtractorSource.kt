@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp.audio

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.MediaFormat
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.DataReader
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.ParsableByteArray
import androidx.media3.extractor.DefaultExtractorInput
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorOutput
import androidx.media3.extractor.PositionHolder
import androidx.media3.extractor.SeekMap
import androidx.media3.extractor.TrackOutput
import androidx.media3.extractor.flac.FlacExtractor
import java.io.Closeable
import java.io.EOFException
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * Preserves compressed raw-FLAC frames before MediaCodec decoding. Some Android
 * MediaExtractor implementations expose a raw .flac as already-decoded 16-bit
 * audio/raw, irreversibly discarding precision before a float request can help.
 * Media3 FlacExtractor only demuxes here; it does not decode or resample.
 *
 * Uses the seekable authenticated proxy FD. Neither compressed plaintext nor
 * PCM is staged on disk. One encoded frame is buffered, bounded to 4 MiB;
 * oversized frames fail explicitly. Artwork and ID3 metadata parsing are off.
 * A header-only preflight also bounds metadata before upstream allocation.
 * Official API/source: androidx.media3:media3-extractor:1.11.1 (Apache-2.0),
 * libraries/extractor/.../flac/FlacExtractor.java in https://github.com/androidx/media.
 */
internal class RawFlacExtractorSource private constructor(context: Context, uri: Uri) : Closeable {
    private var asset: AssetFileDescriptor? = null
    private var stream: FileInputStream? = null
    private lateinit var channel: FileChannel
    private var baseOffset = 0L
    private var length = 0L
    private lateinit var input: DefaultExtractorInput
    private val extractor = FlacExtractor(FlacExtractor.FLAG_DISABLE_ID3_METADATA or FlacExtractor.FLAG_DISABLE_ARTWORK_METADATA)
    private val seekPosition = PositionHolder()
    private var seekMap: SeekMap? = null
    private var trackFormat: Format? = null
    private var ended = false
    private var ready = false
    private var closed = false
    private var frame = ByteArray(32 * 1024)
    private var frameSize = 0
    var sampleTimeUs = 0L
        private set
    var durationUs = 0L
        private set
    lateinit var mediaFormat: MediaFormat
        private set
    lateinit var streamInfo: FlacStreamInfo
        private set

    private val output = object : TrackOutput {
        override fun format(format: Format) {
            check(format.sampleMimeType == MimeTypes.AUDIO_FLAC && format.drmInitData == null) { "Expected original clear FLAC frames." }
            val previous = trackFormat
            check(previous == null || (previous.sampleRate == format.sampleRate && previous.channelCount == format.channelCount &&
                previous.initializationData.size == format.initializationData.size &&
                previous.initializationData.zip(format.initializationData).all { (a, b) -> a.contentEquals(b) })) { "FLAC format changed during playback." }
            trackFormat = format
        }

        override fun durationUs(durationUs: Long) {
            if (durationUs > 0) this@RawFlacExtractorSource.durationUs = durationUs
        }

        override fun sampleData(data: ParsableByteArray, length: Int, sampleDataPart: Int) {
            check(sampleDataPart == TrackOutput.SAMPLE_DATA_PART_MAIN && !ready) { "Unsupported FLAC sample data." }
            reserve(length)
            data.readBytes(frame, frameSize, length)
            frameSize += length
        }

        override fun sampleData(reader: DataReader, length: Int, allowEndOfInput: Boolean, sampleDataPart: Int): Int {
            check(sampleDataPart == TrackOutput.SAMPLE_DATA_PART_MAIN && !ready) { "Unsupported FLAC sample data." }
            reserve(length)
            val count = reader.read(frame, frameSize, length)
            if (count < 0) {
                if (!allowEndOfInput) throw EOFException("Truncated FLAC frame")
                return C.RESULT_END_OF_INPUT
            }
            if (count == 0 && length != 0) throw IOException("FLAC input made no progress")
            frameSize += count
            return count
        }

        override fun sampleMetadata(timeUs: Long, flags: Int, size: Int, offset: Int, cryptoData: TrackOutput.CryptoData?) {
            check(!ready && cryptoData == null && flags and C.BUFFER_FLAG_ENCRYPTED == 0) { "Unsupported protected FLAC sample." }
            check(size > 0 && offset == 0 && size == frameSize && timeUs >= 0) { "Invalid compressed FLAC frame boundary." }
            sampleTimeUs = timeUs
            ready = true
        }
    }

    init {
        try {
            val descriptor = context.contentResolver.openAssetFileDescriptor(uri, "r")
                ?: throw IOException("Unable to open audio source")
            asset = descriptor
            stream = descriptor.createInputStream()
            channel = checkNotNull(stream).channel
            baseOffset = descriptor.startOffset
            val available = channel.size() - baseOffset
            check(available >= 0) { "Audio asset starts beyond its descriptor." }
            length = if (descriptor.declaredLength == AssetFileDescriptor.UNKNOWN_LENGTH) available else minOf(descriptor.declaredLength, available)
            resetInput(0)
            extractor.init(object : ExtractorOutput {
                override fun track(id: Int, type: Int): TrackOutput {
                    check(id == 0 && type == C.TRACK_TYPE_AUDIO) { "Unexpected raw FLAC track." }
                    return output
                }
                override fun endTracks() = Unit
                override fun seekMap(seekMap: SeekMap) {
                    this@RawFlacExtractorSource.seekMap = seekMap
                    if (seekMap.durationUs > 0) durationUs = seekMap.durationUs
                }
            })
        } catch (failure: Throwable) {
            close()
            throw failure
        }
    }

    private fun initialize() {
        while (trackFormat == null || seekMap == null) {
            if (ended) throw IOException("FLAC ended before its format was available")
            readExtractor()
        }
        val format = checkNotNull(trackFormat)
        val csd = format.initializationData.singleOrNull()
            ?: throw IOException("FLAC requires one STREAMINFO initialization block")
        streamInfo = parseFlacStreamInfo(csd) ?: throw IOException("Invalid FLAC STREAMINFO")
        check(format.sampleRate == streamInfo.rate && format.channelCount == streamInfo.channels) { "FLAC format and STREAMINFO disagree." }
        val maxFrame = format.maxInputSize.takeIf { it > 0 } ?: MAX_FRAME_BYTES
        check(maxFrame <= MAX_FRAME_BYTES) { "This FLAC frame size is unsupported." }
        mediaFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_FLAC, streamInfo.rate, streamInfo.channels).apply {
            setByteBuffer("csd-0", ByteBuffer.wrap(csd))
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, maxOf(32 * 1024, maxFrame))
            if (durationUs > 0) setLong(MediaFormat.KEY_DURATION, durationUs)
        }
    }

    fun readSampleData(target: ByteBuffer): Int {
        ensureOpen()
        if (!ensureSample()) return -1
        check(target.remaining() >= frameSize) { "The FLAC decoder input buffer cannot hold a complete compressed frame." }
        target.put(frame, 0, frameSize)
        return frameSize
    }

    fun advance() {
        frame.fill(0, 0, frameSize)
        frameSize = 0
        ready = false
    }

    /** Returns the timestamp of the actual independently decodable frame. */
    fun seekTo(positionUs: Long): Long {
        ensureOpen()
        advance()
        ended = false
        val wanted = positionUs.coerceAtLeast(0).let { if (durationUs > 0) it.coerceAtMost(durationUs) else it }
        val map = checkNotNull(seekMap)
        if (wanted == 0L || !map.isSeekable) {
            extractor.seek(0, 0)
            resetInput(0)
            if (!map.isSeekable && wanted > 0) {
                while (ensureSample() && sampleTimeUs < wanted) advance()
            }
        } else {
            val point = map.getSeekPoints(wanted).first
            extractor.seek(point.position, wanted)
            resetInput(point.position)
        }
        return if (ensureSample()) sampleTimeUs else durationUs
    }

    private fun ensureSample(): Boolean {
        while (!ready && !ended) readExtractor()
        return ready
    }

    private fun readExtractor() {
        if (Thread.currentThread().isInterrupted) throw InterruptedException("FLAC extraction stopped")
        when (extractor.read(input, seekPosition)) {
            Extractor.RESULT_END_OF_INPUT -> ended = true
            Extractor.RESULT_SEEK -> resetInput(seekPosition.position)
        }
    }

    private fun resetInput(position: Long) {
        check(position in 0..length) { "FLAC seek lies outside the source." }
        channel.position(baseOffset + position)
        input = DefaultExtractorInput(DataReader { target, offset, count ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException("FLAC extraction stopped")
            val remaining = length - (channel.position() - baseOffset)
            if (remaining <= 0) C.RESULT_END_OF_INPUT
            else channel.read(ByteBuffer.wrap(target, offset, minOf(count.toLong(), remaining).toInt()))
        }, position, length)
    }

    private fun reserve(additional: Int) {
        check(additional >= 0 && additional <= MAX_FRAME_BYTES - frameSize) { "This FLAC frame exceeds the supported buffer size." }
        val needed = frameSize + additional
        if (needed > frame.size) {
            val replacement = ByteArray(maxOf(needed, minOf(frame.size * 2, MAX_FRAME_BYTES)))
            frame.copyInto(replacement, 0, 0, frameSize)
            frame.fill(0)
            frame = replacement
        }
    }

    /**
     * Do not hand arbitrary tag lengths to an extractor that may allocate its
     * peek buffer before reading. This inspects only small headers using pread;
     * it neither loads artwork nor changes the streaming extractor's position.
     */
    private fun hasBoundedFlacMetadata(): Boolean {
        var position = 0L
        var tags = 0
        while (length - position >= 10) {
            val tag = headerAt(position, 10)
            if (tag[0] != 'I'.code.toByte() || tag[1] != 'D'.code.toByte() || tag[2] != '3'.code.toByte()) break
            if (tag[3].toInt() !in 2..4) return false
            check((6..9).all { tag[it].toInt() and 0x80 == 0 }) { "Invalid ID3 length." }
            val bytes = (6..9).fold(0) { size, i -> (size shl 7) or (tag[i].toInt() and 0x7f) }
            position += 10L + bytes
            tags++
            check(tags <= MAX_METADATA_BLOCKS && position <= length) { "The audio metadata prefix is invalid or truncated." }
        }
        if (length - position < 4 || !headerAt(position, 4).contentEquals(byteArrayOf(0x66, 0x4c, 0x61, 0x43))) return false
        check(position <= MAX_ID3_BYTES) { "The FLAC metadata prefix is too large." }
        position += 4
        var blocks = 0
        do {
            val block = headerAt(position, 4)
            val type = block[0].toInt() and 0x7f
            val bytes = ((block[1].toInt() and 255) shl 16) or ((block[2].toInt() and 255) shl 8) or (block[3].toInt() and 255)
            check(blocks != 0 || (type == 0 && bytes == 34)) { "FLAC requires an initial STREAMINFO block." }
            position += 4L + bytes
            blocks++
            check(blocks <= MAX_METADATA_BLOCKS && position <= MAX_METADATA_BYTES && position <= length) { "FLAC metadata is too large or truncated." }
            val last = block[0].toInt() and 0x80 != 0
        } while (!last)
        return true
    }

    private fun headerAt(position: Long, count: Int): ByteArray {
        check(position >= 0 && count >= 0 && position <= length - count) { "Truncated FLAC metadata header." }
        val bytes = ByteArray(count)
        val target = ByteBuffer.wrap(bytes)
        while (target.hasRemaining()) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("FLAC extraction stopped")
            val read = channel.read(target, baseOffset + position + target.position())
            if (read <= 0) throw EOFException("Truncated FLAC metadata header")
        }
        return bytes
    }

    private fun ensureOpen() { check(!closed) { "FLAC source is closed." } }

    override fun close() {
        if (closed) return
        closed = true
        frame.fill(0); frameSize = 0; ready = false
        extractor.release()
        runCatching { stream?.close() }
        runCatching { asset?.close() }
        stream = null; asset = null
    }

    companion object {
        private const val MAX_FRAME_BYTES = 4 * 1024 * 1024
        private const val MAX_ID3_BYTES = 4 * 1024 * 1024
        private const val MAX_METADATA_BYTES = 32 * 1024 * 1024
        private const val MAX_METADATA_BLOCKS = 4096

        fun openIfSupported(context: Context, uri: Uri): RawFlacExtractorSource? {
            val source = RawFlacExtractorSource(context, uri)
            return try {
                if (!source.hasBoundedFlacMetadata() || !source.extractor.sniff(source.input)) {
                    source.close(); null
                } else {
                    source.input.resetPeekPosition()
                    source.initialize()
                    source
                }
            } catch (failure: Throwable) {
                source.close()
                throw failure
            }
        }
    }
}
