package com.dualscan.mp

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import java.io.IOException

/** Public APIs expose removable-volume UUIDs, but not a reliable per-volume USB bus map. */
object UsbStorageAccess {
    fun snapshot(context: Context): UsbStorageSnapshot {
        val manager = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val usb = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val attached = usb.deviceList.values.any { device ->
            device.deviceClass == UsbConstants.USB_CLASS_MASS_STORAGE ||
                (0 until device.interfaceCount).any { device.getInterface(it).interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE }
        }
        val volumes = manager.storageVolumes.map { RemovableVolume(it.uuid, it.isRemovable, it.state == Environment.MEDIA_MOUNTED) }
        return UsbStorageSnapshot(attached, volumes)
    }
    fun requireAvailable(context: Context) {
        val state = snapshot(context)
        if (!state.usbMassStorageAttached || state.volumes.none { it.removable && it.mounted && !it.uuid.isNullOrBlank() })
            throw IOException("Connect and mount a USB-C/OTG storage drive first. Android must expose it as writable removable storage.")
    }
    fun requireUsbDocument(context: Context, uri: Uri) {
        val documentId = try {
            if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.getDocumentId(uri)
            else DocumentsContract.getTreeDocumentId(uri)
        } catch (_: Exception) { throw IOException("Select a file on the USB drive through Android's storage picker.") }
        val state = snapshot(context)
        UsbAccessPolicy.requireAllowed(uri.authority.orEmpty(), documentId, state)
    }
    fun initialRoot(context: Context): Uri? {
        val state = snapshot(context)
        if (!state.usbMassStorageAttached) return null
        val uuid = state.volumes.firstOrNull { it.removable && it.mounted && !it.uuid.isNullOrBlank() }?.uuid ?: return null
        return DocumentsContract.buildRootUri(UsbAccessPolicy.AUTHORITY, uuid)
    }
}
data class RemovableVolume(val uuid: String?, val removable: Boolean, val mounted: Boolean)
data class UsbStorageSnapshot(val usbMassStorageAttached: Boolean, val volumes: List<RemovableVolume>) {
    val ready get() = usbMassStorageAttached && volumes.any { it.removable && it.mounted && !it.uuid.isNullOrBlank() }
}
object UsbAccessPolicy {
    const val AUTHORITY = "com.android.externalstorage.documents"
    fun requireAllowed(authority: String, documentId: String, snapshot: UsbStorageSnapshot) {
        if (authority != AUTHORITY) throw IOException("USB-only mode rejects cloud, Downloads and other document providers. Choose your attached USB drive.")
        val volumeId = documentId.substringBefore(':')
        if (volumeId.isBlank() || volumeId.equals("primary", true) || !documentId.contains(':'))
            throw IOException("Choose a file on the removable USB drive, not internal storage.")
        if (!snapshot.usbMassStorageAttached) throw IOException("A USB mass-storage drive is not attached. Keep the USB drive connected during this operation.")
        if (snapshot.volumes.none { it.removable && it.mounted && it.uuid.equals(volumeId, ignoreCase = true) })
            throw IOException("The selected removable drive is not mounted or no longer available.")
    }
}
