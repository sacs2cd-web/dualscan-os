@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import com.dualscan.mp.audio.MpAudioController
import com.dualscan.mp.audio.MpAudioState
import com.dualscan.mp.core.*
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class MpViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val work = File(app.filesDir, "collections").apply { mkdirs() }
    var dark by mutableStateOf(app.getSharedPreferences("appearance", Context.MODE_PRIVATE).getBoolean("dark", true)); private set
    var array by mutableStateOf<ReadableMediaLibrary?>(null); private set
    var entries by mutableStateOf<List<MediaEntry>>(emptyList()); private set
    var current by mutableStateOf<MediaEntry?>(null); private set
    var player by mutableStateOf<ExoPlayer?>(null); private set
    var picture by mutableStateOf<Bitmap?>(null); private set
    var artwork by mutableStateOf<Bitmap?>(null); private set
    var artworkKey by mutableStateOf<String?>(null); private set
    var loading by mutableStateOf(false); private set
    private var selectedSortOrder by mutableStateOf(MediaSortOrder.TRACKS)
    val sortOrder get() = selectedSortOrder
    var playing by mutableStateOf(false); private set
    var positionMs by mutableStateOf(0L); private set
    var durationMs by mutableStateOf(0L); private set
    var output by mutableStateOf("Android"); private set
    var bitPerfect by mutableStateOf(false); private set
    var fidelityText by mutableStateOf("Unavailable"); private set
    var busy by mutableStateOf(false); private set
    var status by mutableStateOf(""); private set
    var error by mutableStateOf<String?>(null); private set
    var usbReady by mutableStateOf(false); private set
    var creationOpen by mutableStateOf(false)
    var passwordRequestUri by mutableStateOf<Uri?>(null); private set
    var libraryPasswordRequested by mutableStateOf(false); private set
    var mediaFolders by mutableStateOf<List<SharedEncryptedLibrary.Folder>>(emptyList()); private set
    var draftTitle by mutableStateOf("My collection")
    var draftPassword by mutableStateOf("")
    var draftConfirmation by mutableStateOf("")
    private var sources = emptyList<SelectedMediaSource>()
    private var sourceUri: Uri? = null
    private var sourceFile: File? = null
    private var native: MpAudioController? = null
    private var mediaRoute: Media3RouteReporter? = null
    private var generation = 0L
    private var mode = Mode.NONE
    private var operation: Job? = null
    private var worker = AtomicReference<Thread?>()
    private var imageJob: Job? = null
    private var artworkJob: Job? = null
    private var artworkCoverId: String? = null
    private var audioQueue = emptyList<MediaEntry>()
    private var audioQueueIndex = 0
    private var lastNativeError: String? = null
    val title get() = array?.catalog?.title ?: "Your collection"
    val subtitle get() = "${entries.size} media items"
    val visibleEntries get() = MediaLibraryIndex.sorted(entries, sortOrder)
    val canSave get() = array != null && (sourceUri != null || sourceFile != null)
    val isFolderLibrary get() = array is CompositeMediaLibrary
    val lockedMediaCount get() = (array as? CompositeMediaLibrary)?.lockedDocuments?.size ?: 0

    init {
        work.listFiles()?.forEach { it.delete() }
        refreshUsb()
        viewModelScope.launch {
            while (isActive) {
                delay(400)
                if (mode == Mode.MEDIA3) player?.let {
                    positionMs = it.currentPosition.coerceAtLeast(0); durationMs = it.duration.takeIf { d -> d > 0 && d != C.TIME_UNSET } ?: 0; playing = it.isPlaying
                    val format = it.audioFormat
                    val bits = if (format?.sampleMimeType in setOf("audio/raw", "audio/flac")) when (format?.pcmEncoding) {
                        C.ENCODING_PCM_8BIT -> 8; C.ENCODING_PCM_16BIT -> 16; C.ENCODING_PCM_24BIT -> 24; C.ENCODING_PCM_32BIT -> 32
                        else -> null
                    } else null
                    fidelityText = FidelityFormatter.source(bits, format?.sampleRate?.takeIf { rate -> rate > 0 })
                }
            }
        }
    }
    fun toggleTheme() { dark = !dark; app.getSharedPreferences("appearance", Context.MODE_PRIVATE).edit().putBoolean("dark", dark).apply() }
    fun refreshUsb() { usbReady = try { UsbStorageAccess.snapshot(app).ready } catch (_: Exception) { false } }
    fun dismissError() { error = null }
    fun dismissPasswordRequest() { if (!busy) passwordRequestUri = null }
    fun dismissLibraryPasswordRequest() { if (!busy) libraryPasswordRequested = false }
    fun requestLibraryPassword() { if (!busy && lockedMediaCount > 0) libraryPasswordRequested = true }
    fun setSortOrder(value: MediaSortOrder) { selectedSortOrder = value }
    fun cancelCreation() { creationOpen = false; draftPassword = ""; draftConfirmation = ""; sources = emptyList() }
    fun prepareSources(uris: List<Uri>) {
        if (busy || uris.isEmpty()) return
        task("Reading your selection…") {
            val selected = MediaFolderImporter(app).fromUris(uris)
            withContext(Dispatchers.Main) { sources = selected; creationOpen = true; status = "" }
        }
    }
    fun prepareFolder(uri: Uri) {
        if (busy) return
        task("Reading your folder…") {
            val selected = MediaFolderImporter(app).fromFolder(uri)
            require(selected.isNotEmpty()) { "Choose a folder containing music, video or pictures." }
            withContext(Dispatchers.Main) { sources = selected; creationOpen = true; status = "" }
        }
    }
    fun openMediaFolder(uri: Uri) {
        if (busy) return
        task("Reading your media folder…") {
            val folder = SharedEncryptedLibrary.scan(app, uri)
            try { app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            val selected = mediaFolders.filterNot { it.uri == folder.uri } + folder
            require(selected.size <= 16) { "Choose up to 16 media folders for this session." }
            val opened = openFolderLibrary(selected)
            var pending: ReadableMediaLibrary? = opened
            try {
                withContext(Dispatchers.Main) {
                    mediaFolders = selected
                    activate(opened, null, null); pending = null
                    libraryPasswordRequested = opened.lockedDocuments.isNotEmpty()
                    status = libraryStatus(opened)
                }
            } finally { pending?.close() }
        }
    }
    fun openProtectedLibraryFiles(password: CharArray) {
        if (busy) { password.fill('\u0000'); return }
        val currentLibrary = array as? CompositeMediaLibrary ?: run { password.fill('\u0000'); return }
        val previousCount = entries.size
        task("Opening your files…") {
            var pending: ReadableMediaLibrary? = null
            try {
                val opened = currentLibrary.unlock(password)
                pending = opened
                require(MediaLibraryIndex.playable(opened.catalog.entries).size > previousCount) { "That password did not open any additional files." }
                withContext(Dispatchers.Main) {
                    activate(opened, null, null); pending = null
                    libraryPasswordRequested = false
                    status = libraryStatus(opened)
                }
            } finally { pending?.close(); password.fill('\u0000') }
        }
    }
    private fun openFolderLibrary(folders: List<SharedEncryptedLibrary.Folder>, password: CharArray? = null): CompositeMediaLibrary {
        val documents = folders.flatMap { folder ->
            folder.documents.map { document ->
                val id = DocumentsContract.getDocumentId(document.uri)
                val volume = id.substringBefore(':')
                val namespace = if (volume.equals("primary", true)) "Phone" else "USB $volume"
                EncryptedLibraryDocument(
                    stableId = DocumentsContract.buildDocumentUri(document.uri.authority, id).toString(),
                    relativePath = "$namespace/${id.substringAfter(':')}",
                    open = { SafRandomAccessSource(app, document.uri) })
            }
        }.distinctBy { it.stableId }
        require(documents.size <= 10_000) { "Choose folders containing up to 10,000 encrypted files." }
        val title = folders.singleOrNull()?.title ?: "Your media library"
        return if (password == null) (array as? CompositeMediaLibrary)?.withDocuments(title, documents)
            ?: CompositeMediaLibrary.open(title, documents)
        else CompositeMediaLibrary.open(title, documents, password)
    }
    private fun libraryStatus(library: CompositeMediaLibrary): String = when {
        library.lockedDocuments.isNotEmpty() -> "${library.lockedDocuments.size} files need a password."
        library.rejectedDocuments.isNotEmpty() -> "${library.rejectedDocuments.size} files could not be opened."
        library.catalog.entries.isEmpty() -> "No media found in this folder."
        else -> ""
    }
    fun createCollection() {
        if (busy) return
        val selected = sources.toList(); val pass = draftPassword.toCharArray(); val matches = draftPassword == draftConfirmation; val title = draftTitle.trim()
        task("Creating your collection…") {
            var out: File? = null
            var pending: ReadableMediaLibrary? = null
            try {
                require(selected.isNotEmpty()) { "Choose music, videos or pictures first." }
                require(title.isNotBlank()) { "Give your collection a name." }
                require(pass.isEmpty() || pass.size in 8..256) { "Use a password with 8 to 256 characters, or leave it blank." }
                require(matches) { "The passwords do not match." }
                out = File(work, "Diamond-Player-${UUID.randomUUID().toString().take(12)}.dmpa")
                val opened = SingleMediaLibrary(MediaArray.createPortable(out, title, selected.map { item ->
                    MediaInput(displayName = item.name, mimeType = item.mime, relativePath = item.relativePath,
                        open = { app.contentResolver.openInputStream(item.uri) ?: throw IOException("This item is no longer available.") },
                        trackNumber = item.trackNumber, discNumber = item.discNumber)
                }, pass.takeIf { it.isNotEmpty() }))
                pending = opened
                val created = out
                withContext(Dispatchers.Main) { activate(opened, null, created); pending = null; cancelCreation(); status = "Collection ready." }
            } catch (failure: Exception) { out?.delete(); throw failure }
            finally { pending?.close(); pass.fill('\u0000') }
        }
    }
    fun openCollection(uri: Uri, password: CharArray? = null) {
        if (busy) { password?.fill('\u0000'); return }
        if (password == null) passwordRequestUri = null
        task(if (password == null) "Opening your collection…" else "Unlocking your collection…") {
            var source: SafRandomAccessSource? = null
            var pending: ReadableMediaLibrary? = null
            try {
                requireCollectionLocation(uri)
                try { app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
                source = SafRandomAccessSource(app, uri)
                val signature = ByteArray(8)
                if (source.readAt(0, signature, 0, signature.size) == signature.size && signature.toString(Charsets.US_ASCII) == "DSHP0001") {
                    throw IOException("Export this image again using the latest Dualscan Share, then open the new copy here.")
                }
                val opened = SingleMediaLibrary(MediaArray.open(source, password))
                source = null // Ownership belongs to the unlocked array.
                pending = opened
                withContext(Dispatchers.Main) { activate(opened, uri, null); pending = null; passwordRequestUri = null; status = "" }
            } catch (_: PasswordRequiredException) {
                withContext(Dispatchers.Main) { passwordRequestUri = uri; status = "" }
            } finally { pending?.close(); source?.close(); password?.fill('\u0000') }
        }
    }
    fun openMediaFileIntent(intent: Intent) {
        val uri = intent.data ?: return
        if (!MediaOpenPolicy.accepts(intent.action, uri.scheme, uri.authority, uri.path, intent.type)) {
            if (!busy) error = "Choose a .diamond media file on this phone or USB-C."
            return
        }
        openCollection(uri)
    }
    private fun requireCollectionLocation(uri: Uri) {
        require(uri.authority == UsbAccessPolicy.AUTHORITY) { "Choose a collection on your USB drive or this phone." }
        val id = DocumentsContract.getDocumentId(uri)
        if (!id.startsWith("primary:")) UsbStorageAccess.requireUsbDocument(app, uri)
    }
    private fun activate(opened: ReadableMediaLibrary, uri: Uri?, file: File?) {
        lockInternal()
        array = opened; entries = MediaLibraryIndex.playable(opened.catalog.entries); sourceUri = uri; sourceFile = file
        libraryPasswordRequested = false
        generation++
        val token = generation
        if (Build.VERSION.SDK_INT >= 34) native = MpAudioController(app) { state ->
            viewModelScope.launch(Dispatchers.Main.immediate) { if (generation == token && mode == Mode.NATIVE) applyNative(state) }
        }
        val reporter = Media3RouteReporter(app) { label -> if (generation == token && mode == Mode.MEDIA3) output = label }
        mediaRoute = reporter
        player = ExoPlayer.Builder(app, reporter.renderersFactory).build().apply {
            setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setHandleAudioBecomingNoisy(true)
            setWakeMode(C.WAKE_MODE_LOCAL)
            addListener(object : Player.Listener {
                override fun onPlayerError(failure: PlaybackException) { if (mode == Mode.MEDIA3) { playing = false; error = "This item could not be played." } }
                override fun onIsPlayingChanged(value: Boolean) { if (mode == Mode.MEDIA3) playing = value }
                override fun onPlaybackStateChanged(state: Int) { if (mode == Mode.MEDIA3) loading = state == Player.STATE_BUFFERING }
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    if (mode == Mode.MEDIA3) entries.firstOrNull { it.id == item?.mediaId }?.let(::showCurrent)
                }
            })
        }
    }
    private fun applyNative(state: MpAudioState) {
        playing = state.playing; loading = state.loading; positionMs = state.positionMs
        durationMs = state.durationMs; output = state.output; bitPerfect = state.strictActive
        fidelityText = FidelityFormatter.source(state.sourceBitDepth, state.sourceSampleRateHz)
        if (state.queueIndex in audioQueue.indices) {
            audioQueueIndex = state.queueIndex
            audioQueue[audioQueueIndex].takeIf { it.id != current?.id }?.let(::showCurrent)
        }
        if (state.error != lastNativeError) {
            lastNativeError = state.error
            state.error?.let { error = it }
        }
    }
    private fun showCurrent(entry: MediaEntry) {
        current = entry
        val opened = array ?: return
        val cover = MediaLibraryIndex.coverFor(entry, entries)
        artworkKey = entry.id
        if (artworkCoverId == cover?.id && artwork != null) return
        artworkJob?.cancel(); artworkJob = null; artwork = null; artworkCoverId = cover?.id
        if (cover == null) return
        artworkJob = viewModelScope.launch {
            try {
                val decoded = withContext(Dispatchers.IO) { EncryptedPictureDecoder.decode(opened, cover) }
                if (array === opened && artworkCoverId == cover.id) artwork = decoded else decoded.recycle()
            } catch (_: CancellationException) { }
            catch (_: Exception) { /* Artwork failure must not interrupt music. */ }
        }
    }

    fun play(entry: MediaEntry) {
        val opened = array ?: return
        if (busy) return
        if (!MediaLibraryIndex.isPlayable(entry) || entries.none { it.id == entry.id }) {
            error = "This item is not playable media."
            return
        }
        imageJob?.cancel(); picture = null
        if (Build.VERSION.SDK_INT >= 34) native?.stop()
        Media3PlaybackService.end(app); player?.stop(); player?.clearMediaItems()
        showCurrent(entry); positionMs = 0; durationMs = 0; playing = false; bitPerfect = false; loading = false; fidelityText = "Unavailable"
        when {
            entry.mimeType.startsWith("image/") -> {
                mode = Mode.PHOTO
                imageJob = viewModelScope.launch {
                    try {
                        val bitmap = withContext(Dispatchers.IO) { EncryptedPictureDecoder.decode(opened, entry) }
                        if (current?.id == entry.id && array === opened) picture = bitmap else bitmap.recycle()
                    } catch (_: CancellationException) { }
                    catch (_: Exception) { error = "This picture could not be opened." }
                }
            }
            entry.mimeType.startsWith("audio/") && Build.VERSION.SDK_INT >= 34 -> {
                mode = Mode.NATIVE
                audioQueue = visibleEntries.filter { it.mimeType.startsWith("audio/") }
                audioQueueIndex = audioQueue.indexOfFirst { it.id == entry.id }.coerceAtLeast(0)
                native?.load(opened, audioQueue); native?.play(audioQueueIndex)
            }
            else -> {
                mode = Mode.MEDIA3; output = "Android"; mediaRoute?.refresh()
                val family = entry.mimeType.substringBefore('/')
                val queue = visibleEntries.filter { it.mimeType.startsWith("$family/") }
                val factory = ProgressiveMediaSource.Factory(EncryptedMediaDataSource.Factory(opened))
                val media = queue.map { item -> factory.createMediaSource(MediaItem.Builder()
                    .setMediaId(item.id).setUri(Uri.Builder().scheme("dualscan-mp").authority("entry").appendPath(item.id).build())
                    .setMimeType(item.mimeType).build()) }
                player?.setMediaSources(media, queue.indexOfFirst { it.id == entry.id }.coerceAtLeast(0), 0)
                player?.prepare(); player?.play()
                player?.let { Media3PlaybackService.begin(app, it, entry.displayName) }
            }
        }
    }
    fun togglePlay() {
        when (mode) {
            Mode.NATIVE -> if (Build.VERSION.SDK_INT >= 34) { if (playing) native?.pause() else native?.play(audioQueueIndex) }
            Mode.MEDIA3 -> {
                val active = player ?: return
                if (playing) active.pause() else {
                    if (active.playbackState == Player.STATE_ENDED) active.seekTo(0)
                    if (active.playbackState == Player.STATE_IDLE) active.prepare()
                    active.play()
                    try { current?.let { Media3PlaybackService.begin(app, active, it.displayName) } }
                    catch (_: Exception) { active.pause(); error = "Open Diamond™ Player and try again." }
                }
            }
            else -> { }
        }
    }
    fun seek(position: Long) { if (mode == Mode.NATIVE && Build.VERSION.SDK_INT >= 34) native?.seekTo(position) else if (mode == Mode.MEDIA3) player?.seekTo(position) }
    fun skip(delta: Int) {
        val item = current ?: return; val family = item.mimeType.substringBefore('/')
        val queue = visibleEntries.filter { it.mimeType.startsWith("$family/") }; val index = queue.indexOfFirst { it.id == item.id }
        if (queue.isNotEmpty()) play(queue[(index + delta).mod(queue.size)])
    }
    fun lock() { if (!busy) { lockInternal(); status = "" } }
    private fun lockInternal() {
        generation++; imageJob?.cancel(); imageJob = null; artworkJob?.cancel(); artworkJob = null
        if (Build.VERSION.SDK_INT >= 34) native?.close()
        native = null; Media3PlaybackService.end(app); player?.release(); player = null
        mediaRoute?.close(); mediaRoute = null
        picture = null; artwork = null; artworkKey = null; artworkCoverId = null; audioQueue = emptyList(); audioQueueIndex = 0
        array?.close(); array = null; entries = emptyList(); current = null
        sourceFile?.delete(); sourceFile = null; sourceUri = null
        mode = Mode.NONE; playing = false; loading = false; bitPerfect = false; positionMs = 0; durationMs = 0; output = "Android"; fidelityText = "Unavailable"; lastNativeError = null
    }

    fun saveTo(tree: Uri, phone: Boolean) {
        if (busy || !canSave) return
        val fromUri = sourceUri; val fromFile = sourceFile
        val filename = fromFile?.name ?: fromUri?.let(::collectionFilename) ?: "Diamond-Player-${UUID.randomUUID().toString().take(12)}.dmpa"
        task(if (phone) "Saving on this phone…" else "Saving to USB…") {
            if (phone) {
                require(tree.authority == UsbAccessPolicy.AUTHORITY) { "Choose Music, Pictures or Movies on this phone." }
                val id = DocumentsContract.getTreeDocumentId(tree)
                require(id.startsWith("primary:") && id.substringAfter(':').substringBefore('/') in setOf("Music", "Pictures", "Movies")) { "Choose a Music, Pictures or Movies folder on this phone." }
            } else UsbStorageAccess.requireUsbDocument(app, tree)
            fromUri?.let(::requireCollectionLocation)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val destination = DocumentsContract.createDocument(app.contentResolver, parent, "application/octet-stream", filename) ?: throw IOException("The folder could not create your collection.")
            try {
                val input = fromFile?.inputStream() ?: fromUri?.let { app.contentResolver.openInputStream(it) } ?: throw IOException("The collection is no longer available.")
                val copied = input.use { source -> app.contentResolver.openOutputStream(destination, "wt")?.use { sink ->
                    EncryptedCollectionCopy.copy(source, sink, ::checkInterrupted)
                } ?: throw IOException("The destination could not write your collection.") }
                app.contentResolver.openInputStream(destination)?.use { source ->
                    EncryptedCollectionCopy.verify(source, copied, ::checkInterrupted)
                } ?: throw IOException("The saved collection could not be verified.")
                withContext(Dispatchers.Main) { status = if (phone) "Saved on this phone. Your collection stays encrypted." else "Saved to USB. Your collection stays encrypted." }
            } catch (failure: Exception) { try { DocumentsContract.deleteDocument(app.contentResolver, destination) } catch (_: Exception) {} ; throw failure }
        }
    }
    private fun collectionFilename(uri: Uri): String? = try {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            val name = cursor.getString(0)
            name?.takeIf { it.length in 1..200 && '/' !in it && '\\' !in it && (it.endsWith(".diamond", true) || it.endsWith(".dshare", true) || it.endsWith(".dmpa", true)) }
        }
    } catch (_: Exception) { null }
    private fun task(label: String, block: suspend () -> Unit) {
        busy = true; status = label; error = null
        val thread = AtomicReference<Thread?>(); worker = thread
        val dispatcher = Executors.newSingleThreadExecutor { action -> Thread(action, "DualscanMpTransfer").apply { thread.set(this) } }.asCoroutineDispatcher()
        val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
            var transfer: TransferService.Session? = null
            try {
                transfer = TransferService.begin(app) { operation?.cancel(); thread.get()?.interrupt() }
                transfer.awaitStarted()
                withContext(dispatcher) { block() }
            }
            catch (cancelled: CancellationException) { status = "Stopped."; throw cancelled }
            catch (failure: Exception) { error = failure.message ?: "Please try again."; status = "" }
            finally { transfer?.close(); dispatcher.close(); busy = false; operation = null; refreshUsb() }
        }
        operation = job
        job.start()
    }
    override fun onCleared() { operation?.cancel(); worker.get()?.interrupt(); lockInternal(); draftPassword = ""; draftConfirmation = ""; super.onCleared() }
    private enum class Mode { NONE, NATIVE, MEDIA3, PHOTO }
}
private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Stopped.") }
