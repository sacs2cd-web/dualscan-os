package com.dualscan.mp

import java.io.IOException
import java.util.Locale

enum class MediaGroup(val folder: String) { AUDIO("Music"), IMAGE("Pictures"), VIDEO("Movies") }
object MediaPolicy {
    fun group(name: String, mime: String?): MediaGroup {
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (extension in setOf("apk", "apks", "xapk", "aab", "dex", "odex", "vdex", "diamond", "dshare", "dmpa"))
            throw IOException("Application packages and backup containers are not media files.")
        return when {
            mime?.startsWith("audio/") == true -> MediaGroup.AUDIO
            mime?.startsWith("image/") == true -> MediaGroup.IMAGE
            mime?.startsWith("video/") == true -> MediaGroup.VIDEO
            else -> throw IOException("Lite accepts audio, video and picture files only. Unsupported file: $name")
        }
    }
    fun safeName(name: String): String = name.substringAfterLast('/').substringAfterLast('\\')
        .filter { !it.isISOControl() }.trim().take(180).ifBlank { "media" }
}

object LocalMediaSourcePolicy {
    private val authorities = setOf("media", "com.android.providers.media.documents", "com.android.providers.downloads.documents", "com.android.externalstorage.documents")
    fun requireLocal(authority: String, path: String) {
        if (authority !in authorities || path.split('/').any { it.equals("picker", true) || it.startsWith("picker_", true) })
            throw IOException("Choose an on-device shared file/folder or a local USB file. Cloud and photo-picker cloud routes are disabled.")
    }
}
