package com.dualscan.mp

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.IOException
import java.text.Normalizer
import java.util.Locale

data class SelectedMediaSource(
    val uri: Uri,
    val name: String,
    val mime: String,
    val relativePath: String?,
    val trackNumber: Int? = null,
    val discNumber: Int? = null
)

/** Run on an IO worker. Reads only explicit local selections and existing tree grants. */
class MediaFolderImporter(private val context: Context) {
    private val resolver get() = context.contentResolver

    fun fromFolder(tree: Uri): List<SelectedMediaSource> {
        requireLocal(tree)
        require(DocumentsContract.isTreeUri(tree)) { "Choose a local folder through Android's storage picker." }
        retainGrant(tree)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val rootUri = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        val rootName = documentName(rootUri)
        val base = externalRelativePath(rootUri) ?: checkedSegment(rootName)
        val visited = HashSet<String>()
        val selected = LinkedHashMap<String, SelectedMediaSource>()
        var scanned = 0
        fun walk(documentId: String, parent: String, depth: Int) {
            checkInterrupted()
            require(depth <= 32 && visited.add(documentId)) { "The selected folder is too deep or contains a repeated directory." }
            children(tree, documentId) { child ->
                checkInterrupted()
                require(++scanned <= MAX_ITEMS) { "Choose a folder containing at most $MAX_ITEMS items." }
                val name = checkedSegment(child.name)
                val path = checkedPath(listOf(parent, name).filter { it.isNotEmpty() }.joinToString("/"), name)
                if (child.mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(child.id, path, depth + 1)
                } else {
                    val mime = canonicalMime(name, child.mime) ?: return@children
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, child.id)
                    selected.putIfAbsent(sourceKey(uri), selected(uri, name, mime, path))
                }
            }
        }
        walk(rootId, base, 1)
        return finish(selected.values.toList())
    }

    fun fromUris(uris: List<Uri>): List<SelectedMediaSource> {
        require(uris.size in 1..MAX_ITEMS) { "Choose 1–$MAX_ITEMS media files." }
        val selected = LinkedHashMap<String, SelectedMediaSource>()
        uris.distinct().forEach { uri ->
            checkInterrupted(); requireLocal(uri); retainGrant(uri)
            require(!DocumentsContract.isTreeUri(uri) || DocumentsContract.isDocumentUri(context, uri)) { "Use Add folder for a folder selection." }
            val name = checkedSegment(documentName(uri))
            val reported = resolver.getType(uri)
            require(reported != DocumentsContract.Document.MIME_TYPE_DIR) { "Use Add folder for a folder selection." }
            val mime = canonicalMime(name, reported) ?: throw IOException("Choose audio, video or pictures. Unsupported item: $name")
            val path = relativePath(uri, name)
            selected[sourceKey(uri)] = selected(uri, name, mime, path)
        }
        // A direct document grant normally does not authorize siblings. Never manufacture
        // parent access: cover discovery here uses only already-readable tree grants.
        val grants = resolver.persistedUriPermissions.filter { it.isReadPermission && DocumentsContract.isTreeUri(it.uri) }
            .map { it.uri }.filter { runCatching { requireLocal(it) }.isSuccess }
        val original = selected.values.toList()
        val coverCache = HashMap<String, List<SelectedMediaSource>>()
        original.filter { it.mime.startsWith("audio/") || it.mime.startsWith("video/") }.forEach { source ->
            grants.filter { it.authority == source.uri.authority }.forEach { tree ->
                val cacheKey = tree.toString() + "|" + (source.relativePath?.substringBeforeLast('/', "") ?: source.uri.toString())
                coverCache.getOrPut(cacheKey) { coversWithinGrant(source, tree) }.forEach { cover ->
                    val key = sourceKey(cover.uri)
                    if (selected.size >= MAX_ITEMS && key !in selected) throw IOException("The selection and covers exceed $MAX_ITEMS files.")
                    selected.putIfAbsent(key, cover)
                }
            }
        }
        return finish(selected.values.toList())
    }

    private fun coversWithinGrant(source: SelectedMediaSource, tree: Uri): List<SelectedMediaSource> {
        if (tree.authority != "com.android.externalstorage.documents" || source.relativePath == null) return emptyList()
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val fileId = try { DocumentsContract.getDocumentId(source.uri) } catch (_: Exception) { return emptyList() }
        if (fileId == rootId || !(fileId.startsWith("$rootId/") || rootId.endsWith(':') && fileId.startsWith(rootId))) return emptyList()
        var parentId = fileId.substringBeforeLast('/', "")
        if (parentId.isEmpty()) parentId = fileId.substringBefore(':') + ":"
        val covers = mutableListOf<SelectedMediaSource>()
        var levels = 0
        while (parentId == rootId || parentId.startsWith("$rootId/") || rootId.endsWith(':') && parentId.startsWith(rootId)) {
            checkInterrupted()
            if (++levels > 32) throw IOException("The cover search exceeds the folder depth limit.")
            try {
                var scanned = 0
                children(tree, parentId) { child ->
                    require(++scanned <= MAX_ITEMS) { "The cover folder contains too many items." }
                    if (child.mime == DocumentsContract.Document.MIME_TYPE_DIR) return@children
                    if (!child.name.equals("cover.jpg", true) && !child.name.equals("cover.png", true)) return@children
                    val name = checkedSegment(child.name)
                    val mime = canonicalMime(name, child.mime) ?: return@children
                    if (!mime.startsWith("image/")) return@children
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, child.id)
                    val path = externalRelativePath(uri)?.let { checkedPath(it, name) } ?: return@children
                    covers += SelectedMediaSource(uri, name, mime, path)
                }
            } catch (_: SecurityException) {
                // A stale or narrower grant does not turn an explicit file pick into failure.
                break
            } catch (failure: IOException) {
                if (Thread.currentThread().isInterrupted) throw failure
                break
            } catch (_: UnsupportedOperationException) {
                break
            }
            if (covers.isNotEmpty()) break // The nearest readable cover folder wins.
            if (parentId == rootId) break
            parentId = parentId.substringBeforeLast('/', "").ifEmpty { rootId }
        }
        return covers
    }

    private fun selected(uri: Uri, name: String, mime: String, path: String?): SelectedMediaSource {
        var track: Int? = null; var disc: Int? = null
        if (mime.startsWith("audio/") || mime.startsWith("video/")) {
            checkInterrupted()
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                track = MediaLibraryIndex.tagNumber(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER))
                disc = MediaLibraryIndex.tagNumber(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER))
            } catch (_: Exception) {
                // Unsupported tags/codecs retain a deterministic filename-based track order.
            } finally { try { retriever.release() } catch (_: Exception) { } }
            checkInterrupted()
        }
        return SelectedMediaSource(uri, name, mime, path, track ?: MediaLibraryIndex.trackPrefix(name), disc)
    }

    private fun relativePath(uri: Uri, name: String): String? {
        externalRelativePath(uri)?.let { return checkedPath(it, name) }
        if (Build.VERSION.SDK_INT >= 29 && uri.authority == "media") {
            try {
                resolver.query(uri, arrayOf("relative_path"), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst() && !cursor.isNull(0)) {
                        val folder = cursor.getString(0).trimEnd('/')
                        return checkedPath(listOf(folder, name).filter { it.isNotEmpty() }.joinToString("/"), name)
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }

    private fun externalRelativePath(uri: Uri): String? {
        if (uri.authority != "com.android.externalstorage.documents") return null
        val id = try { DocumentsContract.getDocumentId(uri) } catch (_: Exception) { return null }
        if (':' !in id) return null
        return Normalizer.normalize(id.substringAfter(':'), Normalizer.Form.NFC)
    }

    private fun children(tree: Uri, parentId: String, consume: (Child) -> Unit) {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        requireLocal(uri)
        resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                checkInterrupted()
                if (cursor.isNull(0) || cursor.isNull(1)) throw IOException("A folder item has no safe identity or filename.")
                consume(Child(cursor.getString(0), cursor.getString(1), if (cursor.isNull(2)) null else cursor.getString(2)))
            }
        } ?: throw IOException("The selected folder is no longer readable.")
    }

    private fun documentName(uri: Uri): String = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getString(0) else null
    } ?: throw IOException("The selected item has no readable filename.")

    private fun retainGrant(uri: Uri) {
        try { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
    }
    private fun sourceKey(uri: Uri): String = try {
        if (DocumentsContract.isDocumentUri(context, uri)) uri.authority + "|" + DocumentsContract.getDocumentId(uri) else uri.toString()
    } catch (_: Exception) { uri.toString() }
    private fun requireLocal(uri: Uri) {
        require(uri.scheme == "content") { "Choose media through the local Android storage picker." }
        LocalMediaSourcePolicy.requireLocal(uri.authority.orEmpty(), uri.path.orEmpty())
    }
    private fun finish(entries: List<SelectedMediaSource>): List<SelectedMediaSource> {
        require(entries.isNotEmpty()) { "No supported music, video or picture files were found in this selection." }
        require(entries.size <= MAX_ITEMS) { "Choose at most $MAX_ITEMS files." }
        return entries.sortedWith { a, b -> MediaLibraryIndex.naturalCompare(a.relativePath ?: a.name, b.relativePath ?: b.name) }
    }
    private fun checkedSegment(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFC).also { name ->
        require(name.isNotBlank() && name.length <= 240 && name !in setOf(".", "..") && name.none { it == '/' || it == '\\' || it.code < 32 || it.code == 127 }) { "A selected media filename or folder is unsafe." }
    }
    private fun checkedPath(value: String, name: String): String = Normalizer.normalize(value, Normalizer.Form.NFC).also { path ->
        val segments = path.split('/')
        require(path.isNotBlank() && path.length <= 2048 && !path.startsWith('/') && !path.endsWith('/') && segments.size <= 32 && segments.last() == name) { "The selected media path is too deep or unsafe." }
        segments.forEach(::checkedSegment)
    }
    private fun canonicalMime(name: String, reported: String?): String? {
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (extension in setOf("apk", "apkm", "apks", "xapk", "aab", "dex", "odex", "vdex", "jar", "exe", "dshare", "dmpa")) return null
        val mime = when (extension) {
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"
            else -> reported?.lowercase(Locale.ROOT)?.takeIf { it.substringBefore('/') in setOf("audio", "video", "image") }
                ?: when (extension) {
                    "flac" -> "audio/flac"; "wav" -> "audio/wav"; "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "aac" -> "audio/aac"
                    "ogg", "opus" -> "audio/ogg"; "aif", "aiff" -> "audio/aiff"
                    "mp4", "m4v" -> "video/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"
                    "webp" -> "image/webp"; "gif" -> "image/gif"; "heic", "heif" -> "image/heif"; "avif" -> "image/avif"
                    else -> null
                }
        } ?: return null
        return mime.takeIf { Regex("(?:audio|video|image)/[a-z0-9!#$&^_.+\\-]+").matches(it) }
    }
    private data class Child(val id: String, val name: String, val mime: String?)
    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Media selection cancelled.") }

    companion object {
        private const val MAX_ITEMS = 10_000
        fun fromFolder(context: Context, tree: Uri): List<SelectedMediaSource> = MediaFolderImporter(context).fromFolder(tree)
        fun fromUris(context: Context, uris: List<Uri>): List<SelectedMediaSource> = MediaFolderImporter(context).fromUris(uris)
    }
}
