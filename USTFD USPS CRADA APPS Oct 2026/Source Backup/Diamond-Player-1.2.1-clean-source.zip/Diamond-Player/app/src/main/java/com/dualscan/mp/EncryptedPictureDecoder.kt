package com.dualscan.mp

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.dualscan.mp.core.MediaEntry
import com.dualscan.mp.core.UnlockedMediaArray
import java.io.IOException
import java.io.InputStream

/** Decodes a bounded preview from authenticated reads; no plaintext file or image cache. */
object EncryptedPictureDecoder {
    fun decode(array: UnlockedMediaArray, entry: MediaEntry): Bitmap = decode(SingleMediaLibrary(array, false), entry)
    fun decode(array: ReadableMediaLibrary, entry: MediaEntry): Bitmap {
        require(entry.mimeType.startsWith("image/")) { "Choose a picture." }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        EntryInputStream(array, entry).use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Unsupported picture." }
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return EntryInputStream(array, entry).use { BitmapFactory.decodeStream(it, null, options) }
            ?: throw IOException("Unsupported picture.")
    }
    private class EntryInputStream(private val array: ReadableMediaLibrary, private val entry: MediaEntry) : InputStream() {
        private var position = 0L
        override fun read(): Int { val one = ByteArray(1); return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 255 }
        override fun read(buffer: ByteArray, offset: Int, count: Int): Int { val n = array.readAt(entry.id, position, buffer, offset, count); if (n > 0) position += n; return n }
    }
}
