package com.dualscan.mp.audio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class NativeQueueItem(val uri: String, val name: String)

data class NativePlaybackState(
    val queue: List<NativeQueueItem> = emptyList(),
    val queueIndex: Int = 0,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val positionUs: Long = 0,
    val durationUs: Long = 0,
    val source: NativeTrackInfo? = null,
    val decodedPcmFormat: PcmFormat? = null,
    val rawDecoderFormat: PcmFormat? = null,
    val pcmFormat: PcmFormat? = null,
    val selectedDeviceId: Int? = null,
    val actualRoute: String = "None — playback stopped",
    val strictUsb: Boolean = true,
    val bitPerfectContractActive: Boolean = false,
    val resourcesReleased: Boolean = true,
    val devices: List<NativeOutputDevice> = emptyList(),
    val status: String = "Choose audio files to begin.",
    val error: String? = null,
    val audioTrackSessionId: Int = 0,
    val outputGeneration: Long = 0,
    val gaplessTransitions: Int = 0,
    val outputFramesWritten: Long = 0,
    val outputUnderrunCount: Int = 0,
    val nextTrackReady: Boolean = false
) {
    val title: String get() = queue.getOrNull(queueIndex)?.name ?: "Diamond™ Player"
}

object NativePlaybackStore {
    var state by mutableStateOf(NativePlaybackState())
        internal set
    /** Activity-owned WebView handshake. Null when that WebView has been destroyed. */
    internal var pauseWebAudio: (((() -> Unit)) -> Unit)? = null
}
