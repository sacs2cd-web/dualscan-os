package com.dualscan.mp

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.IOException
import java.io.InputStream
import java.util.Locale

/** Reads only an explicitly selected shared folder. It neither decrypts nor copies media. */
object SharedEncryptedLibrary {
    data class Document(val uri: Uri, val displayName: String, val relativePath: String, val sizeBytes: Long?)
    data class Folder(val uri: Uri, val title: String, val documents: List<Document>)

    /** Run on an IO worker. The caller retains the user's read-only SAF tree grant. */
    fun scan(context: Context, tree: Uri): Folder {
        require(tree.scheme == "content" && DocumentsContract.isTreeUri(tree)) { "Choose a shared media folder through Android's folder picker." }
        LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
        require(tree.authority == UsbAccessPolicy.AUTHORITY) { "Choose a folder on this device or an attached USB-C drive." }
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val primary = rootId.substringBefore(':').equals("primary", true)
        SharedLibraryRules.requireRoot(rootId, primary)
        if (!primary) UsbStorageAccess.requireUsbDocument(context, tree)
        val resolver = context.contentResolver
        val root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        val title = resolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { cursor ->
            require(cursor.moveToFirst() && !cursor.isNull(0)) { "The selected media folder is unavailable." }
            require(cursor.getString(1) == DocumentsContract.Document.MIME_TYPE_DIR) { "Choose a folder containing encrypted media files." }
            SharedLibraryRules.segment(cursor.getString(0))
        } ?: throw IOException("The selected media folder is unavailable.")
        val base = rootId.substringAfter(':').ifEmpty { title }
        val scanner = SharedLibraryWalker(
            children = { parent, consume ->
                val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parent)
                resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { cursor ->
                    while (cursor.moveToNext()) {
                        SharedLibraryRules.interrupted()
                        if (cursor.isNull(0) || cursor.isNull(1)) throw IOException("A shared folder item has no readable identity or name.")
                        consume(SharedLibraryChild(cursor.getString(0), cursor.getString(1),
                            !cursor.isNull(2) && cursor.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR,
                            if (cursor.isNull(3)) null else cursor.getLong(3).takeIf { it >= 0 }))
                    }
                } ?: throw IOException("The selected folder is no longer readable. Reconnect the drive or choose the folder again.")
            },
            header = { id ->
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                resolver.openInputStream(uri)?.use(SharedLibraryRules::readHeader)
                    ?: throw IOException("An encrypted media file could not be read. Reconnect the drive or choose the folder again.")
            })
        val documents = scanner.scan(rootId, base).map { file ->
            Document(DocumentsContract.buildDocumentUriUsingTree(tree, file.id), file.name, file.path.removePrefix("$base/"), file.size)
        }
        return Folder(tree, title, documents)
    }
}

internal data class SharedLibraryChild(val id: String, val name: String, val directory: Boolean, val size: Long?)
internal data class SharedLibraryFile(val id: String, val name: String, val path: String, val size: Long?)

/** The provider-independent walker is bounded before opening each candidate file. */
internal class SharedLibraryWalker(
    private val children: (String, (SharedLibraryChild) -> Unit) -> Unit,
    private val header: (String) -> ByteArray
) {
    fun scan(rootId: String, basePath: String): List<SharedLibraryFile> {
        val visited = HashSet<String>(); val files = LinkedHashMap<String, SharedLibraryFile>(); var examined = 0
        fun walk(id: String, path: String, depth: Int) {
            SharedLibraryRules.interrupted()
            require(depth <= 32 && visited.add(id)) { "The selected media folder is too deep or contains a repeated directory." }
            children(id) { child ->
                SharedLibraryRules.interrupted()
                require(++examined <= 10_000) { "Choose a shared folder containing at most 10,000 items." }
                val name = SharedLibraryRules.segment(child.name)
                if (name.startsWith('.')) return@children
                SharedLibraryRules.requireDescendant(rootId, child.id)
                val next = SharedLibraryRules.path("$path/$name")
                if (SharedLibraryRules.privatePath(child.id.substringAfter(':')) || SharedLibraryRules.privatePath(next)) return@children
                if (child.directory) walk(child.id, next, depth + 1)
                else if (SharedLibraryRules.candidate(name) && (child.size == null || child.size >= 8) && child.id !in files && SharedLibraryRules.supportedHeader(header(child.id))) {
                    files[child.id] = SharedLibraryFile(child.id, name, next, child.size)
                }
            }
        }
        SharedLibraryRules.path(basePath)
        walk(rootId, basePath, 0)
        return files.values.sortedWith { a, b ->
            MediaLibraryIndex.naturalCompare(a.path, b.path).takeUnless { it == 0 }
                ?: a.path.compareTo(b.path).takeUnless { it == 0 } ?: a.id.compareTo(b.id)
        }
    }
}

internal object SharedLibraryRules {
    fun candidate(name: String): Boolean = name.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("diamond", "dshare", "dmpa")
    fun supportedHeader(bytes: ByteArray): Boolean = bytes.size == 8 &&
        (bytes.contentEquals("DSMP0001".toByteArray(Charsets.US_ASCII)) || bytes.contentEquals("DSMP0002".toByteArray(Charsets.US_ASCII)))
    fun readHeader(input: InputStream): ByteArray {
        val buffer = ByteArray(8); var count = 0
        while (count < buffer.size) {
            interrupted(); val n = input.read(buffer, count, buffer.size - count)
            if (n < 0) break
            if (n == 0) throw IOException("The storage provider stopped producing encrypted media data.")
            count += n
        }
        return buffer.copyOf(count)
    }
    fun requireRoot(id: String, primary: Boolean) {
        require(':' in id && id.substringBefore(':').isNotBlank()) { "Choose a readable shared-storage folder." }
        val relative = id.substringAfter(':')
        require(!primary || relative.isNotEmpty()) { "Choose a shared folder such as Music, Pictures or Movies, rather than the storage root." }
        if (relative.isNotEmpty()) path(relative)
        require(!relative.split('/').any { it.startsWith('.') } && !privatePath(relative)) { "Choose an accessible shared media folder outside Android's private app directories." }
    }
    fun requireDescendant(root: String, id: String) {
        require(id.startsWith(if (root.endsWith(':')) root else "$root/") && id != root) { "The provider returned an item outside the selected shared folder." }
        path(id.substringAfter(':'))
    }
    fun segment(name: String): String = name.also {
        require(it.isNotBlank() && it.length <= 240 && it !in setOf(".", "..") && it.none { c -> c == '/' || c == '\\' || c.code < 32 || c.code == 127 }) { "A shared media filename or folder is unsafe." }
    }
    fun path(value: String): String = value.also {
        val parts = it.split('/')
        require(it.isNotBlank() && it.length <= 2048 && parts.size <= 32) { "The selected media folder path is too long or too deep." }
        parts.forEach(::segment)
    }
    fun privatePath(value: String): Boolean {
        val parts = value.split('/').map { it.lowercase(Locale.ROOT) }
        return parts.zipWithNext().any { (a, b) -> a == "android" && b in setOf("data", "obb", "sandbox") }
    }
    fun interrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Encrypted media folder scan cancelled.") }
}
