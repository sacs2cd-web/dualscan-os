package com.dualscan.mp

import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaCatalog
import com.dualscan.mp.core.MediaEntry
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.mp.core.RandomAccessSource
import com.dualscan.mp.core.UnlockedMediaArray
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.UUID

/** A read-only library. Decrypted bytes go to caller memory, never to a staging file. */
interface ReadableMediaLibrary : Closeable {
    val catalog: MediaCatalog
    fun readAt(entryId: String, position: Long, target: ByteArray, targetOffset: Int, count: Int): Int
    fun openEntry(entryId: String): InputStream = object : InputStream() {
        private var position = 0L
        private var closed = false
        override fun read(): Int {
            val one = ByteArray(1)
            return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 255
        }
        override fun read(target: ByteArray, offset: Int, count: Int): Int {
            if (closed) throw IOException("The entry stream is closed.")
            val size = readAt(entryId, position, target, offset, count)
            if (size > 0) position += size
            return size
        }
        override fun close() { closed = true }
    }
}

/** Single-file compatibility; borrowed wrappers never close a caller-owned array. */
class SingleMediaLibrary(private val array: UnlockedMediaArray, private val ownsArray: Boolean = true) : ReadableMediaLibrary {
    override val catalog get() = array.catalog
    override fun readAt(entryId: String, position: Long, target: ByteArray, targetOffset: Int, count: Int) =
        array.readAt(entryId, position, target, targetOffset, count)
    override fun openEntry(entryId: String) = array.openEntry(entryId)
    override fun close() { if (ownsArray) array.close() }
}

/** Stable identity is the granted document URI; relativePath includes its scan-root namespace. */
data class EncryptedLibraryDocument(val stableId: String, val relativePath: String, val open: () -> RandomAccessSource)
data class RejectedLibraryDocument(val document: EncryptedLibraryDocument, val message: String)

/**
 * One visible queue spans separately encrypted files. Discovery retains metadata only.
 * A bounded access-order pool keeps current/next/cover sources ready. Every read holds
 * the pool monitor until complete, so eviction cannot close a source being decoded.
 * Proxy FDs refer to this library, not to an evictable underlying encrypted FD.
 */
class CompositeMediaLibrary private constructor(
    override val catalog: MediaCatalog,
    private val routes: Map<String, Route>,
    private val documents: List<EncryptedLibraryDocument>,
    private val containers: Map<String, Container>,
    val lockedDocuments: List<EncryptedLibraryDocument>,
    val rejectedDocuments: List<RejectedLibraryDocument>,
    private val maxOpenSources: Int
) : ReadableMediaLibrary {
    private data class Container(val document: EncryptedLibraryDocument, val catalog: MediaCatalog, val encryptedBytes: Long, val password: CharArray?)
    private data class Route(val container: Container, val originalEntryId: String)
    private val opened = LinkedHashMap<String, UnlockedMediaArray>(4, 0.75f, true)
    private var closed = false

    @Synchronized override fun readAt(entryId: String, position: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
        if (closed) throw IOException("The library is closed.")
        val route = routes[entryId] ?: throw IOException("The media item is not in this library.")
        val key = route.container.document.stableId
        val array = opened[key] ?: reopen(route.container).also { opened[key] = it }
        return try { array.readAt(route.originalEntryId, position, target, targetOffset, count) }
        catch (failure: Throwable) {
            opened.remove(key)?.close()
            throw failure
        }
    }

    private fun reopen(container: Container): UnlockedMediaArray {
        while (opened.size >= maxOpenSources) {
            val eldest = opened.entries.iterator()
            val entry = eldest.next(); eldest.remove(); entry.value.close()
        }
        val array = MediaArray.open(container.document.open(), container.password)
        if (array.catalog.copy(backupMetadata = null) != container.catalog || array.encryptedSize != container.encryptedBytes) {
            array.close()
            throw IOException("An encrypted file changed. Open the folder again.")
        }
        return array
    }

    /** Exposed for bounded-resource regression checks; contains no key or file contents. */
    val openSourceCount: Int @Synchronized get() = opened.size

    /** Returns a new independent session; the caller replaces/closes this session only on success. */
    fun unlock(password: CharArray): CompositeMediaLibrary = rediscover(catalog.title, documents, password)

    /** Add/rescan granted folders while retaining already-unlocked per-file session credentials. */
    fun withDocuments(title: String, documents: List<EncryptedLibraryDocument>): CompositeMediaLibrary = rediscover(title, documents, null)

    private fun rediscover(title: String, documents: List<EncryptedLibraryDocument>, candidatePassword: CharArray?): CompositeMediaLibrary {
        val credentials = synchronized(this) {
            if (closed) throw IOException("The library is closed.")
            containers.mapNotNull { (id, value) -> value.password?.copyOf()?.let { id to it } }.toMap()
        }
        return try { discover(title, documents, candidatePassword, maxOpenSources, credentials) }
        finally { credentials.values.forEach { it.fill('\u0000') } }
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        opened.values.forEach { runCatching { it.close() } }; opened.clear()
        containers.values.forEach { it.password?.fill('\u0000') }
    }

    companion object {
        fun open(title: String, documents: List<EncryptedLibraryDocument>, password: CharArray? = null,
                 maxOpenSources: Int = 4): CompositeMediaLibrary = discover(title, documents, password, maxOpenSources, emptyMap())

        private fun discover(title: String, documents: List<EncryptedLibraryDocument>, password: CharArray?,
                             maxOpenSources: Int, credentials: Map<String, CharArray>): CompositeMediaLibrary {
            require(maxOpenSources in 2..8) { "Choose a bounded library source pool." }
            require(documents.size <= MediaArray.MAX_ENTRIES) { "Choose at most ${MediaArray.MAX_ENTRIES} encrypted files." }
            require(documents.map { it.stableId }.toSet().size == documents.size) { "The encrypted file selection contains duplicates." }
            val candidatePassword = password?.copyOf()
            val containers = LinkedHashMap<String, Container>()
            try {
                val entries = ArrayList<MediaEntry>()
                val routes = LinkedHashMap<String, Route>()
                val locked = ArrayList<EncryptedLibraryDocument>()
                val rejected = ArrayList<RejectedLibraryDocument>()
                for (document in documents) {
                    if (Thread.currentThread().isInterrupted) throw IOException("Folder opening was interrupted.")
                    var needsPassword = false
                    try {
                        require(document.stableId.isNotBlank()) { "An encrypted file has no stable identity." }
                        requireSafePath(document.relativePath)
                        val secret = credentials[document.stableId] ?: candidatePassword
                        val unlocked = try { MediaArray.open(document.open()) }
                        catch (failure: PasswordRequiredException) {
                            needsPassword = true
                            if (secret == null) throw failure
                            MediaArray.open(document.open(), secret)
                        }
                        unlocked.use { array ->
                            require(entries.size + array.catalog.entries.size <= MediaArray.MAX_ENTRIES) { "The folder contains too many media entries." }
                            // Per-file backup declarations can be 8 MiB. The folder view needs
                            // only media identities, not thousands of retained backup objects.
                            val container = Container(document, array.catalog.copy(backupMetadata = null), array.encryptedSize,
                                if (array.passwordProtected) secret?.copyOf() else null)
                            containers[document.stableId] = container
                            array.catalog.entries.forEach { original ->
                                val alias = alias(document.stableId, array.catalog.id, original.id)
                                val physicalParent = document.relativePath.substringBeforeLast('/', "")
                                val path = if (array.catalog.entries.size == 1) join(physicalParent, original.displayName)
                                else join(join(physicalParent, document.relativePath.substringAfterLast('/')), original.relativePath ?: original.displayName)
                                entries += original.copy(id = alias, relativePath = path)
                                check(routes.put(alias, Route(container, original.id)) == null) { "Duplicate encrypted item identity." }
                            }
                        }
                    } catch (_: PasswordRequiredException) {
                        locked += document
                    } catch (failure: Exception) {
                        if (Thread.currentThread().isInterrupted) throw failure
                        if (needsPassword) locked += document
                        else rejected += RejectedLibraryDocument(document, failure.message ?: "This encrypted file could not be opened.")
                    }
                }
                val id = UUID.nameUUIDFromBytes(documents.map { it.stableId }.sorted().joinToString("\u0000").toByteArray(Charsets.UTF_8)).toString()
                return CompositeMediaLibrary(MediaCatalog(id, title.trim().ifBlank { "Media folder" }, Collections.unmodifiableList(entries)),
                    Collections.unmodifiableMap(routes), documents.toList(), Collections.unmodifiableMap(containers),
                    Collections.unmodifiableList(locked), Collections.unmodifiableList(rejected), maxOpenSources)
            } catch (failure: Throwable) { containers.values.forEach { it.password?.fill('\u0000') }; throw failure }
            finally { candidatePassword?.fill('\u0000') }
        }

        private fun alias(source: String, catalog: String, entry: String): String = MessageDigest.getInstance("SHA-256")
            .digest("$source\u0000$catalog\u0000$entry".toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 255) }
        private fun join(parent: String, name: String) = if (parent.isEmpty()) name else "$parent/$name"
        private fun requireSafePath(path: String) {
            require(path.length in 1..4096 && !path.startsWith('/') && '\\' !in path &&
                path.split('/').all { it.isNotBlank() && it !in setOf(".", "..") && it.none(Char::isISOControl) }) { "An encrypted file has an unsafe folder path." }
        }
    }
}
