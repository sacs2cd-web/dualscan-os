@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioRouting
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioOutput
import androidx.media3.exoplayer.audio.AudioOutputProvider
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.AudioTrackAudioOutput
import androidx.media3.exoplayer.audio.AudioTrackAudioOutputProvider
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioOutputProvider

/** Observes the actual Media3 AudioTrack route without selecting an output or altering PCM. */
class Media3RouteReporter(context: Context, private val publish: (String) -> Unit) : AutoCloseable {
    private val main = Handler(Looper.getMainLooper())
    private val monitor = Any()
    private var active: AudioTrack? = null
    private var listener: AudioRouting.OnRoutingChangedListener? = null
    private var closed = false
    val renderersFactory = object : DefaultRenderersFactory(context) {
        override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioOutputPlaybackParameters: Boolean): AudioSink {
            val provider = object : ForwardingAudioOutputProvider(AudioTrackAudioOutputProvider.Builder(context).build()) {
                override fun getAudioOutput(config: AudioOutputProvider.OutputConfig): AudioOutput {
                    val output = super.getAudioOutput(config)
                    if (output is AudioTrackAudioOutput) attach(output)
                    return output
                }
            }
            return DefaultAudioSink.Builder(context).setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioOutputPlaybackParameters(enableAudioOutputPlaybackParameters)
                .setAudioOutputProvider(provider).build()
        }
    }
    private fun attach(output: AudioTrackAudioOutput) {
        val track = output.audioTrack
        synchronized(monitor) {
            if (closed) return
            detachLocked()
            val callback = AudioRouting.OnRoutingChangedListener { routing -> if (routing === track) report(track) }
            active = track; listener = callback
            track.addOnRoutingChangedListener(callback, main)
        }
        output.addListener(object : AudioOutput.Listener {
            override fun onPositionAdvancing(playoutStartSystemTimeMs: Long) { report(track) }
            override fun onOffloadDataRequest() { }
            override fun onOffloadPresentationEnded() { }
            override fun onUnderrun() { }
            override fun onReleased() { synchronized(monitor) { if (active === track) detachLocked() } }
        })
        report(track)
    }
    fun refresh() { synchronized(monitor) { active }?.let(::report) }
    private fun report(track: AudioTrack) {
        val label = synchronized(monitor) {
            if (closed || active !== track) return
            when (try { track.routedDevice?.type } catch (_: IllegalStateException) { null }) {
                AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB DAC"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_BLE_BROADCAST -> "Bluetooth"
                else -> "Android"
            }
        }
        main.post { synchronized(monitor) { if (!closed && active === track) publish(label) } }
    }
    private fun detachLocked() {
        val track = active; val callback = listener
        if (track != null && callback != null) try { track.removeOnRoutingChangedListener(callback) } catch (_: IllegalStateException) { }
        active = null; listener = null
    }
    override fun close() { synchronized(monitor) { closed = true; detachLocked() }; main.removeCallbacksAndMessages(null) }
}
