package com.dualscan.mp

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.dualscan.mp.core.RandomAccessSource
import java.io.IOException
import java.nio.ByteBuffer

/** Owns a local provider FD; positional reads never materialize plaintext or copy the container. */
class SafRandomAccessSource(context: Context, uri: Uri) : RandomAccessSource {
    private val stream: ParcelFileDescriptor.AutoCloseInputStream
    override val size: Long
    init {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("This file cannot be opened.")
        try {
            size = descriptor.statSize
            require(size > 0) { "Choose a complete, seekable collection file." }
            stream = ParcelFileDescriptor.AutoCloseInputStream(descriptor)
            stream.channel.position(0)
        } catch (failure: Exception) { descriptor.close(); throw failure }
    }
    @Synchronized override fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
        require(offset >= 0 && targetOffset >= 0 && count >= 0 && targetOffset <= target.size - count)
        if (count == 0) return 0
        if (offset >= size) return -1
        if (Thread.currentThread().isInterrupted) throw IOException("Read interrupted.")
        return stream.channel.read(ByteBuffer.wrap(target, targetOffset, minOf(count.toLong(), size - offset).toInt()), offset)
    }
    @Synchronized override fun close() { stream.close() }
}
