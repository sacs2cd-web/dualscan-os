package com.dualscan.mp

import com.dualscan.mp.core.MediaEntry
import java.text.Normalizer
import java.util.Locale

enum class MediaSortOrder { TRACKS, FOLDERS, NAME }

/** Deterministic library ordering, independent of provider enumeration and import order. */
object MediaLibraryIndex {
    /** Share images may also contain documents and firmware; only media enters playback queues. */
    fun playable(entries: List<MediaEntry>): List<MediaEntry> = entries.filter(::isPlayable)
    fun isPlayable(entry: MediaEntry): Boolean = entry.mimeType.startsWith("audio/") ||
        entry.mimeType.startsWith("video/") || entry.mimeType.startsWith("image/")

    fun sorted(entries: List<MediaEntry>, order: MediaSortOrder): List<MediaEntry> = entries.sortedWith { left, right ->
        val compared = when (order) {
            MediaSortOrder.TRACKS -> comparePaths(parent(left), parent(right)).takeUnless { it == 0 }
                ?: compareValues(left.discNumber ?: 1, right.discNumber ?: 1).takeUnless { it == 0 }
                ?: compareValues(left.trackNumber ?: trackPrefix(left.displayName) ?: Int.MAX_VALUE,
                    right.trackNumber ?: trackPrefix(right.displayName) ?: Int.MAX_VALUE).takeUnless { it == 0 }
                ?: naturalCompare(left.displayName, right.displayName)
            MediaSortOrder.FOLDERS -> comparePaths(path(left), path(right))
            MediaSortOrder.NAME -> naturalCompare(left.displayName, right.displayName)
        }
        compared.takeUnless { it == 0 } ?: comparePaths(path(left), path(right)).takeUnless { it == 0 }
            ?: path(left).compareTo(path(right)).takeUnless { it == 0 } ?: left.id.compareTo(right.id)
    }

    /** A nearest-folder cover wins; JPG wins over PNG only within that same folder. */
    fun coverFor(entry: MediaEntry, entries: List<MediaEntry>): MediaEntry? {
        if (!entry.mimeType.startsWith("audio/") && !entry.mimeType.startsWith("video/")) return null
        val covers = entries.filter { it.mimeType.startsWith("image/") && key(it.displayName) in setOf("cover.jpg", "cover.png") }
        var folder = parent(entry)
        while (true) {
            covers.filter { key(parent(it)) == key(folder) }
                .minWithOrNull(compareBy<MediaEntry> { if (key(it.displayName) == "cover.jpg") 0 else 1 }
                    .thenBy { path(it) }.thenBy { it.id })?.let { return it }
            if (folder.isEmpty()) return null
            folder = folder.substringBeforeLast('/', "")
        }
    }

    internal fun trackPrefix(name: String): Int? = Regex("^\\s*(\\d{1,4})(?:[\\s._)\\]-]+|$)")
        .find(name.substringBeforeLast('.', name))?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 1..9999 }

    internal fun tagNumber(value: String?): Int? = value?.trim()?.substringBefore('/')?.trim()
        ?.takeIf { it.matches(Regex("[0-9]{1,4}")) }?.toIntOrNull()?.takeIf { it in 1..9999 }

    internal fun naturalCompare(left: String, right: String): Int {
        val a = key(left); val b = key(right)
        var i = 0; var j = 0
        while (i < a.length && j < b.length) {
            if (a[i] in '0'..'9' && b[j] in '0'..'9') {
                val startA = i; val startB = j
                while (i < a.length && a[i] in '0'..'9') i++
                while (j < b.length && b[j] in '0'..'9') j++
                val digitsA = a.substring(startA, i).trimStart('0').ifEmpty { "0" }
                val digitsB = b.substring(startB, j).trimStart('0').ifEmpty { "0" }
                val difference = digitsA.length.compareTo(digitsB.length).takeUnless { it == 0 } ?: digitsA.compareTo(digitsB)
                if (difference != 0) return difference
            } else {
                val difference = a[i].compareTo(b[j])
                if (difference != 0) return difference
                i++; j++
            }
        }
        return (a.length - i).compareTo(b.length - j)
    }

    private fun comparePaths(left: String, right: String): Int {
        val a = left.split('/'); val b = right.split('/')
        for (index in 0 until minOf(a.size, b.size)) {
            val compared = naturalCompare(a[index], b[index])
            if (compared != 0) return compared
        }
        return a.size.compareTo(b.size)
    }
    private fun path(entry: MediaEntry) = entry.relativePath ?: entry.displayName
    private fun parent(entry: MediaEntry) = path(entry).substringBeforeLast('/', "")
    private fun key(value: String) = Normalizer.normalize(value, Normalizer.Form.NFC).lowercase(Locale.ROOT)
}
