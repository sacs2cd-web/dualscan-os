package com.dualscan.mp.audio

import java.io.Closeable
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/** One next decoder and a bounded PCM prefix; ownership transfers only after preparation completes. */
internal class PreparedNativeTrack(
    val index: Int,
    val source: NativePcmSource,
    val prefix: ByteBuffer,
    val ended: Boolean
) : Closeable {
    override fun close() {
        runCatching { source.close() }
        wipePcmBuffer(prefix)
    }
}

internal fun wipePcmBuffer(buffer: ByteBuffer) {
    val copy = buffer.duplicate().apply { clear() }
    while (copy.remaining() >= 8) copy.putLong(0)
    while (copy.hasRemaining()) copy.put(0)
}

/**
 * One active preparation and one queued job at most. MediaCodec ownership is
 * sequential: preparation publishes a finished source, then the audio worker
 * becomes its sole reader. Cancellation never closes a decoder being read.
 */
internal class NativeQueuePreparation(private val open: (NativeQueueItem) -> NativePcmSource) : Closeable {
    class Ticket(val index: Int, val item: NativeQueueItem) {
        private var cancelled = false
        private var completed = false
        private var prepared: PreparedNativeTrack? = null
        private var failure: Exception? = null

        @Synchronized fun isCancelled() = cancelled
        fun complete(value: PreparedNativeTrack) {
            val discard = synchronized(this) {
                if (cancelled) true else { prepared = value; completed = true; false }
            }
            if (discard) value.close()
        }
        @Synchronized fun fail(error: Exception) { if (!cancelled) { failure = error; completed = true } }
        @Synchronized fun take(): Result? {
            if (!completed || cancelled) return null
            return Result(prepared, failure).also { prepared = null; completed = false }
        }
        @Synchronized fun isReady() = completed && !cancelled
        fun cancel() {
            val discard = synchronized(this) { cancelled = true; prepared.also { prepared = null } }
            discard?.close()
        }
    }
    data class Result(val prepared: PreparedNativeTrack?, val failure: Exception?)

    private val jobs = ArrayBlockingQueue<Ticket>(1)
    private val retired = ArrayBlockingQueue<NativePcmSource>(2)
    private val lock = Any()
    @Volatile private var running = true
    private var active: Ticket? = null
    private val worker = Thread(::run, "DiamondNextAudio").apply { start() }

    fun prepare(index: Int, item: NativeQueueItem): Ticket {
        check(running)
        jobs.poll()?.cancel()
        return Ticket(index, item).also { check(jobs.offer(it)) }
    }

    fun cancel(ticket: Ticket?) {
        if (ticket == null) return
        ticket.cancel()
        jobs.remove(ticket)
        synchronized(lock) { if (active === ticket) worker.interrupt() }
    }

    /** Retire old decoder off the writer thread after a seamless ownership change. */
    fun retire(source: NativePcmSource) {
        check(retired.offer(source)) { "Audio decoder retirement queue is full." }
    }

    private fun run() {
        try {
            while (running) {
                Thread.interrupted()
                drainRetired()
                val ticket = try { jobs.poll(20, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { continue }
                    ?: continue
                synchronized(lock) { active = ticket }
                try { if (!ticket.isCancelled()) prepareSource(ticket) }
                finally { synchronized(lock) { active = null } }
            }
        } finally {
            jobs.poll()?.cancel()
            drainRetired()
        }
    }

    private fun prepareSource(ticket: Ticket) {
        var source: NativePcmSource? = null
        var prefix: ByteBuffer? = null
        try {
            source = open(ticket.item)
            if (ticket.isCancelled()) return
            val frame = source.format.bytesPerFrame
            val target = maxOf(64L * 1024, source.format.sampleRateHz.toLong() * frame / 4)
                .coerceAtMost(1024L * 1024).toInt()
            prefix = ByteBuffer.allocateDirect(maxOf(frame, target / frame * frame))
            var ended = false
            while (prefix.remaining() >= frame && !ticket.isCancelled()) {
                val count = source.read(prefix)
                if (count < 0) { ended = true; break }
                check(count > 0 && count % frame == 0) { "The next track did not produce complete PCM frames." }
            }
            if (ticket.isCancelled()) return
            prefix.flip()
            val ready = PreparedNativeTrack(ticket.index, source, prefix, ended)
            source = null; prefix = null
            ticket.complete(ready)
        } catch (failure: Exception) {
            ticket.fail(failure)
        } finally {
            runCatching { source?.close() }
            prefix?.let(::wipePcmBuffer)
        }
    }

    private fun drainRetired() {
        while (true) {
            val source = retired.poll() ?: break
            runCatching { source.close() }
        }
    }

    override fun close() {
        running = false
        jobs.poll()?.cancel()
        synchronized(lock) { active?.cancel(); worker.interrupt() }
        worker.join(1500)
    }
}
