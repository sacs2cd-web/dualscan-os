package com.dualscan.mp

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.IOException

class SharedEncryptedLibraryTest {
    private val root = "primary:Music"
    private fun header(version: Int = 2) = "DSMP000$version".toByteArray()
    private fun file(path: String, size: Long? = 300) = SharedLibraryChild("primary:Music/$path", path.substringAfterLast('/'), false, size)
    private fun directory(path: String) = SharedLibraryChild("primary:Music/$path", path.substringAfterLast('/'), true, null)
    private fun scan(tree: Map<String, List<SharedLibraryChild>>, headers: Map<String, ByteArray> = emptyMap(), opened: MutableList<String> = mutableListOf()): List<SharedLibraryFile> =
        SharedLibraryWalker({ id, consume -> tree[id].orEmpty().forEach(consume) }, { id -> opened += id; headers[id] ?: header() }).scan(root, "Music")

    @Test fun scansNestedLooseEncryptedMediaAndSortsNaturalPathsWithoutReadingPlainMedia() {
        val album = directory("Album")
        val opened = mutableListOf<String>()
        val result = scan(mapOf(root to listOf(album, file("ordinary.jpg"), file("notes.txt"), file("wrong.dshare")),
            album.id to listOf(file("Album/10 Song.flac.diamond"), file("Album/2 Song.flac.diamond"), file("Album/cover.jpg.diamond"))),
            mapOf(file("wrong.dshare").id to "PK\u0003\u0004xxxx".toByteArray()), opened)
        assertEquals(listOf("Music/Album/2 Song.flac.diamond", "Music/Album/10 Song.flac.diamond", "Music/Album/cover.jpg.diamond"), result.map { it.path })
        assertTrue(opened.none { it.endsWith("ordinary.jpg") || it.endsWith("notes.txt") })
    }

    @Test fun dotFilesMarkersAndAndroidPrivateDirectoriesAreNeverOpened() {
        val android = directory("Android")
        val opened = mutableListOf<String>()
        val tree = mapOf(root to listOf(file(".nomedia"), file(".private.dshare"), directory(".hidden"), android),
            android.id to listOf(directory("Android/data"), directory("Android/obb"), directory("Android/sandbox"), directory("Android/media")),
            directory("Android/media").id to listOf(file("Android/media/allowed.dshare")),
            directory("Android/data").id to listOf(file("Android/data/secret.dshare")))
        assertEquals(listOf("Music/Android/media/allowed.dshare"), scan(tree, opened = opened).map { it.path })
        assertEquals(listOf(file("Android/media/allowed.dshare").id), opened)
    }

    @Test fun extensionsAloneDoNotAdmitPlainZipPasswordZipUnsupportedOrTruncatedFiles() {
        val names = listOf("plain.dshare", "old.dmpa", "future.dshare", "short.dshare", "good.DMPA", "old-player.dmpa")
        val headers = mapOf(file(names[0]).id to "PK\u0003\u0004xxxx".toByteArray(), file(names[1]).id to "DSHP0001".toByteArray(),
            file(names[2]).id to "DSMP9999".toByteArray(), file(names[3]).id to "DSMP".toByteArray(), file(names[5]).id to header(1))
        assertEquals(setOf("good.DMPA", "old-player.dmpa"), scan(mapOf(root to names.map { file(it) }), headers).map { it.name }.toSet())
    }

    @Test fun knownTooSmallCandidatesAreSkippedWithoutOpeningAndUnknownSizesWork() {
        val opened = mutableListOf<String>()
        val result = scan(mapOf(root to listOf(file("empty.dshare", 0), file("small.dshare", 7), file("unknown.dshare", null))), opened = opened)
        assertEquals(listOf("unknown.dshare"), result.map { it.name }); assertEquals(1, opened.size); assertNull(result.single().size)
    }

    @Test fun duplicateProviderFileRowsDoNotDuplicateTheLibrary() {
        val item = file("photo.jpg.dshare"); val opened = mutableListOf<String>()
        assertEquals(1, scan(mapOf(root to listOf(item, item)), opened = opened).size); assertEquals(1, opened.size)
    }

    @Test fun escapedIdsUnsafeNamesAndRepeatedDirectoriesStopTheScan() {
        listOf(SharedLibraryChild("primary:Pictures/escape.dshare", "escape.dshare", false, 300),
            SharedLibraryChild("primary:Music/../escape.dshare", "escape.dshare", false, 300),
            file("safe.dshare").copy(name = "../escape.dshare"),
            file("safe.dshare").copy(name = "bad\u0000.dshare")).forEach { item -> rejected { scan(mapOf(root to listOf(item))) } }
        val album = directory("Album"); rejected { scan(mapOf(root to listOf(album, album))) }
    }

    @Test fun rootPoliciesRejectPrimaryRootAndPrivateOrUnsafeTreesButPermitSharedAndUsbRoot() {
        listOf("primary:", "primary:Android/data", "primary:Android/OBB", "primary:.hidden", "primary:/Music", "primary:Music/../data").forEach { id -> rejected { SharedLibraryRules.requireRoot(id, true) } }
        SharedLibraryRules.requireRoot("primary:Pictures/Albums", true)
        SharedLibraryRules.requireRoot("1234-ABCD:", false)
        SharedLibraryRules.requireRoot("primary:Android/media", true)
    }

    @Test fun itemAndDepthBoundsStopHostileOrOversizedProviders() {
        val tooMany = (1..10_001).map { file("plain-$it.txt") }
        rejected { scan(mapOf(root to tooMany)) }
        val tree = LinkedHashMap<String, List<SharedLibraryChild>>(); var parent = root; var path = ""
        repeat(33) { index -> path = if (path.isEmpty()) "folder$index" else "$path/folder$index"; val child = directory(path); tree[parent] = listOf(child); parent = child.id }
        rejected { scan(tree) }
    }

    @Test fun headerReaderConsumesOnlyEightBytesAndClosesNoCallerOwnedStream() {
        val stream = ByteArrayInputStream(header() + ByteArray(1024))
        assertTrue(SharedLibraryRules.supportedHeader(SharedLibraryRules.readHeader(stream)))
        assertEquals(1024, stream.available())
        assertFalse(SharedLibraryRules.supportedHeader(SharedLibraryRules.readHeader(ByteArrayInputStream(header().copyOf(7)))))
    }

    @Test fun cancellationAndProviderFailurePropagateInsteadOfReturningPartialSuccess() {
        try { Thread.currentThread().interrupt(); rejected { scan(mapOf(root to listOf(file("photo.dshare")))) } } finally { Thread.interrupted() }
        rejected { SharedLibraryWalker({ _, _ -> throw IOException("Disconnected") }, { header() }).scan(root, "Music") }
        rejected { SharedLibraryWalker({ _, consume -> consume(file("photo.dshare")) }, { throw IOException("Unreadable") }).scan(root, "Music") }
    }

    private fun rejected(block: () -> Unit) { try { block() } catch (_: Exception) { return }; throw AssertionError("Unsafe shared-folder input was accepted") }
}
