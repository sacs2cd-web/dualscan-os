package com.dualscan.mp

import com.dualscan.mp.core.MediaEntry
import org.junit.Assert.*
import org.junit.Test

class MediaLibraryIndexTest {
    @Test fun shareDocumentsAndFirmwareDoNotEnterPlaybackQueuesOrCounts() {
        val audio = entry("Music/Album/01.wav", mime = "audio/wav")
        val cover = entry("Music/Album/cover.png", mime = "image/png")
        val video = entry("Movies/video.mp4", mime = "video/mp4")
        val document = entry("Documents/notes.txt", mime = "text/plain")
        val firmware = entry("firmware/system.img", mime = "application/octet-stream")
        val app = entry("Downloads/example.apk", mime = "application/vnd.android.package-archive")
        val mixed = listOf(document, audio, firmware, cover, app, video)
        assertEquals(listOf(audio, cover, video), MediaLibraryIndex.playable(mixed))
        assertEquals(cover, MediaLibraryIndex.coverFor(audio, MediaLibraryIndex.playable(mixed)))
        assertTrue(MediaLibraryIndex.playable(listOf(document, firmware, app)).isEmpty())
    }

    @Test fun naturalTrackPrefixesPutTwoBeforeTenWithoutTags() {
        val entries = listOf(entry("album/10 - Finale.flac"), entry("album/2 - Second.flac"), entry("album/01 - Intro.flac"))
        assertEquals(listOf("01 - Intro.flac", "2 - Second.flac", "10 - Finale.flac"),
            MediaLibraryIndex.sorted(entries, MediaSortOrder.TRACKS).map { it.displayName })
    }

    @Test fun authenticatedTrackTagsOverrideAlphabeticAndFilenameOrderWithinAlbum() {
        val entries = listOf(entry("Album/01 - Alphabetic.flac", track = 10), entry("Album/Zebra.flac", track = 2), entry("Album/First.flac", track = 1))
        assertEquals(listOf("First.flac", "Zebra.flac", "01 - Alphabetic.flac"),
            MediaLibraryIndex.sorted(entries, MediaSortOrder.TRACKS).map { it.displayName })
    }

    @Test fun discsThenTracksAreOrderedInsideTheAlbumHierarchy() {
        val entries = listOf(entry("Album B/first.flac", 1, 1), entry("Album A/disc2-first.flac", 1, 2),
            entry("Album A/disc1-tenth.flac", 10, 1), entry("Album A/disc1-second.flac", 2, 1))
        assertEquals(listOf("disc1-second.flac", "disc1-tenth.flac", "disc2-first.flac", "first.flac"),
            MediaLibraryIndex.sorted(entries, MediaSortOrder.TRACKS).map { it.displayName })
    }

    @Test fun nestedDiscFolderNamesUseNumericOrderAndStayWithTheirAlbum() {
        val entries = listOf(entry("Music/Album 10/Disc 1/01.flac"), entry("Music/Album 2/Disc 10/01.flac"), entry("Music/Album 2/Disc 2/01.flac"))
        assertEquals(listOf("Music/Album 2/Disc 2/01.flac", "Music/Album 2/Disc 10/01.flac", "Music/Album 10/Disc 1/01.flac"),
            MediaLibraryIndex.sorted(entries, MediaSortOrder.FOLDERS).map { it.relativePath })
    }

    @Test fun nameSortIgnoresAlbumAndHandlesLongNumericRunsWithoutOverflow() {
        val entries = listOf(entry("A/Track 999999999999999999999999.mp4"), entry("Z/track 10.mp4"), entry("Q/Track 2.mp4"))
        assertEquals(listOf("Track 2.mp4", "track 10.mp4", "Track 999999999999999999999999.mp4"),
            MediaLibraryIndex.sorted(entries, MediaSortOrder.NAME).map { it.displayName })
    }

    @Test fun equalNumericAndCasefoldNamesHaveStableOrderAcrossInputPermutations() {
        val entries = listOf(entry("Album/2 - track.flac"), entry("Album/02 - Track.flac"))
        val forwards = MediaLibraryIndex.sorted(entries, MediaSortOrder.NAME).map { it.relativePath }
        val backwards = MediaLibraryIndex.sorted(entries.reversed(), MediaSortOrder.NAME).map { it.relativePath }
        assertEquals(forwards, backwards)
    }

    @Test fun tagAndFilenameParsersRejectZeroNegativeOverflowAndMalformedValues() {
        assertEquals(2, MediaLibraryIndex.tagNumber(" 02/12 "))
        assertEquals(3, MediaLibraryIndex.tagNumber("3"))
        listOf(null, "", "0", "-1", "10000", "2.5", "two", "1oops", "99999999999999").forEach { assertNull(MediaLibraryIndex.tagNumber(it)) }
        assertEquals(2, MediaLibraryIndex.trackPrefix("02. Track.flac"))
        assertEquals(10, MediaLibraryIndex.trackPrefix("10 - Song.mp3"))
        assertNull(MediaLibraryIndex.trackPrefix("Track 2.flac"))
        assertNull(MediaLibraryIndex.trackPrefix("0 - Invalid.flac"))
    }

    @Test fun sameFolderCaseInsensitiveJpgWinsOverPngRegardlessOfImportOrder() {
        val track = entry("Music/Album/01.flac")
        val png = entry("Music/Album/Cover.PNG", mime = "image/png")
        val jpg = entry("Music/Album/COVER.JPG", mime = "image/jpeg")
        assertEquals(jpg, MediaLibraryIndex.coverFor(track, listOf(png, track, jpg)))
        assertEquals(jpg, MediaLibraryIndex.coverFor(track, listOf(jpg, png, track)))
    }

    @Test fun nearestAncestorPngBeatsMoreDistantJpgForBothMusicAndVideo() {
        val video = entry("Movies/Series/Season 2/Episode 02.mp4", mime = "video/mp4")
        val close = entry("Movies/Series/cover.png", mime = "image/png")
        val distant = entry("Movies/cover.jpg", mime = "image/jpeg")
        val unrelated = entry("Movies/Series 2/cover.jpg", mime = "image/jpeg")
        assertEquals(close, MediaLibraryIndex.coverFor(video, listOf(distant, unrelated, close, video)))
        val song = entry("Music/Artist/Album/Disc 2/02.flac")
        val albumCover = entry("Music/Artist/Album/cover.png", mime = "image/png")
        assertEquals(albumCover, MediaLibraryIndex.coverFor(song, listOf(song, albumCover)))
    }

    @Test fun siblingFolderAndNameLookalikesAreNeverUsedAsCovers() {
        val track = entry("Music/Album/track.flac")
        val covers = listOf(entry("Music/Other/cover.jpg", mime = "image/jpeg"),
            entry("Music/Album/cover.jpg.backup", mime = "image/jpeg"),
            entry("Music/Album/cover.jpg", mime = "audio/mpeg"))
        assertNull(MediaLibraryIndex.coverFor(track, covers))
    }

    @Test fun legacyRootEntriesCanUseRootCoverAndImagesNeverBecomeAudioTracks() {
        val track = entry("track.flac", relative = null)
        val cover = entry("cover.jpg", mime = "image/jpeg", relative = null)
        val all = MediaLibraryIndex.sorted(listOf(cover, track), MediaSortOrder.TRACKS)
        assertEquals(cover, MediaLibraryIndex.coverFor(track, all))
        assertEquals(listOf(track), all.filter { it.mimeType.startsWith("audio/") })
        assertNull(MediaLibraryIndex.coverFor(cover, all))
    }

    private fun entry(path: String, track: Int? = null, disc: Int? = null, mime: String = "audio/flac", relative: String? = path): MediaEntry =
        MediaEntry(path, path.substringAfterLast('/'), mime, relative, 1, "ab".repeat(32), track, disc)
}
