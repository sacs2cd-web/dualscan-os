package com.dualscan.mp

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

class EncryptedCollectionCopyTest {
    @Test fun copiesBothEncryptedFormatsExactlyAndVerifiesTheSavedBytes() {
        for (version in listOf("DSMP0001", "DSMP0002")) {
            val encrypted = version.toByteArray() + ByteArray(300_017) { (it * 37).toByte() }
            val output = ByteArrayOutputStream()
            val receipt = EncryptedCollectionCopy.copy(encrypted.inputStream(), output)
            assertArrayEquals(encrypted, output.toByteArray())
            assertEquals(encrypted.size.toLong(), receipt.sizeBytes)
            EncryptedCollectionCopy.verify(output.toByteArray().inputStream(), receipt)
            val altered = output.toByteArray().apply { this[lastIndex] = (this[lastIndex].toInt() xor 1).toByte() }
            assertRejected { EncryptedCollectionCopy.verify(altered.inputStream(), receipt) }
            assertRejected { EncryptedCollectionCopy.verify(encrypted.copyOf(encrypted.size - 1).inputStream(), receipt) }
        }
    }

    @Test fun rejectsClearPhotosMusicArchivesAndIncompleteHeadersBeforeWritingAnything() {
        for (clear in listOf(byteArrayOf(-119, 80, 78, 71, 13, 10, 26, 10), "RIFFfakeWAVE".toByteArray(),
            "PK\u0003\u0004plain backup".toByteArray(), "DSMP000".toByteArray())) {
            val output = ByteArrayOutputStream()
            assertRejected { EncryptedCollectionCopy.copy(clear.inputStream(), output) }
            assertEquals(0, output.size())
        }
    }

    @Test fun handlesShortAndZeroLengthSourceReadsWithoutLosingCiphertext() {
        val encrypted = "DSMP0002".toByteArray() + ByteArray(51) { it.toByte() }
        val input = object : InputStream() {
            var position = 0; var stall = true
            override fun read(): Int = if (position < encrypted.size) encrypted[position++].toInt() and 255 else -1
            override fun read(target: ByteArray, offset: Int, length: Int): Int {
                if (stall) { stall = false; return 0 }
                stall = true
                if (position == encrypted.size) return -1
                target[offset] = encrypted[position++]; return 1
            }
        }
        val output = ByteArrayOutputStream()
        val copied = EncryptedCollectionCopy.copy(input, output)
        assertArrayEquals(encrypted, output.toByteArray())
        EncryptedCollectionCopy.verify(encrypted.inputStream(), copied)
    }

    @Test fun cancellationStopsTheCopy() {
        val output = ByteArrayOutputStream()
        assertRejected { EncryptedCollectionCopy.copy(("DSMP0002" + "ciphertext").byteInputStream(), output) { throw IOException("Stopped.") } }
        assertEquals(0, output.size())
    }

    private fun assertRejected(action: () -> Unit) {
        try { action(); fail("Expected the copy boundary to reject this operation") } catch (_: IOException) { }
    }
}
