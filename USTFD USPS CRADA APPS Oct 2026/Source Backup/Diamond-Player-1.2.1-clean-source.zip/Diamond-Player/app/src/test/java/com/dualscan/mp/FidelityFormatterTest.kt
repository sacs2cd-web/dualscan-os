package com.dualscan.mp

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Locale

class FidelityFormatterTest {
    @Test fun thirtyTwoBit768KhzIsDisplayedWithoutClampingToCommonDacRates() {
        assertEquals("32-bit 768.0 kHz", FidelityFormatter.source(32, 768000))
        assertEquals("24-bit 192.0 kHz", FidelityFormatter.source(24, 192000))
    }

    @Test fun commonFractionalRatesKeepTheirActualPrecision() {
        assertEquals("16-bit 44.1 kHz", FidelityFormatter.source(16, 44100))
        assertEquals("24-bit 88.2 kHz", FidelityFormatter.source(24, 88200))
        assertEquals("32-bit 352.8 kHz", FidelityFormatter.source(32, 352800))
        assertEquals("24-bit 44.101 kHz", FidelityFormatter.source(24, 44101))
    }

    @Test fun eitherUnknownFieldNeverInventsAFormat() {
        assertEquals("Unavailable", FidelityFormatter.source(null, null))
        assertEquals("Unavailable", FidelityFormatter.source(24, null))
        assertEquals("Unavailable", FidelityFormatter.source(null, 768000))
    }

    @Test fun InvalidMetadataNeverProducesAnInvalidFidelityLabel() {
        assertEquals("Unavailable", FidelityFormatter.source(0, 48000))
        assertEquals("Unavailable", FidelityFormatter.source(-1, 48000))
        assertEquals("Unavailable", FidelityFormatter.source(24, 0))
        assertEquals("Unavailable", FidelityFormatter.source(24, -1))
    }

    @Test fun decimalPointDoesNotDependOnDeviceLocale() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.GERMANY)
            assertEquals("24-bit 44.1 kHz", FidelityFormatter.source(24, 44100))
            assertEquals("32-bit 768.0 kHz", FidelityFormatter.source(32, 768000))
        } finally { Locale.setDefault(previous) }
    }
}
