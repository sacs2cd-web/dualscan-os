package com.dualscan.mp

import com.dualscan.mp.core.FileRandomAccessSource
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import com.dualscan.mp.core.RandomAccessSource
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

class CompositeMediaLibraryTest {
    @get:Rule val temporary = TemporaryFolder()
    private val alive = AtomicInteger()
    private val peak = AtomicInteger()

    private fun item(path: String, bytes: ByteArray, password: CharArray? = null, mime: String = "audio/wav"): Pair<File, EncryptedLibraryDocument> {
        val file = File(temporary.root, "${System.nanoTime()}.dshare")
        val name = path.substringAfterLast('/').removeSuffix(".dshare")
        MediaArray.createPortable(file, "Fixture", listOf(MediaInput(name, mime) { bytes.inputStream() }), password).close()
        return file to EncryptedLibraryDocument(file.path, path) {
            val source = FileRandomAccessSource(file)
            peak.updateAndGet { maxOf(it, alive.incrementAndGet()) }
            object : RandomAccessSource {
                var closed = false
                override val size get() = source.size
                override fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int) = source.readAt(offset, target, targetOffset, count)
                override fun close() { if (!closed) { closed = true; source.close(); alive.decrementAndGet() } }
            }
        }
    }

    @Test fun collidingInternalEntryIdsBecomeStableIndependentLibraryItems() {
        val a = item("Phone/Music/Album/01.wav.dshare", byteArrayOf(1, 2, 3))
        val b = item("Phone/Music/Album/02.wav.dshare", byteArrayOf(4, 5, 6))
        val documents = listOf(a.second, b.second)
        CompositeMediaLibrary.open("Album", documents).use { library ->
            assertEquals(0, alive.get())
            assertEquals(2, library.catalog.entries.map { it.id }.toSet().size)
            assertArrayEquals(byteArrayOf(1, 2, 3), library.openEntry(library.catalog.entries[0].id).use { it.readBytes() })
            assertArrayEquals(byteArrayOf(4, 5, 6), library.openEntry(library.catalog.entries[1].id).use { it.readBytes() })
            CompositeMediaLibrary.open("Album", documents.reversed()).use { reversed ->
                assertEquals(library.catalog.entries.associate { it.displayName to it.id }, reversed.catalog.entries.associate { it.displayName to it.id })
            }
        }
        assertEquals(0, alive.get())
    }

    @Test fun idleDiscoveryAndPlaybackPoolRemainBoundedAcrossManySeparateFiles() {
        val documents = (1..12).map { item("Phone/Music/Album/$it.wav.dshare", ByteArray(4096) { _ -> it.toByte() }).second }
        CompositeMediaLibrary.open("Album", documents, maxOpenSources = 2).use { library ->
            assertEquals(0, alive.get())
            repeat(2) {
                library.catalog.entries.forEachIndexed { index, entry ->
                    assertEquals(index + 1, library.openEntry(entry.id).use { it.read() })
                    assertTrue(library.openSourceCount <= 2)
                    assertTrue(alive.get() <= 2)
                }
            }
        }
        assertTrue(peak.get() <= 2)
        assertEquals(0, alive.get())
    }

    @Test fun separatePasswordsUnlockIncrementallyWithoutLosingEarlierSessionCredentials() {
        val alpha = "Alpha secret 2026".toCharArray(); val beta = "Beta secret 2026".toCharArray()
        val documents = listOf(item("Phone/Music/00.wav.dshare", byteArrayOf(0)).second,
            item("Phone/Music/01.wav.dshare", byteArrayOf(1), alpha).second,
            item("Phone/Music/02.wav.dshare", byteArrayOf(2), beta).second)
        CompositeMediaLibrary.open("Mixed", documents).use { initial ->
            assertEquals(1, initial.catalog.entries.size); assertEquals(2, initial.lockedDocuments.size)
            initial.unlock(alpha).use { first ->
                assertEquals(2, first.catalog.entries.size); assertEquals(1, first.lockedDocuments.size)
                first.unlock(beta).use { both ->
                    alpha.fill('x'); beta.fill('x') // Caller-owned secrets are not the session's buffers.
                    assertEquals(3, both.catalog.entries.size); assertTrue(both.lockedDocuments.isEmpty())
                    assertEquals(listOf(0, 1, 2), both.catalog.entries.map { entry -> both.openEntry(entry.id).use { it.read() } })
                }
                assertEquals(listOf(0, 1), first.catalog.entries.map { entry -> first.openEntry(entry.id).use { it.read() } })
            }
        }
        assertEquals(0, alive.get())
    }

    @Test fun incorrectPasswordDoesNotExposeOrDropLockedFile() {
        val document = item("Phone/Pictures/private.jpg.dshare", byteArrayOf(9), "Correct secret 2026".toCharArray(), "image/jpeg").second
        CompositeMediaLibrary.open("Photos", listOf(document)).use { initial ->
            initial.unlock("Wrong secret 2026".toCharArray()).use { wrong ->
                assertTrue(wrong.catalog.entries.isEmpty()); assertEquals(listOf(document), wrong.lockedDocuments)
                assertTrue(wrong.rejectedDocuments.isEmpty())
            }
            assertEquals(listOf(document), initial.lockedDocuments)
        }
    }

    @Test fun addingAnotherFolderPreservesPreviouslyUnlockedFiles() {
        val first = item("Phone/Music/private.wav.dshare", byteArrayOf(1), "First secret 2026".toCharArray()).second
        val second = item("USB/Music/public.wav.dshare", byteArrayOf(2)).second
        CompositeMediaLibrary.open("Phone", listOf(first)).use { initial ->
            initial.unlock("First secret 2026".toCharArray()).use { unlocked ->
                unlocked.withDocuments("Phone and USB", listOf(first, second)).use { added ->
                    assertTrue(added.lockedDocuments.isEmpty())
                    assertEquals(listOf(1, 2), added.catalog.entries.map { entry -> added.openEntry(entry.id).use { it.read() } })
                }
            }
        }
        assertEquals(0, alive.get())
    }

    @Test fun physicalFolderControlsArtworkAndAlbumTrackHierarchyAcrossContainers() {
        val documents = listOf(item("Phone/Music/Album/10.wav.dshare", byteArrayOf(10)).second,
            item("Phone/Music/Album/02.wav.dshare", byteArrayOf(2)).second,
            item("Phone/Music/Album/cover.png.dshare", byteArrayOf(3), mime = "image/png").second,
            item("USB/Music/Album/cover.jpg.dshare", byteArrayOf(4), mime = "image/jpeg").second)
        CompositeMediaLibrary.open("Media", documents).use { library ->
            val audio = MediaLibraryIndex.sorted(library.catalog.entries.filter { it.mimeType.startsWith("audio/") }, MediaSortOrder.TRACKS)
            assertEquals(listOf("02.wav", "10.wav"), audio.map { it.displayName })
            assertEquals("Phone/Music/Album/cover.png", MediaLibraryIndex.coverFor(audio[0], library.catalog.entries)?.relativePath)
        }
    }

    @Test fun replacedEncryptedFileCannotReuseStaleCatalogRoute() {
        val (file, document) = item("Phone/Music/item.wav.dshare", byteArrayOf(1))
        CompositeMediaLibrary.open("Media", listOf(document)).use { library ->
            val id = library.catalog.entries.single().id
            assertTrue(file.delete())
            MediaArray.createPortable(file, "Replacement", listOf(MediaInput("item.wav", "audio/wav") { byteArrayOf(2).inputStream() })).close()
            try { library.openEntry(id).use { it.read() }; fail("Replaced catalog accepted") } catch (_: IOException) { }
            assertEquals(0, alive.get())
        }
    }

    @Test fun emptyFolderAndClosedLibraryHaveDefinedBehavior() {
        CompositeMediaLibrary.open("Empty", emptyList()).use { assertTrue(it.catalog.entries.isEmpty()); assertEquals(0, it.openSourceCount) }
        val (file, document) = item("Phone/Pictures/photo.png.dshare", byteArrayOf(1), mime = "image/png")
        val original = file.readBytes()
        val library = CompositeMediaLibrary.open("Photos", listOf(document))
        val stream = library.openEntry(library.catalog.entries.single().id)
        assertEquals(1, stream.read()); library.close()
        try { stream.read(); fail("Closed library read accepted") } catch (_: IOException) { }
        assertArrayEquals(original, file.readBytes()); assertEquals(0, alive.get())
    }
}
