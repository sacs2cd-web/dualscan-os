package com.dualscan.mp.core

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MediaTrackMetadataTest {
    @get:Rule val temporary = TemporaryFolder()
    private val password get() = "Public metadata fixture 2026".toCharArray()

    @Test fun trackAndDiscMetadataRoundTripWithoutChangingAnyMediaBytes() {
        val bytes = byteArrayOf(0, 1, 0xff.toByte(), 3, 5, 8)
        val input = MediaInput("Second.flac", "audio/flac", "Music/Album/Second.flac", { bytes.inputStream() }, 2, 3)
        MediaArray.create(newFile(), "Tagged album", listOf(input), password).use { collection ->
            val track = collection.catalog.entries.single()
            assertEquals(2, track.trackNumber)
            assertEquals(3, track.discNumber)
            val output = ByteArray(bytes.size)
            assertEquals(bytes.size, collection.readAt(track.id, 0, output, 0, output.size))
            assertArrayEquals(bytes, output)
            assertEquals(hash(bytes), track.sha256)
        }
    }

    @Test fun invalidCreateTagsAreRejectedBeforeAnySourceIsOpened() {
        listOf(0, -1, 10000, Int.MAX_VALUE).forEach { invalid ->
            listOf(invalid to null, null to invalid).forEach { (track, disc) ->
                var opens = 0
                val output = newFile()
                val input = MediaInput("track.flac", "audio/flac", null, { opens++; byteArrayOf().inputStream() }, track, disc)
                rejected { MediaArray.create(output, "Invalid metadata", listOf(input), password) }
                assertEquals(0, opens)
                assertFalse(output.exists())
            }
        }
    }

    @Test fun independentOldManifestWithoutNewFieldsRemainsReadable() {
        MediaArray.open(fixture(), password).use { collection ->
            val track = collection.catalog.entries.single()
            assertNull(track.trackNumber)
            assertNull(track.discNumber)
            assertEquals("Legacy empty track.flac", track.displayName)
        }
    }

    @Test fun optionalNullAndUpperBoundMetadataAreAccepted() {
        MediaArray.open(fixture { it.put("trackNumber", JSONObject.NULL).put("discNumber", 9999) }, password).use { collection ->
            assertNull(collection.catalog.entries.single().trackNumber)
            assertEquals(9999, collection.catalog.entries.single().discNumber)
        }
    }

    @Test fun authenticatedButMalformedMetadataTypesAndBoundsFailClosed() {
        val invalid = listOf<Any>(0, -1, 10000, 4_294_967_298L, 2.5, "2", true)
        listOf("trackNumber", "discNumber").forEach { key ->
            invalid.forEach { value -> rejected { MediaArray.open(fixture { it.put(key, value) }, password) } }
        }
    }

    /** Independent JCE framing for a zero-byte entry, so no production writer is used. */
    private fun fixture(change: (JSONObject) -> Unit = {}): File {
        val entry = JSONObject().put("id", "media-000001").put("displayName", "Legacy empty track.flac")
            .put("mimeType", "audio/flac").put("relativePath", JSONObject.NULL).put("sizeBytes", 0)
            .put("sha256", hash(byteArrayOf())).put("index", 0).put("dataOffset", 0).put("firstCounter", 1).put("chunkCount", 0)
        change(entry)
        val manifest = JSONObject().put("format", "dualscan-mp").put("schemaVersion", 1)
            .put("id", "912d63ca-cfc5-4394-b707-c6ac1040caec").put("title", "Independent legacy fixture")
            .put("chunkBytes", 1048576).put("entries", JSONArray().put(entry)).toString().toByteArray()
        val salt = ByteArray(16) { it.toByte() }
        val nonce = ByteArray(12) { (it + 32).toByte() }
        val header = ByteBuffer.allocate(44).put("DSMP0001".toByteArray()).put(salt).put(nonce)
            .putInt(600000).putInt(manifest.size + 16).array()
        val specification = PBEKeySpec(password, salt, 600000, 256)
        val key = try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded }
            finally { specification.clearPassword() }
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            cipher.updateAAD(header + byteArrayOf(0))
            return newFile().also { it.writeBytes(header + cipher.doFinal(manifest)) }
        } finally { key.fill(0); manifest.fill(0) }
    }
    private fun newFile() = File(temporary.root, "metadata-${java.util.UUID.randomUUID()}.dmpa")
    private fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun rejected(block: () -> Unit) {
        try { block() } catch (_: Exception) { return }
        throw AssertionError("Malformed media metadata was accepted")
    }
}
