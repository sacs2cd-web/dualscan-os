package com.dualscan.mp

import org.junit.Assert.*
import org.junit.Test

class LocalMediaSourcePolicyTest {
    @Test fun cloudPickerAliasesAreRejectedBeforeOpeningAnyMedia() {
        for (path in listOf("/picker/0/cloud.example/media/1", "/picker_get_content/0/cloud.example/media/1")) {
            try { LocalMediaSourcePolicy.requireLocal("media", path); fail("Cloud picker alias accepted") }
            catch (_: java.io.IOException) { }
        }
        LocalMediaSourcePolicy.requireLocal("media", "/external/audio/media/1")
        LocalMediaSourcePolicy.requireLocal("com.android.externalstorage.documents", "/document/primary:Music/song.flac")
    }
}
