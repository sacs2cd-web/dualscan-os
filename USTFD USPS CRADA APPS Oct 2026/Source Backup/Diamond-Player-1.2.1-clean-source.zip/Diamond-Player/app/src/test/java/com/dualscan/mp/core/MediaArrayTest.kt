package com.dualscan.mp.core

import org.hzontal.tella.keys.key.MainKey
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Random
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MediaArrayTest {
    @get:Rule val temporary = TemporaryFolder()
    private val password get() = "Public test passphrase 東京 📱 2026".toCharArray()
    private val chunks = MediaArray.CHUNK_BYTES
    private val media = linkedMapOf(
        "Résumé 東京.wav" to ByteArray(2 * chunks + 113) { ((it * 67 + (it shr 9)) and 255).toByte() },
        "photo.jpg" to ByteArray(chunks + 39) { (it * 19 + 13).toByte() },
        "empty.mp4" to byteArrayOf()
    )

    @Test fun completeReadMatchesOriginalHashesAcrossEntriesAndChunkBoundaries() {
        val file = create()
        val children = children()
        MediaArray.open(file, password).use { array ->
            assertEquals("Test media", array.catalog.title)
            assertEquals(file.length(), array.encryptedSize)
            assertEquals(media.keys.toList(), array.catalog.entries.map { it.displayName })
            array.catalog.entries.forEach { entry ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(77_003)
                var position = 0L
                while (true) {
                    val count = array.readAt(entry.id, position, buffer, 0, buffer.size)
                    if (count == -1) break
                    assertTrue(count > 0)
                    output.write(buffer, 0, count)
                    position += count
                }
                assertArrayEquals(media.getValue(entry.displayName), output.toByteArray())
                assertEquals(entry.sha256, hash(output.toByteArray()))
                assertEquals(entry.sizeBytes, position)
            }
        }
        assertEquals(children, children()) // No plaintext file was staged.
    }

    @Test fun randomSeeksAcrossEntriesAndBoundariesMatchOriginalBytes() {
        MediaArray.open(create(), password).use { array ->
            val random = Random(0xD5A9)
            repeat(300) {
                val entry = array.catalog.entries[random.nextInt(2)]
                val source = media.getValue(entry.displayName)
                val position = random.nextInt(source.size)
                val requested = 1 + random.nextInt(100_000)
                val target = ByteArray(requested + 14) { 0x5a }
                val count = array.readAt(entry.id, position.toLong(), target, 7, requested)
                val expectedCount = minOf(requested, source.size - position)
                assertEquals(expectedCount, count)
                assertArrayEquals(source.copyOfRange(position, position + count), target.copyOfRange(7, 7 + count))
                assertTrue(target.take(7).all { byte -> byte == 0x5a.toByte() })
                assertTrue(target.drop(7 + count).all { byte -> byte == 0x5a.toByte() })
            }
            val entry = array.catalog.entries.first()
            val crossing = ByteArray(123)
            assertEquals(123, array.readAt(entry.id, chunks - 51L, crossing, 0, crossing.size))
            assertArrayEquals(media.values.first().copyOfRange(chunks - 51, chunks + 72), crossing)
        }
    }

    @Test fun openAndSingleTailReadOnlyTouchManifestAndRequestedChunk() {
        val bytes = create().readBytes()
        val source = MemorySource(bytes, maxRead = 17_003)
        MediaArray.open(source, password).use { array ->
            val manifestLength = ByteBuffer.wrap(bytes, 40, 4).int
            assertEquals((44 + manifestLength).toLong(), source.bytesRead)
            val before = source.bytesRead
            val entry = array.catalog.entries.first()
            val target = ByteArray(1)
            assertEquals(1, array.readAt(entry.id, entry.sizeBytes - 1, target, 0, 1))
            assertEquals((113 + 16).toLong(), source.bytesRead - before)
            assertEquals(media.values.first().last(), target[0])
            array.readAt(entry.id, entry.sizeBytes - 2, target, 0, 1)
            assertEquals((113 + 16).toLong(), source.bytesRead - before) // One-chunk cache.
        }
        assertTrue(source.closed)
    }

    @Test fun wrongPasswordTamperedManifestAndHeaderNeverUnlock() {
        val bytes = create().readBytes()
        val wrongPasswordSource = MemorySource(bytes)
        rejected { MediaArray.open(wrongPasswordSource, "incorrect-password".toCharArray()) }
        assertTrue(wrongPasswordSource.closed)
        listOf(0, 8, 24, 44, 44 + ByteBuffer.wrap(bytes, 40, 4).int - 1).forEach { location ->
            val changed = bytes.clone().also { it[location] = (it[location].toInt() xor 1).toByte() }
            val source = MemorySource(changed)
            rejected { MediaArray.open(source, password) }
            assertTrue(source.closed)
        }
    }

    @Test fun eachDataChunkAuthenticatesBeforeAnyOfItsBytesAreExposed() {
        val bytes = create().readBytes()
        val start = 44 + ByteBuffer.wrap(bytes, 40, 4).int
        listOf(start, start + chunks + 15, start + (chunks + 16) * 2 + 5).forEach { location ->
            val changed = bytes.clone().also { it[location] = (it[location].toInt() xor 1).toByte() }
            val source = MemorySource(changed)
            val array = MediaArray.open(source, password)
            val entry = array.catalog.entries.first()
            val position = ((location - start) / (chunks + 16)).toLong() * chunks
            val target = ByteArray(10) { 0x55 }
            rejected { array.readAt(entry.id, position, target, 0, target.size) }
            assertTrue(target.all { it == 0x55.toByte() })
            assertTrue(source.closed)
            rejected { array.readAt(entry.id, 0, target, 0, 1) }
        }
    }

    @Test fun swappingValidChunksBetweenEntriesOrPositionsFailsAuthentication() {
        val bytes = create().readBytes()
        val start = 44 + ByteBuffer.wrap(bytes, 40, 4).int
        val swapped = bytes.clone()
        val first = bytes.copyOfRange(start, start + chunks + 16)
        val second = bytes.copyOfRange(start + chunks + 16, start + 2 * (chunks + 16))
        second.copyInto(swapped, start); first.copyInto(swapped, start + chunks + 16)
        MediaArray.open(MemorySource(swapped), password).use { array ->
            rejected { array.readAt(array.catalog.entries.first().id, 0, ByteArray(1), 0, 1) }
        }
    }

    @Test fun truncationAndTrailingDataAreRejectedBeforeUnlock() {
        val bytes = create().readBytes()
        listOf(bytes.copyOf(43), bytes.copyOf(bytes.size - 1), bytes.copyOf(bytes.size / 2), bytes + byteArrayOf(0)).forEach { changed ->
            val source = MemorySource(changed)
            rejected { MediaArray.open(source, password) }
            assertTrue(source.closed)
        }
    }

    @Test fun authenticatedForgedIndexesRangesCountsAndPathsAreRejected() {
        val bytes = create().readBytes()
        val mutations: List<(JSONObject) -> Unit> = listOf(
            { it.getJSONArray("entries").getJSONObject(0).put("index", 1) },
            { it.getJSONArray("entries").getJSONObject(0).put("firstCounter", 0) },
            { it.getJSONArray("entries").getJSONObject(0).put("chunkCount", 0) },
            { it.getJSONArray("entries").getJSONObject(1).put("dataOffset", 0) },
            { it.getJSONArray("entries").getJSONObject(1).put("firstCounter", Long.MAX_VALUE) },
            { it.getJSONArray("entries").getJSONObject(0).put("sizeBytes", Long.MAX_VALUE) },
            { it.getJSONArray("entries").getJSONObject(0).put("sha256", "not-a-hash") },
            { it.getJSONArray("entries").getJSONObject(0).put("relativePath", "../Résumé 東京.wav") },
            { it.getJSONArray("entries").getJSONObject(1).put("id", "media-000001") },
            { it.getJSONArray("entries").getJSONObject(1).put("mimeType", "application/vnd.android.package-archive") },
            { it.put("chunkBytes", 1) }, { it.put("schemaVersion", 2) }
        )
        mutations.forEach { mutation -> rejected { MediaArray.open(MemorySource(forgeManifest(bytes, mutation)), password) } }
    }

    @Test fun seekBeyondEntryUnknownIdAndInvalidBuffersFail() {
        MediaArray.open(create(), password).use { array ->
            val entry = array.catalog.entries.first()
            val target = ByteArray(10) { 0x55 }
            rejected { array.readAt(entry.id, -1, target, 0, 1) }
            rejected { array.readAt(entry.id, entry.sizeBytes + 1, target, 0, 1) }
            rejected { array.readAt("media-999999", 0, target, 0, 1) }
            rejected { array.readAt(entry.id, 0, target, -1, 1) }
            rejected { array.readAt(entry.id, 0, target, 0, 11) }
            assertEquals(-1, array.readAt(entry.id, entry.sizeBytes, target, 0, 1))
            assertEquals(0, array.readAt(entry.id, entry.sizeBytes, target, 0, 0))
            assertEquals(-1, array.readAt(array.catalog.entries.last().id, 0, target, 0, 1))
            assertTrue(target.all { it == 0x55.toByte() })
        }
    }

    @Test fun replacingCacheAndClosingWipesPlaintextAndTellaOwnedKey() {
        val source = MemorySource(create().readBytes())
        val array = MediaArray.open(source, password)
        val entry = array.catalog.entries.first()
        array.readAt(entry.id, 0, ByteArray(20), 0, 20)
        val cached = field(array, "cachedBytes") as ByteArray
        assertTrue(cached.any { it != 0.toByte() })
        array.readAt(entry.id, chunks.toLong(), ByteArray(1), 0, 1)
        assertTrue(cached.all { it == 0.toByte() })
        val replacement = field(array, "cachedBytes") as ByteArray
        val key = field(array, "key") as MainKey
        assertNotNull(key.key)
        array.close(); array.close()
        assertTrue(replacement.all { it == 0.toByte() })
        assertNull(key.key)
        assertTrue(source.closed)
        rejected { array.readAt(entry.id, 0, ByteArray(1), 0, 1) }
    }

    @Test fun changingSourceBetweenHashAndEncryptionDeletesIncompleteOutput() {
        listOf(byteArrayOf(2, 2, 2), byteArrayOf(1, 2), byteArrayOf(1, 2, 3, 4)).forEach { changed ->
            var calls = 0
            val output = freshFile()
            val input = MediaInput("song.wav", "audio/wav") {
                if (calls++ == 0) byteArrayOf(1, 2, 3).inputStream() else changed.inputStream()
            }
            rejected { MediaArray.create(output, "Changes", listOf(input), password) }
            assertFalse(output.exists())
            assertEquals(2, calls)
        }
    }

    @Test fun sourceFailureAndCancellationDoNotLeaveEncryptedOrPlaintextOutput() {
        var calls = 0
        var closed = false
        val output = freshFile()
        val input = MediaInput("movie.mp4", "video/mp4") {
            if (calls++ == 0) byteArrayOf(1, 2, 3).inputStream() else object : InputStream() {
                override fun read(): Int = throw IOException("USB disconnected")
                override fun close() { closed = true }
            }
        }
        rejected { MediaArray.create(output, "Disconnected", listOf(input), password) }
        assertTrue(closed)
        assertFalse(output.exists())
        val before = children()
        try {
            Thread.currentThread().interrupt()
            rejected { MediaArray.create(freshFile(), "Cancelled", inputs(), password) }
        } finally { Thread.interrupted() }
        assertEquals(before, children())
    }

    @Test fun unicodePathsNormalizeAndCasefoldCollisionsAreRejected() {
        val output = freshFile()
        val decomposed = "Re\u0301sume\u0301.wav"
        MediaArray.create(output, "Unicode", listOf(MediaInput(decomposed, "audio/wav", "Music/$decomposed") { byteArrayOf(1).inputStream() }), password).use { array ->
            assertEquals("Résumé.wav", array.catalog.entries.single().displayName)
            assertEquals("Music/Résumé.wav", array.catalog.entries.single().relativePath)
        }
        listOf("Song.wav" to "song.wav", "Straße.wav" to "STRASSE.wav", "Re\u0301sume\u0301.wav" to "Résumé.wav").forEach { (a, b) ->
            rejected { MediaArray.create(freshFile(), "Collision", listOf(MediaInput(a, "audio/wav") { byteArrayOf(1).inputStream() }, MediaInput(b, "audio/wav") { byteArrayOf(2).inputStream() }), password) }
        }
    }

    @Test fun unsafePathsApplicationTypesAndExcessInputsAreRejectedWithoutOpeningSources() {
        var opened = 0
        val unsafe = listOf("../song.wav", "/song.wav", "Music//song.wav", "Music/./song.wav", "Music/../song.wav", "Music\\song.wav", "Music/other.wav")
        unsafe.forEach { path ->
            rejected { MediaArray.create(freshFile(), "Bad path", listOf(MediaInput("song.wav", "audio/wav", path) { opened++; byteArrayOf(1).inputStream() }), password) }
        }
        listOf("application/octet-stream", "application/vnd.android.package-archive").forEach { mime ->
            rejected { MediaArray.create(freshFile(), "Bad MIME", listOf(MediaInput("song.wav", mime) { opened++; byteArrayOf(1).inputStream() }), password) }
        }
        rejected { MediaArray.create(freshFile(), "No apps", listOf(MediaInput("app.apk", "audio/wav") { opened++; byteArrayOf(1).inputStream() }), password) }
        rejected { MediaArray.create(freshFile(), "Empty", emptyList(), password) }
        rejected { MediaArray.create(freshFile(), "Many", List(MediaArray.MAX_ENTRIES + 1) { MediaInput("$it.wav", "audio/wav") { opened++; byteArrayOf(1).inputStream() } }, password) }
        assertEquals(0, opened)
    }

    @Test fun malformedKdfAndManifestLengthsAreRejectedBeforeLargeReads() {
        val bytes = create().readBytes()
        listOf(0, 600_001, Int.MAX_VALUE).forEach { iterations ->
            val changed = bytes.clone().also { ByteBuffer.wrap(it, 36, 4).putInt(iterations) }
            val source = MemorySource(changed)
            rejected { MediaArray.open(source, password) }
            assertEquals(44L, source.bytesRead)
        }
        listOf(-1, 0, 16, MediaArray.MAX_MANIFEST_BYTES + 17, Int.MAX_VALUE).forEach { length ->
            val changed = bytes.clone().also { ByteBuffer.wrap(it, 40, 4).putInt(length) }
            val source = MemorySource(changed)
            rejected { MediaArray.open(source, password) }
            assertEquals(44L, source.bytesRead)
        }
    }

    @Test fun encryptionIsRandomizedAndExistingFilesAreNeverOverwritten() {
        val one = create().readBytes(); val two = create().readBytes()
        assertFalse(one.copyOfRange(8, 24).contentEquals(two.copyOfRange(8, 24)))
        assertFalse(one.copyOfRange(24, 36).contentEquals(two.copyOfRange(24, 36)))
        assertFalse(one.contentEquals(two))
        val existing = freshFile().also { it.writeText("preserve me") }
        rejected { MediaArray.create(existing, "Existing", inputs(), password) }
        assertEquals("preserve me", existing.readText())
    }

    @Test fun weakPasswordsAndStalledProviderAreRejected() {
        listOf(CharArray(0), "short".toCharArray(), CharArray(257) { 'x' }).forEach { weak ->
            val file = freshFile()
            rejected { MediaArray.create(file, "Weak", inputs(), weak) }
            assertFalse(file.exists())
        }
        val stalled = MediaInput("song.wav", "audio/wav") { object : InputStream() {
            override fun read(): Int = 0
            override fun read(bytes: ByteArray, offset: Int, count: Int): Int = 0
        } }
        val output = freshFile()
        rejected { MediaArray.create(output, "Stalled", listOf(stalled), password) }
        assertFalse(output.exists())
    }

    @Test fun sourceSizeMutationAfterUnlockFailsAndClosesArray() {
        val source = MemorySource(create().readBytes())
        val array = MediaArray.open(source, password)
        source.reportedSize++
        rejected { array.readAt(array.catalog.entries.first().id, 0, ByteArray(1), 0, 1) }
        assertTrue(source.closed)
    }

    @Test fun independentNodeOpenSslArraySupportsUnicodePasswordAndAllMediaHashes() {
        val assets = File("src/androidTest/assets/arrays").takeIf { it.isDirectory }
            ?: File("app/src/androidTest/assets/arrays")
        val vector = JSONObject(File(assets, "host-media-vector.json").readText())
        val file = File(assets, "host-media.dmpa")
        assertEquals(vector.getString("encryptedSha256"), hash(file.readBytes()))
        val secret = vector.getString("password").toCharArray()
        val originalPassword = secret.clone()
        MediaArray.open(file, secret).use { array ->
            assertEquals(3, array.catalog.entries.size)
            assertEquals(setOf("audio/wav", "image/png", "video/mp4"), array.catalog.entries.map { it.mimeType }.toSet())
            array.catalog.entries.forEachIndexed { index, entry ->
                val expected = vector.getJSONArray("entries").getJSONObject(index)
                val digest = MessageDigest.getInstance("SHA-256")
                val buffer = ByteArray(81_017)
                var position = 0L
                while (true) {
                    val count = array.readAt(entry.id, position, buffer, 0, buffer.size)
                    if (count == -1) break
                    digest.update(buffer, 0, count); position += count
                }
                assertEquals(expected.getLong("sizeBytes"), position)
                val actualHash = digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
                assertEquals(expected.getString("sha256"), actualHash)
            }
        }
        assertArrayEquals(originalPassword, secret)
        secret.fill('\u0000')
    }

    private fun inputs() = media.map { (name, bytes) -> MediaInput(name, when { name.endsWith("jpg") -> "image/jpeg"; name.endsWith("mp4") -> "video/mp4"; else -> "audio/wav" }) { bytes.inputStream() } }
    private fun create() = freshFile().also { MediaArray.create(it, "Test media", inputs(), password).close() }
    private fun freshFile() = File(temporary.root, "array-${UUID.randomUUID()}.dmpa")
    private fun children() = temporary.root.listFiles()!!.map { it.name }.toSet()
    private fun hash(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun field(target: Any, name: String): Any = target.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(target)!!
    private fun rejected(block: () -> Unit): Throwable {
        try { block() } catch (failure: Exception) { return failure }
        throw AssertionError("Invalid encrypted media operation was accepted")
    }

    private class MemorySource(private val bytes: ByteArray, private val maxRead: Int = Int.MAX_VALUE) : RandomAccessSource {
        var closed = false
        var bytesRead = 0L
        var reportedSize = bytes.size.toLong()
        override val size: Long get() = reportedSize
        override fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
            if (closed) throw IOException("closed")
            if (offset >= bytes.size) return -1
            val read = minOf(count, maxRead, bytes.size - offset.toInt())
            bytes.copyInto(target, targetOffset, offset.toInt(), offset.toInt() + read)
            bytesRead += read
            return read
        }
        override fun close() { closed = true }
    }

    /** Independent standard-JCE manifest edit, retaining correctly authenticated metadata. */
    private fun forgeManifest(original: ByteArray, mutation: (JSONObject) -> Unit): ByteArray {
        val oldHeader = original.copyOfRange(0, 44)
        val specification = PBEKeySpec(password, oldHeader.copyOfRange(8, 24), 600_000, 256)
        val key = try { SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded, "AES") }
            finally { specification.clearPassword() }
        fun cipher(mode: Int, header: ByteArray) = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(mode, key, GCMParameterSpec(128, header.copyOfRange(24, 36))); updateAAD(header + byteArrayOf(0))
        }
        val oldLength = ByteBuffer.wrap(oldHeader, 40, 4).int
        val manifest = JSONObject(String(cipher(Cipher.DECRYPT_MODE, oldHeader).doFinal(original.copyOfRange(44, 44 + oldLength)), Charsets.UTF_8)).also(mutation).toString().toByteArray()
        val header = oldHeader.clone().also { ByteBuffer.wrap(it, 40, 4).putInt(manifest.size + 16) }
        return header + cipher(Cipher.ENCRYPT_MODE, header).doFinal(manifest) + original.copyOfRange(44 + oldLength, original.size)
    }
}
