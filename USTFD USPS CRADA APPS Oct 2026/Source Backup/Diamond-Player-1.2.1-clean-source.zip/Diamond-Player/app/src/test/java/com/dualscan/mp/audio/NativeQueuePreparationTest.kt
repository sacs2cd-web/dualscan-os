package com.dualscan.mp.audio

import android.media.AudioFormat
import org.junit.Assert.*
import org.junit.Test
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class NativeQueuePreparationTest {
    @Test fun preparedPrefixIsBoundedAndContainsOriginalPcm() {
        val source = FakeSource()
        NativeQueuePreparation { source }.use { preparation ->
            val ticket = preparation.prepare(1, NativeQueueItem("test:next", "Next"))
            waitReady(ticket)
            val ready = ticket.take()!!.prepared!!
            assertTrue(ready.prefix.remaining() in 1..(1024 * 1024))
            while (ready.prefix.hasRemaining()) assertEquals(0x35.toByte(), ready.prefix.get())
            assertFalse(source.closed.get())
            ready.close()
            assertTrue(source.closed.get())
        }
    }

    @Test fun cancellingAnActiveReadClosesOnlyAfterReaderExits() {
        val entered = CountDownLatch(1)
        val source = FakeSource(entered)
        NativeQueuePreparation { source }.use { preparation ->
            val ticket = preparation.prepare(1, NativeQueueItem("test:blocked", "Blocked"))
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            preparation.cancel(ticket)
            assertTrue(source.closedSignal.await(2, TimeUnit.SECONDS))
            assertFalse("Cancellation must not close a source concurrently with its reader", source.closedDuringRead.get())
            assertNull(ticket.take())
        }
    }

    @Test fun cancellingCompletedPreparationClosesTheUnclaimedDecoder() {
        val source = FakeSource()
        NativeQueuePreparation { source }.use { preparation ->
            val ticket = preparation.prepare(1, NativeQueueItem("test:unclaimed", "Unclaimed"))
            waitReady(ticket)
            preparation.cancel(ticket)
            assertTrue(source.closed.get())
            assertNull(ticket.take())
        }
    }

    private fun waitReady(ticket: NativeQueuePreparation.Ticket) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2)
        while (!ticket.isReady() && System.nanoTime() < deadline) Thread.sleep(2)
        assertTrue("Preparation did not finish", ticket.isReady())
    }

    private class FakeSource(private val block: CountDownLatch? = null) : NativePcmSource {
        override val format = PcmFormat(768_000, 2, AudioFormat.ENCODING_PCM_16BIT, AudioFormat.CHANNEL_OUT_STEREO)
        override val info = NativeTrackInfo("Fixture", "Original PCM", 16, format.sampleRateHz, 2, 10_000_000, true)
        val closed = AtomicBoolean()
        val closedDuringRead = AtomicBoolean()
        val closedSignal = CountDownLatch(1)
        private val reading = AtomicBoolean()
        override fun read(target: ByteBuffer): Int {
            reading.set(true)
            try {
                if (block != null) { block.countDown(); CountDownLatch(1).await() }
                val count = target.remaining() / 4 * 4
                repeat(count) { target.put(0x35) }
                return count
            } finally { reading.set(false) }
        }
        override fun seekTo(positionUs: Long) = positionUs
        override fun close() { if (reading.get()) closedDuringRead.set(true); closed.set(true); closedSignal.countDown() }
    }
}
