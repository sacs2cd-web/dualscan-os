package com.dualscan.mp

import org.junit.Assert.*
import org.junit.Test

class MediaOpenPolicyTest {
    @Test fun opensNamedLocalEncryptedFilesWithOnlyItsDeclaredMimeTypes() {
        for (mime in listOf("application/octet-stream", MediaOpenPolicy.DIAMOND_MIME)) {
            assertTrue(MediaOpenPolicy.accepts("android.intent.action.VIEW", "content", "com.android.externalstorage.documents", "/document/primary:Music/01 Track.flac.diamond", mime))
        }
    }
    @Test fun rejectsOrdinaryLaunchRawMediaOpaqueCloudAndRemoteRoutes() {
        fun accepts(action: String? = "android.intent.action.VIEW", scheme: String = "content", authority: String = "com.android.externalstorage.documents",
                    path: String = "/document/primary:Music/item.diamond", mime: String = "application/octet-stream") = MediaOpenPolicy.accepts(action, scheme, authority, path, mime)
        assertFalse(accepts(action = "android.intent.action.MAIN")); assertFalse(accepts(action = null))
        assertFalse(accepts(scheme = "https")); assertFalse(accepts(scheme = "file"))
        assertFalse(accepts(authority = "remote.provider")); assertFalse(accepts(authority = "media", path = "/external_primary/file/123"))
        assertFalse(accepts(path = "/document/primary:Pictures/photo.jpg")); assertFalse(accepts(path = "/document/primary:Music/old.dshare"))
        assertFalse(accepts(mime = "image/jpeg")); assertFalse(accepts(mime = "*/*"))
    }
}
