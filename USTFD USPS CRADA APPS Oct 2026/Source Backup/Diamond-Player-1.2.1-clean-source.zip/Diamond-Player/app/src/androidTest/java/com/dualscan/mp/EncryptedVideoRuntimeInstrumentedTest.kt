@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
package com.dualscan.mp

import android.graphics.SurfaceTexture
import android.net.Uri
import android.view.Surface
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Uses the actual Media3 decoder and surface with the production encrypted data source. */
@RunWith(AndroidJUnit4::class)
class EncryptedVideoRuntimeInstrumentedTest {
    @Test fun androidCreatesPortableEncryptedMediaForIndependentHostAuthentication() {
        val instrument = InstrumentationRegistry.getInstrumentation()
        val context = instrument.targetContext
        val file = File(context.filesDir, "verification-android-media.dmpa")
        file.delete()
        val password = "Dualscan MP Android public test 2026".toCharArray()
        try {
            MediaArray.create(file, "Android interoperability fixture", listOf(
                MediaInput("source-24-96.wav", "audio/wav") { instrument.context.assets.open("arrays/source-24-96.wav") }
            ), password).use { array ->
                assertEquals(1_728_044L, array.catalog.entries.single().sizeBytes)
                assertTrue(file.length() > array.catalog.entries.single().sizeBytes)
            }
            // Retain ciphertext only so the independent Node/OpenSSL verifier can authenticate it.
            assertEquals("DSMP0001", java.io.DataInputStream(file.inputStream()).use { input ->
                String(ByteArray(8).also(input::readFully), Charsets.US_ASCII)
            })
        } finally { password.fill('\u0000') }
    }

    @Test fun encryptedH264PreparesSeeksAndRendersThroughProductionDataSource() {
        val instrument = InstrumentationRegistry.getInstrumentation()
        val context = instrument.targetContext
        val assets = instrument.context.assets
        val vector = assets.open("arrays/host-media-vector.json").bufferedReader().use { JSONObject(it.readText()) }
        val file = File.createTempFile("encrypted-video-runtime-", ".dmpa", context.cacheDir)
        val password = vector.getString("password").toCharArray()
        val ready = CountDownLatch(1); val rendered = CountDownLatch(1)
        val failure = AtomicReference<PlaybackException?>(null)
        var player: ExoPlayer? = null; var texture: SurfaceTexture? = null; var surface: Surface? = null
        try {
            assets.open("arrays/host-media.dmpa").use { input -> file.outputStream().use { input.copyTo(it) } }
            MediaArray.open(file, password).use { array ->
                val entry = array.catalog.entries.single { it.mimeType == "video/mp4" }
                instrument.runOnMainSync {
                    texture = SurfaceTexture(0).apply { setDefaultBufferSize(320, 240) }
                    surface = Surface(texture)
                    player = ExoPlayer.Builder(context).build().apply {
                        setVideoSurface(surface)
                        addListener(object : Player.Listener {
                            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_READY) ready.countDown() }
                            override fun onRenderedFirstFrame() { rendered.countDown() }
                            override fun onPlayerError(error: PlaybackException) { failure.set(error); ready.countDown(); rendered.countDown() }
                        })
                        val item = MediaItem.Builder().setUri(Uri.parse("dualscan-mp://entry/${entry.id}")).setMimeType(entry.mimeType).build()
                        setMediaSource(ProgressiveMediaSource.Factory(EncryptedMediaDataSource.Factory(array)).createMediaSource(item))
                        prepare()
                    }
                }
                assertTrue("Encrypted H264 did not prepare", ready.await(20, TimeUnit.SECONDS))
                assertNull("Actual decoder failure: ${failure.get()}", failure.get())
                instrument.runOnMainSync {
                    assertTrue("Three-second source duration", player!!.duration in 2900..3100)
                    player!!.seekTo(1500); player!!.play()
                }
                assertTrue("Actual video decoder did not render", rendered.await(20, TimeUnit.SECONDS))
                assertNull("Actual decoder failure: ${failure.get()}", failure.get())
                instrument.runOnMainSync { player?.release(); player = null }
            }
        } finally {
            instrument.runOnMainSync { player?.release(); surface?.release(); texture?.release() }
            password.fill('\u0000'); file.delete()
        }
    }
}
