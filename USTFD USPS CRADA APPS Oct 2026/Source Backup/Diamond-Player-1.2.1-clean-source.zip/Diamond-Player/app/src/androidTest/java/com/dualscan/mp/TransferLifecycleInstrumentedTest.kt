package com.dualscan.mp

import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

/** Real service scheduling: cancellation may arrive before Android creates the service. */
@RunWith(AndroidJUnit4::class)
class TransferLifecycleInstrumentedTest {
    @Test fun immediateCompletionBeforeServiceCreationDoesNotKillTheApp() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val app = instrumentation.targetContext
        val activity = instrumentation.startActivitySync(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        try {
            instrumentation.runOnMainSync {
                repeat(3) {
                    TransferService.begin(app) { }
                    TransferService.end(app)
                }
            }
            // Android reports a missing foreground promotion asynchronously after its grace period.
            Thread.sleep(12000)
            assertTrue("The application activity must survive immediate completion", !activity.isFinishing)
        } finally { instrumentation.runOnMainSync { activity.finish() } }
    }

    @Test fun rejectedFileFolderAndCreateRequestsRemainRecoverable() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val app = instrumentation.targetContext
        val activity = instrumentation.startActivitySync(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        lateinit var model: MpViewModel
        instrumentation.runOnMainSync { model = ViewModelProvider(activity)[MpViewModel::class.java] }
        fun waitForError() {
            val deadline = android.os.SystemClock.elapsedRealtime() + 12000
            while (android.os.SystemClock.elapsedRealtime() < deadline) {
                var complete = false
                instrumentation.runOnMainSync { complete = !model.busy }
                if (complete) break
                Thread.sleep(25)
            }
            instrumentation.runOnMainSync {
                assertTrue("A rejected operation must finish", !model.busy)
                assertNotNull("A rejected operation must return an error instead of closing the app", model.error)
                model.dismissError()
            }
        }
        try {
            val inaccessible = Uri.parse("content://untrusted.example/document/rejected")
            instrumentation.runOnMainSync { model.prepareSources(listOf(inaccessible)) }
            waitForError()
            instrumentation.runOnMainSync { model.prepareFolder(inaccessible) }
            waitForError()
            // No sources were accepted; creation must report validation failure even
            // if a USB device is present, without leaving a pending service start.
            instrumentation.runOnMainSync { model.createCollection() }
            waitForError()
            Thread.sleep(12000)
            assertTrue(!activity.isFinishing)
        } finally { instrumentation.runOnMainSync { activity.finish() } }
    }
}
