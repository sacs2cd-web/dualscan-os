@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.DataSpec
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File

@RunWith(AndroidJUnit4::class)
class MpMediaAdaptersInstrumentedTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    @Test fun media3SourceReadsExactBytesAndSeeksAcrossChunkBoundary() {
        val bytes = ByteArray(2 * 1024 * 1024 + 149) { ((it * 73) xor (it ushr 5)).toByte() }
        val file = File.createTempFile("media3-range-", ".dmpa", context.cacheDir).apply { delete() }
        val password = "test-range-password".toCharArray()
        try {
            MediaArray.create(file, "Adapter range", listOf(MediaInput("test.wav", "audio/wav") { bytes.inputStream() }), password).use { array ->
                val entry = array.catalog.entries.single()
                val source = EncryptedMediaDataSource.Factory(array).createDataSource()
                val offset = 1024L * 1024 - 71
                val count = 8193
                val spec = DataSpec.Builder().setUri(Uri.parse("dualscan-mp://entry/${entry.id}")).setPosition(offset).setLength(count.toLong()).build()
                assertEquals(count.toLong(), source.open(spec))
                val actual = ByteArray(count); var read = 0
                while (read < actual.size) { val n = source.read(actual, read, minOf(1031, actual.size - read)); assertTrue(n > 0); read += n }
                assertArrayEquals(bytes.copyOfRange(offset.toInt(), offset.toInt() + count), actual)
                assertEquals(C.RESULT_END_OF_INPUT, source.read(ByteArray(1), 0, 1))
                source.close()
                val again = ByteArray(4)
                assertEquals(4, array.readAt(entry.id, 0, again, 0, 4))
                assertArrayEquals(bytes.copyOfRange(0, 4), again)
            }
        } finally { password.fill('\u0000'); file.delete() }
    }
    @Test fun media3SourceAtEndReturnsEofWithoutConsumingAnotherEntry() {
        val file = File.createTempFile("media3-eof-", ".dmpa", context.cacheDir).apply { delete() }
        val password = "test-eof-password".toCharArray()
        try {
            MediaArray.create(file, "Adapter EOF", listOf(MediaInput("one.mp3", "audio/mpeg") { byteArrayOf(1, 2, 3).inputStream() }), password).use { array ->
                val entry = array.catalog.entries.single(); val source = EncryptedMediaDataSource.Factory(array).createDataSource()
                assertEquals(0L, source.open(DataSpec.Builder().setUri(Uri.parse("dualscan-mp://entry/${entry.id}")).setPosition(entry.sizeBytes).build()))
                assertEquals(0, source.read(ByteArray(1), 0, 0))
                assertEquals(C.RESULT_END_OF_INPUT, source.read(ByteArray(1), 0, 1))
                source.close()
            }
        } finally { password.fill('\u0000'); file.delete() }
    }
    @Test fun pictureDecoderDisplaysOriginalPixelsFromEncryptedSource() {
        val colors = intArrayOf(Color.RED, Color.GREEN, Color.BLUE, Color.WHITE)
        val original = Bitmap.createBitmap(colors, 2, 2, Bitmap.Config.ARGB_8888)
        val bytes = ByteArrayOutputStream().use { stream -> original.compress(Bitmap.CompressFormat.PNG, 100, stream); stream.toByteArray() }
        original.recycle()
        val file = File.createTempFile("picture-test-", ".dmpa", context.cacheDir).apply { delete() }
        val password = "test-picture-password".toCharArray()
        try {
            MediaArray.create(file, "Picture", listOf(MediaInput("colors.png", "image/png") { bytes.inputStream() }), password).use { array ->
                EncryptedPictureDecoder.decode(array, array.catalog.entries.single()).let { decoded ->
                    assertEquals(2, decoded.width); assertEquals(2, decoded.height)
                    val actual = IntArray(4); decoded.getPixels(actual, 0, 2, 0, 0, 2, 2)
                    assertArrayEquals(colors, actual); decoded.recycle()
                }
            }
        } finally { password.fill('\u0000'); file.delete() }
    }
}
