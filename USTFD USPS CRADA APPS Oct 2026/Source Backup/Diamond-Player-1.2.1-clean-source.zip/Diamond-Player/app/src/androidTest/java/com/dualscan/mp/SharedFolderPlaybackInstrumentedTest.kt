package com.dualscan.mp

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SdkSuppress
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.audio.EncryptedMediaRegistry
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Actual Share-authored one-item files are read directly from a user-granted system folder. */
@RunWith(AndroidJUnit4::class)
@SdkSuppress(minSdkVersion = 34)
class SharedFolderPlaybackInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val assets get() = instrumentation.context.assets
    private val fixture get() = assets.open("loose/fixture.json").bufferedReader().use { JSONObject(it.readText()) }

    @Test fun systemFolderLibraryKeepsIndividualFilesEncryptedAndOpensPhotosOnlyInsidePlayer() {
        withLooseFolder { tree, rootName, files ->
            val metadata = fixture
            val scanned = SharedEncryptedLibrary.scan(context, tree)
            assertEquals(metadata.getJSONArray("items").length() + metadata.getJSONArray("passwordItems").length(), scanned.documents.size)
            assertTrue(scanned.documents.all { it.displayName.endsWith(".diamond") })
            val before = privateFiles()
            val activity = ShareInterchangeInstrumentedTest().currentPlayerActivity()
            lateinit var model: MpViewModel
            instrumentation.runOnMainSync { model = ViewModelProvider(activity)[MpViewModel::class.java]; model.openMediaFolder(tree) }
            try {
                awaitModel(model) { !it.busy }
                instrumentation.runOnMainSync {
                    assertNull(model.error); assertTrue(model.isFolderLibrary); assertFalse(model.canSave)
                    assertEquals(metadata.getJSONArray("items").length(), model.entries.size)
                    assertEquals(1, model.lockedMediaCount)
                    assertEquals(model.entries.size, model.entries.map { it.id }.toSet().size)
                    model.dismissLibraryPasswordRequest()
                }
                val library = requireNotNull(model.array) as CompositeMediaLibrary
                val photo = library.catalog.entries.single { it.displayName == "photo.png" }
                val expectedPhoto = items(metadata).single { it.getString("displayName") == "photo.png" }.getJSONObject("image")
                instrumentation.runOnMainSync { model.play(photo) }
                awaitModel(model) { it.picture != null }
                instrumentation.runOnMainSync { assertPixels(requireNotNull(model.picture), expectedPhoto) }
                val audio = MediaLibraryIndex.sorted(library.catalog.entries.filter { it.mimeType.startsWith("audio/") }, MediaSortOrder.TRACKS)
                assertEquals(listOf("01 Interop.wav", "02 Interop.wav"), audio.map { it.displayName })
                assertEquals("cover.png", MediaLibraryIndex.coverFor(audio.first(), library.catalog.entries)?.displayName)
                assertTrue(library.openSourceCount <= 4)
                assertCiphertextUnchanged(files)
                assertNoGalleryMedia(rootName, files.values.toList())
                val session = EncryptedMediaRegistry.register(library, listOf(photo))
                try {
                    val response = shell("content read --uri ${EncryptedMediaRegistry.uri(context.packageName, session, photo)}")
                    assertEquals("Another app UID receives no decrypted photo bytes", 0, response.first.size)
                    assertTrue(response.second.contains("Permission Denial", true) || response.second.contains("not exported", true) || response.second.contains("SecurityException", true))
                } finally { EncryptedMediaRegistry.unregister(session) }

                instrumentation.runOnMainSync { model.openProtectedLibraryFiles("Wrong loose fixture password".toCharArray()) }
                awaitModel(model) { !it.busy }
                instrumentation.runOnMainSync { assertNotNull(model.error); assertEquals(1, model.lockedMediaCount); model.dismissError() }
                instrumentation.runOnMainSync { model.openProtectedLibraryFiles(metadata.getString("password").toCharArray()) }
                awaitModel(model) { !it.busy }
                instrumentation.runOnMainSync {
                    assertNull(model.error); assertEquals(0, model.lockedMediaCount)
                    assertEquals(items(metadata).size, model.entries.size)
                    model.play(model.entries.single { it.displayName == "private.png" })
                }
                awaitModel(model) { it.picture != null }
                val expectedPrivate = items(metadata).single { it.getString("displayName") == "private.png" }.getJSONObject("image")
                instrumentation.runOnMainSync { assertPixels(requireNotNull(model.picture), expectedPrivate) }
                assertCiphertextUnchanged(files)
                assertEquals("Folder playback creates no internal plaintext or copied vault files", before, privateFiles())
                val photoUri = files.entries.single { it.key.getString("displayName") == "photo.png" }.value
                val view = Intent(Intent.ACTION_VIEW).setDataAndType(photoUri, "application/octet-stream").addCategory(Intent.CATEGORY_DEFAULT)
                assertTrue("Android Files offers Diamond for a named .diamond document", context.packageManager.queryIntentActivities(view, PackageManager.MATCH_DEFAULT_ONLY).any { it.activityInfo.packageName == context.packageName })
                val raw = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(photoUri.toString().removeSuffix(".diamond")), "application/octet-stream").addCategory(Intent.CATEGORY_DEFAULT)
                assertFalse("Diamond is not a handler for arbitrary raw binary files", context.packageManager.queryIntentActivities(raw, PackageManager.MATCH_DEFAULT_ONLY).any { it.activityInfo.packageName == context.packageName })
                context.startActivity(view.setPackage(context.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_GRANT_READ_URI_PERMISSION))
                awaitModel(model) { !it.busy && it.entries.size == 1 && it.entries.single().displayName == "photo.png" }
                instrumentation.runOnMainSync { assertNull(model.error); assertFalse(model.isFolderLibrary); model.play(model.entries.single()) }
                awaitModel(model) { it.picture != null }
                instrumentation.runOnMainSync { assertPixels(requireNotNull(model.picture), expectedPhoto) }
                assertEquals("Files ACTION_VIEW also opens the encrypted source directly", before, privateFiles())
                File(context.filesDir, "verification-shared-folder-library.json").writeText(JSONObject()
                    .put("result", "PASS").put("androidApi", 36).put("extension", ".diamond")
                    .put("realSafFolderGrant", true).put("directSharedFolderReads", true)
                    .put("individualEncryptedFiles", files.size).put("distinctRuntimeEntryIds", true)
                    .put("galleryMediaAbsent", true).put("ordinaryImageDecoderRejected", true)
                    .put("inAppPhotoExactPixels", true).put("protectedFilePasswordRequired", true)
                    .put("externalUidDenied", true).put("ciphertextUnchanged", true)
                    .put("androidFilesViewIntent", true)
                    .put("plaintextDiskFilesCreated", false).put("physicalUsbTested", false).toString(2))
            } finally {
                instrumentation.runOnMainSync { model.lock(); activity.finish() }
                instrumentation.waitForIdleSync()
            }
        }
    }

    @Test fun separateEncryptedAudioFilesShareOneGaplessNativeQueue() {
        withLooseFolder { tree, _, files ->
            val metadata = fixture
            val scanned = SharedEncryptedLibrary.scan(context, tree)
            val documents = scanned.documents.map { document -> EncryptedLibraryDocument(
                DocumentsContract.buildDocumentUri(document.uri.authority, DocumentsContract.getDocumentId(document.uri)).toString(),
                "Phone/${document.relativePath}") { SafRandomAccessSource(context, document.uri) } }
            CompositeMediaLibrary.open("Loose encrypted album", documents).use { library ->
                val audio = MediaLibraryIndex.sorted(library.catalog.entries.filter { it.mimeType.startsWith("audio/") }, MediaSortOrder.TRACKS)
                assertEquals(2, audio.size); assertNotEquals(audio[0].id, audio[1].id)
                val expectedItems = items(metadata).filter { it.getString("mimeType").startsWith("audio/") }.sortedBy { it.getString("displayName") }
                val expected = ByteArrayOutputStream().use { combined ->
                    audio.forEachIndexed { index, entry ->
                        val bytes = library.openEntry(entry.id).use { it.readBytes() }
                        try {
                            val item = expectedItems[index]
                            assertEquals(item.getString("sha256"), hash(bytes))
                            val pcm = bytes.copyOfRange(44, bytes.size)
                            try { assertEquals(item.getJSONObject("audio").getString("pcmSha256"), hash(pcm)); combined.write(pcm) }
                            finally { pcm.fill(0) }
                        } finally { bytes.fill(0) }
                    }
                    combined.toByteArray()
                }
                try {
                    assertEquals(metadata.getJSONObject("gapless").getString("pcmSha256"), hash(expected))
                    assertEquals(metadata.getJSONObject("gapless").getLong("pcmBytes"), expected.size.toLong())
                    val format = expectedItems.first().getJSONObject("audio")
                    val bytesPerFrame = format.getInt("channelCount") * format.getInt("bitDepth") / 8
                    val firstFrames = format.getLong("pcmBytes") / bytesPerFrame
                    NativeGaplessInstrumentedTest().verifyQueue(library, expected, firstFrames, bytesPerFrame, "loose-files-24-192", requirePlayingTransition = false)
                } finally { expected.fill(0) }
            }
            assertCiphertextUnchanged(files)
        }
    }

    private fun withLooseFolder(action: (Uri, String, Map<JSONObject, Uri>) -> Unit) {
        val parent = ShareInterchangeInstrumentedTest().obtainPicturesFolderGrant()
        val rootName = "DiamondLoose-${UUID.randomUUID()}"
        val directory = requireNotNull(DocumentFile.fromTreeUri(context, parent)?.createDirectory(rootName))
        var tree: Uri? = null
        val files = LinkedHashMap<JSONObject, Uri>()
        try {
            for (item in items(fixture)) {
                val path = item.getString("file").split('/')
                var folder = directory
                for (part in path.dropLast(1)) folder = folder.findFile(part) ?: requireNotNull(folder.createDirectory(part))
                val output = requireNotNull(folder.createFile("application/octet-stream", path.last()))
                assets.open("loose/${item.getString("file")}").use { input ->
                    requireNotNull(context.contentResolver.openOutputStream(output.uri, "wt")).use { EncryptedCollectionCopy.copy(input, it) }
                }
                files[item] = output.uri
            }
            assertCiphertextUnchanged(files)
            val grant = ShareInterchangeInstrumentedTest().obtainFolderGrant(DocumentsContract.getDocumentId(directory.uri))
            tree = grant
            action(grant, rootName, files)
        } finally {
            directory.delete()
            tree?.let { runCatching { context.contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } }
        }
    }

    private fun items(metadata: JSONObject): List<JSONObject> = listOf("items", "passwordItems").flatMap { key ->
        val array = metadata.getJSONArray(key); (0 until array.length()).map(array::getJSONObject)
    }
    private fun assertCiphertextUnchanged(files: Map<JSONObject, Uri>) {
        for ((item, uri) in files) {
            val bytes = requireNotNull(context.contentResolver.openInputStream(uri)).use { it.readBytes() }
            try {
                assertEquals(item.getLong("encryptedBytes"), bytes.size.toLong())
                assertEquals(item.getString("encryptedSha256"), hash(bytes))
                assertNull("Ordinary Gallery image decoding rejects encrypted files", BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
            } finally { bytes.fill(0) }
        }
    }
    private fun assertNoGalleryMedia(rootName: String, files: List<Uri>) {
        val paths = files.map { uri -> "/storage/emulated/0/${DocumentsContract.getDocumentId(uri).substringAfter(':')}" }
        val complete = CountDownLatch(paths.size)
        MediaScannerConnection.scanFile(context, paths.toTypedArray(), null) { _, _ -> complete.countDown() }
        assertTrue("Android scans the shared folder files", complete.await(15, TimeUnit.SECONDS))
        val observed = shell("content query --uri ${MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)} --projection _id:relative_path")
        assertEquals("", observed.second)
        assertFalse("Gallery indexes no photo from the encrypted file tree", observed.first.toString(Charsets.UTF_8).contains(rootName))
    }
    private fun shell(command: String): Pair<ByteArray, String> {
        val pipes = instrumentation.uiAutomation.executeShellCommandRwe(command); pipes[1].close()
        val output = ParcelFileDescriptor.AutoCloseInputStream(pipes[0]).use { it.readBytes() }
        val error = ParcelFileDescriptor.AutoCloseInputStream(pipes[2]).bufferedReader().use { it.readText() }
        return output to error
    }
    private fun assertPixels(bitmap: Bitmap, expected: JSONObject) {
        assertEquals(expected.getInt("width"), bitmap.width); assertEquals(expected.getInt("height"), bitmap.height)
        val actual = IntArray(bitmap.width * bitmap.height); bitmap.getPixels(actual, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        val pixels = expected.getJSONArray("pixels")
        assertArrayEquals(IntArray(pixels.length()) { pixels.getLong(it).toInt() }, actual)
    }
    private fun awaitModel(model: MpViewModel, predicate: (MpViewModel) -> Boolean) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(20)
        var complete = false
        while (!complete && System.nanoTime() < deadline) {
            instrumentation.runOnMainSync { complete = predicate(model) }
            if (!complete) Thread.sleep(25)
        }
        assertTrue("The player operation must complete without closing the app", complete)
    }
    private fun privateFiles(): Set<String> = listOf(context.filesDir, context.cacheDir).flatMap { root ->
        root.walkTopDown().filter { it.isFile }.map { "${root.name}/${it.relativeTo(root).path}" }.toList()
    }.toSet()
    private fun hash(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
}
