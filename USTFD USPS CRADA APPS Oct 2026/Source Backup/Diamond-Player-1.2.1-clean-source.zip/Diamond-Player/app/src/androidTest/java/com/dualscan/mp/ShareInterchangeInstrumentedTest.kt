@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.dualscan.mp

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.accessibility.AccessibilityNodeInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.C
import androidx.media3.datasource.DataSpec
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SdkSuppress
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry
import androidx.test.runner.lifecycle.Stage
import com.dualscan.mp.audio.EncryptedMediaRegistry
import com.dualscan.mp.audio.WavPcmSource
import com.dualscan.mp.audio.strictPrecisionFailure
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.mp.core.UnlockedMediaArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Consumes actual ArchiveEngine exports made by the separate Share Android app. */
@RunWith(AndroidJUnit4::class)
class ShareInterchangeInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val assets get() = instrumentation.context.assets
    private val vector get() = assets.open("interop/share-fixture.json").bufferedReader().use { JSONObject(it.readText()) }

    @Test fun shareDefaultImageOpensWithoutPasswordAndPreservesEveryEntryAndCoverPixel() {
        withFixture("share-global.dshare") { file ->
            val encryptedHash = file.sha256()
            val before = privateFiles()
            MediaArray.open(file).use { array ->
                assertTrue(array.isPortable)
                assertFalse(array.passwordProtected)
                assertCatalogAndBytes(array)
                val expectedCover = vector.getJSONObject("cover")
                val media = MediaLibraryIndex.playable(array.catalog.entries)
                assertTrue("Fixture must include a document excluded from playback", media.size < array.catalog.entries.size)
                val audio = media.single { it.relativePath == vector.getJSONObject("audio").getString("relativePath") }
                val cover = requireNotNull(MediaLibraryIndex.coverFor(audio, media))
                assertEquals(expectedCover.getString("relativePath"), cover.relativePath)
                EncryptedPictureDecoder.decode(array, cover).let { bitmap ->
                    try {
                        assertEquals(expectedCover.getInt("width"), bitmap.width)
                        assertEquals(expectedCover.getInt("height"), bitmap.height)
                        val pixels = IntArray(bitmap.width * bitmap.height)
                        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                        val expected = expectedCover.getJSONArray("pixels")
                        assertArrayEquals(IntArray(expected.length()) { expected.getLong(it).toInt() }, pixels)
                    } finally { bitmap.recycle() }
                }

                // Media3 reads the same authenticated payload, including precise range seeks.
                val source = EncryptedMediaDataSource.Factory(array).createDataSource()
                val offset = 61L
                val length = minOf(4097L, audio.sizeBytes - offset).toInt()
                assertTrue(length > 0)
                try {
                    assertEquals(length.toLong(), source.open(DataSpec.Builder()
                        .setUri(Uri.parse("dualscan-mp://entry/${audio.id}"))
                        .setPosition(offset).setLength(length.toLong()).build()))
                    val actual = ByteArray(length); var position = 0
                    while (position < actual.size) {
                        val count = source.read(actual, position, minOf(103, actual.size - position))
                        assertTrue(count > 0); position += count
                    }
                    val direct = ByteArray(length); var directPosition = 0
                    while (directPosition < direct.size) {
                        val count = array.readAt(audio.id, offset + directPosition, direct, directPosition, direct.size - directPosition)
                        assertTrue(count > 0); directPosition += count
                    }
                    assertArrayEquals(direct, actual)
                    assertEquals(C.RESULT_END_OF_INPUT, source.read(ByteArray(1), 0, 1))
                    actual.fill(0); direct.fill(0)
                } finally { source.close() }
            }
            assertEquals("Opening and playback adapters leave ciphertext unchanged", encryptedHash, file.sha256())
            assertEquals("No plaintext playback staging file is created", before, privateFiles())
        }
    }

    @Test fun shareProtectedImageRequiresItsPasswordAndDoesNotFallBackToGlobalKey() {
        withFixture("share-password.dshare") { file ->
            try {
                MediaArray.open(file).close()
                fail("Protected Share image opened without its password")
            } catch (_: PasswordRequiredException) { }
            val wrong = "Incorrect public fixture password".toCharArray()
            try {
                try {
                    MediaArray.open(file, wrong).close()
                    fail("Protected image accepted an incorrect password")
                } catch (_: IOException) { }
            } finally { wrong.fill('\u0000') }
            val password = vector.getString("password").toCharArray()
            try {
                MediaArray.open(file, password).use { array ->
                    assertTrue(array.isPortable)
                    assertTrue(array.passwordProtected)
                    assertCatalogAndBytes(array)
                }
            } finally { password.fill('\u0000') }
        }
    }

    @Test @SdkSuppress(minSdkVersion = 34)
    fun share192k24BitMusicReachesNativePcmProviderWithoutChangingSamples() {
        withFixture("share-global.dshare") { file ->
            val before = privateFiles()
            MediaArray.open(file).use { array ->
                val expected = vector.getJSONObject("audio")
                val entry = array.catalog.entries.single { it.relativePath == expected.getString("relativePath") }
                val session = EncryptedMediaRegistry.register(array, listOf(entry))
                try {
                    WavPcmSource(context, EncryptedMediaRegistry.uri(context.packageName, session, entry), entry.displayName).use { source ->
                        assertEquals(expected.getInt("bitDepth"), source.info.sourceBitDepth)
                        assertEquals(expected.getInt("sampleRateHz"), source.info.sourceSampleRateHz)
                        assertEquals(expected.getInt("channelCount"), source.info.sourceChannelCount)
                        assertNull(strictPrecisionFailure(source.info, source.format))
                        val digest = MessageDigest.getInstance("SHA-256")
                        val buffer = ByteBuffer.allocateDirect(96 * 1024)
                        val bytes = ByteArray(buffer.capacity()); var total = 0L
                        try {
                            while (true) {
                                buffer.clear()
                                val count = source.read(buffer)
                                if (count < 0) break
                                assertTrue(count > 0 && count % source.format.bytesPerFrame == 0)
                                assertEquals(count, buffer.position())
                                buffer.flip(); buffer.get(bytes, 0, count)
                                digest.update(bytes, 0, count); bytes.fill(0); total += count
                            }
                            assertEquals(expected.getLong("pcmBytes"), total)
                            assertEquals(expected.getString("pcmSha256"), hex(digest.digest()))
                        } finally { bytes.fill(0) }
                    }
                } finally { EncryptedMediaRegistry.unregister(session) }
            }
            assertEquals("Native playback reads ciphertext without plaintext files", before, privateFiles())
        }
    }

    @Test @SdkSuppress(minSdkVersion = 34)
    fun localPicturesCopyStaysEncryptedAndGalleryCannotDecodeOrIndexItsPhoto() {
        val resolver = context.contentResolver
        val tree = obtainPicturesFolderGrant()
        val folderName = "DiamondCiphertext-${UUID.randomUUID()}"
        val relative = "${Environment.DIRECTORY_PICTURES}/$folderName/"
        val filename = "Share-photo-collection.dshare"
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val folder = requireNotNull(DocumentsContract.createDocument(resolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, folderName))
        val destination = requireNotNull(DocumentsContract.createDocument(resolver, folder, "application/octet-stream", filename))
        try {
            val before = privateFiles()
            val receipt = assets.open("interop/share-global.dshare").use { input ->
                requireNotNull(resolver.openOutputStream(destination, "wt")).use { output ->
                    EncryptedCollectionCopy.copy(input, output)
                }
            }
            requireNotNull(resolver.openInputStream(destination)).use { EncryptedCollectionCopy.verify(it, receipt) }
            assertEquals(vector.getString("globalSha256"), hex(receipt.sha256))
            val path = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "$folderName/$filename").absolutePath
            val scanned = CountDownLatch(1)
            val scannedUri = AtomicReference<Uri?>()
            MediaScannerConnection.scanFile(context, arrayOf(path), null) { _, uri -> scannedUri.set(uri); scanned.countDown() }
            assertTrue("Android completed the ordinary media scan", scanned.await(15, TimeUnit.SECONDS))
            // A SAF-created row belongs to DocumentsProvider, so use a separate broad observer
            // for classification; the app itself retains only its ordinary folder URI grant.
            val classification = shellObservation("content query --uri ${requireNotNull(scannedUri.get())} --projection media_type:mime_type")
            assertTrue("Android ignores the encrypted extension or classifies it as a non-media file: $classification",
                classification.contains("No result found") || classification.contains("media_type=0"))
            assertTrue("An encrypted collection has no playable media MIME type", listOf("image/", "audio/", "video/").none { classification.contains("mime_type=$it") })
            val gallery = shellObservation("content query --uri ${MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)} --projection _id --where relative_path='$relative'")
            assertTrue("The transferred container exposes no standalone Gallery photo: $gallery", gallery.contains("No result found"))
            requireNotNull(resolver.openInputStream(destination)).use { clearAttempt ->
                assertNull("A normal image decoder cannot read the encrypted container", BitmapFactory.decodeStream(clearAttempt))
            }
            MediaArray.open(SafRandomAccessSource(context, destination)).use { array ->
                val expected = vector.getJSONObject("cover")
                val photo = array.catalog.entries.single { it.relativePath == expected.getString("relativePath") }
                EncryptedPictureDecoder.decode(array, photo).let { bitmap ->
                    try {
                        assertEquals(expected.getInt("width"), bitmap.width); assertEquals(expected.getInt("height"), bitmap.height)
                        val pixels = IntArray(bitmap.width * bitmap.height)
                        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                        val expectedPixels = expected.getJSONArray("pixels")
                        assertArrayEquals(IntArray(expectedPixels.length()) { expectedPixels.getLong(it).toInt() }, pixels)
                    } finally { bitmap.recycle() }
                }
            }
            requireNotNull(resolver.openInputStream(destination)).use { EncryptedCollectionCopy.verify(it, receipt) }
            assertEquals("Photo viewing creates no plaintext file or image cache", before, privateFiles())
        } finally { DocumentsContract.deleteDocument(resolver, folder) }
    }

    @Test @SdkSuppress(minSdkVersion = 34)
    fun decodedMediaProviderCannotBeExportedOrGrantReadAccessToOtherApps() {
        val provider = requireNotNull(context.packageManager.resolveContentProvider("${context.packageName}.internal-media", PackageManager.GET_META_DATA))
        assertFalse("Gallery and other app UIDs cannot enter the decoder provider", provider.exported)
        assertFalse("The player cannot hand another app a plaintext URI grant", provider.grantUriPermissions)
        assertEquals(context.applicationInfo.uid, provider.applicationInfo.uid)
        withFixture("share-global.dshare") { file ->
            MediaArray.open(file).use { array ->
                val photo = array.catalog.entries.first { it.mimeType.startsWith("image/") }
                val session = EncryptedMediaRegistry.register(array, listOf(photo))
                try {
                    val uri = EncryptedMediaRegistry.uri(context.packageName, session, photo)
                    // UiAutomation executes as the separate shell UID, which has no app URI grant.
                    val pipes = instrumentation.uiAutomation.executeShellCommandRwe("content read --uri $uri")
                    pipes[1].close()
                    val output = ParcelFileDescriptor.AutoCloseInputStream(pipes[0]).use { it.readBytes() }
                    val denial = ParcelFileDescriptor.AutoCloseInputStream(pipes[2]).bufferedReader().use { it.readText() }
                    assertEquals("Another UID receives no photo bytes", 0, output.size)
                    assertTrue("A separate UID must be denied even while the photo is unlocked",
                        denial.contains("Permission Denial", true) || denial.contains("not exported", true) || denial.contains("SecurityException", true))
                } finally { EncryptedMediaRegistry.unregister(session) }
            }
        }
    }

    private fun assertCatalogAndBytes(array: UnlockedMediaArray) {
        val expected = vector
        assertEquals(expected.getString("title"), array.catalog.title)
        assertNotNull("Share backup manifest remains authenticated in the shared container", array.catalog.backupMetadata)
        val entries = expected.getJSONArray("entries")
        assertEquals(entries.length(), array.catalog.entries.size)
        for (index in 0 until entries.length()) {
            val item = entries.getJSONObject(index)
            val entry = array.catalog.entries.single { it.relativePath == item.getString("relativePath") }
            assertEquals(item.getLong("sizeBytes"), entry.sizeBytes)
            assertEquals(item.getString("sha256"), entry.sha256)
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = ByteArray(8191); var position = 0L
            try {
                while (position < entry.sizeBytes) {
                    val count = array.readAt(entry.id, position, bytes, 0, minOf(bytes.size.toLong(), entry.sizeBytes - position).toInt())
                    assertTrue(count > 0); digest.update(bytes, 0, count); position += count
                }
                assertEquals(entry.sha256, hex(digest.digest()))
                assertEquals(-1, array.readAt(entry.id, entry.sizeBytes, bytes, 0, 1))
            } finally { bytes.fill(0) }
        }
    }

    /** A real DocumentsUI grant, with no adopted shell permissions or broad storage access. */
    internal fun obtainPicturesFolderGrant(): Uri = obtainFolderGrant("primary:Pictures")

    internal fun obtainFolderGrant(documentId: String): Uri {
        val existing = context.contentResolver.persistedUriPermissions.firstOrNull { permission ->
            permission.isReadPermission && permission.isWritePermission && permission.uri.authority == UsbAccessPolicy.AUTHORITY &&
                runCatching { DocumentsContract.getTreeDocumentId(permission.uri) == documentId }.getOrDefault(false)
        }
        if (existing != null) return existing.uri
        val activity = currentPlayerActivity()
        val complete = CountDownLatch(1); val chosen = AtomicReference<Uri?>(); val failure = AtomicReference<Throwable?>()
        instrumentation.runOnMainSync {
            val launcher = activity.activityResultRegistry.register("encrypted-folder-test-${documentId.hashCode()}", ActivityResultContracts.OpenDocumentTree()) { uri ->
                try {
                    requireNotNull(uri) { "Folder selection was cancelled." }
                    context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    chosen.set(uri)
                } catch (error: Throwable) { failure.set(error) }
                finally { complete.countDown() }
            }
            launcher.launch(DocumentsContract.buildDocumentUri(UsbAccessPolicy.AUTHORITY, documentId))
        }
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(25)
        while (complete.count > 0 && System.nanoTime() < deadline) {
            instrumentation.uiAutomation.rootInActiveWindow?.let { root ->
                listOf("Use this folder", "USE THIS FOLDER", "Allow", "ALLOW").forEach { text ->
                    root.findAccessibilityNodeInfosByText(text).filter { it.text?.toString()?.equals(text, ignoreCase = true) == true }.forEach(::click)
                }
            }
            complete.await(150, TimeUnit.MILLISECONDS)
        }
        failure.get()?.let { throw AssertionError("Could not retain the actual folder picker grant", it) }
        check(complete.count == 0L) { "The Android folder picker did not return the selected folder grant." }
        val tree = requireNotNull(chosen.get())
        check(DocumentsContract.getTreeDocumentId(tree) == documentId) { "Choose the selected local media folder." }
        return tree
    }

    internal fun currentPlayerActivity(): MainActivity {
        var resumed: MainActivity? = null
        instrumentation.runOnMainSync {
            resumed = ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED).filterIsInstance<MainActivity>().firstOrNull()
        }
        return resumed ?: instrumentation.startActivitySync(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
    }

    private fun click(node: AccessibilityNodeInfo) {
        var target: AccessibilityNodeInfo? = node
        repeat(6) {
            val item = target ?: return
            if (item.isClickable && item.isEnabled) { item.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
            target = item.parent
        }
    }

    private fun shellObservation(command: String): String {
        val pipes = instrumentation.uiAutomation.executeShellCommandRwe(command)
        pipes[1].close()
        val output = ParcelFileDescriptor.AutoCloseInputStream(pipes[0]).bufferedReader().use { it.readText() }
        val error = ParcelFileDescriptor.AutoCloseInputStream(pipes[2]).bufferedReader().use { it.readText() }
        assertEquals("A separate observer must complete its media query", "", error)
        return output
    }

    private fun withFixture(name: String, action: (File) -> Unit) {
        val file = File.createTempFile("share-interop-encrypted-", ".dshare", context.cacheDir)
        try {
            assets.open("interop/$name").use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            action(file)
        } finally { file.delete() }
    }
    private fun File.sha256(): String = inputStream().use { input ->
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = ByteArray(64 * 1024)
        while (true) { val count = input.read(bytes); if (count < 0) break; digest.update(bytes, 0, count) }
        hex(digest.digest())
    }
    private fun privateFiles(): Set<String> = listOf(context.filesDir, context.cacheDir).flatMap { root ->
        root.walkTopDown().filter { it.isFile }.map { "${root.name}/${it.relativeTo(root).path}" }.toList()
    }.toSet()
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
}
