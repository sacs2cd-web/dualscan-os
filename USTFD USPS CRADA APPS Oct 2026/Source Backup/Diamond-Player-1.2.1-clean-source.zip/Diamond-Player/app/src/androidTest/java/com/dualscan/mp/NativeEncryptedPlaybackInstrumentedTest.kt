package com.dualscan.mp

import android.media.AudioFormat
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SdkSuppress
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.audio.CodecPcmSource
import com.dualscan.mp.audio.EncryptedMediaRegistry
import com.dualscan.mp.audio.NativePcmSource
import com.dualscan.mp.audio.WavPcmSource
import com.dualscan.mp.audio.strictPrecisionFailure
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import com.dualscan.mp.core.UnlockedMediaArray
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Runs the shipped provider and decoder on an independent Node/OpenSSL fixture.
 * Only the encrypted array is copied to disk. Source WAV/FLAC assets stay in the
 * test APK; decoded PCM is hashed in memory and never written to a media file.
 * This tests source preservation, not a physical DAC or Android mixer contract.
 */
@RunWith(AndroidJUnit4::class)
@SdkSuppress(minSdkVersion = 34)
class NativeEncryptedPlaybackInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val assets get() = instrumentation.context.assets

    @Test fun encrypted32Bit768kWaveReportsSourceAndPreservesBytesWithoutOutputClaim() {
        val pcm = ByteBuffer.allocate(4096 * 8).order(ByteOrder.LITTLE_ENDIAN).apply {
            repeat(4096) { frame -> putInt(Int.MIN_VALUE + frame * 131_071); putInt(Int.MAX_VALUE - frame * 65_537) }
        }.array()
        val wave = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt(36 + pcm.size); put("WAVEfmt ".toByteArray()); putInt(16)
            putShort(1); putShort(2); putInt(768_000); putInt(768_000 * 8); putShort(8); putShort(32)
            put("data".toByteArray()); putInt(pcm.size); put(pcm)
        }.array()
        val file = File.createTempFile("source-32-768-encrypted-", ".dmpa", context.cacheDir).apply { delete() }
        val password = "Public 32bit 768k test 2026".toCharArray()
        try {
            MediaArray.create(file, "Source format verification", listOf(MediaInput("source-32-768.wav", "audio/wav") { wave.inputStream() }), password).use { array ->
                val entry = array.catalog.entries.single()
                val session = EncryptedMediaRegistry.register(array, listOf(entry))
                try {
                    val uri = EncryptedMediaRegistry.uri(context.packageName, session, entry)
                    WavPcmSource(context, uri, entry.displayName).use { source ->
                        assertEquals(32, source.info.sourceBitDepth)
                        assertEquals(768_000, source.info.sourceSampleRateHz)
                        assertEquals(AudioFormat.ENCODING_PCM_32BIT, source.format.encoding)
                        assertEquals(768_000, source.format.sampleRateHz)
                        assertNull(strictPrecisionFailure(source.info, source.format))
                        val actual = hashPcm(source)
                        assertEquals(pcm.size.toLong(), actual.first)
                        assertEquals(hex(MessageDigest.getInstance("SHA-256").digest(pcm)), actual.second)
                    }
                } finally { EncryptedMediaRegistry.unregister(session) }
            }
        } finally { password.fill('\u0000'); file.delete(); pcm.fill(0); wave.fill(0) }
    }

    @Test fun encryptedProxyWavAndFlacProduceExactOriginal24BitPcm() {
        withFixture("flac-media") { array, vector ->
            val expectedHash = "a2f9453ab78682f920a3602ef579dea1e062419e0304a08188c37fa0a3ba05cf"
            val expectedBytes = 1_728_000L
            assertEquals(expectedHash, vector.getString("sourcePcmSha256"))
            assertEquals(expectedBytes, vector.getLong("sourcePcmBytes"))
            val session = EncryptedMediaRegistry.register(array, array.catalog.entries)
            val cases = JSONArray()
            val before = privateFiles()
            try {
                assertEquals(2, array.catalog.entries.size)
                for (entry in array.catalog.entries) {
                    val uri = EncryptedMediaRegistry.uri(context.packageName, session, entry)
                    val isWave = entry.mimeType == "audio/wav"
                    assertEquals("Provider signature sniff", isWave, WavPcmSource.isWave(context, uri))
                    val details = JSONObject().put("entry", entry.displayName).put("providerUriScheme", uri.scheme)
                    cases.put(details)
                    val source: NativePcmSource = if (isWave) {
                        WavPcmSource(context, uri, entry.displayName)
                    } else {
                        CodecPcmSource(context, uri, entry.displayName)
                    }
                    source.use {
                        details.put("sourceBits", it.info.sourceBitDepth)
                            .put("sourceRate", it.info.sourceSampleRateHz)
                            .put("sourceChannels", it.info.sourceChannelCount)
                            .put("producedEncoding", it.format.encoding)
                            .put("decoderEncoding", it.decoderFormat?.encoding ?: JSONObject.NULL)
                        if (it is CodecPcmSource) details.put("decoderDiagnostics", it.decoderDiagnostics)
                        assertEquals(24, it.info.sourceBitDepth)
                        assertEquals(96_000, it.info.sourceSampleRateHz)
                        assertEquals(2, it.info.sourceChannelCount)
                        assertEquals(96_000, it.format.sampleRateHz)
                        assertEquals(2, it.format.channelCount)
                        assertEquals(AudioFormat.CHANNEL_OUT_STEREO, it.format.channelMask)
                        assertEquals(AudioFormat.ENCODING_PCM_24BIT_PACKED, it.format.encoding)
                        assertNull("Source precision must qualify before strict playback", strictPrecisionFailure(it.info, it.format))
                        if (!isWave) {
                            assertEquals("FLAC must actually decode to float before exact 24-bit packing",
                                AudioFormat.ENCODING_PCM_FLOAT, it.decoderFormat?.encoding)
                        }
                        val actual = hashPcm(it)
                        details.put("decodedBytes", actual.first).put("decodedPcmSha256", actual.second)
                        Log.i(TAG, details.toString())
                        assertEquals("Decoded PCM byte count: ${entry.displayName}", expectedBytes, actual.first)
                        assertEquals("Decoded PCM must preserve every source bit: ${entry.displayName}", expectedHash, actual.second)

                        // Seek back through the proxy after EOS, including decoder flush.
                        assertEquals("Seeking to zero must restart the source", 0L, it.seekTo(0))
                        val replay = hashPcm(it)
                        assertEquals("Replay byte count", expectedBytes, replay.first)
                        assertEquals("Replay PCM bytes", expectedHash, replay.second)

                        // Check a real nonzero seek, not only extractor restart. A FLAC
                        // seek returns a complete frame at or before the target. Convert
                        // its floored microsecond timestamp back to the exact 96 kHz
                        // sample index, then compare every remaining original byte.
                        val actualSeekUs = it.seekTo(1_500_000)
                        assertTrue("Nonzero seek must reach a frame near the requested time", actualSeekUs in 1_000_000L..1_500_000L)
                        val firstFrame = (actualSeekUs * 96_000 + 999_999) / 1_000_000
                        val byteOffset = (firstFrame * 6).toInt()
                        val original = assets.open("arrays/source-24-96.wav").use { input -> input.readBytes() }
                        val expectedTailHash = MessageDigest.getInstance("SHA-256").apply {
                            update(original, 44 + byteOffset, expectedBytes.toInt() - byteOffset)
                        }.digest().let(::hex)
                        original.fill(0)
                        val tail = hashPcm(it)
                        details.put("nonzeroSeekUs", actualSeekUs).put("seekPcmBytes", tail.first).put("seekPcmSha256", tail.second)
                        assertEquals("Seek tail byte count", expectedBytes - byteOffset, tail.first)
                        assertEquals("Seek tail preserves the exact original PCM", expectedTailHash, tail.second)
                    }
                }
                assertEquals("Playback must not leave a plaintext staging file", before, privateFiles())
            } catch (failure: Throwable) {
                Log.e(TAG, "Encrypted native PCM verification failed", failure)
                throw failure
            } finally {
                EncryptedMediaRegistry.unregister(session)
                // Diagnostics contain synthetic fixture metadata, format and digests only.
                File(context.filesDir, "verification-native-encrypted-result.json")
                    .writeText(JSONObject().put("cases", cases).put("expectedPcmSha256", expectedHash)
                        .put("expectedPcmBytes", expectedBytes).toString(2) + "\n")
            }
        }
    }

    @Test fun providerReadsIndependentEntriesAndRevokesAlreadyOpenDescriptor() {
        withFixture("host-media") { array, vector ->
            val session = EncryptedMediaRegistry.register(array, array.catalog.entries)
            try {
                val expected = vector.getJSONArray("entries")
                assertEquals(expected.length(), array.catalog.entries.size)
                for ((index, entry) in array.catalog.entries.withIndex()) {
                    val independent = expected.getJSONObject(index)
                    val uri = EncryptedMediaRegistry.uri(context.packageName, session, entry)
                    assertEquals(independent.getString("sha256"), entry.sha256)
                    context.contentResolver.openAssetFileDescriptor(uri, "r")!!.use { descriptor ->
                        assertEquals(entry.sizeBytes, descriptor.length)
                    }
                    val digest = MessageDigest.getInstance("SHA-256")
                    var size = 0L
                    context.contentResolver.openInputStream(uri)!!.use { input ->
                        val buffer = ByteArray(65_537)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            assertTrue("Provider reads must make progress", count > 0)
                            digest.update(buffer, 0, count)
                            size += count
                        }
                    }
                    assertEquals(independent.getLong("sizeBytes"), size)
                    assertEquals(independent.getString("sha256"), hex(digest.digest()))
                }

                val entry = array.catalog.entries.first()
                assertTrue("Revocation fixture needs a distant uncached page", entry.sizeBytes > 2L * MediaArray.CHUNK_BYTES)
                val uri = EncryptedMediaRegistry.uri(context.packageName, session, entry)
                context.contentResolver.openAssetFileDescriptor(uri, "r")!!.use { asset ->
                    val descriptor = asset.parcelFileDescriptor
                    val initial = ByteArray(32)
                    assertEquals(initial.size, Os.pread(descriptor.fileDescriptor, initial, 0, initial.size, 0L))
                    assertEquals("RIFF", String(initial, 0, 4, Charsets.US_ASCII))
                    EncryptedMediaRegistry.unregister(session)
                    var rejected = false
                    try {
                        // Avoid a page already returned before revocation. This offset is
                        // inside the entry, so an EOF result must not masquerade as denial.
                        Os.pread(descriptor.fileDescriptor, ByteArray(32), 0, 32, 2L * MediaArray.CHUNK_BYTES + 123)
                    } catch (failure: ErrnoException) {
                        assertEquals("Revoked provider reports an authenticated read failure", OsConstants.EIO, failure.errno)
                        rejected = true
                    }
                    assertTrue("Unregister must revoke reads on an existing proxy descriptor", rejected)
                }
                // Revocation must not accidentally close the separately owned array.
                val clear = ByteArray(4)
                assertEquals(4, array.readAt(entry.id, 0, clear, 0, clear.size))
                assertEquals("RIFF", String(clear, Charsets.US_ASCII))
            } finally {
                EncryptedMediaRegistry.unregister(session)
            }
        }
    }

    private fun hashPcm(source: NativePcmSource): Pair<Long, String> {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteBuffer.allocateDirect(96 * 1024)
        val copy = ByteArray(buffer.capacity())
        val deadline = android.os.SystemClock.elapsedRealtime() + 30_000
        var total = 0L
        while (true) {
            assertTrue("Decoder did not finish within 30 seconds", android.os.SystemClock.elapsedRealtime() < deadline)
            buffer.clear()
            val count = source.read(buffer)
            if (count < 0) break
            assertTrue("Decoder must produce complete PCM frames", count > 0 && count % source.format.bytesPerFrame == 0)
            assertEquals("PCM source byte count agrees with buffer position", count, buffer.position())
            buffer.flip(); buffer.get(copy, 0, count)
            digest.update(copy, 0, count)
            copy.fill(0)
            total += count
        }
        return total to hex(digest.digest())
    }

    private fun <T> withFixture(name: String, block: (UnlockedMediaArray, JSONObject) -> T): T {
        val vector = assets.open("arrays/$name-vector.json").bufferedReader().use { JSONObject(it.readText()) }
        val encrypted = File.createTempFile("native-encrypted-fixture-", ".dmpa", context.cacheDir)
        val password = vector.getString("password").toCharArray()
        try {
            assets.open("arrays/$name.dmpa").use { input -> encrypted.outputStream().use { output -> input.copyTo(output) } }
            assertEquals(vector.getLong("encryptedBytes"), encrypted.length())
            val digest = MessageDigest.getInstance("SHA-256")
            encrypted.inputStream().use { input ->
                val bytes = ByteArray(64 * 1024)
                while (true) { val count = input.read(bytes); if (count < 0) break; digest.update(bytes, 0, count) }
            }
            assertEquals("Independent encrypted fixture SHA", vector.getString("encryptedSha256"), hex(digest.digest()))
            return MediaArray.open(encrypted, password).use { block(it, vector) }
        } finally {
            password.fill('\u0000')
            encrypted.delete()
        }
    }

    private fun privateFiles(): Set<String> = listOf(context.filesDir, context.cacheDir).flatMap { root ->
        root.walkTopDown().filter { it.isFile }.map { "${root.name}/${it.relativeTo(root).path}" }.toList()
    }.toSet()

    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }

    companion object { private const val TAG = "MpNativeEncryptedTest" }
}
