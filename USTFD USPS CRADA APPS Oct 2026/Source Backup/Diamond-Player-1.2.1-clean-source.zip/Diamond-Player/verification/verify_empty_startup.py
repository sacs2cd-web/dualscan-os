"""Android regression on task-owned emulator-5580: upgrade, empty launch, picker cancellation.

Uses archived synthetic demo data, then clears emulator app data to check fresh startup.
"""
import hashlib
import json
import re
import subprocess
import time
import xml.etree.ElementTree as E
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'verification'
ADB = ['/Users/williamgrecia/Library/Android/sdk/platform-tools/adb', '-s', 'emulator-5580']
PACKAGE = 'com.dualscan.mp'
OLD = ROOT / 'dist-diamond-1.1.1/Diamond-Player-1.1.1-dev.apk'
NEW = ROOT / 'app/build/outputs/apk/debug/app-debug.apk'

def call(*args):
    return subprocess.check_output(ADB + list(args), timeout=60)

def start():
    call('shell', 'am', 'start', '-W', '-n', PACKAGE + '/.MainActivity')

def state():
    call('shell', 'uiautomator', 'dump', '/sdcard/diamond-empty.xml')
    data = call('exec-out', 'cat', '/sdcard/diamond-empty.xml')
    return data, E.fromstring(data)

def labels(root):
    return [n.get(key) for n in root.iter('node') for key in ('text', 'content-desc') if n.get(key)]

def empty(name=None):
    data, root = state()
    text = labels(root)
    assert {'Your library is empty', 'Add media', 'Open collection'} <= set(text), text
    assert not any(word in '\n'.join(text) for word in ('Demo album', 'Silver Thread', 'Somewhere Below', 'Opening demo', 'Source fidelity')), text
    assert all(n.get('package') == PACKAGE for n in root.iter('node')), text
    if name:
        (OUT / (name + '.xml')).write_bytes(data)
        (OUT / (name + '.png')).write_bytes(call('exec-out', 'screencap', '-p'))

def tap(value):
    _, root = state()
    for n in root.iter('node'):
        if n.get('text') == value or n.get('content-desc') == value:
            a, b, c, d = map(int, re.findall(r'\d+', n.get('bounds')))
            call('shell', 'input', 'tap', str((a+c)//2), str((b+d)//2))
            return
    raise AssertionError('Missing action: ' + value)

def picker_then_cancel():
    _, root = state()
    packages = {n.get('package') for n in root.iter('node')}
    assert packages & {'com.google.android.documentsui', 'com.android.documentsui'}, packages
    for _ in range(5):
        call('shell', 'input', 'keyevent', '4')
        _, current = state()
        if all(n.get('package') == PACKAGE for n in current.iter('node')):
            empty()
            return
    raise AssertionError('The document picker did not close after navigating back')

call('install', '-r', '-d', str(OLD))
call('shell', 'am', 'force-stop', PACKAGE)
start()
for attempt in range(12):
    if 'Somewhere Below 34th Street' in labels(state()[1]):
        break
else:
    raise AssertionError('Could not reproduce prior automatic demo load')
old_files = call('exec-out', 'run-as', PACKAGE, 'ls', 'files/collections').decode().splitlines()
assert any(name.startswith('Diamond-Demo-') for name in old_files), old_files
print('Reproduced old startup and retained demo working copy.', flush=True)
call('install', '-r', str(NEW))
start()
empty('diamond-empty-upgrade-1.1.2')
time.sleep(3)
empty()
assert not call('exec-out', 'run-as', PACKAGE, 'ls', 'files/collections').strip()
tap('Open collection')
picker_then_cancel()
tap('Add media')
tap('Choose a folder')
picker_then_cancel()
time.sleep(1)
empty()
print('Upgrade stays empty; cancelled collection/folder pickers stay empty.', flush=True)
call('shell', 'pm', 'clear', PACKAGE)
start()
empty('diamond-empty-dark-1.1.2')
time.sleep(3)
empty()
call('shell', 'am', 'force-stop', PACKAGE)
start()
empty()
tap('Switch light or dark appearance')
empty('diamond-empty-light-1.1.2')
report = {'result': 'PASS', 'version': '1.1.2', 'emulator': 'Android14 API34 ARM64',
          'apkSha256': hashlib.sha256(NEW.read_bytes()).hexdigest(),
          'reproducedPriorAutomaticDemo': True, 'upgradeFrom': '1.1.1',
          'priorDemoWorkingCopiesRemoved': True, 'stableEmptyUpgrade': True,
          'stableEmptyFreshData': True, 'stableEmptyColdRelaunch': True,
          'noAutomaticPickerOrPermissionPrompt': True,
          'explicitCollectionPickerAndCancel': True, 'explicitFolderPickerAndCancel': True,
          'screenshots': ['diamond-empty-upgrade-1.1.2.png', 'diamond-empty-dark-1.1.2.png', 'diamond-empty-light-1.1.2.png']}
(OUT / 'empty-startup-1.1.2.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2), flush=True)
