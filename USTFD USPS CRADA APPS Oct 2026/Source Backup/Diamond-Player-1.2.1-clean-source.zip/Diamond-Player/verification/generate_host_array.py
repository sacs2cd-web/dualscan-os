"""Independent Python/Node-OpenSSL DSMP0001 compatibility fixture.
All content and the Unicode password are public synthetic test data.
Fixed salt/nonce are TEST ONLY; production uses random values.
"""
import hashlib, io, json, math, os, pathlib, shutil, struct, subprocess, tempfile, wave, zlib
project = pathlib.Path(__file__).resolve().parents[1]
out = project / 'app/src/androidTest/assets/arrays'
out.mkdir(parents=True, exist_ok=True)
node = os.environ.get('NODE_BINARY') or shutil.which('node')
if not node:
    raise RuntimeError('Node.js is required to regenerate the independent test fixture.')
password = 'Dualscan MP public 東京 fixture 2026'
with tempfile.TemporaryDirectory(prefix='dualscan-mp-public-fixture-') as working:
    working = pathlib.Path(working)
    samples = bytearray()
    for i in range(96000 * 8):
        amplitude = round(40000 * math.sin(2 * math.pi * 997 * i / 96000))
        samples.extend(amplitude.to_bytes(3, 'little', signed=True) * 2)
    wav = io.BytesIO()
    with wave.open(wav, 'wb') as audio:
        audio.setnchannels(2); audio.setsampwidth(3); audio.setframerate(96000); audio.writeframes(samples)
    (working / 'quiet-tone-24bit.wav').write_bytes(wav.getvalue())
    def png_chunk(kind, value):
        return struct.pack('>I', len(value)) + kind + value + struct.pack('>I', zlib.crc32(kind + value) & 0xffffffff)
    pixels = b''.join(b'\x00' + b''.join(bytes((30+x*3, 60+y*2, 180, 255)) for x in range(64)) for y in range(64))
    png = b'\x89PNG\r\n\x1a\n' + png_chunk(b'IHDR', struct.pack('>IIBBBBB',64,64,8,6,0,0,0)) + png_chunk(b'IDAT',zlib.compress(pixels)) + png_chunk(b'IEND',b'')
    (working / 'blue-gradient.png').write_bytes(png)
    files = [dict(name='quiet-tone-24bit.wav', mime='audio/wav', relative='Music/Fixture/quiet-tone-24bit.wav'), dict(name='blue-gradient.png', mime='image/png', relative='Pictures/Fixture/blue-gradient.png')]
    ffmpeg = shutil.which('ffmpeg')
    if ffmpeg:
        subprocess.run([str(ffmpeg), '-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=320x240:rate=24','-t','3','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(working/'test-pattern.mp4')],check=True)
        files.append(dict(name='test-pattern.mp4',mime='video/mp4',relative='Movies/Fixture/test-pattern.mp4'))
    else:
        raise RuntimeError('ffmpeg with the libx264 encoder is required to regenerate this three-media fixture.')
    configuration = dict(password=password, output=str(out/'host-media.dmpa'), files=[dict(item,path=str(working/item['name'])) for item in files])
    script = r'''
import {readFileSync,writeFileSync} from 'node:fs';
import {createCipheriv,pbkdf2Sync,createHash} from 'node:crypto';
const c=JSON.parse(process.env.DUALSCAN_PUBLIC_ARRAY);
const contents=c.files.map(file=>readFileSync(file.path));
let offset=0,counter=1;
const entries=c.files.map((file,index)=>{
 const data=contents[index], count=Math.ceil(data.length/1048576);
 const item={id:`media-${String(index+1).padStart(6,'0')}`,displayName:file.name,mimeType:file.mime,relativePath:file.relative,sizeBytes:data.length,sha256:createHash('sha256').update(data).digest('hex'),index,dataOffset:offset,firstCounter:counter,chunkCount:count};
 offset+=data.length+count*16;counter+=count;return item;
});
const manifest=Buffer.from(JSON.stringify({format:'dualscan-mp',schemaVersion:1,id:'86d435ca-e4b4-4622-a910-390e1965b53f',title:'Public cross-provider media',chunkBytes:1048576,entries}));
const header=Buffer.alloc(44);header.write('DSMP0001');Buffer.from([...Array(16).keys()]).copy(header,8);Buffer.from([...Array(12).keys()].map(x=>x+32)).copy(header,24);header.writeInt32BE(600000,36);header.writeInt32BE(manifest.length+16,40);
const key=pbkdf2Sync(Buffer.from(c.password,'utf8'),header.subarray(8,24),600000,32,'sha256');
function seal(data,counter,aad){const nonce=Buffer.from(header.subarray(24,36));nonce.writeBigUInt64BE(nonce.readBigUInt64BE(4)^BigInt(counter),4);const cipher=createCipheriv('aes-256-gcm',key,nonce);cipher.setAAD(aad);return Buffer.concat([cipher.update(data),cipher.final(),cipher.getAuthTag()]);}
const encrypted=[header,seal(manifest,0,Buffer.concat([header,Buffer.from([0])]))];
for(const entry of entries){const data=contents[entry.index];for(let chunk=0;chunk<entry.chunkCount;chunk++){const clear=data.subarray(chunk*1048576,Math.min((chunk+1)*1048576,data.length));const aad=Buffer.alloc(61);header.copy(aad);aad[44]=1;aad.writeInt32BE(entry.index,45);aad.writeBigUInt64BE(BigInt(chunk),49);aad.writeInt32BE(clear.length,57);encrypted.push(seal(clear,entry.firstCounter+chunk,aad));}}
const bytes=Buffer.concat(encrypted);writeFileSync(c.output,bytes);key.fill(0);
console.log(JSON.stringify({password:c.password,purpose:'Public synthetic cross-provider test data. Fixed salt/nonce/password are never production settings.',generator:'Python WAV/PNG/ffmpeg source + independent Node/OpenSSL DSMP0001 writer',format:'DSMP0001',encryptedBytes:bytes.length,encryptedSha256:createHash('sha256').update(bytes).digest('hex'),entries},null,2));
'''
    env = os.environ.copy(); env['DUALSCAN_PUBLIC_ARRAY'] = json.dumps(configuration)
    generated = subprocess.run([node,'--input-type=module','-'],input=script,env=env,text=True,capture_output=True,check=True)
    vector = json.loads(generated.stdout)
    (out/'host-media-vector.json').write_text(json.dumps(vector,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'encryptedBytes':vector['encryptedBytes'],'encryptedSha256':vector['encryptedSha256'],'entries':len(vector['entries'])},indent=2))
