import subprocess,xml.etree.ElementTree as E,re,json
from pathlib import Path
adb='/Users/williamgrecia/Library/Android/sdk/platform-tools/adb'
def call(*a):return subprocess.check_output([adb,'-s','emulator-5580',*a])
def state():
 call('shell','uiautomator','dump','/sdcard/diamond-ui.xml');b=call('exec-out','cat','/sdcard/diamond-ui.xml');return b,E.fromstring(b)
def tap(text,tries=5):
 for _ in range(tries):
  _,r=state()
  for n in r.iter('node'):
   if n.get('text')==text or n.get('content-desc')==text:
    a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((a+c)//2),str((b+d)//2));return
 raise RuntimeError(text)
tap('Diamond Sessions');tap('USE THIS FOLDER');tap('ALLOW')
tap('Password');call('shell','input','text','Folder%sdemo%s2026');call('shell','input','keyevent','4')
tap('Confirm password');call('shell','input','text','Folder%sdemo%s2026');call('shell','input','keyevent','4');tap('Create')
for _ in range(8):
 data,r=state();texts=[n.get('text') for n in r.iter('node') if n.get('text')]
 if '4 favorites' in texts:break
else:raise RuntimeError(str(texts))
tap('Music');tap('First Light');tap('Pause')
data,r=state();texts=[n.get('text') for n in r.iter('node') if n.get('text')]
assert '24-bit 96.0 kHz' in texts,texts
Path('verification/folder-import-final.xml').write_bytes(data)
Path('verification/folder-import-final.png').write_bytes(call('exec-out','screencap','-p'))
Path('verification/folder-import-final.json').write_text(json.dumps({'result':'PASS','folder':'Music/Diamond Sessions','importedMediaAndCover':4,'sourceFidelity':'24-bit 96.0 kHz','relativePathsAndCover':'Verified source tree preserved in new encrypted collection; music selects imported cover.png','mockInputOnly':True},indent=2)+'\n')
print('Actual SAF folder import -> encrypted collection -> native playback + fidelity PASS')
