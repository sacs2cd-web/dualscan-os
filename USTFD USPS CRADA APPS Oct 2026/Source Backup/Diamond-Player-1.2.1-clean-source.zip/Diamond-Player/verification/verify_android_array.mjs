// Independent Node/OpenSSL verifier: never writes the decrypted source to disk.
import {readFileSync,writeFileSync} from 'node:fs';
import {createDecipheriv,pbkdf2Sync,createHash} from 'node:crypto';
const file=readFileSync('verification/android-produced.dmpa');
const header=file.subarray(0,44);
if(header.subarray(0,8).toString()!=='DSMP0001'||header.readInt32BE(36)!==600000)throw Error('Bad header');
const key=pbkdf2Sync('Dualscan MP Android public test 2026',header.subarray(8,24),600000,32,'sha256');
function decrypt(data,counter,aad){const nonce=Buffer.from(header.subarray(24,36));nonce.writeBigUInt64BE(nonce.readBigUInt64BE(4)^BigInt(counter),4);const c=createDecipheriv('aes-256-gcm',key,nonce);c.setAAD(aad);c.setAuthTag(data.subarray(-16));return Buffer.concat([c.update(data.subarray(0,-16)),c.final()]);}
const length=header.readInt32BE(40);
const clear=decrypt(file.subarray(44,44+length),0,Buffer.concat([header,Buffer.from([0])]));
const manifest=JSON.parse(clear);clear.fill(0);let position=44+length;const entries=[];
for(const entry of manifest.entries){const digest=createHash('sha256');let bytes=0;
 for(let chunk=0;chunk<entry.chunkCount;chunk++){const count=Math.min(1048576,entry.sizeBytes-chunk*1048576);const aad=Buffer.alloc(61);header.copy(aad);aad[44]=1;aad.writeInt32BE(entry.index,45);aad.writeBigUInt64BE(BigInt(chunk),49);aad.writeInt32BE(count,57);const media=decrypt(file.subarray(position,position+count+16),entry.firstCounter+chunk,aad);digest.update(media);bytes+=media.length;media.fill(0);position+=count+16;}
 const sha=digest.digest('hex');if(bytes!==entry.sizeBytes||sha!==entry.sha256)throw Error('Media hash mismatch');
 const original=readFileSync('app/src/androidTest/assets/arrays/'+entry.displayName);if(createHash('sha256').update(original).digest('hex')!==sha)throw Error('Original source differs');
 entries.push({name:entry.displayName,bytes,sha256:sha,chunks:entry.chunkCount});
}
key.fill(0);if(position!==file.length)throw Error('Unexpected tail');
writeFileSync('verification/android-to-host-interoperability.json',JSON.stringify({result:'PASS',direction:'Android AES-GCM encryption -> independent Node/OpenSSL authentication + every original media byte',entries},null,2)+'\n');
