// Public synthetic test data only. Independent Node/OpenSSL DSMP0001 writer;
// never imports application code. Fixed salt, nonce and password are TEST ONLY.
import { createCipheriv, createDecipheriv, createHash, pbkdf2Sync } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = resolve(project, 'app/src/androidTest/assets/arrays');
mkdirSync(output, { recursive: true });
const ffmpeg = process.env.FFMPEG_BINARY || '/usr/local/bin/ffmpeg';
const password = 'Dualscan MP FLAC test 2026';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const u32 = value => { const data = Buffer.alloc(4); data.writeUInt32BE(value); return data; };
const u64 = value => { const data = Buffer.alloc(8); data.writeBigUInt64BE(BigInt(value)); return data; };
const chunkBytes = 1048576;

// Quiet original 24-bit stereo PCM. Its nonzero low bits detect 16-bit decode
// followed by zero-padding, which cannot be caught from a PCM format label.
const rate = 96000, frames = rate * 3, pcm = Buffer.alloc(frames * 6);
for (let frame = 0; frame < frames; frame++) {
  pcm.writeIntLE(Math.round(Math.sin(2 * Math.PI * 997 * frame / rate) * 260003), frame * 6, 3);
  pcm.writeIntLE(Math.round(Math.sin(2 * Math.PI * 613 * frame / rate) * 190019), frame * 6 + 3, 3);
}
const waveHeader = Buffer.alloc(44);
waveHeader.write('RIFF'); waveHeader.writeUInt32LE(36 + pcm.length, 4); waveHeader.write('WAVE', 8);
waveHeader.write('fmt ', 12); waveHeader.writeUInt32LE(16, 16); waveHeader.writeUInt16LE(1, 20);
waveHeader.writeUInt16LE(2, 22); waveHeader.writeUInt32LE(rate, 24); waveHeader.writeUInt32LE(rate * 6, 28);
waveHeader.writeUInt16LE(6, 32); waveHeader.writeUInt16LE(24, 34); waveHeader.write('data', 36); waveHeader.writeUInt32LE(pcm.length, 40);
const wav = Buffer.concat([waveHeader, pcm]);
const wavPath = resolve(output, 'source-24-96.wav'), flacPath = resolve(output, 'source-24-96.flac');
writeFileSync(wavPath, wav);
execFileSync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-i', wavPath, '-c:a', 'flac', '-sample_fmt', 's32', '-bits_per_raw_sample', '24', flacPath]);
const flac = readFileSync(flacPath);
const decoded = execFileSync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-i', flacPath, '-f', 's24le', '-acodec', 'pcm_s24le', '-'], { maxBuffer: 4 * 1024 * 1024 });
if (!decoded.equals(pcm)) throw Error('Host FLAC decode changed source PCM');

const sources = [
  { name: 'source-24-96.wav', mime: 'audio/wav', bytes: wav },
  { name: 'source-24-96.flac', mime: 'audio/flac', bytes: flac },
];
let offset = 0, counter = 1;
const entries = sources.map((source, index) => {
  const chunkCount = Math.ceil(source.bytes.length / chunkBytes);
  const entry = { id: `media-${String(index + 1).padStart(6, '0')}`, displayName: source.name,
    mimeType: source.mime, relativePath: `Music/FLAC-Fixture/${source.name}`, sizeBytes: source.bytes.length,
    sha256: sha(source.bytes), index, dataOffset: offset, firstCounter: counter, chunkCount };
  offset += source.bytes.length + chunkCount * 16; counter += chunkCount;
  return entry;
});
const manifest = Buffer.from(JSON.stringify({ format: 'dualscan-mp', schemaVersion: 1,
  id: '2a812f86-a4c2-4cee-ae4c-3235cf804800', title: 'Independent FLAC playback fixture', chunkBytes, entries }), 'utf8');
const salt = Buffer.from('f430880ac612d865a0679b9a6d851463', 'hex');
const baseNonce = Buffer.from('a9c54724fa6d3fb987d66129', 'hex');
const header = Buffer.concat([Buffer.from('DSMP0001'), salt, baseNonce, u32(600000), u32(manifest.length + 16)]);
if (header.length !== 44) throw Error('Header size');
const key = pbkdf2Sync(Buffer.from(password, 'utf8'), salt, 600000, 32, 'sha256');
const nonceFor = counter => {
  const nonce = Buffer.from(baseNonce), encoded = u64(counter);
  for (let i = 0; i < 8; i++) nonce[i + 4] ^= encoded[i];
  return nonce;
};
function seal(clear, counter, aad) {
  const cipher = createCipheriv('aes-256-gcm', key, nonceFor(counter));
  cipher.setAAD(aad);
  const encrypted = Buffer.concat([cipher.update(clear), cipher.final(), cipher.getAuthTag()]);
  const decoder = createDecipheriv('aes-256-gcm', key, nonceFor(counter));
  decoder.setAAD(aad); decoder.setAuthTag(encrypted.subarray(-16));
  if (!Buffer.concat([decoder.update(encrypted.subarray(0, -16)), decoder.final()]).equals(clear)) throw Error('Fixture record failed verification');
  return encrypted;
}
const records = [header, seal(manifest, 0, Buffer.concat([header, Buffer.from([0])]))];
const chunks = [];
for (const entry of entries) for (let chunk = 0; chunk < entry.chunkCount; chunk++) {
  const clear = sources[entry.index].bytes.subarray(chunk * chunkBytes, (chunk + 1) * chunkBytes);
  const aad = Buffer.concat([header, Buffer.from([1]), u32(entry.index), u64(chunk), u32(clear.length)]);
  const encrypted = seal(clear, entry.firstCounter + chunk, aad);
  records.push(encrypted);
  chunks.push({ entryId: entry.id, chunkIndex: chunk, counter: entry.firstCounter + chunk,
    clearBytes: clear.length, clearSha256: sha(clear), encryptedSha256: sha(encrypted) });
}
const bytes = Buffer.concat(records);
key.fill(0);
writeFileSync(resolve(output, 'flac-media.dmpa'), bytes);
const vector = { generator: 'Independent Node/OpenSSL DSMP0001 writer + ffmpeg FLAC source verification', testOnly: true,
  purpose: 'Public synthetic WAV/FLAC test data. Fixed salt, nonce and password must never be production settings.',
  password, format: 'DSMP0001', arrayName: 'flac-media.dmpa', encryptedBytes: bytes.length, encryptedSha256: sha(bytes),
  headerHex: header.toString('hex'), sourcePcmSha256: sha(pcm), sourcePcmBytes: pcm.length,
  pcmBits: 24, pcmRate: rate, pcmChannels: 2, pcmFrames: frames, entries, chunks };
writeFileSync(resolve(output, 'flac-media-vector.json'), JSON.stringify(vector, null, 2) + '\n');
console.log(JSON.stringify({ encryptedBytes: vector.encryptedBytes, encryptedSha256: vector.encryptedSha256,
  sourcePcmSha256: vector.sourcePcmSha256, entries: entries.map(entry => ({ id: entry.id, sizeBytes: entry.sizeBytes, chunks: entry.chunkCount })) }, null, 2));
