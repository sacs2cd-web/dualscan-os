"""Root-owned emulator UI check; public synthetic fixture only."""
import subprocess,xml.etree.ElementTree as E,re,time,json,hashlib
from pathlib import Path
adb='/Users/williamgrecia/Library/Android/sdk/platform-tools/adb'
def call(*args,output=False):
 r=subprocess.run([adb,'-s','emulator-5580',*args],check=True,capture_output=True)
 return r.stdout if output else None
def state():
 call('shell','uiautomator','dump','/sdcard/mp-ui.xml')
 data=call('exec-out','cat','/sdcard/mp-ui.xml',output=True)
 return data,E.fromstring(data)
def tap_text(text,tries=4):
 for _ in range(tries):
  data,root=state()
  for n in root.iter('node'):
   if n.get('text')==text:
    x1,y1,x2,y2=map(int,re.findall(r'\d+',n.get('bounds')))
    call('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2));return
 raise RuntimeError('UI text unavailable: '+text)
call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
tap_text('Open collection');tap_text('Dualscan-MP-Demo.dmpa');tap_text('Collection password')
call('shell','input','text','Dualscan%sMP%sdemo%s2026');call('shell','input','keyevent','4');tap_text('Unlock')
tap_text('quiet-tone-24bit.wav',8)
# The fixture is eight seconds long. Verify end, then press the actual Play control.
ended=False
for _ in range(7):
 data,root=state()
 nodes=list(root.iter('node'))
 if any(n.get('content-desc')=='Play' for n in nodes) and any(n.get('text')=='0:08' for n in nodes):ended=True;break
if not ended:raise RuntimeError('WAV did not reach its normal finished state')
for n in nodes:
 if n.get('content-desc')=='Play':
  x1,y1,x2,y2=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2));break
replayed=False
for _ in range(4):
 data,root=state();nodes=list(root.iter('node'))
 if any(n.get('content-desc')=='Pause' for n in nodes) and any(n.get('text') in ('0:00','0:01','0:02','0:03') for n in nodes):replayed=True;break
assert replayed,'Play after EOS did not restart playback'
Path('verification/ui-replay-final.xml').write_bytes(data)
Path('verification/ui-replay-final.png').write_bytes(call('exec-out','screencap','-p',output=True))
apk=Path('app/build/outputs/apk/debug/app-debug.apk')
record={'result':'PASS','testedApkSha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'nativeWavFinishedThenPlayRestarted':True,'ordinaryOutput':'Android','physicalUsbDac':False,'evidence':'ui-replay-final.xml'}
Path('verification/ui-replay-final.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
