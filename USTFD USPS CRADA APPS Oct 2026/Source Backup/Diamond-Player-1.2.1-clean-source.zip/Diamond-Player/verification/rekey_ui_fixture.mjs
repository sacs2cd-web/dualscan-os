// Public synthetic demo only: re-encrypt the independent fixture entirely in memory.
import {readFileSync,writeFileSync} from 'node:fs';
import {createCipheriv,createDecipheriv,pbkdf2Sync,randomBytes,createHash} from 'node:crypto';
const source=readFileSync('app/src/androidTest/assets/arrays/host-media.dmpa');
const vector=JSON.parse(readFileSync('app/src/androidTest/assets/arrays/host-media-vector.json','utf8'));
const oldHeader=source.subarray(0,44),header=Buffer.from(oldHeader);
randomBytes(16).copy(header,8);randomBytes(12).copy(header,24);
const password='Dualscan MP demo 2026';
const oldKey=pbkdf2Sync(vector.password,oldHeader.subarray(8,24),600000,32,'sha256');
const newKey=pbkdf2Sync(password,header.subarray(8,24),600000,32,'sha256');
function transform(bytes,counter,makeAAD){
 const oldNonce=Buffer.from(oldHeader.subarray(24,36));oldNonce.writeBigUInt64BE(oldNonce.readBigUInt64BE(4)^BigInt(counter),4);
 const decrypt=createDecipheriv('aes-256-gcm',oldKey,oldNonce);decrypt.setAAD(makeAAD(oldHeader));decrypt.setAuthTag(bytes.subarray(-16));
 const clear=Buffer.concat([decrypt.update(bytes.subarray(0,-16)),decrypt.final()]);
 const nonce=Buffer.from(header.subarray(24,36));nonce.writeBigUInt64BE(nonce.readBigUInt64BE(4)^BigInt(counter),4);
 const encrypt=createCipheriv('aes-256-gcm',newKey,nonce);encrypt.setAAD(makeAAD(header));
 try{return Buffer.concat([encrypt.update(clear),encrypt.final(),encrypt.getAuthTag()]);}finally{clear.fill(0);}
}
const length=oldHeader.readInt32BE(40),parts=[header,transform(source.subarray(44,44+length),0,h=>Buffer.concat([h,Buffer.from([0])]))];
let offset=44+length;
for(const entry of vector.entries)for(let chunk=0;chunk<entry.chunkCount;chunk++){
 const count=Math.min(1048576,entry.sizeBytes-chunk*1048576);
 const aad=h=>{const b=Buffer.alloc(61);h.copy(b);b[44]=1;b.writeInt32BE(entry.index,45);b.writeBigUInt64BE(BigInt(chunk),49);b.writeInt32BE(count,57);return b;};
 parts.push(transform(source.subarray(offset,offset+count+16),entry.firstCounter+chunk,aad));offset+=count+16;
}
if(offset!==source.length)throw Error('Unexpected fixture tail');
const output=Buffer.concat(parts);writeFileSync('verification/Public-Media-Demo.dmpa',output);
oldKey.fill(0);newKey.fill(0);
writeFileSync('verification/Public-Media-Demo.json',JSON.stringify({password,sha256:createHash('sha256').update(output).digest('hex'),bytes:output.length,purpose:'Synthetic WAV, PNG, H264 demonstration; public password. No commercial content.'},null,2)+'\n');
