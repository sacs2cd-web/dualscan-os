"""Exercise current artwork modal and capture actual Android UI, using mock audio."""
import json
import re
import subprocess
import xml.etree.ElementTree as E
from pathlib import Path

ADB = '/Users/williamgrecia/Library/Android/sdk/platform-tools/adb'
OUT = Path(__file__).resolve().parent

def call(*args):
    return subprocess.check_output([ADB, '-s', 'emulator-5580', *args])

def state():
    call('shell', 'uiautomator', 'dump', '/sdcard/diamond-ui.xml')
    data = call('exec-out', 'cat', '/sdcard/diamond-ui.xml')
    return data, E.fromstring(data)

def tap(value, tries=8):
    for _ in range(tries):
        _, root = state()
        for node in root.iter('node'):
            if node.get('text') == value or node.get('content-desc') == value:
                left, top, right, bottom = map(int, re.findall(r'\d+', node.get('bounds')))
                call('shell', 'input', 'tap', str((left + right) // 2), str((top + bottom) // 2))
                return
    raise RuntimeError('UI unavailable: ' + value)

def capture(name):
    data, root = state()
    (OUT / (name + '.xml')).write_bytes(data)
    (OUT / (name + '.png')).write_bytes(call('exec-out', 'screencap', '-p'))
    return root

def labels(root):
    return [node.get(key) for node in root.iter('node') for key in ('text', 'content-desc') if node.get(key)]

call('shell', 'am', 'start', '-W', '-n', 'com.dualscan.mp/.MainActivity')
tap('Music', 12)
prefs = call('exec-out', 'run-as', 'com.dualscan.mp', 'cat', 'shared_prefs/appearance.xml')
if b'name="dark" value="false"' in prefs:
    tap('Switch light or dark appearance')
tracklist = capture('diamond-tracklist-dark-1.1.1')
expected = ['Silver Thread', 'Breathe in the Violet', 'Weightless for a Moment', 'Where the Colors Move', 'Rondo', 'Velvet Spin', 'Let the Quiet Burn']
assert all(title in labels(tracklist) for title in expected), labels(tracklist)
assert 'Lock collection' not in labels(tracklist)
tap('Silver Thread')
tap('Pause')
dark = capture('diamond-player-dark-1.1.1')
assert '24-bit 192.0 kHz' in labels(dark), labels(dark)
assert 'Bit-perfect' not in labels(dark)
tap('Artwork for Silver Thread')
modal = capture('diamond-artwork-fullscreen-dark-1.1.1')
assert 'Full-screen artwork for Silver Thread' in labels(modal), labels(modal)
assert 'Close artwork' in labels(modal)
tap('Close artwork')
assert 'Full-screen artwork for Silver Thread' not in labels(state()[1])
tap('Switch light or dark appearance')
light = capture('diamond-player-light-1.1.1')
assert 'Lock collection' not in labels(light)
tap('Artwork for Silver Thread')
assert 'Full-screen artwork for Silver Thread' in labels(state()[1])
call('shell', 'input', 'keyevent', '4')
assert 'Full-screen artwork for Silver Thread' not in labels(state()[1])
assert '24-bit 192.0 kHz' in labels(state()[1])
result = {'result': 'PASS', 'version': '1.1.1', 'mockAudio': True, 'titles': expected,
          'noVisibleLockButton': True, 'sourceFidelity': '24-bit 192.0 kHz',
          'actualUsbDacPresent': False, 'artworkTapOpensFullScreen': True,
          'closeButtonReturnsToPlayer': True, 'androidBackReturnsToPlayer': True,
          'screenshots': ['diamond-tracklist-dark-1.1.1.png', 'diamond-player-dark-1.1.1.png',
                          'diamond-player-light-1.1.1.png', 'diamond-artwork-fullscreen-dark-1.1.1.png']}
(OUT / 'ui-1.1.1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
