"""Actual Android16 SAF global/password opening; only task-owned emulator-5580."""
import hashlib,json,re,shlex,subprocess,time,xml.etree.ElementTree as E
from pathlib import Path
P=Path(__file__).resolve().parents[1]; OUT=P/'verification'; FIX=P/'app/src/androidTest/assets/loose'
ADB=['/Users/williamgrecia/Library/Android/sdk/platform-tools/adb','-s','emulator-5580']
vector=json.loads((FIX/'fixture.json').read_text())
def call(*args):return subprocess.check_output(ADB+list(args),timeout=60)
def state():
 call('shell','uiautomator','dump','/sdcard/mp-interchange.xml')
 data=call('exec-out','cat','/sdcard/mp-interchange.xml');return data,E.fromstring(data)
def labels(root):return [n.get(k) for n in root.iter('node') for k in ('text','content-desc') if n.get(k)]
def click(n):
 a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((a+c)//2),str((b+d)//2))
def tap(text):
 _,root=state()
 for n in root.iter('node'):
  if any((n.get(k) or '').casefold()==text.casefold() for k in ('text','content-desc')):click(n);return
 raise AssertionError(('Missing action',text,labels(root)))
def wait(text,tries=8):
 for _ in range(tries):
  data,root=state()
  if text in labels(root):return data,root
 raise AssertionError(('Missing UI',text,labels(root)))
def capture(name):
 data,root=state();(OUT/(name+'.xml')).write_bytes(data);(OUT/(name+'.png')).write_bytes(call('exec-out','screencap','-p'));return labels(root)
def choose(name):
 _,root=state();tap('Open another collection' if 'Open another collection' in labels(root) else 'Open collection')
 _,root=state()
 if 'ShareInterop' in labels(root):tap('ShareInterop')
 tap(name)
def enter_password(value):
 _,root=wait('Collection password')
 fields=[n for n in root.iter('node') if n.get('class')=='android.widget.EditText' and n.get('enabled')=='true']
 assert len(fields)==1
 click(fields[0]);call('shell','input','text',value.replace(' ','%s'));call('shell','input','keyevent','4');tap('Open')

call('shell','mkdir','-p','/sdcard/Music/DiamondLooseUI')
for item in vector['items']+vector['passwordItems']:
    target='/sdcard/Music/DiamondLooseUI/'+item['file']
    call('shell',shlex.join(['mkdir','-p',target.rsplit('/',1)[0]]))
    call('push',str(FIX/item['file']),target)
call('shell','am','force-stop','com.dualscan.mp')
call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
wait('Your library is empty'); capture('ui-empty-ciphertext-api36')
tap('Open media folder')
_,root=wait('DiamondLooseUI')
if 'Files in DiamondLooseUI' not in labels(root): tap('DiamondLooseUI')
tap('Use this folder')
_,root=state()
if any(label.casefold()=='allow' for label in labels(root)): tap('Allow')
# This fixture intentionally mixes four default files and one optional-password
# file. Dismiss that file's prompt to verify the default media opens on its own.
wait('File password'); tap('Cancel')
wait('DiamondLooseUI')
text=capture('ui-folder-open-ciphertext-api36')
assert 'Open remaining files (1)' in text,text
assert 'Collection password' not in text and 'File password' not in text,text
tap('Music'); tap('Interop'); wait('24-bit 192.0 kHz')
text=capture('ui-shared-player-ciphertext-api36')
assert 'Bit-perfect' not in text,text
# The cover is a separately encrypted file in the same album folder.
tap('Artwork for Interop')
wait('Close artwork'); capture('ui-folder-artwork-ciphertext-api36'); tap('Close artwork')
tap('Photos'); wait('photo'); tap('photo')
wait('Artwork for photo'); capture('ui-folder-photo-ciphertext-api36')
tap('Open remaining files (1)'); wait('File password')
_,root=state()
field=next(n for n in root.iter('node') if n.get('class')=='android.widget.EditText')
click(field); call('shell','input','text',vector['password'].replace(' ','%s')); call('shell','input','keyevent','4'); tap('Open')
wait('private')
text=capture('ui-folder-password-open-ciphertext-api36')
assert 'Open remaining files (1)' not in text and 'File password' not in text,text
call('shell','am','force-stop','com.dualscan.mp'); call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
wait('Your library is empty')
report={'result':'PASS','androidApi':36,
    'testedApkSha256':hashlib.sha256((P/'app/build/outputs/apk/debug/app-debug.apk').read_bytes()).hexdigest(),
    'sharedFolderPickedThroughRealSaf':True,'perItemDiamondFiles':5,'globalFilesOpenedWithoutPassword':True,
    'protectedFilePromptCanBeDismissed':True,
    'privateVaultCopyRequired':False,'sourceFidelity':'24-bit 192.0 kHz','separatelyEncryptedCoverShown':True,
    'fullscreenArtworkOpened':True,'photoShownInPlayer':True,'optionalPasswordOpensRemainingFile':True,
    'coldLaunchEmpty':True,'physicalUsbTested':False,
    'source':'Actual Share Android per-item producer; normal shared Music folder; real Android SAF folder grant',
    'fixtureManifestSha256':hashlib.sha256((FIX/'fixture.json').read_bytes()).hexdigest(),
    'evidence':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for name in ('empty','folder-open','shared-player','folder-artwork','folder-photo','folder-password-open')
        for suffix in ('.png','.xml')
        for p in (OUT/('ui-'+name+'-ciphertext-api36'+suffix),)]}
(OUT/'ui-ciphertext-api36.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
