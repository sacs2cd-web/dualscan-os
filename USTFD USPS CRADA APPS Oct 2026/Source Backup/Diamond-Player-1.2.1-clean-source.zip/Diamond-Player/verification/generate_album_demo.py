"""Research-only mock files/art; never writes media into the shipping application."""
from pathlib import Path
import json,subprocess,shutil,os
project=Path(__file__).resolve().parents[1]
folder=project/'verification/album-demo-source/Somewhere Below 34th Street';folder.mkdir(parents=True,exist_ok=True)
titles=['Silver Thread','Breathe in the Violet','Weightless for a Moment','Where the Colors Move','Rondo','Velvet Spin','Let the Quiet Burn']
files=[]
for n,title in enumerate(titles,1):
 path=folder/f'{n:02d} - {title}.wav'
 subprocess.run(['/usr/local/bin/ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'sine=frequency={220+n*33}:sample_rate=192000','-af','volume=0.001','-ac','2','-c:a','pcm_s24le','-t','8' if n==1 else '2',str(path)],check=True)
 files.append(dict(path=str(path),name=path.name,mime='audio/wav',relative=f'Music/Somewhere Below 34th Street/{path.name}',track=n,disc=1))
cover=Path('/var/folders/n6/gpmsw14x043dlzfrv2xs9lhw0000gp/T/codex-clipboard-b257d756-11ee-41a2-9abf-1cb016353e6a.png')
shutil.copyfile(cover,folder/'cover.png')
files.append(dict(path=str(folder/'cover.png'),name='cover.png',mime='image/png',relative='Music/Somewhere Below 34th Street/cover.png'))
output=project/'verification/album-demo-source/Somewhere-Below-34th-Street-MOCK.dmpa';output.parent.mkdir(parents=True,exist_ok=True)
config=dict(output=str(output),title='Somewhere Below 34th Street',password='Diamond demo 2026',files=files)
script=r'''
const fs=require('fs'),crypto=require('crypto');const c=JSON.parse(process.env.DIAMOND_DEMO_CONFIG),data=c.files.map(f=>fs.readFileSync(f.path));let offset=0,counter=1;
const entries=c.files.map((f,index)=>{const b=data[index],chunkCount=Math.ceil(b.length/1048576);const e={id:`media-${String(index+1).padStart(6,'0')}`,displayName:f.name,mimeType:f.mime,relativePath:f.relative,sizeBytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),index,dataOffset:offset,firstCounter:counter,chunkCount,...(f.track?{trackNumber:f.track,discNumber:f.disc}:{})};offset+=b.length+chunkCount*16;counter+=chunkCount;return e;});
const manifest=Buffer.from(JSON.stringify({format:'dualscan-mp',schemaVersion:1,id:crypto.randomUUID(),title:c.title,chunkBytes:1048576,entries}));const h=Buffer.alloc(44);h.write('DSMP0001');crypto.randomBytes(16).copy(h,8);crypto.randomBytes(12).copy(h,24);h.writeInt32BE(600000,36);h.writeInt32BE(manifest.length+16,40);const key=crypto.pbkdf2Sync(c.password,h.subarray(8,24),600000,32,'sha256');
function seal(b,n,a){const iv=Buffer.from(h.subarray(24,36));iv.writeBigUInt64BE(iv.readBigUInt64BE(4)^BigInt(n),4);const enc=crypto.createCipheriv('aes-256-gcm',key,iv);enc.setAAD(a);return Buffer.concat([enc.update(b),enc.final(),enc.getAuthTag()]);}
const out=[h,seal(manifest,0,Buffer.concat([h,Buffer.from([0])]))];for(const e of entries){const b=data[e.index];for(let chunk=0;chunk<e.chunkCount;chunk++){const clear=b.subarray(chunk*1048576,Math.min((chunk+1)*1048576,b.length));const a=Buffer.alloc(61);h.copy(a);a[44]=1;a.writeInt32BE(e.index,45);a.writeBigUInt64BE(BigInt(chunk),49);a.writeInt32BE(clear.length,57);out.push(seal(clear,e.firstCounter+chunk,a));}}const bytes=Buffer.concat(out);fs.writeFileSync(c.output,bytes);key.fill(0);console.log(JSON.stringify({publicMockAudio:true,title:c.title,artist:'Digitaldruglord, Spynx',password:c.password,sourcePcm:'24-bit 192000 Hz stereo',sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,tracks:entries.filter(e=>e.trackNumber).map(e=>({number:e.trackNumber,name:e.displayName,bytes:e.sizeBytes,sha256:e.sha256})),coverSha256:entries.at(-1).sha256},null,2));
'''
env=dict(os.environ,DIAMOND_DEMO_CONFIG=json.dumps(config))
r=subprocess.run(['/Users/williamgrecia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','-e',script],env=env,capture_output=True,text=True,check=True)
(project/'verification/album-demo-vector.json').write_text(r.stdout+'\n')
print(json.dumps({'output':str(output),'bytes':output.stat().st_size,'mockTracks':len(titles)}))
