import subprocess,xml.etree.ElementTree as E,re
from pathlib import Path
adb='/Users/williamgrecia/Library/Android/sdk/platform-tools/adb'
def call(*args):return subprocess.check_output([adb,'-s','emulator-5580',*args])
def state():
 call('shell','uiautomator','dump','/sdcard/diamond-ui.xml')
 data=call('exec-out','cat','/sdcard/diamond-ui.xml');return data,E.fromstring(data)
def tap(value,tries=5):
 for _ in range(tries):
  _,root=state()
  for n in root.iter('node'):
   if n.get('text')==value or n.get('content-desc')==value:
    x1,y1,x2,y2=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2));return
 raise RuntimeError('Unavailable '+value)
tap('Open collection');tap('Diamond-Demo.dmpa');tap('Collection password')
call('shell','input','text','Diamond%sdemo%s2026');call('shell','input','keyevent','4');tap('Unlock')
tap('Music',8);tap('01 - First Light.wav');tap('Pause')
data,root=state();Path('verification/diamond-player-dark.xml').write_bytes(data);Path('verification/diamond-player-dark.png').write_bytes(call('exec-out','screencap','-p'))
tap('Switch light or dark appearance');data,root=state();Path('verification/diamond-player-light.xml').write_bytes(data);Path('verification/diamond-player-light.png').write_bytes(call('exec-out','screencap','-p'))
print('Captured actual Android dark/light player with cover.png and numbered music rows')
