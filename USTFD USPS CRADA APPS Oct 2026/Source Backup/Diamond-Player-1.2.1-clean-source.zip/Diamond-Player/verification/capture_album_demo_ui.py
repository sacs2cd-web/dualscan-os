"""Capture actual Android screens using the user-authorized built-in mock album."""
import subprocess,xml.etree.ElementTree as E,re,json,hashlib
from pathlib import Path
adb='/Users/williamgrecia/Library/Android/sdk/platform-tools/adb';out=Path('verification')
def call(*args):return subprocess.check_output([adb,'-s','emulator-5580',*args])
def state():
 call('shell','uiautomator','dump','/sdcard/diamond-ui.xml');data=call('exec-out','cat','/sdcard/diamond-ui.xml');return data,E.fromstring(data)
def tap(value,tries=6):
 for _ in range(tries):
  _,root=state()
  for n in root.iter('node'):
   if n.get('text')==value or n.get('content-desc')==value:
    a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((a+c)//2),str((b+d)//2));return
 raise RuntimeError('UI unavailable: '+value)
def capture(name):
 data,root=state();(out/(name+'.xml')).write_bytes(data);(out/(name+'.png')).write_bytes(call('exec-out','screencap','-p'));return [n.get('text') for n in root.iter('node') if n.get('text')]
call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
tap('Music',10)
prefs=call('exec-out','run-as','com.dualscan.mp','cat','shared_prefs/appearance.xml')
if b'name="dark" value="false"' in prefs:tap('Switch light or dark appearance')
texts=capture('diamond-album-tracklist-dark')
expected=['Silver Thread','Breathe in the Violet','Weightless for a Moment','Where the Colors Move','Rondo','Velvet Spin','Let the Quiet Burn']
assert all(title in texts for title in expected),texts
tap('Silver Thread');tap('Pause',8)
texts=capture('diamond-album-player-dark')
assert '24-bit 192.0 kHz' in texts,texts
assert 'Bit-perfect' not in texts,texts
tap('Switch light or dark appearance');capture('diamond-album-player-light')
print(json.dumps({'result':'PASS','titles':expected,'fidelity':'24-bit 192.0 kHz','actualUsbDacPresent':False,'mockAudio':True,'screenshots':['diamond-album-tracklist-dark.png','diamond-album-player-dark.png','diamond-album-player-light.png']},indent=2))
