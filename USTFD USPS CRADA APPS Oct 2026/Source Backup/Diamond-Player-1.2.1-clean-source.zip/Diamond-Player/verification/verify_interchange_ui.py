"""Actual Android16 SAF global/password opening; only task-owned emulator-5580."""
import hashlib,json,re,subprocess,time,xml.etree.ElementTree as E
from pathlib import Path
P=Path(__file__).resolve().parents[1]; OUT=P/'verification'; FIX=P/'app/src/androidTest/assets/interop'
ADB=['/Users/williamgrecia/Library/Android/sdk/platform-tools/adb','-s','emulator-5580']
vector=json.loads((FIX/'share-fixture.json').read_text())
def call(*args):return subprocess.check_output(ADB+list(args),timeout=60)
def state():
 call('shell','uiautomator','dump','/sdcard/mp-interchange.xml')
 data=call('exec-out','cat','/sdcard/mp-interchange.xml');return data,E.fromstring(data)
def labels(root):return [n.get(k) for n in root.iter('node') for k in ('text','content-desc') if n.get(k)]
def click(n):
 a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds')));call('shell','input','tap',str((a+c)//2),str((b+d)//2))
def tap(text):
 _,root=state()
 for n in root.iter('node'):
  if n.get('text')==text or n.get('content-desc')==text:click(n);return
 raise AssertionError(('Missing action',text,labels(root)))
def wait(text,tries=8):
 for _ in range(tries):
  data,root=state()
  if text in labels(root):return data,root
 raise AssertionError(('Missing UI',text,labels(root)))
def capture(name):
 data,root=state();(OUT/(name+'.xml')).write_bytes(data);(OUT/(name+'.png')).write_bytes(call('exec-out','screencap','-p'));return labels(root)
def choose(name):
 _,root=state();tap('Open another collection' if 'Open another collection' in labels(root) else 'Open collection')
 _,root=state()
 if 'ShareInterop' in labels(root):tap('ShareInterop')
 tap(name)
def enter_password(value):
 _,root=wait('Collection password')
 fields=[n for n in root.iter('node') if n.get('class')=='android.widget.EditText' and n.get('enabled')=='true']
 assert len(fields)==1
 click(fields[0]);call('shell','input','text',value.replace(' ','%s'));call('shell','input','keyevent','4');tap('Open')

call('shell','mkdir','-p','/sdcard/Music/ShareInterop')
for name in ('share-global.dshare','share-password.dshare'):call('push',str(FIX/name),'/sdcard/Music/ShareInterop/'+name)
call('shell','am','force-stop','com.dualscan.mp');call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
wait('Your library is empty');capture('ui-empty-interchange-api36')
choose('share-global.dshare');wait(vector['title'])
text=capture('ui-global-open-interchange-api36')
assert 'Collection password' not in text and '2 media items' in text,text
assert 'Interop.txt' not in text,text
tap('Interop');wait('24-bit 192.0 kHz')
text=capture('ui-shared-player-interchange-api36');assert 'Bit-perfect' not in text,text
choose('share-password.dshare');wait('Collection password');capture('ui-password-required-interchange-api36')
tap('Cancel');wait(vector['title']);assert 'Collection password' not in labels(state()[1])
choose('share-password.dshare');enter_password('Wrong password 2026')
wait('OK');tap('OK');wait('Collection password')
enter_password(vector['password']);wait(vector['title'])
assert 'Collection password' not in labels(state()[1])
capture('ui-password-open-interchange-api36')
call('shell','am','force-stop','com.dualscan.mp');call('shell','am','start','-W','-n','com.dualscan.mp/.MainActivity')
wait('Your library is empty')
report={'result':'PASS','androidApi':36,'consumerApkSha256':hashlib.sha256((P/'app/build/outputs/apk/debug/app-debug.apk').read_bytes()).hexdigest(),
 'actualShareGlobalFilePicked':True,'globalOpenedWithoutPassword':True,'documentsExcludedFromPlayback':True,'sourceFidelity':'24-bit 192.0 kHz',
 'passwordImagePrompts':True,'cancelPreservesLibrary':True,'wrongPasswordRejected':True,'correctPasswordOpens':True,'coldLaunchEmpty':True,
 'source':'actual Share Android producer; local Android SAF Music folder','physicalUsbTested':False}
(OUT/'ui-interchange-api36.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
