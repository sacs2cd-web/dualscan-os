// Synthetic demonstration media only. Existing independent fixture is decrypted in memory.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createCipheriv,createDecipheriv,pbkdf2Sync,createHash,randomBytes,randomUUID} from 'node:crypto';
const old=readFileSync('app/src/androidTest/assets/arrays/host-media.dmpa'), v=JSON.parse(readFileSync('app/src/androidTest/assets/arrays/host-media-vector.json'));
const oh=old.subarray(0,44), ok=pbkdf2Sync(v.password,oh.subarray(8,24),600000,32,'sha256');
function nonce(h,n){const b=Buffer.from(h.subarray(24,36));b.writeBigUInt64BE(b.readBigUInt64BE(4)^BigInt(n),4);return b;}
function aad(h,e,c,l){const b=Buffer.alloc(61);h.copy(b);b[44]=1;b.writeInt32BE(e,45);b.writeBigUInt64BE(BigInt(c),49);b.writeInt32BE(l,57);return b;}
function open(b,key,h,n,a){const d=createDecipheriv('aes-256-gcm',key,nonce(h,n));d.setAAD(a);d.setAuthTag(b.subarray(-16));return Buffer.concat([d.update(b.subarray(0,-16)),d.final()]);}
const start=44+oh.readInt32BE(40);
function original(e){let at=start+e.dataOffset;const chunks=[];for(let i=0;i<e.chunkCount;i++){const l=Math.min(1048576,e.sizeBytes-i*1048576);chunks.push(open(old.subarray(at,at+l+16),ok,oh,e.firstCounter+i,aad(oh,e.index,i,l)));at+=l+16;}return Buffer.concat(chunks);}
const wav=original(v.entries.find(e=>e.mimeType==='audio/wav')),video=original(v.entries.find(e=>e.mimeType==='video/mp4'));
const cover=readFileSync('/Users/williamgrecia/Documents/USTFD CRADA Icons And Logos/Diamond Fedility Icon.png');
const specs=[
 ['Music/Diamond Sessions/10 - Finale.wav','audio/wav',wav,10],
 ['Music/Diamond Sessions/02 - Interlude.wav','audio/wav',wav,2],
 ['Music/Diamond Sessions/01 - First Light.wav','audio/wav',wav,1],
 ['Music/Diamond Sessions/cover.png','image/png',cover,null],
 ['Movies/Live Session/01 - Live Session.mp4','video/mp4',video,null],
 ['Movies/Live Session/cover.png','image/png',cover,null]
];
let offset=0,counter=1;
const entries=specs.map(([path,mime,data,track],index)=>{const chunkCount=Math.ceil(data.length/1048576);const e={id:`media-${String(index+1).padStart(6,'0')}`,displayName:path.split('/').at(-1),mimeType:mime,relativePath:path,sizeBytes:data.length,sha256:createHash('sha256').update(data).digest('hex'),index,dataOffset:offset,firstCounter:counter,chunkCount,...(track?{trackNumber:track,discNumber:1}:{})};offset+=data.length+chunkCount*16;counter+=chunkCount;return e;});
const manifest=Buffer.from(JSON.stringify({format:'dualscan-mp',schemaVersion:1,id:randomUUID(),title:'Diamond Sessions',chunkBytes:1048576,entries}));
const h=Buffer.alloc(44);h.write('DSMP0001');randomBytes(16).copy(h,8);randomBytes(12).copy(h,24);h.writeInt32BE(600000,36);h.writeInt32BE(manifest.length+16,40);
const password='Diamond demo 2026',key=pbkdf2Sync(password,h.subarray(8,24),600000,32,'sha256');
function seal(data,n,a){const c=createCipheriv('aes-256-gcm',key,nonce(h,n));c.setAAD(a);return Buffer.concat([c.update(data),c.final(),c.getAuthTag()]);}
const parts=[h,seal(manifest,0,Buffer.concat([h,Buffer.from([0])]))];
for(const e of entries){const data=specs[e.index][2];for(let chunk=0;chunk<e.chunkCount;chunk++){const clear=data.subarray(chunk*1048576,Math.min((chunk+1)*1048576,data.length));parts.push(seal(clear,e.firstCounter+chunk,aad(h,e.index,chunk,clear.length)));}}
const bytes=Buffer.concat(parts);writeFileSync('verification/Diamond-Demo.dmpa',bytes);writeFileSync('verification/Diamond-Demo.json',JSON.stringify({password,publicSyntheticTestData:true,sha256:createHash('sha256').update(bytes).digest('hex'),entries:entries.map(e=>({name:e.displayName,path:e.relativePath,trackNumber:e.trackNumber}))},null,2)+'\n');
// Only synthetic source material is written for a real Android SAF folder-import test.
for(const [path,,data]of specs){const output='verification/diamond-demo-source/'+path;mkdirSync(output.slice(0,output.lastIndexOf('/')),{recursive:true});writeFileSync(output,data);}
key.fill(0);ok.fill(0);wav.fill(0);video.fill(0);manifest.fill(0);
