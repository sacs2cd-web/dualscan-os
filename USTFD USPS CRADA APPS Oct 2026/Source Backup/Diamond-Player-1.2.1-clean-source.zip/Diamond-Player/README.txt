DIAMOND™ PLAYER 1.2.1 — DEVELOPMENT RELEASE CANDIDATE

Standalone Android entertainment player for encrypted local collections.
Music, video and photos; simple black/light appearance. Android 8.0+ (API26).
No Internet permission, cloud transfer, general sharing or plaintext export.

BUILD
JDK21, AndroidSDK36, Gradle9.3.1:
Both Share and Diamond require the same separately retained 32-byte ecosystem
key. See interchange-core/FORMAT.md for build configuration and key backup.
The raw key and generated key source are excluded from clean source ZIPs.
  ./gradlew :tella-keys-core:test :interchange-core:testDebugUnitTest :app:testDebugUnitTest
  ./gradlew :app:assembleDebug :app:assembleRelease :app:lintDebug
  ./gradlew :app:assembleDebugAndroidTest

Installable development APK: app/build/outputs/apk/debug/app-debug.apk
Unsigned OEM candidate: app/build/outputs/apk/release/app-release-unsigned.apk
No production signing credential is included or reused from another project.

USE
- The app opens to an empty library. No collection, mock media, storage picker
  or loading operation starts automatically. Opening or importing is your choice.
- Add media: choose local music, video or pictures and give the collection a title.
  Password is optional. A blank password uses the shared Dualscan interchange key;
  a supplied password must be confirmed and kept separately. It cannot be recovered.
- Open collection: select a current .dshare image or .dmpa collection from attached
  USB storage or this phone. Default images open directly. Only password-protected
  images ask for a password. Cancel or a failed password keeps the prior collection.
  Browse All, Music, Video or Photos and tap an item. Documents and firmware files
  inside a Share image stay in the encrypted container and are not playback items.
- Use playback controls to pause, seek and change tracks. Tap the sun/moon
  icon to switch between black and light appearance.
- Tap artwork in the player to view the whole image in a full-screen modal.
  Use its close button or Android Back to return to the player.
- Save collection: choose USB or this phone. On phone, select a Music, Pictures
  or Movies folder. Only the unchanged encrypted .dshare/.dmpa container is copied;
  the destination is read back and SHA-256 checked. No plaintext media file
  is exported. If transfer fails, deletion of the newly created copy is attempted.
- An authored collection remains encrypted after a USB/phone transfer. Android
  Gallery, music and video apps receive no extracted media or playable URI.
  Only Diamond decodes collection entries in memory. The separate original
  authoring files and any plaintext restored by older Share versions are not
  erased or changed by installing this update.
- Closing/replacing a collection runs internal playback/reader cleanup and
  clears its keys. USB/phone originals remain.

PLAYBACK
The shared interchange-core implements DSMP0002 for new .dmpa collections and
Dualscan Share .dshare images. Both use the same authenticated encrypted catalog
and independently authenticated seekable chunks. Password-based DSMP0001 media
collections remain readable. Earlier DSHP0001 Share backups must be exported
again with the updated Share app before playback; they are not silently converted.
Decrypted media is delivered to decoders in
memory; no plaintext temporary media or disk cache is created for playback.
Source reading and decoding depend on codecs supported by the Android device.
Raw FLAC uses Media3 compressed-frame extraction before MediaCodec, avoiding
Android framework extractors that preconvert high-precision FLAC to 16-bit PCM.
WAV and raw FLAC actual Android tests compare all decoded24/96PCM bytes.
Physical USB DAC output still requires separate hardware qualification.

API34+ audio uses Diamond's independently written native PCM pipeline through
an own-UID-only encrypted content provider and Android proxy file descriptors.
USB audio devices are detected separately from USB storage. Supported exact
Android BIT_PERFECT mixer output is selected automatically and the UI shows
Bit-perfect only when the native engine's route/format contract is active.
Headphone, speaker and Bluetooth paths follow Android's actual routing.
API26–33 ordinary audio and video use Media3 with a custom authenticated
random-access DataSource. No bit-perfect claim is made for those paths.
Video uses Media3 and photos use bounded in-memory decode. Playback and
creation/copies have separate foreground services. Android or storage failures
can still interrupt operations; interrupted transfers are not resumed.

PRIVACY / STORAGE
Known cloud providers and photo-picker cloud routes are rejected before input
is opened. Collections open from the local external-storage document provider.
Removable archive sources/destinations additionally require a mounted removable
volume UUID and attached USB mass-storage device. Public APIs do not reliably
prove a volume's USB-versus-SD bus or physical USB-C connector; choose USB explicitly.
Folder destinations are validated before a document is created. The app is
excluded from Android cloud/device backup. Passwords are never saved or exported.
Encryption protects collection storage and authenticates data reads. It is not
platform DRM, protected video output or a guarantee against a privileged device.
The default global key is shared by compatible Dualscan apps. It enables password-
free interchange, not private access control: someone with the apps or their key
can open a default image. Add an optional password when personal confidentiality
is needed. Password-protected images do not fall back to the global key.

TELLA / ORIGINAL IMPLEMENTATION
The app includes the upstream Tella MainKey/Wiper utility module under its
actual MIT source license. See third_party/tella and docs/TELLA-* for exact
provenance and exclusions. The new seekable chunk format is independently
implemented; legacy unauthenticated CTR is not used for collection playback.
Tella MIT license/notice are packaged in app assets/legal and shown in About.
The native PCM pipeline is reused from our own clean-room Diamond source;
no Onkyo or other reference-app binaries, code or branding are included.

See verification for build/tests and the delivery report for actual device
checks versus unverified physical USB DAC / USB-C hardware acceptance.

LIBRARY / PLAYBACK
Magenta#FF00FE branding and the user-supplied diamond icon. Album folder
import includes cover.jpg/cover.png as encrypted media. Tracks/Folders/Name
ordering uses authenticated track/disc numbers, then natural filename order.
Source-fidelity display uses actual file precision/rate and supports32bit768kHz
values. It does not assert output bit identity unless strict USB is active.
Equal-format WAV/FLAC native queues prepare the next source ahead of time and
append PCM without resetting AudioTrack. Format changes require reconfiguration;
MP3/AAC encoder delay/padding is not verified by that native lossless guarantee.
Slow media, device scheduling and route changes can still cause interruptions.

VERSION1.1.1 UI
Removed the visible collection lock button. Launcher artwork uses proportional
insets, preserving its aspect ratio at different icon sizes on a black adaptive
background. The full diamond and trademark fit inside circular/squircle masks.
The launcher label is Diamond™ so it fits standard home-screen icon cells;
the app name and in-app banner remain Diamond™ Player.
Tap player artwork to open a full-screen image with Close and Android Back.

VERSION1.1.2 EMPTY START
Transfer work waits for Android's foreground service acknowledgement; immediate
completion/cancellation no longer stops a service before its required startup.
Removed the automatic demo load, demo action and bundled mock collection from
the installed app. The empty library remains until the user chooses Open
collection or Add media; a cancelled picker leaves the library unchanged.
Earlier screenshots and mock generators are research-only verification assets;
they are not a bundled music library and do not establish real album fidelity.

VERSION1.2.0 SHARE INTERCHANGE
New Share images open directly in Diamond with their media and folder covers.
The app still starts empty and never launches a storage picker automatically.
Global-key images do not show a password prompt. Protected images request their
own password, and cancellation never resets the current library. Mixed document
backups list only media; document-only backups show No playable media.
Default collections and password-protected collections are encrypted at rest.
Native PCM precision, source fidelity, artwork modal and lossless queue behavior
are unchanged by the container integration. No cloud or plaintext playback spool
is introduced. Test-only cross-app fixtures are excluded from the shipping APK.

VERSION1.2.1 ENCRYPTED COPIES
The save boundary accepts encrypted DSMP collection signatures only and copies
the complete ciphertext byte for byte; it never accepts an entry decode stream.
It rejects clear photo/music/archive streams before writing any bytes and verifies
the saved file by size and SHA-256. Photos stay inside the sealed collection in
shared Pictures storage, and the non-exported decoder provider cannot grant other
applications a decrypted URI. Android tests cover media scanner classification,
absence from Gallery's image table, failed ordinary image decoding and successful
exact-pixel in-app photo decoding without plaintext files or a disk image cache.
