package com.dualscan.share.core

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Public-folder layout is archive metadata; ZIP payload names never become paths. */
class RelativePathArchiveTest {
    @get:Rule val temporary = TemporaryFolder()
    private val device = DeviceIdentity("Dualscan", "Test", "test", "14", 34, "test-build", "2026-10-01")
    private val request get() = BundleRequest("Public folders", device = device)

    @Test fun nestedUnicodeAndBinaryFolderRoundTripKeepsRelativePathsAndExactBytes() {
        val files = linkedMapOf(
            "Documents/Research/東京 résumé.txt" to "Portable Unicode document\nΚαλημέρα".toByteArray(),
            "Download/data/capture.bin" to ByteArray(131_079) { (it * 37).toByte() },
            "Pictures/empty.dat" to byteArrayOf()
        )
        val archive = newFile()
        val inspection = ArchiveEngine.create(archive, request, files.map { (path, bytes) -> input(path, bytes) })
        assertEquals(files.keys.toList(), inspection.manifest.entries.map { it.relativePath })
        val restored = linkedMapOf<String, ByteArrayOutputStream>()
        val result = ArchiveEngine.restore(archive, inspection.manifest.entries.map { it.id }.toSet()) { entry ->
            ByteArrayOutputStream().also { restored[requireNotNull(entry.relativePath)] = it }
        }
        assertEquals(files.keys, restored.keys)
        files.forEach { (path, bytes) -> assertArrayEquals(path, bytes, restored.getValue(path).toByteArray()) }
        assertEquals(files.values.sumOf { it.size.toLong() }, result.restoredBytes)
    }

    @Test fun sameBasenameInDifferentFoldersIsAcceptedAndDoesNotCollapseEntries() {
        val archive = newFile()
        val inspection = ArchiveEngine.create(archive, request, listOf(
            input("Documents/settings.json", "documents".toByteArray()),
            input("Download/settings.json", "download".toByteArray())
        ))
        assertEquals(listOf("settings.json", "settings.json"), inspection.manifest.entries.map { it.displayName })
        assertEquals(2, inspection.manifest.entries.map { it.id }.toSet().size)
        val outputs = linkedMapOf<String, ByteArrayOutputStream>()
        ArchiveEngine.restore(archive, inspection.manifest.entries.map { it.id }.toSet()) { entry ->
            ByteArrayOutputStream().also { outputs[requireNotNull(entry.relativePath)] = it }
        }
        assertEquals("documents", outputs.getValue("Documents/settings.json").toString("UTF-8"))
        assertEquals("download", outputs.getValue("Download/settings.json").toString("UTF-8"))
    }

    @Test fun nestedSelectionDoesNotOpenSiblingDestination() {
        val archive = newFile()
        val inspection = ArchiveEngine.create(archive, request, listOf(
            input("Documents/a/note.txt", byteArrayOf(1, 2)),
            input("Documents/b/note.txt", byteArrayOf(3, 4))
        ))
        val selected = inspection.manifest.entries.last()
        val calls = mutableListOf<String?>()
        val output = ByteArrayOutputStream()
        ArchiveEngine.restore(archive, setOf(selected.id)) { entry -> calls += entry.relativePath; output }
        assertEquals(listOf("Documents/b/note.txt"), calls)
        assertArrayEquals(byteArrayOf(3, 4), output.toByteArray())
    }

    @Test fun duplicateEffectivePathsAreRejectedBeforeOpeningAnyInputOrCreatingOutput() {
        val duplicates = listOf(
            listOf("Documents/report.txt", "Documents/report.txt"),
            listOf(null, "report.txt")
        )
        duplicates.forEach { paths ->
            var opens = 0
            val output = newFile()
            val sources = paths.map { path -> BundleInput("report.txt", "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }
            rejected { ArchiveEngine.create(output, request, sources) }
            assertEquals("Duplicate effective paths must be preflighted", 0, opens)
            assertFalse(output.exists())
        }
    }

    @Test fun duplicateManifestPathsAreRejectedBeforeAnyRestoreDestination() {
        val archive = createTwoPaths()
        val ids = ArchiveEngine.inspect(archive).manifest.entries.map { it.id }.toSet()
        val corrupt = mutateManifest(archive) { json ->
            val entries = json.getJSONArray("entries")
            entries.getJSONObject(1).put("relativePath", entries.getJSONObject(0).getString("relativePath"))
        }
        var destinations = 0
        rejected { ArchiveEngine.restore(corrupt, ids) { destinations++; ByteArrayOutputStream() } }
        assertEquals(0, destinations)
    }

    @Test fun casefoldAndCanonicallyEquivalentPathsCannotCollideOnUsbFilesystems() {
        listOf(
            listOf("Documents/report.txt", "documents/REPORT.txt"),
            listOf("Documents/résumé.txt", "Documents/re\u0301sume\u0301.txt")
        ).forEach { paths ->
            var opens = 0
            val output = newFile()
            val inputs = paths.map { path -> BundleInput(path.substringAfterLast('/'), "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }
            rejected { ArchiveEngine.create(output, request, inputs) }
            assertEquals(0, opens)
            assertFalse(output.exists())
        }
        val archive = createTwoPaths()
        val ids = ArchiveEngine.inspect(archive).manifest.entries.map { it.id }.toSet()
        val corrupt = mutateManifest(archive) { json ->
            json.getJSONArray("entries").getJSONObject(1)
                .put("displayName", "REPORT.txt").put("relativePath", "documents/REPORT.txt")
        }
        var writes = 0
        rejected { ArchiveEngine.restore(corrupt, ids) { writes++; ByteArrayOutputStream() } }
        assertEquals(0, writes)
    }

    @Test fun aFileCannotAlsoBeAnotherEntriesParentDirectory() {
        listOf(
            listOf("Documents/report.txt", "Documents/report.txt/child.txt"),
            listOf("Documents/REPORT.txt", "documents/report.txt/child.txt")
        ).forEach { paths ->
            var opens = 0
            val sources = paths.map { path -> BundleInput(path.substringAfterLast('/'), "text/plain", path) { opens++; byteArrayOf(1).inputStream() } }
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, sources) }
            assertEquals(0, opens)
            assertFalse(output.exists())
        }
    }

    @Test fun hostileManifestFileAsDirectoryConflictPreventsAnyDestinationWrites() {
        val archive = createTwoPaths()
        val ids = ArchiveEngine.inspect(archive).manifest.entries.map { it.id }.toSet()
        val corrupt = mutateManifest(archive) { json ->
            json.getJSONArray("entries").getJSONObject(1)
                .put("displayName", "child.txt").put("relativePath", "documents/REPORT.txt/child.txt")
        }
        var writes = 0
        rejected { ArchiveEngine.restore(corrupt, ids) { writes++; ByteArrayOutputStream() } }
        assertEquals(0, writes)
    }

    @Test fun traversalAbsoluteAndControlPathsAreRejectedAtCreationAndInspection() {
        val archive = newFile()
        ArchiveEngine.create(archive, request, listOf(input("Documents/report.txt", byteArrayOf(1))))
        val invalid = listOf("../report.txt", "Documents/../report.txt", "/Documents/report.txt",
            "Documents//report.txt", "./report.txt", "Documents/./report.txt", "Documents\\report.txt",
            "Documents/\n/report.txt", "Documents/\u007f/report.txt", "", "Documents/report.txt/")
        invalid.forEach { path ->
            var opened = false
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, listOf(BundleInput("report.txt", "text/plain", path) { opened = true; byteArrayOf(1).inputStream() })) }
            assertFalse("Unsafe path was read: $path", opened)
            assertFalse("Unsafe path left output: $path", output.exists())
            val corrupt = mutateManifest(archive) { it.getJSONArray("entries").getJSONObject(0).put("relativePath", path) }
            rejected { ArchiveEngine.inspect(corrupt) }
        }
    }

    @Test fun relativePathBasenameMustMatchDisplayName() {
        val output = newFile()
        rejected { ArchiveEngine.create(output, request, listOf(BundleInput("display.txt", "text/plain", "Documents/different.txt") { byteArrayOf(1).inputStream() })) }
        assertFalse(output.exists())
        val base = newFile()
        ArchiveEngine.create(base, request, listOf(input("Documents/report.txt", byteArrayOf(1))))
        rejected { ArchiveEngine.inspect(mutateManifest(base) { it.getJSONArray("entries").getJSONObject(0).put("relativePath", "Documents/different.txt") }) }
    }

    @Test fun pathsBeyondLengthOrDepthLimitAreRejected() {
        val tooDeep = (List(32) { "folder" } + "report.txt").joinToString("/")
        val tooLong = "folder/" + "x".repeat(1010) + "/report.txt"
        assertTrue(tooLong.length > 1024)
        listOf(tooDeep, tooLong).forEach { path ->
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, listOf(BundleInput("report.txt", "text/plain", path) { byteArrayOf(1).inputStream() })) }
            assertFalse(output.exists())
        }
    }

    @Test fun maximumSupportedDepthIsAccepted() {
        val path = (List(31) { "folder" } + "report.txt").joinToString("/")
        val inspection = ArchiveEngine.create(newFile(), request, listOf(input(path, byteArrayOf(1))))
        assertEquals(path, inspection.manifest.entries.single().relativePath)
    }

    @Test fun independentlyConstructedLegacyManifestWithoutRelativePathStillRestores() {
        val content = "legacy host-generated fixture\n".toByteArray()
        val archive = legacyFixture(content)
        val inspection = ArchiveEngine.inspect(archive)
        assertNull(inspection.manifest.entries.single().relativePath)
        val output = ByteArrayOutputStream()
        ArchiveEngine.restore(archive, setOf("file-000001")) { entry ->
            assertEquals("legacy.txt", entry.displayName)
            assertNull(entry.relativePath)
            output
        }
        assertArrayEquals(content, output.toByteArray())
    }

    @Test fun manifestSdkLongCannotWrapIntoValidAndroidSdk() {
        val base = legacyFixture(byteArrayOf(1))
        listOf(4_294_967_330L, -4_294_967_262L, Long.MAX_VALUE).forEach { sdk ->
            val corrupt = mutateManifest(base) { it.getJSONObject("device").put("sdkInt", sdk) }
            rejected { ArchiveEngine.inspect(corrupt) }
        }
    }

    @Test fun publicFolderArchiveCanExceedFormer512EntryLimit() {
        val inputs = (1..513).map { index -> input("Documents/folder/item-$index.txt", byteArrayOf(index.toByte())) }
        val inspection = ArchiveEngine.create(newFile(), request, inputs)
        assertEquals(513, inspection.manifest.entries.size)
        assertEquals(513L, inspection.totalPayloadBytes)
    }

    @Test fun moreThanTenThousandEntriesIsRejectedBeforeSourcesOpen() {
        var opens = 0
        val inputs = (1..10_001).map { index -> BundleInput("item-$index.txt", "text/plain", "Documents/item-$index.txt") { opens++; byteArrayOf().inputStream() } }
        val output = newFile()
        rejected { ArchiveEngine.create(output, request, inputs) }
        assertEquals(0, opens)
        assertFalse(output.exists())
    }

    private fun createTwoPaths(): File = newFile().also { file -> ArchiveEngine.create(file, request,
        listOf(input("Documents/report.txt", byteArrayOf(1)), input("Download/report.txt", byteArrayOf(2)))) }
    private fun input(path: String, bytes: ByteArray) = BundleInput(path.substringAfterLast('/'), "application/octet-stream", path) { bytes.inputStream() }
    private fun newFile() = File(temporary.root, "paths-${UUID.randomUUID()}.dshare")

    private fun mutateManifest(source: File, mutation: (JSONObject) -> Unit): File {
        val output = newFile()
        ZipFile(LegacyArchiveFixture.zipForMutation(source)).use { input -> ZipOutputStream(output.outputStream()).use { zip ->
            input.entries().toList().forEach { entry ->
                val bytes = input.getInputStream(entry).use { it.readBytes() }
                val modified = if (entry.name == "manifest.json") JSONObject(bytes.toString(Charsets.UTF_8)).also(mutation).toString().toByteArray() else bytes
                zip.putNextEntry(ZipEntry(entry.name)); zip.write(modified); zip.closeEntry()
            }
        } }
        return output
    }

    private fun legacyFixture(content: ByteArray): File {
        val manifest = JSONObject().apply {
            put("format", "dualscan-share"); put("schemaVersion", 1)
            put("bundleId", "a0fa5399-cf88-4498-a60b-56e8aa8ba48c")
            put("title", "Legacy backup"); put("description", "Fixture built without ArchiveEngine")
            put("kind", "PORTABLE_BACKUP"); put("createdAtEpochMs", 0)
            put("encryption", "none"); put("coverage", "explicit-user-selected-content")
            put("device", JSONObject().put("manufacturer", "Host").put("model", "Fixture")
                .put("device", "fixture").put("androidRelease", "14").put("sdkInt", 34)
                .put("fingerprint", "host-generated").put("securityPatch", "2026-10-01"))
            put("apps", JSONArray()); put("oem", JSONObject.NULL)
            put("entries", JSONArray().put(JSONObject().put("id", "file-000001")
                .put("displayName", "legacy.txt").put("mimeType", "text/plain")
                .put("sizeBytes", content.size).put("sha256", hash(content))))
        }
        return newFile().also { file -> ZipOutputStream(file.outputStream()).use { zip ->
            zip.putNextEntry(ZipEntry("payload/file-000001")); zip.write(content); zip.closeEntry()
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write(manifest.toString().toByteArray()); zip.closeEntry()
        } }
    }

    private fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun rejected(block: () -> Unit) {
        try { block() } catch (_: Exception) { return }
        throw AssertionError("Unsafe path/archive was accepted")
    }
}
