package com.dualscan.share

import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class UsbAndMediaPolicyTest {
    private val mounted = UsbStorageSnapshot(true, listOf(RemovableVolume("1234-ABCD", true, true)))
    @Test fun mountedRemovableWithAttachedUsbIsAccepted() { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "1234-abcd:Backups/library.dshare", mounted) }
    @Test fun cloudProviderIsRejected() { rejects { UsbAccessPolicy.requireAllowed("com.google.android.apps.docs.storage", "1234-ABCD:image", mounted) } }
    @Test fun internalPrimaryArchiveIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "primary:Download/image.dshare", mounted) } }
    @Test fun disconnectedUsbIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "1234-ABCD:image", mounted.copy(usbMassStorageAttached = false)) } }
    @Test fun unmountedVolumeIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "1234-ABCD:image", UsbStorageSnapshot(true, listOf(RemovableVolume("1234-ABCD", true, false)))) } }
    @Test fun uuidMismatchIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "9999-AAAA:image", mounted) } }
    @Test fun nonRemovableVolumeIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "1234-ABCD:image", UsbStorageSnapshot(true, listOf(RemovableVolume("1234-ABCD", false, true)))) } }
    @Test fun malformedDocumentIdIsRejected() { rejects { UsbAccessPolicy.requireAllowed(UsbAccessPolicy.AUTHORITY, "1234-ABCD", mounted) } }
    @Test fun apkWithSpoofedImageMimeIsRejected() { rejects { MediaPolicy.group("installer.APK", "image/png") } }
    @Test fun appBundleWithSpoofedAudioMimeIsRejected() { rejects { MediaPolicy.group("application.aab", "audio/flac") } }
    @Test fun mediaGroupsMapToTheirOwnFolders() { assertEquals(MediaGroup.AUDIO, MediaPolicy.group("track.flac", "audio/flac")); assertEquals("Music", MediaGroup.AUDIO.folder); assertEquals(MediaGroup.IMAGE, MediaPolicy.group("photo.jpg", "image/jpeg")); assertEquals(MediaGroup.VIDEO, MediaPolicy.group("movie.mp4", "video/mp4")) }
    @Test fun genericOctetStreamIsNotAssumedToBeMedia() { rejects { MediaPolicy.group("track.flac", "application/octet-stream") } }
    @Test fun localAndroidProvidersAreAccepted() { listOf("media", "com.android.providers.media.documents", "com.android.providers.downloads.documents", "com.android.externalstorage.documents").forEach { LocalMediaSourcePolicy.requireLocal(it, "/document/audio:123") } }
    @Test fun cloudSourceIsRejectedBeforeAnyRead() { rejects { LocalMediaSourcePolicy.requireLocal("cloud.example.provider", "/document/track") } }
    @Test fun photoPickerCloudRouteIsRejected() {
        for (segment in listOf("picker", "picker_get_content")) rejects { LocalMediaSourcePolicy.requireLocal("media", "/$segment/0/cloud.example/media/1") }
    }
    @Test fun outputDisplayNameIsFlatAndControlFree() { assertEquals("track.flac", MediaPolicy.safeName("../../private\\track.flac")); assertEquals("ab.jpg", MediaPolicy.safeName("a\nb.jpg")) }
    private fun rejects(block: () -> Unit) { try { block(); fail("Expected rejection") } catch (_: IOException) {} }
}
