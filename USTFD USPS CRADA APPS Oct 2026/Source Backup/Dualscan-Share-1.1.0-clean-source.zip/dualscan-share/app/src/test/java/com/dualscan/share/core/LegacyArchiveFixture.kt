package com.dualscan.share.core

import com.dualscan.mp.core.MediaArray
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** ZIP construction is test-only: production creates encrypted DSMP0002 images. */
internal object LegacyArchiveFixture {
    fun zipForMutation(source: File): File {
        if (!MediaArray.isSupported(source)) return source
        val inspection = ArchiveEngine.inspect(source)
        val payloads = linkedMapOf<String, ByteArrayOutputStream>()
        ArchiveEngine.restore(source, inspection.manifest.entries.map { it.id }.toSet()) { entry ->
            ByteArrayOutputStream().also { payloads[entry.id] = it }
        }
        return File(source.parentFile, "legacy-mutation-${UUID.randomUUID()}.dshare").also { file ->
            ZipOutputStream(file.outputStream()).use { zip ->
                payloads.forEach { (id, bytes) ->
                    zip.putNextEntry(ZipEntry("payload/$id")); zip.write(bytes.toByteArray()); zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(ArchiveEngine.encodeManifest(inspection.manifest).toString().toByteArray())
                zip.closeEntry()
            }
        }
    }
}
