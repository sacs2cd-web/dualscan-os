package com.dualscan.share.core

import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class PortableShareInterchangeTest {
    @get:Rule val temporary = TemporaryFolder()
    private val request = BundleRequest("USB collection", "Share to Diamond Player", device =
        DeviceIdentity("Dualscan", "Fixture", "fixture", "16", 36, "public-test", "2026-10-01"))
    private val audio = ByteArray(1_048_593) { (it * 31).toByte() }
    private val document = "Independent document alongside media 東京".toByteArray()
    private val inputs get() = listOf(
        BundleInput("01 Track.wav", "audio/wav", "Music/Album/01 Track.wav") { audio.inputStream() },
        BundleInput("notes.txt", "text/plain", "Documents/notes.txt") { document.inputStream() })

    @Test fun noPasswordCreatesEncryptedPlayerReadableContainerAndPreservesBackupMetadata() {
        val output = fresh()
        val info = ArchiveEngine.create(output, request, inputs)
        assertEquals("DSMP0002", output.inputStream().use { String(it.readNBytes(8), Charsets.US_ASCII) })
        assertTrue(info.encrypted); assertFalse(info.passwordProtected)
        assertFalse(output.readBytes().toString(Charsets.ISO_8859_1).contains(document.toString(Charsets.UTF_8)))
        MediaArray.open(output).use { player ->
            assertTrue(player.isPortable); assertFalse(player.passwordProtected)
            assertEquals(request.title, player.catalog.title)
            assertEquals(2, player.catalog.entries.size)
            assertArrayEquals(audio, player.openEntry(player.catalog.entries.first().id).use { it.readBytes() })
            assertNotNull(player.catalog.backupMetadata)
        }
        assertEquals(request.description, info.manifest.description)
        assertEquals(request.device, info.manifest.device)
        assertEquals(listOf("Music/Album/01 Track.wav", "Documents/notes.txt"), info.manifest.entries.map { it.relativePath })
        val restored = linkedMapOf<String, ByteArrayOutputStream>()
        ArchiveEngine.restore(output, info.manifest.entries.map { it.id }.toSet()) { entry ->
            ByteArrayOutputStream().also { restored[entry.displayName] = it }
        }
        assertArrayEquals(audio, restored.getValue("01 Track.wav").toByteArray())
        assertArrayEquals(document, restored.getValue("notes.txt").toByteArray())
        assertTrue(temporary.root.listFiles()!!.none { it.name.startsWith(".dualscan-unlocked-") })
    }

    @Test fun optionalPasswordAddsProtectionThatGlobalAccessCannotBypass() {
        val output = fresh(); val password = "Independent test password 2026".toCharArray()
        try {
            val info = ArchiveEngine.create(output, request, inputs, password)
            assertTrue(info.encrypted); assertTrue(info.passwordProtected)
            try { ArchiveEngine.inspect(output); fail("Password prompt required") } catch (_: PasswordRequiredException) { }
            var opened = 0
            rejected { ArchiveEngine.restore(output, setOf("file-000001"), "Wrong optional password".toCharArray()) { opened++; ByteArrayOutputStream() } }
            assertEquals(0, opened)
            MediaArray.open(output, password).use { assertTrue(it.passwordProtected); it.verifyAll() }
            assertEquals(info.manifest, ArchiveEngine.inspect(output, password).manifest)
        } finally { password.fill('\u0000') }
    }

    @Test fun corruptUnselectedEncryptedPayloadBlocksAllRestoreDestinations() {
        val output = fresh(); val info = ArchiveEngine.create(output, request, inputs)
        val bytes = output.readBytes()
        output.writeBytes(bytes.also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() })
        var opened = 0
        rejected { ArchiveEngine.inspect(output) }
        rejected { ArchiveEngine.restore(output, setOf(info.manifest.entries.first().id)) { opened++; ByteArrayOutputStream() } }
        assertEquals(0, opened)
    }

    @Test fun weakOptionalPasswordDoesNotLeaveOutput() {
        val output = fresh()
        rejected { ArchiveEngine.create(output, request, inputs, "short".toCharArray()) }
        assertFalse(output.exists())
    }

    private fun fresh() = File(temporary.root, "portable-${UUID.randomUUID()}.dshare")
    private fun rejected(block: () -> Unit) {
        try { block() } catch (_: Exception) { return }
        throw AssertionError("Unsafe archive operation was accepted")
    }
}
