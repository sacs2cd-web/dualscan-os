package com.dualscan.share

import org.junit.Assert.*
import org.junit.Test

class SharedFilePolicyTest {
    @Test fun publicDocumentsAndMediaAreAllowed() {
        listOf("notes.txt","report.pdf","table.csv","book.epub","project.zip","recording.flac","movie.mp4","photo.jpg","recording.wav","metadata.json")
            .forEach { GenericFilePolicy.requireAllowed(it,"application/octet-stream") }
    }
    @Test fun androidApplicationFamiliesAreExcludedRegardlessOfCase() {
        listOf("APK","apkm","apks","xapk","aab","dex","odex","vdex","obb").forEach {
            expectFailure { GenericFilePolicy.requireAllowed("file.$it","image/jpeg") }
        }
    }
    @Test fun packageMimeCannotBeDisguisedByADocumentExtension() {
        expectFailure { GenericFilePolicy.requireAllowed("report.txt","APPLICATION/VND.ANDROID.PACKAGE-ARCHIVE") }
    }
    @Test fun unicodeRelativeFolderPathsRemainReadable() {
        assertEquals(listOf("Documents","東京","Research notes.txt"),RelativeFilePaths.segments("Documents/東京/Research notes.txt"))
    }
    @Test fun absoluteTraversalAndSeparatorAmbiguitiesFailClosed() {
        listOf("/Documents/a.txt","Documents/../a.txt","Documents/./a.txt","Documents//a.txt","C:\\Documents\\a.txt","Documents/a\u0000.txt")
            .forEach { path -> expectFailure { RelativeFilePaths.segments(path) } }
    }
    @Test fun nestingIsBoundedBeforeProviderOperations() {
        assertEquals(32,RelativeFilePaths.segments((List(31) { "folder" } + "file.txt").joinToString("/")).size)
        expectFailure { RelativeFilePaths.segments((List(32) { "folder" } + "file.txt").joinToString("/")) }
    }
    @Test fun segmentLengthMatchesPortableArchiveContract() {
        RelativeFilePaths.requireSegment("a".repeat(240))
        expectFailure { RelativeFilePaths.requireSegment("a".repeat(241)) }
    }
    private fun expectFailure(action: () -> Unit) {
        var failed=false
        try { action() } catch (_: Exception) { failed=true }
        assertTrue("Unsafe or excluded source was accepted",failed)
    }
}
