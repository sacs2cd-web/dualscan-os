package com.dualscan.share.core

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ArchiveEngineTest {
    @get:Rule val temporary = TemporaryFolder()

    private val device = DeviceIdentity("Dualscan", "Test phone", "test_device", "14", 34,
        "dualscan/test/device:14/test:user/release-keys", "2026-10-01")
    private val request get() = BundleRequest("My selected content", device = device)
    private val oem get() = OemImageMetadata("Dualscan", "test_device", "DS-2026.10", "AOSP_OTA", "ab".repeat(32))
    private val sampleContents = linkedMapOf(
        "Résumé 東京 📱.txt" to "Unicode content: Καλημέρα / 日本語 / café\n".toByteArray(),
        "camera.bin" to ByteArray(262_151) { ((it * 67 + 13) and 255).toByte() },
        "empty.dat" to byteArrayOf()
    )

    @Test fun multifileRoundTripPreservesBinaryUnicodeAndEmptyFiles() {
        val archive = create()
        val inspection = ArchiveEngine.inspect(archive)
        val outputs = linkedMapOf<String, ByteArrayOutputStream>()
        val result = ArchiveEngine.restore(archive, inspection.manifest.entries.map { it.id }.toSet()) { entry ->
            ByteArrayOutputStream().also { outputs[entry.displayName] = it }
        }
        assertEquals(sampleContents.keys, outputs.keys)
        sampleContents.forEach { (name, bytes) -> assertArrayEquals(name, bytes, outputs.getValue(name).toByteArray()) }
        assertEquals(3, result.restoredEntries)
        assertEquals(sampleContents.values.sumOf { it.size.toLong() }, result.restoredBytes)
        assertEquals(result.restoredBytes, inspection.totalPayloadBytes)
        assertEquals(hash(archive.readBytes()), inspection.archiveSha256)
        assertEquals(archive.length(), inspection.archiveBytes)
        inspection.manifest.entries.forEach { entry ->
            assertEquals(hash(sampleContents.getValue(entry.displayName)), entry.sha256)
            assertEquals(sampleContents.getValue(entry.displayName).size.toLong(), entry.sizeBytes)
        }
    }

    @Test fun selectedRestoreNeverOpensUnselectedDestinations() {
        val archive = create()
        val selected = ArchiveEngine.inspect(archive).manifest.entries.single { it.displayName == "camera.bin" }
        val calls = mutableListOf<String>()
        val restored = ByteArrayOutputStream()
        val result = ArchiveEngine.restore(archive, setOf(selected.id)) { entry -> calls += entry.id; restored }
        assertEquals(listOf(selected.id), calls)
        assertEquals(1, result.restoredEntries)
        assertArrayEquals(sampleContents.getValue("camera.bin"), restored.toByteArray())
    }

    @Test fun emptyAndUnknownSelectionsDoNotOpenDestinations() {
        val archive = create()
        var calls = 0
        listOf(emptySet(), setOf("file-999999")).forEach { selection ->
            rejected { ArchiveEngine.restore(archive, selection) { calls++; ByteArrayOutputStream() } }
        }
        assertEquals(0, calls)
    }

    @Test fun corruptionInLastUnselectedPayloadPreventsEveryDestinationWrite() {
        val archive = create()
        val inspection = ArchiveEngine.inspect(archive)
        // Corrupt an unselected entry after the selected entry in manifest order. Restore must
        // validate the entire package before asking a document provider for any output stream.
        val lastId = inspection.manifest.entries.last().id
        val corrupt = rewrite(archive) { name, bytes -> if (name == "payload/$lastId") byteArrayOf(0x55) else bytes }
        var calls = 0
        rejected { ArchiveEngine.restore(corrupt, setOf(inspection.manifest.entries.first().id)) { calls++; ByteArrayOutputStream() } }
        assertEquals(0, calls)
    }

    @Test fun payloadHashTamperIsRejectedBeforeRestore() {
        val bad = mutateManifest(create()) { it.getJSONArray("entries").getJSONObject(0).put("sha256", "00".repeat(32)) }
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun declaredPayloadSizeTamperIsRejected() {
        val bad = mutateManifest(create()) { it.getJSONArray("entries").getJSONObject(1).put("sizeBytes", 1) }
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun payloadWithSameLengthButDifferentBytesFailsChecksum() {
        val bad = rewrite(create()) { name, bytes ->
            if (name == "payload/file-000002") bytes.clone().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() } else bytes
        }
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun declaredMissingPayloadIsRejected() {
        val bad = rewrite(create(), omit = setOf("payload/file-000002"))
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun missingManifestIsRejected() {
        val bad = rewrite(create(), omit = setOf("manifest.json"))
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun unexpectedPayloadAndUndeclaredMembersAreRejected() {
        val base = create()
        listOf("notes.txt", "payload/file-000004").forEach { name ->
            val bad = rewrite(base, additional = listOf(name to byteArrayOf(1, 2, 3)))
            rejected { ArchiveEngine.inspect(bad) }
        }
    }

    @Test fun traversalAndAbsoluteZipPathsAreRejected() {
        val base = create()
        listOf("../outside", "/absolute", "payload/../../outside", "payload\\file-000004").forEach { name ->
            val bad = rewrite(base, additional = listOf(name to byteArrayOf(1)))
            rejected { ArchiveEngine.inspect(bad) }
        }
    }

    @Test fun directoryMembersAreRejected() {
        val bad = rewrite(create(), additional = listOf("payload/" to byteArrayOf()))
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun duplicateZipMembersAreRejected() {
        // ZipOutputStream itself refuses duplicate names. Equal-length byte patching changes
        // both the local and central names of the second member without changing offsets/CRC.
        val base = create()
        val bad = newFile()
        val bytes = LegacyArchiveFixture.zipForMutation(base).readBytes()
        replaceAll(bytes, "payload/file-000002".toByteArray(), "payload/file-000001".toByteArray())
        bad.writeBytes(bytes)
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun duplicateManifestIdsAreRejected() {
        val bad = mutateManifest(create()) { json ->
            json.getJSONArray("entries").getJSONObject(1).put("id", "file-000001")
        }
        rejected { ArchiveEngine.inspect(bad) }
    }

    @Test fun unsafeNamesAreRejectedDuringCreateAndInspection() {
        listOf("../outside", "dir/file", "dir\\file", ".", "..", "", "\u0000name", "line\nname", "delete\u007f").forEach { unsafe ->
            val output = newFile()
            rejected { ArchiveEngine.create(output, request, listOf(input(unsafe, byteArrayOf(1)))) }
            assertFalse("Rejected input must not leave an archive: $unsafe", output.exists())
            val bad = mutateManifest(create()) { it.getJSONArray("entries").getJSONObject(0).put("displayName", unsafe) }
            rejected { ArchiveEngine.inspect(bad) }
        }
    }

    @Test fun unsupportedVersionAndInconsistentCoverageAreRejected() {
        val base = create()
        val changes: List<(JSONObject) -> Unit> = listOf(
            { it.put("schemaVersion", 2) },
            { it.put("format", "another-archive") },
            { it.put("coverage", "complete-device-clone") },
            { it.put("encryption", "unverified-encryption") }
        )
        changes.forEach { mutation -> rejected { ArchiveEngine.inspect(mutateManifest(base, mutation)) } }
    }

    @Test fun malformedTruncatedAndEmptyArchivesAreRejected() {
        val valid = create().readBytes()
        listOf(byteArrayOf(), "not a zip".toByteArray(), valid.copyOf(valid.size - 22), valid.copyOf(valid.size / 2)).forEach { bytes ->
            val bad = newFile().also { it.writeBytes(bytes) }
            rejected { ArchiveEngine.inspect(bad) }
        }
    }

    @Test fun providerFailureClosesInputAndRemovesPartialArchive() {
        var closed = false
        val broken = BundleInput("unavailable.bin", "application/octet-stream") {
            object : InputStream() {
                var calls = 0
                override fun read(): Int = throw UnsupportedOperationException()
                override fun read(bytes: ByteArray, offset: Int, length: Int): Int {
                    if (calls++ > 0) throw IOException("Disconnected USB-C document provider")
                    bytes.fill(0x42, offset, offset + minOf(1024, length)); return minOf(1024, length)
                }
                override fun close() { closed = true }
            }
        }
        val output = newFile()
        val failure = rejected { ArchiveEngine.create(output, request, listOf(broken)) }
        assertTrue(failure is IOException)
        assertTrue(closed)
        assertFalse(output.exists())
    }

    @Test fun stalledProviderDoesNotSpinOrLeavePartialArchive() {
        val output = newFile()
        rejected { ArchiveEngine.create(output, request, listOf(BundleInput("stalled.bin") {
            object : ByteArrayInputStream(byteArrayOf(1)) {
                override fun read(bytes: ByteArray, offset: Int, length: Int): Int = 0
            }
        })) }
        assertFalse(output.exists())
    }

    @Test fun existingOutputIsNeverOverwrittenOrDeleted() {
        val original = byteArrayOf(0x13, 0x37, 0, 0xff.toByte())
        val output = newFile().also { it.writeBytes(original) }
        rejected { ArchiveEngine.create(output, request, listOf(input("file.txt", byteArrayOf(1)))) }
        assertArrayEquals(original, output.readBytes())
    }

    @Test fun appInventoryOnlyBackupIsAllowedAndMarkedPortable() {
        val apps = listOf(AppInventoryItem("com.example.reader", "2.4", 24))
        val inspection = ArchiveEngine.create(newFile(), request.copy(apps = apps), emptyList())
        assertEquals(BundleKind.PORTABLE_BACKUP, inspection.manifest.kind)
        assertEquals(apps, inspection.manifest.apps)
        assertEquals(0, inspection.manifest.entries.size)
        assertEquals(0L, inspection.totalPayloadBytes)
    }

    @Test fun emptyBackupAndDuplicateInventoryAreRejected() {
        rejected { ArchiveEngine.create(newFile(), request, emptyList()) }
        val app = AppInventoryItem("com.example.reader", "2.4", 24)
        rejected { ArchiveEngine.create(newFile(), request.copy(apps = listOf(app, app)), emptyList()) }
    }

    @Test fun oemImageRequiresTargetMetadataAndPayload() {
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE), listOf(input("payload.bin", byteArrayOf(1)))) }
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE, oem = oem.copy(deviceCodename = "")), listOf(input("payload.bin", byteArrayOf(1)))) }
        rejected { ArchiveEngine.create(newFile(), request.copy(kind = BundleKind.OEM_IMAGE, oem = oem), emptyList()) }
        rejected { ArchiveEngine.create(newFile(), request.copy(oem = oem), listOf(input("file.txt", byteArrayOf(1)))) }
    }

    @Test fun oemPackageCannotIncludePersonalInventoryOrUsePersonalRestore() {
        val imageRequest = request.copy(kind = BundleKind.OEM_IMAGE, oem = oem)
        rejected { ArchiveEngine.create(newFile(), imageRequest.copy(apps = listOf(AppInventoryItem("com.example.privateapp", "1", 1))), listOf(input("payload.bin", byteArrayOf(1)))) }
        val archive = newFile()
        val inspection = ArchiveEngine.create(archive, imageRequest, listOf(input("payload.bin", byteArrayOf(1, 2, 3))))
        assertEquals(oem, inspection.manifest.oem)
        var writes = 0
        rejected { ArchiveEngine.restore(archive, inspection.manifest.entries.map { it.id }.toSet()) { writes++; ByteArrayOutputStream() } }
        assertEquals(0, writes)
    }

    private fun create(): File = newFile().also { output ->
        ArchiveEngine.create(output, request, sampleContents.map { (name, bytes) -> input(name, bytes) })
    }

    private fun input(name: String, bytes: ByteArray) = BundleInput(name, "application/octet-stream") { bytes.inputStream() }
    private fun newFile() = File(temporary.root, "archive-${java.util.UUID.randomUUID()}.dshare")

    private fun mutateManifest(source: File, mutation: (JSONObject) -> Unit): File = rewrite(source) { name, bytes ->
        if (name == "manifest.json") JSONObject(bytes.toString(Charsets.UTF_8)).also(mutation).toString().toByteArray() else bytes
    }

    private fun rewrite(source: File, omit: Set<String> = emptySet(), additional: List<Pair<String, ByteArray>> = emptyList(),
                        transform: (String, ByteArray) -> ByteArray = { _, bytes -> bytes }): File {
        val result = newFile()
        ZipFile(LegacyArchiveFixture.zipForMutation(source)).use { zip ->
            ZipOutputStream(result.outputStream()).use { output ->
                zip.entries().toList().filter { it.name !in omit }.forEach { entry ->
                    val bytes = zip.getInputStream(entry).use { it.readBytes() }
                    output.putNextEntry(ZipEntry(entry.name)); output.write(transform(entry.name, bytes)); output.closeEntry()
                }
                additional.forEach { (name, bytes) -> output.putNextEntry(ZipEntry(name)); output.write(bytes); output.closeEntry() }
            }
        }
        return result
    }

    private fun replaceAll(bytes: ByteArray, needle: ByteArray, replacement: ByteArray) {
        require(needle.size == replacement.size)
        var replacements = 0
        for (i in 0..bytes.size - needle.size) {
            if (needle.indices.all { bytes[i + it] == needle[it] }) {
                replacement.copyInto(bytes, i); replacements++
            }
        }
        assertEquals("Both the local and central ZIP names must change", 2, replacements)
    }

    private fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun rejected(block: () -> Unit): Throwable {
        try { block() } catch (failure: Exception) { return failure }
        throw AssertionError("Unsafe or unsupported archive operation was accepted")
    }
}
