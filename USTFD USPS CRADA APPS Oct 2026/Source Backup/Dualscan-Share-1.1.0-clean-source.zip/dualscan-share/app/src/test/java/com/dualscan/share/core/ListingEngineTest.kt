package com.dualscan.share.core

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.security.MessageDigest

class ListingEngineTest {
    @get:Rule val temporary = TemporaryFolder()
    private val device = DeviceIdentity("Dualscan", "Reference", "reference_device", "14", 34, "test-fingerprint", "2026-10-01")
    private val oem = OemImageMetadata("Dualscan", "reference_device", "DS-2026.10", "AOSP_OTA")
    private val draft get() = ListingDraft("Dualscan OS", "Device owner", "A device-specific image", 1299, "USD", "Licensed for compatible devices")

    @Test fun draftPinsActualArchiveIdentityAndNeverClaimsPublishedOrVerified() {
        val (file, inspection) = image()
        val json = JSONObject(ListingEngine.create(inspection, draft))
        assertEquals("DRAFT_NOT_PUBLISHED", json.getString("status"))
        assertFalse(json.getBoolean("checkoutConfigured"))
        assertFalse(json.getBoolean("firmwareSignatureVerified"))
        assertFalse(json.getBoolean("installationCompatibilityVerified"))
        val expectedHash = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it.toInt() and 255) }
        val artifact = json.getJSONObject("artifact")
        assertEquals(expectedHash, artifact.getString("archiveSha256"))
        assertEquals(file.length(), artifact.getLong("bytes"))
        assertEquals(inspection.manifest.bundleId, artifact.getString("bundleId"))
        assertEquals(oem.deviceCodename, json.getJSONObject("declaredTarget").getString("deviceCodename"))
        assertEquals(1299L, json.getLong("priceMinor"))
        assertEquals(2, json.getInt("currencyFractionDigits"))
    }

    @Test fun yenUsesZeroFractionDigitsAndKeepsMinorUnitsExact() {
        val inspection = image().second
        val json = JSONObject(ListingEngine.create(inspection, draft.copy(currency = "JPY", priceMinor = 1500)))
        assertEquals("JPY", json.getString("currency"))
        assertEquals(0, json.getInt("currencyFractionDigits"))
        assertEquals(1500L, json.getLong("priceMinor"))
    }

    @Test fun zeroPriceAndThreeFractionDigitCurrencyAreSupported() {
        val json = JSONObject(ListingEngine.create(image().second, draft.copy(currency = "KWD", priceMinor = 0)))
        assertEquals(0L, json.getLong("priceMinor"))
        assertEquals(3, json.getInt("currencyFractionDigits"))
    }

    @Test fun personalBackupsCannotBeListed() {
        val file = File(temporary.root, "personal.dshare")
        val personal = ArchiveEngine.create(file, BundleRequest("My documents", device = device),
            listOf(BundleInput("private.txt") { "private information".byteInputStream() }))
        rejected { ListingEngine.create(personal, draft) }
    }

    @Test fun negativeAndExcessivePricesAreRejected() {
        val inspection = image().second
        listOf(-1L, 100_000_000_001L, Long.MAX_VALUE).forEach { price ->
            rejected { ListingEngine.create(inspection, draft.copy(priceMinor = price)) }
        }
    }

    @Test fun invalidOrNoncommercialCurrenciesAreRejected() {
        val inspection = image().second
        listOf("usd", "US", "USDD", "ZZZ", "XXX").forEach { currency ->
            rejected { ListingEngine.create(inspection, draft.copy(currency = currency)) }
        }
    }

    @Test fun missingLicenseCreatorOrTitleIsRejected() {
        val inspection = image().second
        listOf(draft.copy(title = " "), draft.copy(creator = ""), draft.copy(license = " "),
            draft.copy(description = "x".repeat(4001))).forEach { invalid ->
            rejected { ListingEngine.create(inspection, invalid) }
        }
    }

    private fun image(): Pair<File, BundleInspection> {
        val file = File(temporary.root, "image-${java.util.UUID.randomUUID()}.dshare")
        return file to ArchiveEngine.create(file, BundleRequest("Device image", kind = BundleKind.OEM_IMAGE, device = device, oem = oem),
            listOf(BundleInput("ota-payload.bin") { ByteArray(4097) { (it and 255).toByte() }.inputStream() }))
    }

    private fun rejected(block: () -> Unit) {
        try { block() } catch (_: Exception) { return }
        throw AssertionError("Invalid listing was accepted")
    }
}
