package com.dualscan.share.core

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipFile
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class ProtectedArchiveTest {
    @get:Rule val temporary = TemporaryFolder()
    private val password get() = "a long unique test passphrase 東京".toCharArray()

    @Test fun multirecordRoundTripPreservesAllBytesAndRemovesPrivatePlaintext() {
        val bytes = ByteArray(3 * 1024 * 1024 + 71) { ((it * 131 + (it shr 12)) and 255).toByte() }
        val encrypted = encrypt(bytes)
        val filesBefore = children()
        var unlockedPath: File? = null
        val result = ProtectedArchive.withPlaintext(encrypted, password) { plaintext ->
            unlockedPath = plaintext
            assertNotEquals(encrypted, plaintext)
            assertEquals(temporary.root.canonicalFile, plaintext.parentFile!!.canonicalFile)
            assertArrayEquals(bytes, plaintext.readBytes())
            "authenticated"
        }
        assertEquals("authenticated", result)
        assertFalse(unlockedPath!!.exists())
        assertEquals(filesBefore, children())
        assertTrue(ProtectedArchive.isProtected(encrypted))
    }

    @Test fun zeroLengthPlaintextStillRequiresValidAuthenticatedFooter() {
        val encrypted = encrypt(byteArrayOf())
        assertEquals(76L, encrypted.length())
        ProtectedArchive.withPlaintext(encrypted, password) { assertEquals(0L, it.length()) }
        assertRejectedBeforeCallback(encrypted.readBytes().copyOf(75))
    }

    @Test fun zipCallbackCanCloseItsStreamAndCloseIsIdempotent() {
        val encrypted = freshFile()
        val data = "Private backup payload with unicode 日本語".toByteArray()
        ProtectedArchive.encrypt(encrypted, password) { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(ZipEntry("payload/test"))
                zip.write(data)
                zip.closeEntry()
            }
            output.close()
            output.close()
        }
        ProtectedArchive.withPlaintext(encrypted, password) { plaintext ->
            ZipInputStream(plaintext.inputStream()).use { zip ->
                assertEquals("payload/test", zip.nextEntry.name)
                assertArrayEquals(data, zip.readBytes())
                assertNull(zip.nextEntry)
            }
        }
    }

    @Test fun differentArchivesUseDifferentSaltNonceAndCiphertext() {
        val a = encrypt("same private data".toByteArray()).readBytes()
        val b = encrypt("same private data".toByteArray()).readBytes()
        assertArrayEquals("DSHP0001".toByteArray(), a.copyOfRange(0, 8))
        assertFalse(a.copyOfRange(8, 24).contentEquals(b.copyOfRange(8, 24)))
        assertFalse(a.copyOfRange(24, 36).contentEquals(b.copyOfRange(24, 36)))
        assertEquals(600_000, ByteBuffer.wrap(a, 36, 4).int)
        assertFalse(a.contentEquals(b))
    }

    @Test fun wrongPasswordNeverExposesPlaintextAndUsesGenericFailure() {
        val encrypted = encrypt(ByteArray(1024 * 1024 + 1) { it.toByte() })
        val before = children()
        var callbacks = 0
        val failure = rejected { ProtectedArchive.withPlaintext(encrypted, "wrong-password".toCharArray()) { callbacks++ } }
        assertEquals(0, callbacks)
        assertTrue(failure is IOException)
        assertTrue(failure.message!!.contains("password is incorrect"))
        assertEquals(before, children())
    }

    @Test fun tamperedHeaderCiphertextAndTagNeverExposePartialArchives() {
        val bytes = encrypt(ByteArray(1024 * 1024 + 19) { it.toByte() }).readBytes()
        // Salt, base nonce, first ciphertext, last data tag, and footer tag are protected.
        listOf(8, 24, 44, 40 + 4 + 1024 * 1024 + 15, bytes.lastIndex).forEach { offset ->
            assertRejectedBeforeCallback(bytes.clone().also { it[offset] = (it[offset].toInt() xor 1).toByte() })
        }
    }

    @Test fun missingFooterTruncatedRecordAndAppendedBytesAreRejected() {
        val bytes = encrypt(ByteArray(1024 * 1024 + 17) { (it * 3).toByte() }).readBytes()
        listOf(bytes.copyOf(4), bytes.copyOf(39), bytes.copyOf(43), bytes.copyOf(77),
            bytes.copyOf(bytes.size - 1), bytes.copyOf(bytes.size - 36), bytes + byteArrayOf(0)).forEach(::assertRejectedBeforeCallback)
    }

    @Test fun reorderedDuplicatedOrRemovedRecordsAreRejected() {
        val bytes = encrypt(ByteArray(2 * 1024 * 1024 + 1) { (it * 7).toByte() }).readBytes()
        val records = splitRecords(bytes)
        val header = bytes.copyOfRange(0, 40)
        assertEquals(4, records.size) // Three data records and footer.
        assertRejectedBeforeCallback(header + records[1] + records[0] + records[2] + records[3])
        assertRejectedBeforeCallback(header + records[0] + records[0] + records[2] + records[3])
        assertRejectedBeforeCallback(header + records[0] + records[2] + records[3])
    }

    @Test fun authenticatedNoncanonicalShortRecordsAreRejectedBeforeCallback() {
        // Independently generated by Node/OpenSSL: two correctly authenticated
        // one-byte records [1], [2], then valid totals [2 bytes, 2 records].
        // The second data record is forbidden after a short first data record.
        val hex = "4453485030303031000102030405060708090a0b0c0d0e0f202122232425262728292a2b000927c0" +
            "0000000190e2b0b1b7a8de8ed6fb7c8cccc4294d0a0000000139c7d021f6ad4993a6f71e0a87fb294f0f" +
            "00000000196823ea199a8847f2f42545363623c00bc54df880ea7bdea7ba0fb384ef7391"
        val bytes = hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val secret = "public-test-passphrase-東京".toCharArray()
        val header = bytes.copyOfRange(0, 40)
        val specification = PBEKeySpec(secret, header.copyOfRange(8, 24), 600_000, 256)
        val key = try { SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded, "AES") }
            finally { specification.clearPassword() }
        // Verify all fixed vector tags independently of the archive parser so
        // this test cannot accidentally pass merely due to a corrupt fixture.
        val records = splitRecords(bytes)
        records.forEachIndexed { index, record ->
            val length = ByteBuffer.wrap(record, 0, 4).int
            val nonce = header.copyOfRange(24, 36)
            ByteBuffer.wrap(nonce, 4, 8).putLong(ByteBuffer.wrap(nonce, 4, 8).long xor index.toLong())
            val aad = ByteBuffer.allocate(53).put(header).putLong(index.toLong()).putInt(length).put(if (length == 0) 1.toByte() else 0.toByte()).array()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce)); cipher.updateAAD(aad)
            val plaintext = cipher.doFinal(record.copyOfRange(4, record.size))
            if (length > 0) assertArrayEquals(byteArrayOf((index + 1).toByte()), plaintext)
            else assertArrayEquals(ByteBuffer.allocate(16).putLong(2).putLong(2).array(), plaintext)
        }
        val malformed = freshFile().also { it.writeBytes(bytes) }
        val before = children()
        var callbacks = 0
        rejected { ProtectedArchive.withPlaintext(malformed, secret) { callbacks++ } }
        secret.fill('\u0000')
        assertEquals(0, callbacks)
        assertEquals(before, children())
    }

    @Test fun forgedLengthUnsupportedVersionAndKdfParametersAreRejected() {
        val bytes = encrypt(byteArrayOf(1, 2, 3)).readBytes()
        listOf(-1, 1024 * 1024 + 1, Int.MAX_VALUE).forEach { invalid ->
            assertRejectedBeforeCallback(bytes.clone().also { ByteBuffer.wrap(it, 40, 4).putInt(invalid) })
        }
        assertRejectedBeforeCallback(bytes.clone().also { it[7] = '2'.code.toByte() })
        listOf(1, 599_999, 600_001, Int.MAX_VALUE).forEach { iterations ->
            assertRejectedBeforeCallback(bytes.clone().also { ByteBuffer.wrap(it, 36, 4).putInt(iterations) })
        }
    }

    @Test fun protectedFamilyDetectionIncludesUnsupportedVersions() {
        listOf("DSHP0001", "DSHP9999", "DSHP").forEach { signature ->
            val file = freshFile().also { it.writeText(signature) }
            assertTrue(signature, ProtectedArchive.isProtected(file))
        }
        listOf("PK\u0003\u0004", "", "ordinary selected file").forEach { text ->
            assertFalse(ProtectedArchive.isProtected(freshFile().also { it.writeText(text) }))
        }
        assertFalse(ProtectedArchive.isProtected(freshFile()))
    }

    @Test fun weakMissingAndOversizedPasswordsAreRejectedWithoutCallback() {
        listOf(CharArray(0), "short".toCharArray(), CharArray(257) { 'x' }).forEach { weak ->
            val output = freshFile()
            rejected { ProtectedArchive.encrypt(output, weak) { it.write(42) } }
            assertFalse(output.exists())
        }
        val encrypted = encrypt(byteArrayOf(1))
        val before = children()
        listOf<CharArray?>(null, CharArray(0), "short".toCharArray(), CharArray(257) { 'x' }).forEach { weak ->
            var callbacks = 0
            rejected { ProtectedArchive.withPlaintext(encrypted, weak) { callbacks++ } }
            assertEquals(0, callbacks)
            assertEquals(before, children())
        }
    }

    @Test fun callbackFailureDeletesUnlockedTempAndPreservesOriginalException() {
        val encrypted = encrypt(byteArrayOf(1, 2, 3))
        val before = children()
        val intended = IOException("Destination disconnected")
        var temp: File? = null
        val actual = rejected {
            ProtectedArchive.withPlaintext(encrypted, password) {
                temp = it
                assertArrayEquals(byteArrayOf(1, 2, 3), it.readBytes())
                throw intended
            }
        }
        assertSame(intended, actual)
        assertFalse(temp!!.exists())
        assertEquals(before, children())
    }

    @Test fun encryptionFailureDeletesPartialCiphertextAndPreservesExistingFiles() {
        val output = freshFile()
        val intended = IOException("Source disconnected")
        val failure = rejected {
            ProtectedArchive.encrypt(output, password) {
                it.write(ByteArray(1024 * 1024 + 9))
                throw intended
            }
        }
        assertSame(intended, failure)
        assertFalse(output.exists())
        val existing = freshFile().also { it.writeText("keep me") }
        rejected { ProtectedArchive.encrypt(existing, password) { it.write(1) } }
        assertEquals("keep me", existing.readText())
    }

    @Test fun oversizedProtectedInputIsRejectedBeforeCreatingPlaintext() {
        val file = freshFile()
        RandomAccessFile(file, "rw").use { sparse ->
            sparse.write("DSHP0001".toByteArray())
            sparse.setLength(ProtectedArchive.MAX_ENCRYPTED_BYTES + 1)
        }
        val before = children()
        var called = false
        rejected { ProtectedArchive.withPlaintext(file, password) { called = true } }
        assertFalse(called)
        assertEquals(before, children())
    }

    @Test fun ordinaryArchivePassesThroughWithoutPasswordOrTemp() {
        val original = freshFile().also { it.writeBytes(byteArrayOf(0x50, 0x4b, 3, 4, 1, 2, 3)) }
        val before = children()
        val answer = ProtectedArchive.withPlaintext(original, null) {
            assertSame(original, it)
            assertArrayEquals(original.readBytes(), it.readBytes())
            42
        }
        assertEquals(42, answer)
        assertTrue(original.exists())
        assertEquals(before, children())
    }

    @Test fun independentNodeOpenSslFixtureDecryptsWithUnicodePassphrase() {
        val assets = File("src/androidTest/assets/crypto").takeIf { it.isDirectory }
            ?: File("app/src/androidTest/assets/crypto")
        val vector = org.json.JSONObject(File(assets, "host-encrypted-vector.json").readText())
        val encrypted = freshFile().also { File(assets, "host-encrypted.dshare").copyTo(it) }
        val secret = vector.getString("password").toCharArray()
        val originalPassword = secret.clone()
        assertEquals(vector.getString("encryptedSha256"), sha256(encrypted.readBytes()))
        ProtectedArchive.withPlaintext(encrypted, secret) { plaintext ->
            assertEquals(vector.getLong("plainArchiveBytes"), plaintext.length())
            assertEquals(vector.getString("plainArchiveSha256"), sha256(plaintext.readBytes()))
            ZipFile(plaintext).use { zip ->
                val payload = zip.getInputStream(zip.getEntry("payload/file-000001")).use { it.readBytes() }
                assertEquals(vector.getLong("payloadBytes"), payload.size.toLong())
                assertEquals(vector.getString("payloadSha256"), sha256(payload))
            }
        }
        assertArrayEquals(originalPassword, secret)
        secret.fill('\u0000')
    }

    @Test fun cancellationRemovesPartialEncryptedAndPlaintextFiles() {
        val encrypted = encrypt(ByteArray(1024 * 1024 + 1))
        val before = children()
        var callbacks = 0
        try {
            Thread.currentThread().interrupt()
            rejected { ProtectedArchive.withPlaintext(encrypted, password) { callbacks++ } }
        } finally { Thread.interrupted() }
        assertEquals(0, callbacks)
        assertEquals(before, children())
        val partial = freshFile()
        try {
            Thread.currentThread().interrupt()
            rejected { ProtectedArchive.encrypt(partial, password) { it.write(1) } }
        } finally { Thread.interrupted() }
        assertFalse(partial.exists())
    }

    private fun encrypt(bytes: ByteArray): File = freshFile().also { output ->
        ProtectedArchive.encrypt(output, password) { stream -> stream.write(bytes) }
    }

    private fun assertRejectedBeforeCallback(bytes: ByteArray) {
        val bad = freshFile().also { it.writeBytes(bytes) }
        val before = children()
        var callbacks = 0
        val failure = rejected { ProtectedArchive.withPlaintext(bad, password) { callbacks++ } }
        assertEquals(0, callbacks)
        assertTrue(failure is IOException)
        assertEquals(before, children())
    }

    private fun splitRecords(bytes: ByteArray): List<ByteArray> {
        var position = 40
        val records = mutableListOf<ByteArray>()
        while (position < bytes.size) {
            val length = ByteBuffer.wrap(bytes, position, 4).int
            val size = 4 + (if (length == 0) 16 else length) + 16
            records += bytes.copyOfRange(position, position + size)
            position += size
        }
        return records
    }

    private fun children() = temporary.root.listFiles()!!.map { it.name }.toSet()
    private fun sha256(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun freshFile() = File(temporary.root, "protected-${UUID.randomUUID()}.dshare")
    private fun rejected(block: () -> Unit): Throwable {
        try { block() } catch (failure: Exception) { return failure }
        throw AssertionError("Unauthenticated or invalid operation was accepted")
    }
}
