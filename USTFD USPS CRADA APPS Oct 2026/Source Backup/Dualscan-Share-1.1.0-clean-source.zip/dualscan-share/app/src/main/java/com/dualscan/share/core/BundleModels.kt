package com.dualscan.share.core

import java.io.InputStream

enum class BundleKind { PORTABLE_BACKUP, OEM_IMAGE }

data class DeviceIdentity(
    val manufacturer: String, val model: String, val device: String,
    val androidRelease: String, val sdkInt: Int, val fingerprint: String,
    val securityPatch: String
)

data class AppInventoryItem(val packageName: String, val versionName: String, val versionCode: Long)

/** Publisher declarations, not proof of firmware signatures or installation compatibility. */
data class OemImageMetadata(
    val manufacturer: String, val deviceCodename: String, val buildId: String,
    val payloadFormat: String = "OEM_SUPPLIED", val signingKeySha256: String = ""
)

data class BundleInput(val displayName: String, val mimeType: String?, val relativePath: String?, val open: () -> InputStream) {
    constructor(displayName: String, mimeType: String? = null, open: () -> InputStream) : this(displayName, mimeType, null, open)
}

data class BundleRequest(
    val title: String, val description: String = "", val kind: BundleKind = BundleKind.PORTABLE_BACKUP,
    val device: DeviceIdentity, val apps: List<AppInventoryItem> = emptyList(),
    val oem: OemImageMetadata? = null
)

data class BundleEntry(val id: String, val displayName: String, val mimeType: String?, val sizeBytes: Long, val sha256: String, val relativePath: String? = null)

data class BundleManifest(
    val schemaVersion: Int, val bundleId: String, val title: String, val description: String,
    val kind: BundleKind, val createdAtEpochMs: Long, val device: DeviceIdentity,
    val apps: List<AppInventoryItem>, val oem: OemImageMetadata?, val entries: List<BundleEntry>
)

data class BundleInspection(val manifest: BundleManifest, val archiveSha256: String, val archiveBytes: Long, val totalPayloadBytes: Long, val encrypted: Boolean = false, val passwordProtected: Boolean = false)
data class RestoreResult(val restoredEntries: Int, val restoredBytes: Long)
data class ListingDraft(val title: String, val creator: String, val description: String, val priceMinor: Long, val currency: String, val license: String)
