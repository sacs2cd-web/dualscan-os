package com.dualscan.share.core

import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.MediaInput
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.mp.core.UnlockedMediaArray
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.Locale
import java.text.Normalizer
import java.util.zip.ZipFile

/** Encrypted, player-compatible archives. Legacy ZIP/DSHP archives remain read-only inputs. */
object ArchiveEngine {
    const val MAX_ENTRIES = 10_000
    const val MAX_PAYLOAD_BYTES = 32L * 1024 * 1024 * 1024
    const val MAX_MANIFEST_BYTES = 8 * 1024 * 1024
    const val MAX_ARCHIVE_BYTES = MAX_PAYLOAD_BYTES + 16L * 1024 * 1024
    val MAX_ENCRYPTED_BYTES: Long get() = maxOf(ProtectedArchive.MAX_ENCRYPTED_BYTES, MediaArray.MAX_ENCRYPTED_BYTES)
    private val idPattern = Regex("file-[0-9]{6}")
    private val shaPattern = Regex("[0-9a-f]{64}")

    fun create(output: File, request: BundleRequest, inputs: List<BundleInput>, password: CharArray? = null): BundleInspection {
        validateRequest(request)
        require(inputs.isNotEmpty() || request.apps.isNotEmpty()) { "Choose files for the backup." }
        require(inputs.size <= MAX_ENTRIES) { "A package can contain at most $MAX_ENTRIES selected files." }
        require(request.kind != BundleKind.OEM_IMAGE || inputs.isNotEmpty()) { "Choose an OEM-supplied image payload." }
        inputs.forEach { validateName(it.displayName); validateMime(it.mimeType); validateRelativePath(it.relativePath, it.displayName) }
        validatePortablePaths(inputs.map { it.relativePath ?: it.displayName })
        require(!output.exists()) { "The output file already exists. Choose a new package name." }
        output.parentFile?.let { require(it.exists() || it.mkdirs()) { "Cannot create the output directory." } }
        try {
            // Backup declarations are authenticated inside the shared encrypted catalog.
            // Payload identities/sizes/hashes come from that catalog when it is opened.
            val metadata = encodeManifest(BundleManifest(1, UUID.randomUUID().toString(), request.title.trim(), request.description,
                request.kind, System.currentTimeMillis(), request.device, request.apps, request.oem, emptyList())).toString()
            require(metadata.toByteArray(Charsets.UTF_8).size <= MAX_MANIFEST_BYTES) { "The package manifest is too large." }
            MediaArray.createPortable(output, request.title, inputs.map { source ->
                MediaInput(source.displayName, source.mimeType ?: "application/octet-stream", source.relativePath, source.open)
            }, password, metadata).use { array ->
                return inspectPortable(output, array)
            }
        } catch (failure: Throwable) {
            output.delete()
            throw failure
        }
    }

    fun inspect(file: File, password: CharArray? = null): BundleInspection {
        if (MediaArray.isSupported(file)) return MediaArray.open(file, password).use { inspectPortable(file, it) }
        if (ProtectedArchive.isProtected(file) && password == null) throw PasswordRequiredException()
        if (!ProtectedArchive.isProtected(file)) return inspectPlain(file)
        return ProtectedArchive.withPlaintext(file, password) { plain ->
            inspectPlain(plain).copy(archiveSha256 = sha256(file), archiveBytes = file.length(), encrypted = true, passwordProtected = true)
        }
    }

    private fun inspectPortable(file: File, array: UnlockedMediaArray): BundleInspection {
        require(array.isPortable) { "This is a legacy Diamond media collection. Open it with Diamond Player." }
        val json = JSONObject(requireNotNull(array.catalog.backupMetadata) { "This collection has no Dualscan Share backup metadata. Open it with Diamond Player." })
        require(json.getJSONArray("entries").length() == 0) { "The backup declarations contain conflicting payload metadata." }
        require(json.getString("title") == array.catalog.title) { "The backup title does not match its catalog." }
        json.put("entries", JSONArray().apply { array.catalog.entries.forEachIndexed { index, entry ->
            put(JSONObject().put("id", shareEntryId(index)).put("displayName", entry.displayName)
                .put("mimeType", entry.mimeType).put("relativePath", entry.relativePath ?: JSONObject.NULL)
                .put("sizeBytes", entry.sizeBytes).put("sha256", entry.sha256))
        } })
        val manifest = decodeManifest(json)
        val total = manifest.entries.fold(0L) { sum, entry ->
            require(entry.sizeBytes <= MAX_PAYLOAD_BYTES - sum) { "The package exceeds the payload size limit." }
            sum + entry.sizeBytes
        }
        // No preview or restore destination is exposed before every encrypted
        // chunk and every declared payload SHA-256 has passed verification.
        array.verifyAll()
        return BundleInspection(manifest, sha256(file), file.length(), total, encrypted = true, passwordProtected = array.passwordProtected)
    }

    private fun shareEntryId(index: Int) = "file-${(index + 1).toString().padStart(6, '0')}"

    private fun inspectPlain(file: File): BundleInspection {
        require(file.isFile && file.length() in 1..MAX_ARCHIVE_BYTES) { "The archive is missing, empty, or too large." }
        ZipFile(file).use { zip ->
            val items = zip.entries().toList()
            require(items.size <= MAX_ENTRIES + 1) { "The archive contains too many entries." }
            require(items.none { it.isDirectory }) { "Directory entries are not part of the Dualscan archive format." }
            require(items.map { it.name }.toSet().size == items.size) { "The archive contains duplicate paths." }
            require(items.all { it.name == "manifest.json" || it.name.matches(Regex("payload/file-[0-9]{6}")) }) {
                "The archive contains unexpected or unsafe paths."
            }
            val manifestEntry = zip.getEntry("manifest.json") ?: error("This is not a Dualscan archive: manifest.json is missing.")
            require(manifestEntry.size in 1..MAX_MANIFEST_BYTES.toLong()) { "The manifest is too large or has an unknown size." }
            val raw = zip.getInputStream(manifestEntry).use { input ->
                val out = java.io.ByteArrayOutputStream()
                copyLimited(input, out, MAX_MANIFEST_BYTES.toLong(), null)
                out.toByteArray().toString(Charsets.UTF_8)
            }
            val manifest = decodeManifest(JSONObject(raw))
            require(manifest.entries.size + 1 == items.size) { "The manifest does not match the archive payloads." }
            var total = 0L
            manifest.entries.forEach { entry ->
                checkInterrupted()
                val member = zip.getEntry("payload/${entry.id}") ?: error("A declared payload is missing: ${entry.displayName}")
                require(member.size == entry.sizeBytes) { "Payload size mismatch: ${entry.displayName}" }
                require(entry.sizeBytes <= MAX_PAYLOAD_BYTES - total) { "The package exceeds the payload size limit." }
                val digest = MessageDigest.getInstance("SHA-256")
                val count = zip.getInputStream(member).use { copyLimited(it, null, entry.sizeBytes, digest) }
                require(count == entry.sizeBytes && digest.hex() == entry.sha256) { "Payload checksum mismatch: ${entry.displayName}" }
                total += count
            }
            return BundleInspection(manifest, sha256(file), file.length(), total)
        }
    }

    /** Caller creates fresh destination documents and removes them if a write fails. */
    fun restore(file: File, selectedEntryIds: Set<String>, destination: (BundleEntry) -> OutputStream): RestoreResult {
        return restore(file, selectedEntryIds, null, destination)
    }

    fun restore(file: File, selectedEntryIds: Set<String>, password: CharArray?, destination: (BundleEntry) -> OutputStream): RestoreResult {
        if (MediaArray.isSupported(file)) return MediaArray.open(file, password).use { array ->
            val checked = inspectPortable(file, array)
            validateRestoreSelection(checked, selectedEntryIds)
            var bytes = 0L
            var count = 0
            checked.manifest.entries.forEachIndexed { index, entry ->
                if (entry.id in selectedEntryIds) {
                    checkInterrupted()
                    val digest = MessageDigest.getInstance("SHA-256")
                    val size = array.openEntry(array.catalog.entries[index].id).use { input ->
                        destination(entry).use { output -> copyLimited(input, output, entry.sizeBytes, digest) }
                    }
                    require(size == entry.sizeBytes && digest.hex() == entry.sha256) { "The archive changed during restore." }
                    bytes += size; count++
                }
            }
            RestoreResult(count, bytes)
        }
        if (ProtectedArchive.isProtected(file) && password == null) throw PasswordRequiredException()
        return ProtectedArchive.withPlaintext(file, password) { plain -> restorePlain(plain, selectedEntryIds, destination) }
    }

    private fun restorePlain(file: File, selectedEntryIds: Set<String>, destination: (BundleEntry) -> OutputStream): RestoreResult {
        val checked = inspectPlain(file)
        validateRestoreSelection(checked, selectedEntryIds)
        var bytes = 0L
        var count = 0
        ZipFile(file).use { zip ->
            checked.manifest.entries.filter { it.id in selectedEntryIds }.forEach { entry ->
                checkInterrupted()
                val digest = MessageDigest.getInstance("SHA-256")
                val size = zip.getInputStream(zip.getEntry("payload/${entry.id}")).use { input ->
                    destination(entry).use { output -> copyLimited(input, output, entry.sizeBytes, digest) }
                }
                require(size == entry.sizeBytes && digest.hex() == entry.sha256) { "The archive changed during restore." }
                bytes += size; count++
            }
        }
        return RestoreResult(count, bytes)
    }

    private fun validateRestoreSelection(checked: BundleInspection, selectedEntryIds: Set<String>) {
        require(checked.manifest.kind == BundleKind.PORTABLE_BACKUP) { "OEM images require your device's verified OEM installation service; they are not portable data restores." }
        require(selectedEntryIds.isNotEmpty()) { "Select at least one file to restore." }
        require(selectedEntryIds.all { id -> checked.manifest.entries.any { it.id == id } }) { "A selected restore entry is not in this archive." }
    }

    fun sha256(file: File): String = file.inputStream().buffered().use { input ->
        val digest = MessageDigest.getInstance("SHA-256")
        copyLimited(input, null, MAX_ENCRYPTED_BYTES, digest)
        digest.hex()
    }

    private fun copyLimited(input: InputStream, output: OutputStream?, limit: Long, digest: MessageDigest?): Long {
        require(limit >= 0) { "The archive exceeds the payload size limit." }
        var total = 0L
        val buffer = ByteArray(128 * 1024)
        while (true) {
            checkInterrupted()
            val read = input.read(buffer)
            if (read == -1) break
            if (read == 0) throw IOException("The selected file provider stopped producing data.")
            require(read.toLong() <= limit - total) { "A file exceeds its declared size or the package size limit." }
            output?.write(buffer, 0, read); digest?.update(buffer, 0, read); total += read
        }
        return total
    }

    private fun MessageDigest.hex() = digest().joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Backup operation cancelled.") }
    private fun validateName(name: String) {
        require(name.isNotBlank() && name.length <= 240 && name !in setOf(".", "..") &&
            name.none { it == '/' || it == '\\' || it.code < 32 || it.code == 127 }) { "A selected file has an unsafe or unsupported display name." }
    }
    private fun validateMime(mime: String?) { require(mime == null || (mime.length <= 160 && mime.none { it.code < 32 })) { "Invalid file MIME type." } }
    private fun validateRelativePath(path: String?, displayName: String) {
        if (path == null) return
        require(path.isNotBlank() && path.length <= 1024 && !path.startsWith('/') && !path.contains('\\')) { "A file has an unsafe relative path." }
        val parts=path.split('/')
        require(parts.size <= 32 && parts.last() == displayName) { "A relative path is too deep or does not match its file name." }
        parts.forEach(::validateName)
    }
    private fun pathKey(path: String) = Normalizer.normalize(path, Normalizer.Form.NFC).lowercase(Locale.ROOT)
    private fun validatePortablePaths(paths: List<String>) {
        val keys=paths.map(::pathKey)
        val all=keys.toSet()
        require(all.size == paths.size) { "Two selected files have the same portable path. Select their parent folders or rename the files." }
        for (key in keys) {
            var separator=key.indexOf('/')
            while (separator >= 0) {
                require(key.substring(0,separator) !in all) { "A portable path is declared as both a file and a folder." }
                separator=key.indexOf('/',separator+1)
            }
        }
    }
    private fun validateRequest(r: BundleRequest) {
        require(r.title.isNotBlank() && r.title.length <= 160 && r.description.length <= 4000) { "Enter a title of 1–160 characters and a description of at most 4000 characters." }
        require(r.apps.size <= 2048 && r.apps.map { it.packageName }.toSet().size == r.apps.size) { "The visible-app inventory is too large or contains duplicates." }
        require(r.apps.all { it.packageName.matches(Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")) && it.versionName.length <= 256 && it.versionCode >= 0 }) { "Invalid visible-app inventory." }
        require(r.device.sdkInt in 1..100 && listOf(r.device.manufacturer,r.device.model,r.device.device,r.device.androidRelease,r.device.fingerprint,r.device.securityPatch).all { it.length <= 512 }) { "Invalid device build metadata." }
        if (r.kind == BundleKind.OEM_IMAGE) {
            val o = requireNotNull(r.oem) { "OEM image packages need declared target-device metadata." }
            require(listOf(o.manufacturer,o.deviceCodename,o.buildId,o.payloadFormat).all { it.isNotBlank() && it.length <= 256 && it.none { c -> c.code < 32 } }) { "Enter an OEM manufacturer, device codename, build ID and payload format." }
            require(o.signingKeySha256.isEmpty() || o.signingKeySha256.matches(Regex("[0-9A-Fa-f]{64}"))) { "The declared signing-key fingerprint must be SHA-256 hex." }
            require(r.apps.isEmpty()) { "A distributable OEM image package cannot include a personal app inventory." }
        } else require(r.oem == null) { "Portable data backups cannot claim OEM firmware metadata." }
    }

    internal fun encodeManifest(m: BundleManifest): JSONObject = JSONObject().apply {
        put("format", "dualscan-share"); put("schemaVersion", m.schemaVersion); put("bundleId", m.bundleId)
        put("title", m.title); put("description", m.description); put("kind", m.kind.name); put("createdAtEpochMs", m.createdAtEpochMs)
        put("encryption", "none"); put("coverage", if (m.kind == BundleKind.PORTABLE_BACKUP) "explicit-user-selected-content" else "publisher-supplied-device-specific-payload")
        put("device", JSONObject().apply { val d=m.device; put("manufacturer",d.manufacturer);put("model",d.model);put("device",d.device);put("androidRelease",d.androidRelease);put("sdkInt",d.sdkInt);put("fingerprint",d.fingerprint);put("securityPatch",d.securityPatch) })
        put("apps", JSONArray().apply { m.apps.forEach { a -> put(JSONObject().put("packageName",a.packageName).put("versionName",a.versionName).put("versionCode",a.versionCode)) } })
        put("oem", m.oem?.let { o -> JSONObject().put("manufacturer",o.manufacturer).put("deviceCodename",o.deviceCodename).put("buildId",o.buildId).put("payloadFormat",o.payloadFormat).put("signingKeySha256",o.signingKeySha256) } ?: JSONObject.NULL)
        put("entries", JSONArray().apply { m.entries.forEach { e -> put(JSONObject().put("id",e.id).put("displayName",e.displayName).put("mimeType",e.mimeType ?: JSONObject.NULL).put("sizeBytes",e.sizeBytes).put("sha256",e.sha256).put("relativePath",e.relativePath ?: JSONObject.NULL)) } })
    }

    private fun decodeManifest(j: JSONObject): BundleManifest {
        require(j.string("format") == "dualscan-share" && j.long("schemaVersion") == 1L) { "Unsupported Dualscan archive format or version." }
        require(j.string("encryption") == "none") { "Unsupported legacy backup declaration." }
        val kind = BundleKind.valueOf(j.string("kind"))
        require(j.string("coverage") == if (kind == BundleKind.PORTABLE_BACKUP) "explicit-user-selected-content" else "publisher-supplied-device-specific-payload") { "The archive has inconsistent coverage metadata." }
        val dev=j.getJSONObject("device")
        val sdk=dev.long("sdkInt"); require(sdk in 1..100) { "Invalid Android API level in the manifest." }
        val device=DeviceIdentity(dev.string("manufacturer"),dev.string("model"),dev.string("device"),dev.string("androidRelease"),sdk.toInt(),dev.string("fingerprint"),dev.string("securityPatch"))
        val arr=j.getJSONArray("apps"); require(arr.length() <= 2048) { "The app inventory is too large." }
        val apps=(0 until arr.length()).map { arr.getJSONObject(it).let { a -> AppInventoryItem(a.string("packageName"),a.string("versionName"),a.long("versionCode")) } }
        val o=if (j.isNull("oem")) null else j.getJSONObject("oem").let { o -> OemImageMetadata(o.string("manufacturer"),o.string("deviceCodename"),o.string("buildId"),o.string("payloadFormat"),o.string("signingKeySha256")) }
        val entries=j.getJSONArray("entries"); require(entries.length() <= MAX_ENTRIES) { "The archive contains too many declared files." }
        val list=(0 until entries.length()).map { entries.getJSONObject(it).let { e ->
            BundleEntry(e.string("id"),e.string("displayName"),if(e.isNull("mimeType"))null else e.string("mimeType"),e.long("sizeBytes"),e.string("sha256"),if(!e.has("relativePath") || e.isNull("relativePath"))null else e.string("relativePath")).also { f ->
                require(f.id.matches(idPattern) && f.sha256.matches(shaPattern) && f.sizeBytes in 0..MAX_PAYLOAD_BYTES) { "Invalid payload identity, size or hash." }
                validateName(f.displayName);validateMime(f.mimeType);validateRelativePath(f.relativePath,f.displayName)
            }
        } }
        require(list.map { it.id }.toSet().size == list.size) { "The manifest declares duplicate file IDs." }
        validatePortablePaths(list.map { it.relativePath ?: it.displayName })
        require(list.isNotEmpty() || apps.isNotEmpty()) { "The archive contains no backup content." }
        val id=j.string("bundleId"); require(UUID.fromString(id).toString() == id) { "Invalid bundle identity." }
        val created=j.long("createdAtEpochMs");require(created >= 0) { "Invalid creation timestamp." }
        val request=BundleRequest(j.string("title"),j.string("description"),kind,device,apps,o); validateRequest(request)
        require(kind != BundleKind.OEM_IMAGE || list.isNotEmpty()) { "An OEM image payload is missing." }
        return BundleManifest(1,id,request.title,request.description,kind,created,device,apps,o,list)
    }

    private fun JSONObject.string(key: String): String = (get(key) as? String) ?: throw IOException("Invalid manifest string: $key")
    private fun JSONObject.long(key: String): Long = when(val value=get(key)) { is Int -> value.toLong();is Long -> value;else -> throw IOException("Invalid manifest integer: $key") }
}
