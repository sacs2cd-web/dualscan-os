package com.dualscan.share

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.dualscan.share.core.*
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

/** Restores only explicit media entries, publishing them after full read-back verification. */
object MediaStoreRestorer {
    fun restore(context: Context, archive: File, selected: Set<String>, password: CharArray?): RestoreResult {
        require(Build.VERSION.SDK_INT >= 29) { "On Android 8–9, choose a local Music folder using the folder picker." }
        val resolver = context.contentResolver
        val info = ArchiveEngine.inspect(archive, password)
        require(info.manifest.kind == BundleKind.PORTABLE_BACKUP) { "An OEM firmware package cannot be restored as personal media." }
        val entries = info.manifest.entries.filter { it.id in selected }
        require(entries.isNotEmpty() && entries.size == selected.size) { "Select valid media entries before restoring." }
        entries.forEach { MediaPolicy.group(it.displayName, it.mimeType) }
        val created = linkedMapOf<Uri, BundleEntry>()
        try {
            val result = ArchiveEngine.restore(archive, selected, password) { entry ->
                checkInterrupted()
                val group = MediaPolicy.group(entry.displayName, entry.mimeType)
                val collection = when (group) {
                    MediaGroup.AUDIO -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    MediaGroup.IMAGE -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    MediaGroup.VIDEO -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "DS-${UUID.randomUUID().toString().take(8)}-${MediaPolicy.safeName(entry.displayName)}")
                    put(MediaStore.MediaColumns.MIME_TYPE, entry.mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${group.folder}/DualscanShare/")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(collection, values) ?: throw IOException("Android could not create a pending media file.")
                created[uri] = entry
                writeJournal(context, created.keys)
                resolver.openOutputStream(uri, "w") ?: throw IOException("Android could not open the pending media file.")
            }
            for ((uri, entry) in created) {
                checkInterrupted()
                val digest = MessageDigest.getInstance("SHA-256"); var length = 0L
                resolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) { checkInterrupted(); val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n); length += n }
                } ?: throw IOException("The restored media could not be read back for verification.")
                val hash = digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
                require(length == entry.sizeBytes && hash == entry.sha256) { "Restored media failed SHA-256 verification; the new output will be removed." }
            }
            for (uri in created.keys) {
                checkInterrupted()
                val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                if (resolver.update(uri, values, null, null) != 1) throw IOException("Android could not publish a verified media file.")
            }
            journal(context).delete()
            return result
        } catch (failure: Exception) {
            val remaining = created.keys.filter { uri -> try { resolver.delete(uri, null, null); false } catch (_: Exception) { true } }
            if (remaining.isEmpty()) journal(context).delete() else writeJournal(context, remaining)
            throw IOException("Media restore stopped. " + if (remaining.isEmpty()) "New outputs were removed; existing media was unchanged." else "${remaining.size} incomplete outputs could not be removed automatically.", failure)
        }
    }
    fun cleanupAbandoned(context: Context) {
        val file = journal(context)
        if (!file.isFile) return
        val remaining = file.readLines().filter { it.isNotBlank() }.map(Uri::parse).filter { uri ->
            if (uri.authority != MediaStore.AUTHORITY) false
            else try { context.contentResolver.delete(uri, null, null); false } catch (_: Exception) { true }
        }
        if (remaining.isEmpty()) file.delete() else writeJournal(context, remaining)
    }
    private fun journal(context: Context) = File(context.filesDir, "pending-media-restore.txt")
    private fun writeJournal(context: Context, uris: Collection<Uri>) { journal(context).writeText(uris.joinToString("\n")) }
    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("The transfer was interrupted.") }
}
