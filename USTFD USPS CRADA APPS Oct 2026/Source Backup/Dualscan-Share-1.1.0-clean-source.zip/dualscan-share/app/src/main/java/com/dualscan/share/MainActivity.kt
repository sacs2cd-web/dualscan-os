package com.dualscan.share

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dualscan.share.core.BundleKind
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFBDA4FF), onPrimary = Color(0xFF241345), secondary = Color(0xFF5CDBED),
                background = Color(0xFF10101E), surface = Color(0xFF191827), surfaceVariant = Color(0xFF29263B),
                onSurface = Color(0xFFF5F0FF), onSurfaceVariant = Color(0xFFCAC4DA)
            )) { ShareApp(viewModel()) }
        }
    }
}
private class UsbOpenDocument : ActivityResultContracts.OpenDocument() {
    override fun createIntent(context: Context, input: Array<String>): Intent = super.createIntent(context, input).apply {
        UsbStorageAccess.initialRoot(context)?.let { putExtra(DocumentsContract.EXTRA_INITIAL_URI, it) }
    }
}
private class UsbOpenTree : ActivityResultContracts.OpenDocumentTree() {
    override fun createIntent(context: Context, input: Uri?): Intent = super.createIntent(context, input).apply {
        UsbStorageAccess.initialRoot(context)?.let { putExtra(DocumentsContract.EXTRA_INITIAL_URI, it) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShareApp(model: ShareViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pickingOem by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<File?>(null) }
    var importPassword by remember { mutableStateOf("") }
    val lifecycle = LocalLifecycleOwner.current
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) model.refreshUsb() }
        lifecycle.lifecycle.addObserver(observer)
        onDispose { lifecycle.lifecycle.removeObserver(observer) }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> model.selectDocuments(uris, pickingOem) }
    val open = rememberLauncherForActivityResult(UsbOpenDocument()) { uri -> importPassword = ""; uri?.let { model.importArchive(it) } }
    val save = rememberLauncherForActivityResult(UsbOpenTree()) { uri -> val file = pendingExport; if (uri != null && file != null) model.exportToUsbTree(uri, file); pendingExport = null }
    val restoreTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(model::restoreFolder) }
    val sourceTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(model::selectFolder) }
    val notify = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val labels = if (BuildConfig.OEM_EDITION) listOf("Back up", "Restore", "OEM images", "Device") else listOf("Back up", "Restore", "Device")
    val icons = if (BuildConfig.OEM_EDITION) listOf(Icons.Rounded.Backup, Icons.Rounded.Restore, Icons.Rounded.Layers, Icons.Rounded.Smartphone) else listOf(Icons.Rounded.Backup, Icons.Rounded.Restore, Icons.Rounded.Smartphone)
    val deviceTab = labels.lastIndex
    val export = { file: File -> pendingExport = file; save.launch(null) }
    Scaffold(
        topBar = { TopAppBar(title = { Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.dualscan_share_artwork), null, Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column { Text(if (BuildConfig.OEM_EDITION) "Dualscan Share" else "Dualscan Share Lite", fontWeight = FontWeight.Bold, fontSize = 21.sp); Text("USB only. Yours to carry.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)) },
        bottomBar = { NavigationBar(containerColor = Color(0xFF191827)) {
            labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 11.sp) }) }
        } }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
            Spacer(Modifier.height(2.dp))
            when {
                tab == 0 -> {
                    Hero("YOUR FILES, YOUR NEXT DEVICE", "Back up. Plug in.\nTake it with you.", "Documents, music, videos, pictures and other accessible shared files in one image. Save to USB-C and open your media in Diamond Player.", Icons.Rounded.FolderCopy)
                    UsbCard(model)
                    SectionTitle("Create a files and media backup image", "Local files only · no apps · no cloud")
                    Field(model.title, { model.title = it }, "Backup title", !model.busy)
                    Field(model.description, { model.description = it }, "Description (optional)", !model.busy, false)
                    OutlinedButton(onClick = { pickingOem = false; pick.launch(arrayOf("*/*")) }, enabled = !model.busy, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(7.dp)); Text("Choose local files")
                    }
                    OutlinedButton(onClick = { sourceTree.launch(null) }, enabled = !model.busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.CreateNewFolder, null); Spacer(Modifier.width(7.dp)); Text("Add a local folder and subfolders") }
                    Text("Choose accessible shared folders such as Documents, Music, Pictures, DCIM or Movies. Android 11+ blocks storage roots, the Download root and Android/data or Android/obb in the folder picker. Individual permitted Downloads files and allowed subfolders can still be selected. No private-app bypass is used.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SelectedFiles(model)
                    PasswordFields(model)
                    Button(onClick = { model.createBundle(false) }, enabled = !model.busy && model.usbReady && model.selectedFiles.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Lock, null, Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)); Text("Create encrypted image (.dshare)") }
                    if (!model.usbReady) Text("Connect a USB-C drive to enable creation and export. You can preview the app and select local files or folders now.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Notice("Add a password for extra privacy, or leave it empty for direct access in Diamond Player. Application packages, accounts, private app data and system partitions are not included.")
                    ArchiveCard(model, export, { tab = 1 }, false, folderTree = { restoreTree.launch(null) })
                }
                tab == 1 -> {
                    Hero("PLUG IN YOUR LIBRARY", "From your USB.\nBack to your phone.", "Unlock a .dshare image from your attached drive. Restore files with their relative folders, or send selected media directly to Music, Pictures or Movies.", Icons.Rounded.Restore)
                    UsbCard(model)
                    Button(onClick = { open.launch(arrayOf("*/*")) }, enabled = !model.busy && model.usbReady, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Usb, null); Spacer(Modifier.width(8.dp)); Text("Open image from USB-C") }
                    Notice("Only mounted removable storage from Android's local storage provider is accepted. Cloud, Downloads and internal-storage archive locations are rejected.")
                    ArchiveCard(model, export, {}, true, folderTree = { restoreTree.launch(null) })
                    if (model.inspection == null) CapabilityCard("Ready when your drive is", "No image open", "Insert the USB drive and open your image. You will be asked for a password only if one was added. The entire archive is validated before any file is restored.", false)
                }
                tab == 2 && BuildConfig.OEM_EDITION -> {
                    Hero("FOR YOUR OEM ECOSYSTEM", "Share the build.\nRespect the hardware.", "Package an already-built OEM update artifact for USB delivery with declared device compatibility. Installation requires your trusted OEM updater.", Icons.Rounded.Layers)
                    UsbCard(model)
                    Notice("This OEM edition packages supplied firmware as opaque data. It does not capture protected partitions, sign firmware or flash this device. Manufacturer metadata is a declaration, not verification.")
                    Field(model.title, { model.title = it }, "OEM image title", !model.busy)
                    Field(model.description, { model.description = it }, "Description", !model.busy, false)
                    OutlinedButton(onClick = { pickingOem = true; pick.launch(arrayOf("*/*")) }, enabled = !model.busy, modifier = Modifier.fillMaxWidth()) { Text("Choose local OEM payload files") }
                    SelectedFiles(model)
                    Field(model.oemManufacturer, { model.oemManufacturer = it }, "Manufacturer", !model.busy)
                    Field(model.oemCodename, { model.oemCodename = it }, "Exact device codename", !model.busy)
                    Field(model.oemBuildId, { model.oemBuildId = it }, "Build ID", !model.busy)
                    Field(model.oemFormat, { model.oemFormat = it }, "Payload format", !model.busy)
                    Field(model.oemSigningKey, { model.oemSigningKey = it }, "Declared signing certificate SHA-256 (optional)", !model.busy)
                    PasswordFields(model)
                    Button(onClick = { model.createBundle(true) }, enabled = !model.busy && model.usbReady && model.selectedFiles.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Create encrypted OEM package") }
                    ArchiveCard(model, export, { tab = 1 }, false, folderTree = { restoreTree.launch(null) })
                    CapabilityCard("Firmware installation", "OEM integration required", "Connect your AOSP OTA service or authorized Knox / Android Enterprise integration. Trusted signatures, exact device support and rollback rules must be enforced by the OEM service.", false)
                    Text("OEM release candidate: production signing and ODM hardware validation are still required.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                tab == deviceTab -> {
                    Hero("CAPABILITY FIRST", "One archive.\nClear boundaries.", "A portable files-and-media image works within Android's public APIs. Full OS images require device-specific OEM trust and integration.", Icons.Rounded.Smartphone)
                    UsbCard(model)
                    SectionTitle("${model.device.manufacturer} ${model.device.model}", "Android ${model.device.androidRelease} · API ${model.device.sdkInt}")
                    KeyValue("Device codename", model.device.device)
                    KeyValue("Security patch", model.device.securityPatch.ifBlank { "Not reported" })
                    CapabilityCard("Portable shared files and media", "Android 8.0+", "Select files or accessible local folder trees. Relative subfolders are preserved when restoring to a chosen local folder. Android 10+ also sends selected compatible media directly into Music, Pictures or Movies. App-private directories remain subject to Android restrictions.", true)
                    CapabilityCard("USB-C / external storage", if (model.usbReady) "Available" else "Insert drive", "Archive operations require mounted removable storage and an attached USB mass-storage device. OTG and filesystem support depend on the phone. Public Android APIs cannot reliably map a volume to a USB connector or distinguish an SD card while USB is attached; choose your USB drive explicitly.", model.usbReady)
                    CapabilityCard("Privacy", "No cloud route", "No Internet permission, cloud backup, app inventory or general share sheet. Source pickers accept known local providers; archive pickers accept local removable storage only.", true)
                    CapabilityCard("Device owner", if (model.isDeviceOwner) "Provisioned" else "Not provisioned", "Device-owner status does not grant raw partition access or unrestricted private app data. Brand detection is not a Knox or system privilege.", model.isDeviceOwner)
                    CapabilityCard("Full OS capture / flash", "Unavailable in public app mode", "Stock Android does not allow an ordinary app to image protected partitions or hardware-bound keys. An OEM-signed platform service is a separate integration.", false)
                    if (Build.VERSION.SDK_INT >= 33) OutlinedButton(onClick = { notify.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) { Text("Enable transfer notifications") }
                    Text("Independent Dualscan application · ${BuildConfig.VERSION_NAME} · ${if (BuildConfig.OEM_EDITION) "OEM" else "Lite"} development release candidate", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            StatusPanel(model)
            Spacer(Modifier.height(20.dp))
        }
    }
    if (model.passwordRequiredUri != null) {
        val dismiss = { model.dismissPasswordRequest(); importPassword = "" }
        AlertDialog(onDismissRequest = dismiss, title = { Text("Unlock USB image") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Enter the password that was added to this image.", fontSize = 13.sp)
            OutlinedTextField(importPassword, { importPassword = it.take(256) }, label = { Text("Archive password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
            Text("Passwords remain in this session only and are never saved or exported.", fontSize = 11.sp)
        } }, confirmButton = { TextButton(enabled = !model.busy && importPassword.isNotEmpty(), onClick = { val uri = model.passwordRequiredUri; val pass = importPassword.toCharArray(); dismiss(); if (uri != null) model.importArchive(uri, pass) }) { Text("Unlock and verify") } }, dismissButton = { TextButton(onClick = dismiss) { Text("Cancel") } })
    }
    model.error?.let { message -> AlertDialog(onDismissRequest = model::dismissError, title = { Text("Operation stopped") }, text = { Text(message) }, confirmButton = { TextButton(onClick = model::dismissError) { Text("OK") } }) }
}

@Composable
private fun PasswordFields(model: ShareViewModel) {
    SectionTitle("Optional password", "Leave empty to open directly in Diamond Player")
    OutlinedTextField(model.passwordText, { model.passwordText = it.take(256) }, label = { Text("Password (optional, 8–256 characters)") }, modifier = Modifier.fillMaxWidth(), enabled = !model.busy, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
    OutlinedTextField(model.passwordConfirmation, { model.passwordConfirmation = it.take(256) }, label = { Text("Confirm password") }, modifier = Modifier.fillMaxWidth(), enabled = !model.busy, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrect = false))
    Text("If you add a password, keep it safe. Forgotten passwords cannot be recovered.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
@Composable
private fun SelectedFiles(model: ShareViewModel) {
    if (model.selectedFiles.isEmpty()) return
    Card(shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("${model.selectedFiles.size} selected local file(s)", fontWeight = FontWeight.SemiBold)
        model.selectedFiles.take(12).forEach { doc -> Column { Text(doc.relativePath ?: doc.name, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(doc.sizeBytes?.let(::formatBytes) ?: "Size checked while copying", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        if (model.selectedFiles.size > 12) Text("And ${model.selectedFiles.size - 12} more", fontSize = 11.sp)
        TextButton(onClick = model::clearSelection, enabled = !model.busy) { Text("Clear selection") }
    } }
}
@Composable
private fun UsbCard(model: ShareViewModel) {
    Surface(color = Color(0xFF1D2A37), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Usb, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.secondary); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(model.usbLabel, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text("Local storage · no cloud", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        IconButton(onClick = model::refreshUsb, enabled = !model.busy) { Icon(Icons.Rounded.Refresh, "Refresh USB storage") }
    } }
}
@Composable
private fun ArchiveCard(model: ShareViewModel, export: (File) -> Unit, openRestore: () -> Unit, restorePage: Boolean, folderTree: () -> Unit) {
    val info = model.inspection ?: return; val file = model.currentFile ?: return; val manifest = info.manifest
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF232036)), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SmallLabel(if (info.encrypted) "UNLOCKED · CONTENTS VERIFIED" else "LEGACY UNENCRYPTED · CONTENTS VERIFIED")
        Text(manifest.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(if (manifest.kind == BundleKind.OEM_IMAGE) "OEM artifact package · compatibility declared only" else "Portable selected-files-and-media image", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        Text("${manifest.entries.size} files · ${formatBytes(info.totalPayloadBytes)} payload · ${formatBytes(info.archiveBytes)} image", fontSize = 12.sp)
        manifest.oem?.let { KeyValue("Intended hardware", "${it.manufacturer} / ${it.deviceCodename}"); KeyValue("Build", it.buildId); Text("Firmware signature not verified. This app cannot install the package.", fontSize = 11.sp) }
        Text(when { info.passwordProtected -> "Password added. Close the image when you finish."; info.encrypted && manifest.kind == BundleKind.PORTABLE_BACKUP -> "Ready to open in Diamond Player."; info.encrypted -> "Ready to save to USB-C."; else -> "This legacy image is unencrypted. New images are encrypted automatically." }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SelectionContainer { Column { SmallLabel("IMAGE SHA-256"); Text(info.archiveSha256, fontSize = 10.sp, lineHeight = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace) } }
        Button(onClick = { export(file) }, enabled = !model.busy && model.usbReady, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Usb, null); Spacer(Modifier.width(8.dp)); Text("Save to USB-C / removable drive") }
        Text("Choose the USB drive in Android's picker. Other providers are rejected. The destination is read back and SHA-256 checked when the provider permits it.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (manifest.kind == BundleKind.PORTABLE_BACKUP && restorePage) {
            HorizontalDivider()
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Restore selected files", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp); TextButton(onClick = { model.selectAllRestore(model.restoreSelection.size != manifest.entries.size) }, enabled = !model.busy) { Text(if (model.restoreSelection.size == manifest.entries.size) "Clear all" else "Select all") } }
            manifest.entries.take(50).forEach { entry -> Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(entry.id in model.restoreSelection, { model.toggleRestore(entry.id) }, enabled = !model.busy)
                Column(Modifier.weight(1f)) { Text(entry.relativePath ?: entry.displayName, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(formatBytes(entry.sizeBytes), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } }
            if (manifest.entries.size > 50) Text("First 50 shown. Select all includes all ${manifest.entries.size} files.", fontSize = 11.sp)
            val ready = !model.busy && model.usbReady && model.archiveFromUsb && model.restoreSelection.isNotEmpty()
            Button(onClick = folderTree, enabled = ready, modifier = Modifier.fillMaxWidth()) { Text("Restore selected files to a local folder", fontSize = 12.sp) }
            Text("Choose a local folder on this phone. A new Dualscan-Restore folder preserves relative subfolders; each file is read back and SHA-256 verified. Existing files are not overwritten.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (Build.VERSION.SDK_INT >= 29) {
                val mediaCompatible = manifest.entries.filter { it.id in model.restoreSelection }.all { try { MediaPolicy.group(it.displayName, it.mimeType); true } catch (_: Exception) { false } }
                TextButton(onClick = model::selectMediaRestore, enabled = !model.busy) { Text("Select only audio, video and pictures") }
                OutlinedButton(onClick = model::restoreMedia, enabled = ready && mediaCompatible, modifier = Modifier.fillMaxWidth()) { Text("Decrypt media to Music / Pictures / Movies", fontSize = 11.sp) }
                if (!mediaCompatible) Text("Direct media restore is disabled while non-media files are selected. Use the local-folder restore for documents and mixed files.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!model.archiveFromUsb) Text("Save this image to USB, then reopen it from the drive before restoring.", fontSize = 11.sp)
        } else if (manifest.kind == BundleKind.PORTABLE_BACKUP) TextButton(onClick = openRestore) { Text("Go to USB restore") }
        TextButton(onClick = model::closeArchive, enabled = !model.busy) { Text("Close image, remove working copy and clear password", fontSize = 11.sp) }
    } }
}
@Composable
private fun Hero(eyebrow: String, title: String, subtitle: String, icon: ImageVector) { Surface(shape = RoundedCornerShape(26.dp)) { Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFF33215F), Color(0xFF18324C)))).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(eyebrow, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBFE6FF), modifier = Modifier.weight(1f)); Icon(icon, null, Modifier.size(25.dp), tint = Color(0xFF65D9EE)) }
    Text(title, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
    Text(subtitle, fontSize = 14.sp, lineHeight = 21.sp, color = Color(0xFFDBD8F0))
} } }
@Composable private fun SectionTitle(title: String, subtitle: String) { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun Notice(text: String) { Surface(color = Color(0xFF202536), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { Icon(Icons.Rounded.Info, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.secondary); Text(text, fontSize = 12.sp, lineHeight = 18.sp) } } }
@Composable private fun Field(value: String, change: (String) -> Unit, label: String, enabled: Boolean, singleLine: Boolean = true) { OutlinedTextField(value, change, modifier = Modifier.fillMaxWidth(), label = { Text(label, fontSize = 13.sp) }, enabled = enabled, singleLine = singleLine, minLines = if (singleLine) 1 else 2) }
@Composable private fun SmallLabel(text: String) { Text(text, fontSize = 10.sp, letterSpacing = 0.7.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary) }
@Composable private fun KeyValue(label: String, value: String) { Column(verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp); Text(value, fontSize = 13.sp) } }
@Composable private fun CapabilityCard(title: String, state: String, detail: String, available: Boolean) { Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) { Icon(if (available) Icons.Rounded.CheckCircle else Icons.Rounded.Lock, null, Modifier.size(18.dp), tint = if (available) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
    Text(state, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text(detail, fontSize = 12.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
} } }
@Composable private fun StatusPanel(model: ShareViewModel) { Surface(color = Color(0xFF181F2D), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { if (model.busy) LinearProgressIndicator(Modifier.fillMaxWidth()); Text(model.status, fontSize = 12.sp, lineHeight = 18.sp); if (model.busy) Text("A foreground transfer runs while this operation is active. Keep attached storage connected.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); if (model.busy) TextButton(onClick = model::cancelCurrentTransfer) { Text("Cancel current operation") } } } }
