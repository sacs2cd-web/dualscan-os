package com.dualscan.share

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import java.io.IOException

/** Keeps an explicitly started local backup/export operation observable while it runs. */
class TransferService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var foreground = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        promote()
    }

    private fun promote() {
        if (foreground) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Backup and sharing transfers", NotificationManager.IMPORTANCE_LOW))
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_transfer_notification)
            .setContentTitle("Dualscan Share transfer")
            .setContentText("Copying or verifying your selected data")
            .setContentIntent(pending)
            .setOngoing(true)
            .setProgress(0, 0, true)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        foreground = true
        if (wakeLock?.isHeld != true) {
            wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DualscanShare:Transfer").apply { acquire(MAX_WAKE_MS) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // A fast operation can finish before Android delivers this callback. We
        // must still promote the pending start before honoring its stop request.
        promote()
        val id = intent?.getLongExtra(EXTRA_SESSION, -1L)
        sessions[id]?.let { session ->
            session.owner = this
            session.started.complete(Unit)
            if (session.finished) sessions.remove(id)
        }
        if (sessions.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foreground = false
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onTimeout(startId: Int, fgsType: Int) {
        sessions.values.toList().filter { it.owner === this && !it.finished }.forEach { it.timeout() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onDestroy() {
        if (instance === this) instance = null
        sessions.values.toList().filter { it.owner === this }.forEach { session ->
            sessions.remove(session.id)
            if (!session.finished) {
                session.started.completeExceptionally(IOException("The foreground transfer was stopped by Android."))
                session.timeout()
            }
        }
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "dualscan_transfers"
        private const val NOTIFICATION_ID = 101
        private const val MAX_WAKE_MS = 6L * 60 * 60 * 1000
        private const val EXTRA_SESSION = "transfer_session"
        // Calls and service lifecycle callbacks run on the app's main thread.
        private val sessions = linkedMapOf<Long, Session>()
        private var nextSession = 0L
        private var instance: TransferService? = null
        fun begin(context: Context, timeout: () -> Unit): Session {
            val session = Session(++nextSession, context.applicationContext, timeout)
            sessions[session.id] = session
            try {
                ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java).putExtra(EXTRA_SESSION, session.id))
            } catch (failure: Exception) {
                sessions.remove(session.id)
                throw IOException("Android could not start the foreground transfer. Open the app and try again.", failure)
            }
            return session
        }
        fun end(context: Context) {
            sessions.values.toList().forEach { finish(it) }
        }
        private fun finish(session: Session) {
            session.finished = true
            // Keep pending starts until onStartCommand acknowledges promotion.
            // Calling stopService before onCreate causes Android's fatal
            // ForegroundServiceDidNotStartInTimeException even for short work.
            if (session.started.isCompleted) sessions.remove(session.id)
            if (sessions.isEmpty() && instance?.foreground == true) {
                session.context.stopService(Intent(session.context, TransferService::class.java))
            }
        }
    }

    class Session internal constructor(internal val id: Long, internal val context: Context, internal val timeout: () -> Unit) {
        internal val started = CompletableDeferred<Unit>()
        internal var finished = false
        internal var owner: TransferService? = null
        suspend fun awaitStarted() = started.await()
        fun close() = finish(this)
    }
}
