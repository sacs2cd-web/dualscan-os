package com.dualscan.share

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.dualscan.share.core.ArchiveEngine
import java.io.IOException

object LocalFolderEnumerator {
    /** Only the explicit tree grant is traversed. No storage-root or private-app bypass. */
    fun enumerate(context: Context, tree: Uri): FolderSelection {
        LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        val name = context.contentResolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use {
            if (!it.moveToFirst() || it.getString(1) != DocumentsContract.Document.MIME_TYPE_DIR) throw IOException("Choose an accessible shared folder.")
            it.getString(0)
        } ?: throw IOException("The selected local folder is unavailable.")
        RelativeFilePaths.requireSegment(name)
        val pending = ArrayDeque<FolderNode>(); pending.add(FolderNode(rootId, listOf(name), 0))
        val visited = hashSetOf<String>(); val selected = mutableListOf<SelectedDocument>(); var skipped = 0
        val columns = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE)
        while (pending.isNotEmpty()) {
            checkInterrupted()
            val folder = pending.removeFirst()
            if (!visited.add(folder.id)) throw IOException("The provider reported a repeated folder or cycle; the backup selection was stopped.")
            if (visited.size > MAX_VISITED) throw IOException("The folder has too many directories for this build.")
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, folder.id)
            context.contentResolver.query(children, columns, null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    checkInterrupted()
                    val id = cursor.getString(0) ?: throw IOException("A document has no stable identifier.")
                    val childName = cursor.getString(1) ?: throw IOException("A document has no name.")
                    RelativeFilePaths.requireSegment(childName)
                    val mime = cursor.getString(2)
                    val relative = folder.path + childName
                    RelativeFilePaths.segments(relative.joinToString("/"))
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (folder.depth + 1 > MAX_DEPTH) throw IOException("Folder nesting exceeds this build's $MAX_DEPTH level limit.")
                        pending.add(FolderNode(id, relative, folder.depth + 1))
                        if (pending.size + visited.size > MAX_VISITED) throw IOException("The folder has too many directories for this build.")
                    } else if (GenericFilePolicy.isExcluded(childName, mime)) {
                        skipped++
                    } else {
                        if (selected.size >= ArchiveEngine.MAX_ENTRIES) throw IOException("Choose a smaller folder: at most ${ArchiveEngine.MAX_ENTRIES} files fit in one image.")
                        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        val size = if (cursor.isNull(3)) null else cursor.getLong(3)
                        selected.add(SelectedDocument(uri, childName, mime, size, relative.joinToString("/")))
                    }
                }
            } ?: throw IOException("The provider could not enumerate a folder; no partial selection was accepted.")
        }
        return FolderSelection(name, selected, skipped)
    }
    private const val MAX_DEPTH = 32
    private const val MAX_VISITED = 20_000
    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Folder selection was interrupted.") }
    private data class FolderNode(val id: String, val path: List<String>, val depth: Int)
}
data class FolderSelection(val name: String, val files: List<SelectedDocument>, val skippedPackages: Int)

object GenericFilePolicy {
    private val excluded = setOf("apk", "apkm", "apks", "xapk", "aab", "dex", "odex", "vdex", "obb")
    fun isExcluded(name: String, mime: String?): Boolean = name.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT) in excluded || mime.equals("application/vnd.android.package-archive", ignoreCase = true)
    fun requireAllowed(name: String, mime: String?) { if (isExcluded(name, mime)) throw IOException("Application packages, app bundles and app runtime files are excluded from backups.") }
}
object RelativeFilePaths {
    fun requireSegment(segment: String) {
        if (segment.isBlank() || segment.length > 240 || segment == "." || segment == ".." || segment.any { it == '/' || it == '\\' || it.isISOControl() })
            throw IOException("A folder or file name is unsafe for a portable backup.")
    }
    fun segments(path: String): List<String> {
        if (path.length > 1024 || path.startsWith('/') || path.startsWith('\\')) throw IOException("A relative file path is unsafe or too long.")
        return path.split('/').also { parts -> if (parts.size > 32) throw IOException("Folder nesting is too deep."); parts.forEach(::requireSegment) }
    }
}
