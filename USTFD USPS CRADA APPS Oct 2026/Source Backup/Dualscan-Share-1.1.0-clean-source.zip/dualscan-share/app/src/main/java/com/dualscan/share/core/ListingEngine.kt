package com.dualscan.share.core

import org.json.JSONObject
import java.util.Currency

/** Offline metadata draft only. This neither publishes a product nor accepts payment. */
object ListingEngine {
    fun create(inspection: BundleInspection, draft: ListingDraft): String {
        require(inspection.manifest.kind == BundleKind.OEM_IMAGE) { "Personal backups are not OEM OS images and cannot be listed for sale." }
        require(draft.title.isNotBlank() && draft.title.length <= 160 && draft.creator.isNotBlank() && draft.creator.length <= 160) { "Enter a listing title and creator." }
        require(draft.description.length <= 4000 && draft.license.isNotBlank() && draft.license.length <= 2000) { "Enter a license and a description of at most 4000 characters." }
        require(draft.priceMinor in 0..100_000_000_000L) { "Invalid price in minor currency units." }
        require(draft.currency.matches(Regex("[A-Z]{3}"))) { "Use a three-letter ISO currency code." }
        val currency=Currency.getInstance(draft.currency)
        require(currency.defaultFractionDigits in 0..3) { "This currency is not supported for listing drafts." }
        val target=requireNotNull(inspection.manifest.oem)
        return JSONObject().apply {
            put("schemaVersion",1);put("status","DRAFT_NOT_PUBLISHED");put("checkoutConfigured",false)
            put("title",draft.title);put("creator",draft.creator);put("description",draft.description);put("license",draft.license)
            put("priceMinor",draft.priceMinor);put("currency",draft.currency);put("currencyFractionDigits",currency.defaultFractionDigits)
            put("artifact",JSONObject().put("bundleId",inspection.manifest.bundleId).put("archiveSha256",inspection.archiveSha256).put("bytes",inspection.archiveBytes))
            put("declaredTarget",JSONObject().put("manufacturer",target.manufacturer).put("deviceCodename",target.deviceCodename).put("buildId",target.buildId))
            put("firmwareSignatureVerified",false);put("installationCompatibilityVerified",false)
        }.toString(2)
    }
}
