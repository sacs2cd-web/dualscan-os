package com.dualscan.share

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.dualscan.share.core.*
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID
import java.util.Locale
import java.text.Normalizer

/** Generic local-folder restore. The production caller separately requires the source USB. */
object FolderRestorer {
    fun restore(context: Context, archive: File, selected: Set<String>, password: CharArray?, tree: Uri): FolderRestoreResult {
        LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
        require(tree.authority == UsbAccessPolicy.AUTHORITY && DocumentsContract.getTreeDocumentId(tree).startsWith("primary:")) {
            "Choose an accessible local folder on this phone. Cloud and archive-drive destinations are not accepted here."
        }
        val info = ArchiveEngine.inspect(archive, password)
        require(info.manifest.kind == BundleKind.PORTABLE_BACKUP) { "OEM firmware cannot be restored as user files." }
        val entries = info.manifest.entries.filter { it.id in selected }
        require(entries.isNotEmpty() && entries.size == selected.size) { "Select valid files to restore." }
        entries.forEach { GenericFilePolicy.requireAllowed(it.displayName, it.mimeType); RelativeFilePaths.segments(it.relativePath ?: it.displayName) }
        val root = DocumentFile.fromTreeUri(context, tree) ?: throw IOException("The selected local folder is unavailable.")
        require(root.canWrite()) { "This local folder is not writable." }
        val folderName = "Dualscan-Restore-${UUID.randomUUID().toString().take(12)}"
        val output = root.createDirectory(folderName) ?: throw IOException("Android could not create a new restore folder.")
        val directories = mutableMapOf("" to output)
        val written = linkedMapOf<Uri, BundleEntry>()
        try {
            val result = ArchiveEngine.restore(archive, selected, password) { entry ->
                checkInterrupted()
                val parts = RelativeFilePaths.segments(entry.relativePath ?: entry.displayName)
                var current = output; var prefix = ""
                for (segment in parts.dropLast(1)) {
                    prefix = if (prefix.isEmpty()) segment else "$prefix/$segment"
                    val key = Normalizer.normalize(prefix, Normalizer.Form.NFC).lowercase(Locale.ROOT)
                    current = directories[key] ?: current.createDirectory(segment)?.also { directories[key] = it }
                        ?: throw IOException("The local provider could not create a nested folder.")
                }
                val document = current.createFile(entry.mimeType ?: "application/octet-stream", parts.last())
                    ?: throw IOException("The local provider could not create a restored file.")
                written[document.uri] = entry
                context.contentResolver.openOutputStream(document.uri, "w") ?: throw IOException("The local provider could not open a restored file.")
            }
            for ((uri, entry) in written) {
                val digest = MessageDigest.getInstance("SHA-256"); var count = 0L
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) { checkInterrupted(); val n = input.read(buffer); if (n < 0) break; count += n; digest.update(buffer, 0, n) }
                } ?: throw IOException("The local provider could not read a restored file for verification.")
                val hash = digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
                require(count == entry.sizeBytes && hash == entry.sha256) { "A restored file failed read-back verification." }
            }
            return FolderRestoreResult(result.restoredEntries, result.restoredBytes, folderName)
        } catch (failure: Exception) {
            val deleted = try { output.delete() } catch (_: Exception) { false }
            throw IOException("Folder restore stopped. " + if (deleted) "The new output folder was removed; existing files are unchanged." else "A partial $folderName folder may remain. Remove it before retrying.", failure)
        }
    }
    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("The restore was interrupted.") }
}
data class FolderRestoreResult(val restoredEntries: Int, val restoredBytes: Long, val folderName: String)
