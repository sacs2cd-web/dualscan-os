package com.dualscan.share

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dualscan.share.core.*
import com.dualscan.mp.core.PasswordRequiredException
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class ShareViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    val exports = File(app.filesDir, "exports").apply { mkdirs() }
    var selectedFiles by mutableStateOf<List<SelectedDocument>>(emptyList()); private set
    var currentFile by mutableStateOf<File?>(null); private set
    var inspection by mutableStateOf<BundleInspection?>(null); private set
    var restoreSelection by mutableStateOf<Set<String>>(emptySet()); private set
    var busy by mutableStateOf(false); private set
    var status by mutableStateOf("Choose local shared files or folders. Archive transfer uses USB storage only."); private set
    var error by mutableStateOf<String?>(null); private set
    var usbReady by mutableStateOf(false); private set
    var usbLabel by mutableStateOf("Connect a USB-C/OTG storage drive"); private set
    var title by mutableStateOf("My files backup image")
    var description by mutableStateOf("")
    var passwordText by mutableStateOf("")
    var passwordConfirmation by mutableStateOf("")
    var passwordRequiredUri by mutableStateOf<Uri?>(null); private set
    var oemManufacturer by mutableStateOf("Dualscan")
    var oemCodename by mutableStateOf("")
    var oemBuildId by mutableStateOf("")
    var oemFormat by mutableStateOf("OEM_SUPPLIED")
    var oemSigningKey by mutableStateOf("")
    private var currentPassword: CharArray? = null
    private var sourceUsbUri: Uri? = null
    val archiveFromUsb get() = sourceUsbUri != null
    private var operationJob: Job? = null
    private var operationWorker: AtomicReference<Thread?>? = null
    val device = DeviceIdentity(Build.MANUFACTURER, Build.MODEL, Build.DEVICE, Build.VERSION.RELEASE,
        Build.VERSION.SDK_INT, Build.FINGERPRINT, Build.VERSION.SECURITY_PATCH)
    val isDeviceOwner: Boolean get() = (app.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isDeviceOwnerApp(app.packageName)
    private val maintenance = viewModelScope.async(Dispatchers.IO) {
        MediaStoreRestorer.cleanupAbandoned(app)
        app.cacheDir.listFiles()?.filter { it.name.startsWith("contacts-") || it.name.startsWith(".dualscan-unlocked-") }?.forEach { it.delete() }
        exports.listFiles()?.filter { it.name.startsWith(".dualscan-unlocked-") || it.name.endsWith(".part") || it.extension == "dshare" }?.forEach { it.delete() }
    }
    init { refreshUsb() }

    fun refreshUsb() {
        val state = try { UsbStorageAccess.snapshot(app) } catch (_: Exception) { null }
        usbReady = state?.ready == true
        usbLabel = if (usbReady) "Removable storage mounted · USB storage attached" else "Connect and mount a USB-C/OTG storage drive"
    }

    fun selectDocuments(uris: List<Uri>, oem: Boolean = false) {
        if (busy || uris.isEmpty()) return
        runTask("Checking the selected local files.") {
            require(uris.distinct().size <= ArchiveEngine.MAX_ENTRIES) { "Select at most ${ArchiveEngine.MAX_ENTRIES} files per archive." }
            val selected = uris.distinct().map { uri ->
                LocalMediaSourcePolicy.requireLocal(uri.authority.orEmpty(), uri.path.orEmpty())
                try { app.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { /* Use the current foreground grant. */ }
                var name = uri.lastPathSegment ?: "Document"; var size: Long? = null
                app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) ?: name }
                        c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) }
                    }
                }
                val mime = app.contentResolver.getType(uri)
                GenericFilePolicy.requireAllowed(name, mime)
                SelectedDocument(uri, name, mime, size)
            }
            withContext(Dispatchers.Main) { selectedFiles = mergeSelection(selectedFiles, selected)
                status = "${selectedFiles.size} local file(s) selected. Apps and private app data are not included." }
        }
    }
    fun selectFolder(tree: Uri) {
        if (busy) return
        runTask("Reading the accessible local folder and its subfolders.") {
            LocalMediaSourcePolicy.requireLocal(tree.authority.orEmpty(), tree.path.orEmpty())
            try { app.contentResolver.takePersistableUriPermission(tree, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            val folder = LocalFolderEnumerator.enumerate(app, tree)
            withContext(Dispatchers.Main) {
                selectedFiles = mergeSelection(selectedFiles, folder.files)
                status = "Added ${folder.files.size} files from ${folder.name}, preserving relative folders. ${folder.skippedPackages} application package/runtime files excluded. ${selectedFiles.size} files selected in total."
            }
        }
    }
    private fun mergeSelection(existing: List<SelectedDocument>, added: List<SelectedDocument>): List<SelectedDocument> {
        val merged = (existing + added).associateBy { document ->
            val id = try { DocumentsContract.getDocumentId(document.uri) } catch (_: Exception) { document.uri.toString() }
            "${document.uri.authority}:$id"
        }.values.toList()
        require(merged.size <= ArchiveEngine.MAX_ENTRIES) { "One image supports at most ${ArchiveEngine.MAX_ENTRIES} files. Clear some sources or choose a smaller folder." }
        return merged
    }
    fun clearSelection() { if (!busy) selectedFiles = emptyList() }

    fun createBundle(oem: Boolean) {
        if (busy) return
        val sources = selectedFiles.toList(); val bundleTitle = title.trim(); val bundleDescription = description.trim()
        val pass = passwordText.takeIf { it.isNotEmpty() }?.toCharArray(); val match = passwordText == passwordConfirmation
        val metadata = if (oem) OemImageMetadata(oemManufacturer.trim(), oemCodename.trim(), oemBuildId.trim(), oemFormat.trim(), oemSigningKey.trim()) else null
        runTask("Encrypting and verifying the selected files. Keep the drive connected.") {
            try {
                UsbStorageAccess.requireAvailable(app)
                require(!oem || BuildConfig.OEM_EDITION) { "OEM images require the OEM edition." }
                require(sources.isNotEmpty()) { "Choose accessible local files or folders first." }
                require(bundleTitle.isNotBlank()) { "Give this backup image a title." }
                require(pass == null || pass.size in 8..256) { "Use a password with 8 to 256 characters, or leave both password fields empty." }
                require(match) { "The passwords do not match." }
                sources.forEach { LocalMediaSourcePolicy.requireLocal(it.uri.authority.orEmpty(), it.uri.path.orEmpty()); GenericFilePolicy.requireAllowed(it.name, it.mimeType) }
                val out = File(exports, "Dualscan-${if (oem) "OEM" else "Media"}-${stamp()}-${UUID.randomUUID().toString().take(8)}.dshare")
                val request = BundleRequest(bundleTitle, bundleDescription, if (oem) BundleKind.OEM_IMAGE else BundleKind.PORTABLE_BACKUP, device, emptyList(), metadata)
                val result = ArchiveEngine.create(out, request, sources.map { doc ->
                    BundleInput(doc.name, doc.mimeType, doc.relativePath) { app.contentResolver.openInputStream(doc.uri) ?: throw IOException("The local provider could not open ${doc.name}.") }
                }, pass)
                withContext(Dispatchers.Main) {
                    activate(out, result, pass, null); passwordText = ""; passwordConfirmation = ""
                    status = "Encrypted image verified. Use Save to USB-C to finish transferring ${formatBytes(result.archiveBytes)} to your drive."
                }
            } finally { pass?.fill('\u0000') }
        }
    }

    fun importArchive(uri: Uri, password: CharArray? = null) {
        if (busy) { password?.fill('\u0000'); return }
        runTask("Reading the USB archive and verifying its complete contents.") {
            val imported = File(exports, "USB-Import-${stamp()}-${UUID.randomUUID().toString().take(8)}.dshare")
            try {
                UsbStorageAccess.requireUsbDocument(app, uri)
                app.contentResolver.openInputStream(uri)?.use { input -> imported.outputStream().use { output ->
                    val buffer = ByteArray(128 * 1024); var total = 0L
                    while (true) { checkInterrupted(); val n = input.read(buffer); if (n < 0) break; total += n
                        if (total > ArchiveEngine.MAX_ENCRYPTED_BYTES) throw IOException("The archive exceeds this build's 32 GiB payload limit.")
                        output.write(buffer, 0, n)
                    }
                } } ?: throw IOException("The USB drive could not open this archive.")
                val result = try { ArchiveEngine.inspect(imported, password) }
                catch (failure: PasswordRequiredException) {
                    withContext(Dispatchers.Main) { passwordRequiredUri = uri; status = "This image needs its password." }
                    imported.delete()
                    return@runTask
                }
                if (!BuildConfig.OEM_EDITION) {
                    require(result.manifest.kind == BundleKind.PORTABLE_BACKUP) { "Use Dualscan Share OEM for firmware packages. Lite restores user files and media." }
                    result.manifest.entries.forEach { GenericFilePolicy.requireAllowed(it.displayName, it.mimeType) }
                    require(result.manifest.apps.isEmpty()) { "Lite does not import app inventories or application backups." }
                }
                withContext(Dispatchers.Main) { activate(imported, result, password, uri); passwordRequiredUri = null; refreshUsb(); status = if (result.encrypted) "USB image opened and fully verified. Select files to restore." else "Legacy unencrypted archive verified. New archives are always encrypted." }
            } catch (failure: Exception) { imported.delete(); throw failure }
            finally { password?.fill('\u0000') }
        }
    }

    fun toggleRestore(id: String) { if (!busy) restoreSelection = if (id in restoreSelection) restoreSelection - id else restoreSelection + id }
    fun selectAllRestore(selected: Boolean) { if (!busy) restoreSelection = if (selected) inspection?.manifest?.entries?.map { it.id }?.toSet().orEmpty() else emptySet() }
    fun selectMediaRestore() {
        if (!busy) restoreSelection = inspection?.manifest?.entries?.filter { try { MediaPolicy.group(it.displayName, it.mimeType); true } catch (_: Exception) { false } }?.map { it.id }?.toSet().orEmpty()
    }
    fun cancelCurrentTransfer() { status = "Stopping the current operation safely…"; operationJob?.cancel(); operationWorker?.get()?.interrupt() }
    fun restoreMedia() {
        if (busy) return
        val file = currentFile ?: return; val source = sourceUsbUri ?: return; val ids = restoreSelection.toSet()
        runTask("Decrypting and restoring media directly to Music, Pictures or Movies. Verifying every output before it becomes visible.") {
            UsbStorageAccess.requireUsbDocument(app, source)
            val result = MediaStoreRestorer.restore(app, file, ids, currentPassword)
            withContext(Dispatchers.Main) { status = "Restored ${result.restoredEntries} files (${formatBytes(result.restoredBytes)}). Audio is in Music/DualscanShare, pictures in Pictures/DualscanShare and videos in Movies/DualscanShare. Every output passed SHA-256 read-back verification." }
        }
    }
    fun restoreFolder(tree: Uri) {
        if (busy) return
        val file = currentFile ?: return; val source = sourceUsbUri ?: return; val ids = restoreSelection.toSet()
        runTask("Decrypting selected files into a new local restore folder, preserving relative paths and verifying each output.") {
            UsbStorageAccess.requireUsbDocument(app, source)
            val result = FolderRestorer.restore(app, file, ids, currentPassword, tree)
            withContext(Dispatchers.Main) { status = "Restored ${result.restoredEntries} files (${formatBytes(result.restoredBytes)}) into ${result.folderName}. Relative folders preserved; all outputs passed SHA-256 read-back checks. Existing files were not overwritten." }
        }
    }

    fun exportToUsbTree(tree: Uri, file: File) {
        if (busy) return
        runTask("Saving the encrypted image to USB storage. Keep the drive connected until read-back verification finishes.") {
            // Validate the selected provider and volume before creating or opening anything.
            UsbStorageAccess.requireUsbDocument(app, tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val uri = DocumentsContract.createDocument(app.contentResolver, parent, "application/octet-stream", file.name)
                ?: throw IOException("The USB folder could not create the image file.")
            writeUsbExport(uri, file)
        }
    }
    private suspend fun writeUsbExport(uri: Uri, file: File) {
            val expected = MessageDigest.getInstance("SHA-256"); var written = 0L
            try {
                app.contentResolver.openOutputStream(uri, "wt")?.use { output -> file.inputStream().use { input ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) { checkInterrupted(); val n = input.read(buffer); if (n < 0) break; output.write(buffer, 0, n); expected.update(buffer, 0, n); written += n }
                    output.flush()
                } } ?: throw IOException("The USB provider could not create the export.")
            } catch (failure: Exception) {
                val deleted = removePartialExport(uri)
                throw IOException("USB export stopped. The drive may be full or disconnected. " + if (deleted) "The partial output was removed." else "A partial output may remain; remove it before retrying.", failure)
            }
            val expectedHash = expected.digest()
            val readBack = try {
                val digest = MessageDigest.getInstance("SHA-256"); var read = 0L
                app.contentResolver.openInputStream(uri)?.use { input -> val buffer = ByteArray(128 * 1024)
                    while (true) { checkInterrupted(); val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n); read += n }
                } ?: throw IOException("USB read-back is unavailable.")
                read to digest.digest()
            } catch (_: Exception) { null }
            if (readBack == null) withContext(Dispatchers.Main) { status = "Saved ${formatBytes(written)} to the USB provider. Read-back verification was unavailable: keep the original and verify the copy before relying on it." }
            else {
                if (readBack.first != written || !MessageDigest.isEqual(readBack.second, expectedHash)) {
                    val deleted = removePartialExport(uri)
                    throw IOException("USB copy failed SHA-256 verification. " + if (deleted) "The invalid output was removed." else "Delete the invalid output before retrying.")
                }
                withContext(Dispatchers.Main) { status = "Saved ${formatBytes(written)} to USB and verified its exact SHA-256 by reading it back. Use Android's eject control before removing the drive." }
            }
    }
    private fun removePartialExport(uri: Uri) = try { DocumentsContract.deleteDocument(app.contentResolver, uri) } catch (_: Exception) { false }
    fun dismissError() { error = null }
    fun dismissPasswordRequest() { passwordRequiredUri = null }
    fun closeArchive() {
        if (busy) return
        currentPassword?.fill('\u0000'); currentPassword = null; passwordText = ""; passwordConfirmation = ""
        currentFile?.delete()
        currentFile = null; sourceUsbUri = null; inspection = null; restoreSelection = emptySet(); passwordRequiredUri = null
        status = "Image closed. Its app-private working copy was removed and its password cleared; USB source files are unchanged."
    }
    private fun activate(file: File, info: BundleInspection, password: CharArray?, source: Uri?) {
        currentPassword?.fill('\u0000'); currentPassword = if (info.passwordProtected) password?.copyOf() else null
        currentFile?.takeIf { it.absolutePath != file.absolutePath }?.delete()
        currentFile = file; inspection = info; sourceUsbUri = source; restoreSelection = info.manifest.entries.map { it.id }.toSet()
    }
    override fun onCleared() { operationJob?.cancel(); operationWorker?.get()?.interrupt(); currentPassword?.fill('\u0000'); passwordText = ""; passwordConfirmation = ""; super.onCleared() }
    private fun runTask(message: String, task: suspend () -> Unit) {
        busy = true; status = message; error = null
        val worker = AtomicReference<Thread?>(); operationWorker = worker
        val dispatcher = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "DualscanTransfer").apply { worker.set(this) } }.asCoroutineDispatcher()
        val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
            var transfer: TransferService.Session? = null
            try {
                transfer = TransferService.begin(app) { error = "Android's transfer time limit was reached. Inspect any partial output before retrying."; operationJob?.cancel(); worker.get()?.interrupt() }
                transfer.awaitStarted()
                maintenance.await()
                withContext(dispatcher) { task() }
            }
            catch (failure: CancellationException) { status = "Transfer stopped before completion. Source files were unchanged."; throw failure }
            catch (failure: Exception) { error = failure.message ?: "The operation could not be completed."; status = "Operation stopped. Review the message and try again." }
            finally { transfer?.close(); dispatcher.close(); busy = false; operationWorker = null; operationJob = null; refreshUsb() }
        }
        operationJob = job
        job.start()
    }
}
data class SelectedDocument(val uri: Uri, val name: String, val mimeType: String?, val sizeBytes: Long?, val relativePath: String? = null)
fun formatBytes(bytes: Long): String = when { bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f GiB", bytes / (1024.0 * 1024 * 1024)); bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MiB", bytes / (1024.0 * 1024)); bytes >= 1024 -> String.format(Locale.US, "%.1f KiB", bytes / 1024.0); else -> "$bytes B" }
private fun stamp() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("The transfer was interrupted.") }
