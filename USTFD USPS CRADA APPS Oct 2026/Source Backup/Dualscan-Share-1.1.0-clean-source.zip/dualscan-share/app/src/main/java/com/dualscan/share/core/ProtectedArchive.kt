package com.dualscan.share.core

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-protected, bounded-memory envelope around a complete Dualscan ZIP.
 *
 * Version 1 header: DSHP0001 (8 bytes), random salt (16), random base nonce (12),
 * big-endian PBKDF2 iteration count (4). Records use big-endian clear length (4)
 * followed by AES-256-GCM ciphertext with a 128-bit tag. Data records contain
 * exactly 1 MiB except for an optional short final data record. A short data
 * record must be followed immediately by the footer. A mandatory length-zero
 * record encrypts two longs: total plaintext bytes and data record count.
 * No bytes may follow that footer.
 *
 * Each record authenticates the complete header, its zero-based counter,
 * declared clear length and a final-record flag. Its nonce XORs the counter
 * into the last eight bytes of the random base nonce. This makes replacement,
 * reordering, truncation and appended data fail closed, with bounded JCE memory.
 * It does not replace an OEM firmware signature or rollback policy.
 *
 * Callers must supply app-private files and erase their password arrays when
 * finished. The caller's original password array is never modified here.
 */
object ProtectedArchive {
    private val magic = "DSHP0001".toByteArray(Charsets.US_ASCII)
    private val family = "DSHP".toByteArray(Charsets.US_ASCII)
    private const val HEADER_BYTES = 40
    private const val TAG_BYTES = 16
    private const val ITERATIONS = 600_000
    private const val CHUNK_BYTES = 1024 * 1024
    private const val MAX_DATA_RECORDS = (ArchiveEngine.MAX_ARCHIVE_BYTES + CHUNK_BYTES - 1) / CHUNK_BYTES
    private const val FOOTER_PLAIN_BYTES = 16
    private const val UNLOCK_FAILURE = "Cannot unlock this protected archive. The password is incorrect, or the file is damaged or unsupported."
    const val MAX_ENCRYPTED_BYTES = ArchiveEngine.MAX_ARCHIVE_BYTES + 2L * 1024 * 1024

    /** Includes unsupported DSHP versions so they cannot be mistaken for ZIPs. */
    fun isProtected(file: File): Boolean {
        if (!file.isFile || file.length() < family.size) return false
        return file.inputStream().use { input ->
            val prefix = ByteArray(family.size)
            var offset = 0
            while (offset < prefix.size) {
                val count = input.read(prefix, offset, prefix.size - offset)
                if (count <= 0) return@use false
                offset += count
            }
            prefix.contentEquals(family)
        }
    }

    /** Creates a fresh encrypted file, removing incomplete output on failure. */
    fun encrypt(output: File, password: CharArray, writePlaintext: (OutputStream) -> Unit) {
        validatePassword(password)
        require(output.createNewFile()) { "The output file already exists. Choose a new package name." }
        try {
            privatePermissions(output)
            val header = newHeader()
            withKey(password, header) { key ->
                DataOutputStream(output.outputStream().buffered(128 * 1024)).use { destination ->
                    destination.write(header)
                    EncryptingStream(destination, key, header).use(writePlaintext)
                }
            }
        } catch (failure: Throwable) {
            if (!output.delete() && output.exists()) failure.addSuppressed(IOException("Could not remove an incomplete encrypted archive."))
            throw failure
        }
    }

    /**
     * Authenticates every record AND the final totals before exposing a private
     * temp plaintext file. Deletes the temp on every exit path. Plain ZIPs are
     * passed through directly. The input must be in private application storage;
     * no plaintext is written to shared/USB storage by this helper.
     */
    fun <T> withPlaintext(file: File, password: CharArray?, block: (File) -> T): T {
        if (!isProtected(file)) return block(file)
        requireNotNull(password) { "Enter the password to open this protected archive." }
        validatePassword(password)
        if (file.length() !in (HEADER_BYTES + 4 + FOOTER_PLAIN_BYTES + TAG_BYTES).toLong()..MAX_ENCRYPTED_BYTES) {
            throw IOException(UNLOCK_FAILURE)
        }
        val parent = file.absoluteFile.parentFile ?: throw IOException("Private storage is unavailable.")
        val plaintext = File.createTempFile(".dualscan-unlocked-", ".tmp", parent)
        try {
            privatePermissions(plaintext)
            try {
                decrypt(file, password, plaintext)
            } catch (failure: GeneralSecurityException) {
                throw IOException(UNLOCK_FAILURE, failure)
            } catch (failure: IOException) {
                if (Thread.currentThread().isInterrupted) throw failure
                throw IOException(UNLOCK_FAILURE, failure)
            } catch (failure: IllegalArgumentException) {
                throw IOException(UNLOCK_FAILURE, failure)
            }
            // No callback can consume a partial archive with a missing footer.
            return block(plaintext)
        } finally {
            if (!plaintext.delete() && plaintext.exists()) {
                throw IOException("Could not remove the temporary unlocked archive. Free private storage and retry.")
            }
        }
    }

    private fun decrypt(source: File, password: CharArray, plaintext: File) {
        DataInputStream(source.inputStream().buffered(128 * 1024)).use { input ->
            val header = ByteArray(HEADER_BYTES)
            input.readFully(header)
            require(header.copyOfRange(0, magic.size).contentEquals(magic)) { UNLOCK_FAILURE }
            // Untrusted headers cannot select expensive KDF parameters.
            require(ByteBuffer.wrap(header, 36, 4).int == ITERATIONS) { UNLOCK_FAILURE }
            withKey(password, header) { key ->
                plaintext.outputStream().buffered(128 * 1024).use { output ->
                    var counter = 0L
                    var total = 0L
                    var shortDataRecordSeen = false
                    var encryptedBytes = HEADER_BYTES.toLong()
                    while (true) {
                        checkInterrupted()
                        val length = input.readInt()
                        require(length in 0..CHUNK_BYTES) { UNLOCK_FAILURE }
                        if (length > 0) {
                            // Canonical framing bounds the number of crypto
                            // operations even for archives from a password holder.
                            require(!shortDataRecordSeen && counter < MAX_DATA_RECORDS &&
                                length.toLong() <= ArchiveEngine.MAX_ARCHIVE_BYTES - total) { UNLOCK_FAILURE }
                        }
                        val ciphertextLength = if (length == 0) FOOTER_PLAIN_BYTES + TAG_BYTES else length + TAG_BYTES
                        require(4L + ciphertextLength <= MAX_ENCRYPTED_BYTES - encryptedBytes) { UNLOCK_FAILURE }
                        encryptedBytes += 4L + ciphertextLength
                        val ciphertext = ByteArray(ciphertextLength)
                        input.readFully(ciphertext)
                        val clear = try {
                            recordCipher(Cipher.DECRYPT_MODE, key, header, counter, length, length == 0).doFinal(ciphertext)
                        } finally { ciphertext.fill(0) }
                        try {
                            if (length == 0) {
                                require(clear.size == FOOTER_PLAIN_BYTES) { UNLOCK_FAILURE }
                                val footer = ByteBuffer.wrap(clear)
                                require(footer.long == total && footer.long == counter && input.read() == -1) { UNLOCK_FAILURE }
                                break
                            }
                            require(clear.size == length && length.toLong() <= ArchiveEngine.MAX_ARCHIVE_BYTES - total) { UNLOCK_FAILURE }
                            output.write(clear)
                            total += length
                            counter++
                            shortDataRecordSeen = length < CHUNK_BYTES
                        } finally { clear.fill(0) }
                    }
                }
            }
        }
    }

    private fun newHeader(): ByteArray {
        val salt = ByteArray(16)
        val nonce = ByteArray(12)
        SecureRandom().apply { nextBytes(salt); nextBytes(nonce) }
        return ByteBuffer.allocate(HEADER_BYTES).put(magic).put(salt).put(nonce).putInt(ITERATIONS).array()
    }

    private fun <T> withKey(password: CharArray, header: ByteArray, block: (SecretKeySpec) -> T): T {
        val specification = PBEKeySpec(password, header.copyOfRange(8, 24), ITERATIONS, 256)
        val keyBytes = try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded
        } finally { specification.clearPassword() }
        return try { block(SecretKeySpec(keyBytes, "AES")) } finally { keyBytes.fill(0) }
    }

    private fun recordCipher(mode: Int, key: SecretKeySpec, header: ByteArray, counter: Long, length: Int, final: Boolean): Cipher {
        val nonce = header.copyOfRange(24, 36)
        for (index in 0..7) nonce[nonce.size - 1 - index] = (nonce[nonce.size - 1 - index].toInt() xor (counter ushr (index * 8)).toInt()).toByte()
        val aad = ByteBuffer.allocate(HEADER_BYTES + 8 + 4 + 1)
            .put(header).putLong(counter).putInt(length).put(if (final) 1.toByte() else 0.toByte()).array()
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(mode, key, GCMParameterSpec(128, nonce))
            updateAAD(aad)
        }
    }

    private fun validatePassword(password: CharArray) {
        require(password.size in 8..256) { "Use a password of 8–256 characters. A long, unique passphrase is recommended." }
    }

    private fun privatePermissions(file: File) {
        check(file.setReadable(false, false) && file.setWritable(false, false) &&
            file.setReadable(true, true) && file.setWritable(true, true)) { "Cannot secure the private archive file." }
    }

    private fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Backup operation cancelled.") }

    private class EncryptingStream(private val destination: DataOutputStream, private val key: SecretKeySpec, private val header: ByteArray) : OutputStream() {
        private var closed = false
        private val buffer = ByteArray(CHUNK_BYTES)
        private var used = 0
        private var total = 0L
        private var counter = 0L

        override fun write(value: Int) = write(byteArrayOf(value.toByte()), 0, 1)

        override fun write(source: ByteArray, offset: Int, length: Int) {
            if (closed) throw IOException("The archive stream is closed.")
            require(offset >= 0 && length >= 0 && offset <= source.size - length) { "Invalid buffer bounds." }
            checkInterrupted()
            if (length.toLong() > ArchiveEngine.MAX_ARCHIVE_BYTES - total) throw IOException("The archive is too large.")
            var position = offset
            var remaining = length
            while (remaining > 0) {
                checkInterrupted()
                val count = minOf(buffer.size - used, remaining)
                source.copyInto(buffer, used, position, position + count)
                used += count
                position += count
                remaining -= count
                total += count
                if (used == buffer.size) emitData()
            }
        }

        private fun emitData() {
            val ciphertext = recordCipher(Cipher.ENCRYPT_MODE, key, header, counter, used, false).doFinal(buffer, 0, used)
            destination.writeInt(used)
            destination.write(ciphertext)
            buffer.fill(0, 0, used)
            used = 0
            counter++
        }

        override fun flush() { if (!closed) destination.flush() }

        override fun close() {
            if (closed) return
            closed = true
            try {
                checkInterrupted()
                if (used > 0) emitData()
                val totals = ByteBuffer.allocate(FOOTER_PLAIN_BYTES).putLong(total).putLong(counter).array()
                try {
                    val footer = recordCipher(Cipher.ENCRYPT_MODE, key, header, counter, 0, true).doFinal(totals)
                    destination.writeInt(0)
                    destination.write(footer)
                    destination.flush()
                } finally { totals.fill(0) }
                // encrypt() owns and closes the underlying destination.
            } finally { buffer.fill(0) }
        }
    }
}
