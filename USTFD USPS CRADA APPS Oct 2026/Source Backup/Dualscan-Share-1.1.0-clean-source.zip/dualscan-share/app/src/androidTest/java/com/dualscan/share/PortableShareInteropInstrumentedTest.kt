package com.dualscan.share

import android.graphics.Bitmap
import android.os.Build
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.mp.core.MediaArray
import com.dualscan.mp.core.PasswordRequiredException
import com.dualscan.share.core.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** Produces real Share images for consumption by Diamond's actual playback adapters. */
@RunWith(AndroidJUnit4::class)
class PortableShareInteropInstrumentedTest {
    @Test fun shareProducesEncryptedGlobalAndPasswordImagesForDiamondPlayer() {
        val app = InstrumentationRegistry.getInstrumentation().targetContext
        val directory = File(app.filesDir, "exports").apply { mkdirs() }
        val title = "Share to Diamond interop"
        val passphrase = "Dualscan interop fixture 2026"
        val password = passphrase.toCharArray()
        val audioPath = "Music/Interop Album/01 Interop.wav"
        val coverPath = "Music/Interop Album/cover.png"
        val documentPath = "Documents/Interop.txt"
        val pcm = ByteArray(19_200 * 6) { index -> ((index * 17 + index / 6) and 255).toByte() }
        val wav = wav(pcm)
        val pixels = intArrayOf(0xffff00fe.toInt(), 0xff00ffff.toInt(), 0xff000000.toInt(), 0xffffffff.toInt())
        val cover = ByteArrayOutputStream().use { output ->
            val bitmap = Bitmap.createBitmap(pixels, 2, 2, Bitmap.Config.ARGB_8888)
            try { assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)); output.toByteArray() }
            finally { bitmap.recycle() }
        }
        val files = linkedMapOf(audioPath to wav, coverPath to cover, documentPath to "Public test document. No real music or personal files.\n".toByteArray())
        val inputs = files.map { (path, bytes) -> BundleInput(path.substringAfterLast('/'), when(path) {
            audioPath -> "audio/wav"; coverPath -> "image/png"; else -> "text/plain"
        }, path) { bytes.inputStream() } }
        val request = BundleRequest(title, "Public Share-to-Diamond Android interoperability fixture", device = DeviceIdentity(
            Build.MANUFACTURER, Build.MODEL, Build.DEVICE, Build.VERSION.RELEASE, Build.VERSION.SDK_INT, Build.FINGERPRINT, Build.VERSION.SECURITY_PATCH))
        val global = File(directory, "share-global.dshare").apply { delete() }
        val protected = File(directory, "share-password.dshare").apply { delete() }
        try {
            val info = ArchiveEngine.create(global, request, inputs)
            assertTrue(info.encrypted); assertFalse(info.passwordProtected)
            val protectedInfo = ArchiveEngine.create(protected, request, inputs, password)
            assertTrue(protectedInfo.encrypted); assertTrue(protectedInfo.passwordProtected)
            try { ArchiveEngine.inspect(protected); fail("Optional password was bypassed") } catch (_: PasswordRequiredException) { }
            for ((file, pass) in listOf(global to null, protected to password)) {
                MediaArray.open(file, pass).use { player ->
                    assertTrue(player.isPortable); player.verifyAll()
                    player.catalog.entries.forEach { entry ->
                        assertArrayEquals(files.getValue(requireNotNull(entry.relativePath)), player.openEntry(entry.id).use { it.readBytes() })
                    }
                }
                val restored = linkedMapOf<String, ByteArrayOutputStream>()
                ArchiveEngine.restore(file, info.manifest.entries.map { it.id }.toSet(), pass) { entry ->
                    ByteArrayOutputStream().also { restored[requireNotNull(entry.relativePath)] = it }
                }
                files.forEach { (path, bytes) -> assertArrayEquals(bytes, restored.getValue(path).toByteArray()) }
            }
            val json = JSONObject().put("title", title).put("password", passphrase).put("entries", JSONArray().apply {
                files.forEach { (path, bytes) -> put(JSONObject().put("relativePath", path).put("sha256", sha256(bytes)).put("sizeBytes", bytes.size)) }
            }).put("audio", JSONObject().put("relativePath", audioPath).put("pcmSha256", sha256(pcm)).put("pcmBytes", pcm.size)
                .put("bitDepth", 24).put("sampleRateHz", 192_000).put("channelCount", 2))
                .put("cover", JSONObject().put("relativePath", coverPath).put("width", 2).put("height", 2).put("pixels", JSONArray(pixels.toList())))
                .put("globalSha256", ArchiveEngine.sha256(global)).put("passwordSha256", ArchiveEngine.sha256(protected))
            File(directory, "share-fixture.json").writeText(json.toString(2))
            assertTrue(directory.listFiles().orEmpty().none { it.name.startsWith(".dualscan-unlocked-") })
            // Encrypted fixtures intentionally remain for Root's cross-app Android test.
        } finally { password.fill('\u0000') }
    }

    private fun wav(pcm: ByteArray): ByteArray = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN).apply {
        put("RIFF".toByteArray()); putInt(36 + pcm.size); put("WAVEfmt ".toByteArray()); putInt(16)
        putShort(1); putShort(2); putInt(192_000); putInt(192_000 * 6); putShort(6); putShort(24)
        put("data".toByteArray()); putInt(pcm.size); put(pcm)
    }.array()
    private fun sha256(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
}
