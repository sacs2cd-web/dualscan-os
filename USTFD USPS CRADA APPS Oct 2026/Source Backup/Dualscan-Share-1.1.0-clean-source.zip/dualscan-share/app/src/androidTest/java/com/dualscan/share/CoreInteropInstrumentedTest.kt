package com.dualscan.share

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.dualscan.share.core.ArchiveEngine
import com.dualscan.share.core.ProtectedArchive
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.io.OutputStream
import java.security.MessageDigest
import android.content.ContentUris
import android.provider.MediaStore

/** Independent Node/OpenSSL fixture proves the container travels between crypto providers. */
@RunWith(AndroidJUnit4::class)
class CoreInteropInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val app get() = instrumentation.targetContext
    private val vector get() = JSONObject(instrumentation.context.assets.open("crypto/host-encrypted-vector.json").bufferedReader().use { it.readText() })

    private fun fixture(): File = File(app.cacheDir, "interop-host-${System.nanoTime()}.dshare").also { file ->
        instrumentation.context.assets.open("crypto/host-encrypted.dshare").use { input -> file.outputStream().use(input::copyTo) }
    }

    @Test fun independentHostArchiveUnlocksAndRestoresEveryOriginalByteOnAndroid() {
        val meta=vector; val source=fixture();val password=meta.getString("password").toCharArray()
        try {
            val inspection=ArchiveEngine.inspect(source,password)
            assertTrue(inspection.encrypted)
            assertEquals(meta.getString("encryptedSha256"),inspection.archiveSha256)
            val restored=HashSink()
            val result=ArchiveEngine.restore(source,setOf(meta.getString("payloadId")),password) { restored }
            assertEquals(1,result.restoredEntries)
            assertEquals(meta.getLong("payloadBytes"),result.restoredBytes)
            assertEquals(meta.getString("payloadSha256"),restored.hex())
            assertNoPlaintextTemps(source.parentFile!!)
        } finally { password.fill('\u0000');source.delete() }
    }

    @Test fun wrongPasswordNeverOpensARestoreDestination() {
        val source=fixture();var opened=false
        try {
            try {
                ArchiveEngine.restore(source,setOf("file-000001"),"Incorrect test password".toCharArray()) {
                    opened=true;HashSink()
                }
                fail("Wrong password was accepted")
            } catch (_: java.io.IOException) { /* Expected authenticated failure. */ }
            assertFalse(opened)
            assertNoPlaintextTemps(source.parentFile!!)
        } finally { source.delete() }
    }

    @Test fun androidEncryptedOutputCanBeExportedForIndependentHostVerification() {
        val source=fixture();val meta=vector;val password=meta.getString("password").toCharArray()
        val output=File(app.filesDir,"verification-android-produced.dshare").apply { delete() }
        try {
            ProtectedArchive.withPlaintext(source,password) { plain ->
                ProtectedArchive.encrypt(output,password) { target -> plain.inputStream().use { it.copyTo(target) } }
            }
            assertTrue(output.isFile)
            assertNotEquals(meta.getString("encryptedSha256"),ArchiveEngine.sha256(output))
            ProtectedArchive.withPlaintext(output,password) { plain ->
                assertEquals(meta.getString("plainArchiveSha256"),ArchiveEngine.sha256(plain))
            }
            assertNoPlaintextTemps(source.parentFile!!)
            // Intentional encrypted test artifact, retained for host-side Node/OpenSSL verification.
        } finally { password.fill('\u0000');source.delete() }
    }

    @Test fun productionMediaRestorerPublishesExactDecryptedAudioIntoMusic() {
        val source=fixture();val meta=vector;val password=meta.getString("password").toCharArray()
        val collection=MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        fun rows(): Set<Long> = app.contentResolver.query(collection,arrayOf(MediaStore.Audio.Media._ID),
            "${MediaStore.MediaColumns.RELATIVE_PATH} = ? AND ${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?",
            arrayOf("Music/DualscanShare/","%${meta.getString("payloadName")}"),null)?.use { cursor ->
                buildSet { while(cursor.moveToNext()) add(cursor.getLong(0)) }
            }.orEmpty()
        val before=rows()
        try {
            val result=MediaStoreRestorer.restore(app,source,setOf(meta.getString("payloadId")),password)
            assertEquals(1,result.restoredEntries)
            val created=rows()-before
            assertEquals(1,created.size)
            val uri=ContentUris.withAppendedId(collection,created.single())
            app.contentResolver.query(uri,arrayOf(MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.IS_PENDING,MediaStore.MediaColumns.SIZE),null,null,null)!!.use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("Music/DualscanShare/",cursor.getString(0));assertEquals(0,cursor.getInt(1))
                assertEquals(meta.getLong("payloadBytes"),cursor.getLong(2))
            }
            val sink=HashSink()
            app.contentResolver.openInputStream(uri)!!.use { it.copyTo(sink) }
            assertEquals(meta.getString("payloadSha256"),sink.hex())
            assertFalse(File(app.filesDir,"pending-media-restore.txt").exists())
        } finally {
            (rows()-before).forEach { app.contentResolver.delete(ContentUris.withAppendedId(collection,it),null,null) }
            password.fill('\u0000');source.delete()
        }
    }

    private fun assertNoPlaintextTemps(parent: File) {
        assertTrue(parent.listFiles().orEmpty().none { it.name.startsWith(".dualscan-unlocked-") })
    }
    private class HashSink: OutputStream() {
        private val digest=MessageDigest.getInstance("SHA-256")
        override fun write(b: Int) { digest.update(b.toByte()) }
        override fun write(b: ByteArray,off: Int,len: Int) { digest.update(b,off,len) }
        fun hex()=digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}
