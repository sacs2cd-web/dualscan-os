import org.gradle.api.tasks.PathSensitivity

plugins { id("com.android.library") }

val ecosystemKeyFile = providers.gradleProperty("dualscanEcosystemKeyFile")
    .orElse(providers.environmentVariable("DUALSCAN_ECOSYSTEM_KEY_FILE"))
    .orElse("${System.getProperty("user.home")}/.local/share/dualscan-research/keys/ecosystem-v1.key")
val generatedKeyDirectory = layout.buildDirectory.dir("generated/ecosystemKey")
val generateEcosystemKey by tasks.registering {
    inputs.file(ecosystemKeyFile).withPathSensitivity(PathSensitivity.NONE)
    outputs.dir(generatedKeyDirectory)
    doLast {
        val key = file(ecosystemKeyFile.get()).readBytes()
        require(key.size == 32) { "The Dualscan ecosystem key file must contain exactly 32 bytes." }
        try {
            // Java is registered through AndroidSourceSet.java and is visible to built-in Kotlin.
            // Remove the former generated Kotlin variant when upgrading an existing build folder.
            generatedKeyDirectory.get().file("com/dualscan/mp/core/EcosystemBuildKey.kt").asFile.delete()
            val destination = generatedKeyDirectory.get().file("com/dualscan/mp/core/EcosystemBuildKey.java").asFile
            destination.parentFile.mkdirs()
            destination.writeText("package com.dualscan.mp.core;\nfinal class EcosystemBuildKey { private EcosystemBuildKey() {} static byte[] bytes() { return new byte[] {" +
                key.joinToString(",") { it.toString() } + "}; } }\n")
        } finally { key.fill(0) }
    }
}

android {
    namespace = "com.dualscan.interchange"
    compileSdk = 36
    defaultConfig { minSdk = 26 }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    // AndroidSourceSet accepts a concrete directory here, not Gradle Provider<Directory>.
    // preBuild below supplies the explicit producer dependency for every variant.
    sourceSets.getByName("main").java.srcDir(generatedKeyDirectory.get().asFile)
}
tasks.named("preBuild").configure { dependsOn(generateEcosystemKey) }
dependencies {
    implementation(project(":tella-keys-core"))
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
