package com.dualscan.mp.core

import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile

/** The source must be reopenable for the create operation's two verification passes. */
data class MediaInput(
    val displayName: String,
    val mimeType: String,
    /** Full relative path including the filename, or null to use displayName. */
    val relativePath: String? = null,
    val open: () -> InputStream,
    val trackNumber: Int? = null,
    val discNumber: Int? = null
) {
    constructor(displayName: String, mimeType: String, open: () -> InputStream) : this(displayName, mimeType, null, open)
    constructor(displayName: String, mimeType: String, relativePath: String?, open: () -> InputStream) :
        this(displayName, mimeType, relativePath, open, null, null)
}

data class MediaCatalog(
    val id: String,
    val title: String,
    val entries: List<MediaEntry>,
    /** Optional authenticated Share backup metadata. Never used as an extraction path. */
    val backupMetadata: String? = null
)

/** The selected container is password protected; retry only after user input. */
class PasswordRequiredException : IOException("Enter the password for this file.")
data class MediaEntry(
    val id: String,
    val displayName: String,
    val mimeType: String,
    val relativePath: String?,
    val sizeBytes: Long,
    val sha256: String,
    val trackNumber: Int? = null,
    val discNumber: Int? = null
)

/** readAt may return short reads; -1 indicates EOF. MediaArray.open takes ownership. */
interface RandomAccessSource : Closeable {
    val size: Long
    fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int): Int
}

/** Read-only file implementation. No plaintext is written by this adapter. */
class FileRandomAccessSource(file: File) : RandomAccessSource {
    private val file = RandomAccessFile(file, "r")
    private var closed = false
    override val size: Long @Synchronized get() { ensureOpen(); return file.length() }
    @Synchronized override fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
        ensureOpen()
        require(offset >= 0) { "Negative source offset." }
        require(targetOffset >= 0 && count >= 0 && targetOffset <= target.size - count) { "Invalid source buffer bounds." }
        if (count == 0) return 0
        file.seek(offset)
        return file.read(target, targetOffset, count)
    }
    @Synchronized override fun close() { if (!closed) { closed = true; file.close() } }
    private fun ensureOpen() { if (closed) throw IOException("The encrypted source is closed.") }
}
