package com.dualscan.mp.core

import org.hzontal.tella.keys.key.MainKey
import org.hzontal.tella.keys.util.Wiper
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.security.GeneralSecurityException
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.Normalizer
import java.util.Collections
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Portable encrypted media array, DSMP0001. It contains no plaintext staging files.
 * Header: magic[8], salt[16], baseNonce[12], PBKDF2 iterations int32-BE,
 * encrypted manifest length int32-BE. KDF: PBKDF2-HMAC-SHA256, 600000, 256 bits.
 * Manifest AES-GCM uses nonce counter 0 and AAD header || byte(0).
 * Data uses consecutive global counters 1..N and independently authenticated
 * 1 MiB chunks (last chunk per entry may be short). Data AAD is header ||
 * byte(1) || entryIndex int32-BE || chunkIndex int64-BE || clearLength int32-BE.
 * Nonces XOR the counter into the last 8 bytes of the random base nonce.
 * Relative offsets in the authenticated manifest address data after the manifest.
 * There are no inter-chunk length words: authenticated metadata fixes all ranges.
 * This is an application format, not a DRM or OEM firmware authenticity scheme.
 */
object MediaArray {
    const val CHUNK_BYTES = 1024 * 1024
    const val MAX_ENTRIES = 10_000
    const val MAX_TOTAL_BYTES = 32L * 1024 * 1024 * 1024
    const val MAX_MANIFEST_BYTES = 8 * 1024 * 1024
    const val MAX_BACKUP_METADATA_BYTES = 8 * 1024 * 1024
    const val MAX_PORTABLE_MANIFEST_BYTES = 16 * 1024 * 1024
    const val MAX_ENCRYPTED_BYTES = MAX_TOTAL_BYTES + MAX_PORTABLE_MANIFEST_BYTES +
        16L * (MAX_ENTRIES + (MAX_TOTAL_BYTES + CHUNK_BYTES - 1) / CHUNK_BYTES) + 128L
    internal const val HEADER_BYTES = 44
    internal const val PORTABLE_HEADER_BYTES = 112
    private const val PORTABLE_PREFIX_BYTES = 64
    private const val GLOBAL_MODE = 0
    private const val PASSWORD_MODE = 1
    internal const val TAG_BYTES = 16
    private const val ITERATIONS = 600_000
    private val magic = "DSMP0001".toByteArray(Charsets.US_ASCII)
    private val portableMagic = "DSMP0002".toByteArray(Charsets.US_ASCII)
    private val portableMimePattern = Regex("[a-z0-9!#$&^_.+\\-]+/[a-z0-9!#$&^_.+\\-]+")
    private val prohibitedMimes = setOf("application/vnd.android.package-archive", "application/x-dex", "application/java-archive", "application/x-executable", "application/x-msdownload", "application/x-sharedlib")
    private val runtimeExtensions = setOf("apkm", "obb", "vdex", "oat", "art", "so", "class", "aar", "apex", "capex", "idsig", "dm")
    private val shaPattern = Regex("[0-9a-f]{64}")
    private val mimePattern = Regex("(?:audio|video|image)/[a-z0-9!#$&^_.+\\-]+")
    private val prohibitedExtensions = setOf("apk", "apks", "aab", "xapk", "dex", "odex", "jar", "exe")
    private const val OPEN_FAILURE = "Cannot unlock this media array. The password is incorrect, or the file is damaged or unsupported."

    /** Legacy password-only DSMP0001 writer retained for compatibility. */
    fun create(output: File, title: String, inputs: List<MediaInput>, password: CharArray): UnlockedMediaArray =
        createInternal(output, title, inputs, password, null, false)

    /** Always encrypted. A password adds protection to the shared offline ecosystem key. */
    fun createPortable(output: File, title: String, inputs: List<MediaInput>, password: CharArray? = null,
                       metadata: String? = null): UnlockedMediaArray =
        createInternal(output, title, inputs, password, metadata, true)

    private fun createInternal(output: File, title: String, inputs: List<MediaInput>, password: CharArray?,
                               metadata: String?, portable: Boolean): UnlockedMediaArray {
        if (!portable || password != null) validatePassword(password ?: throw PasswordRequiredException())
        validateMetadata(metadata)
        val cleanTitle = title.trim().also(::validateTitle)
        require(inputs.size <= MAX_ENTRIES && (inputs.isNotEmpty() || portable && metadata != null)) {
            "Choose 1–$MAX_ENTRIES files."
        }
        require(!output.exists()) { "The output file already exists." }
        val seen = HashSet<String>()
        val normalizedInputs = inputs.map { input ->
            require(input.trackNumber == null || input.trackNumber in 1..9999) { "Track numbers must be between 1 and 9999." }
            require(input.discNumber == null || input.discNumber in 1..9999) { "Disc numbers must be between 1 and 9999." }
            val displayName = normalizedName(input.displayName)
            val path = input.relativePath?.let { normalizedPath(it, displayName) }
            require(seen.add(pathKey(path ?: displayName))) { "Two selected files have conflicting paths. Choose distinct names or folders." }
            val mime = input.mimeType.lowercase(Locale.ROOT)
            validateMime(mime, portable)
            if (portable) validatePublicPath(path ?: displayName)
            input.copy(displayName = displayName, mimeType = mime, relativePath = path)
        }
        var total = 0L
        var dataOffset = 0L
        var globalCounter = 1L
        val indexes = normalizedInputs.mapIndexed { index, input ->
            checkInterrupted()
            val digest = MessageDigest.getInstance("SHA-256")
            val size = input.open().use { stream -> hashStream(stream, digest, MAX_TOTAL_BYTES - total) }
            total += size
            val entry = MediaEntry(entryId(index), input.displayName, input.mimeType, input.relativePath, size, digest.hex(), input.trackNumber, input.discNumber)
            val chunks = chunksFor(size)
            IndexedMediaEntry(entry, index, dataOffset, globalCounter, chunks).also {
                dataOffset += size + chunks * TAG_BYTES
                globalCounter += chunks
            }
        }
        val catalog = MediaCatalog(UUID.randomUUID().toString(), cleanTitle,
            Collections.unmodifiableList(indexes.map { it.entry }), metadata)
        val manifest = encodeManifest(catalog, indexes, portable).toString().toByteArray(Charsets.UTF_8)
        require(manifest.size <= if (portable) MAX_PORTABLE_MANIFEST_BYTES else MAX_MANIFEST_BYTES) { "The media catalog is too large." }
        val (header, key) = if (portable) makePortableHeader(manifest.size + TAG_BYTES, password)
            else makeHeader(manifest.size + TAG_BYTES).let { it to deriveKey(password!!, it) }
        var created = false
        try {
            require(output.createNewFile()) { "The output file already exists." }
            created = true
            output.outputStream().buffered(128 * 1024).use { destination ->
                destination.write(header)
                destination.write(manifestCipher(Cipher.ENCRYPT_MODE, key, header).doFinal(manifest))
                val buffer = ByteArray(CHUNK_BYTES)
                try {
                    indexes.forEach { indexed ->
                        checkInterrupted()
                        val digest = MessageDigest.getInstance("SHA-256")
                        normalizedInputs[indexed.index].open().use { input ->
                            var chunk = 0L
                            while (chunk < indexed.chunkCount) {
                                checkInterrupted()
                                val length = minOf(CHUNK_BYTES.toLong(), indexed.entry.sizeBytes - chunk * CHUNK_BYTES).toInt()
                                readExpected(input, buffer, length)
                                digest.update(buffer, 0, length)
                                val cipher = dataCipher(Cipher.ENCRYPT_MODE, key, header, indexed, chunk, length)
                                destination.write(cipher.doFinal(buffer, 0, length))
                                Wiper.wipe(buffer)
                                chunk++
                            }
                            require(input.read() == -1 && digest.hex() == indexed.entry.sha256) { "A selected source changed during encryption. No array was saved." }
                        }
                    }
                } finally { Wiper.wipe(buffer) }
            }
            require(output.length() == header.size + manifest.size.toLong() + TAG_BYTES + dataOffset) { "The encrypted array write was incomplete." }
        } catch (failure: Throwable) {
            if (created && !output.delete() && output.exists()) failure.addSuppressed(IOException("Cannot remove incomplete encrypted output."))
            throw failure
        } finally {
            Wiper.wipe(manifest)
            key.wipe()
        }
        return try { open(output, password) } catch (failure: Throwable) { output.delete(); throw failure }
    }

    fun open(file: File, password: CharArray? = null): UnlockedMediaArray = open(FileRandomAccessSource(file), password)

    /** Takes ownership of source, including on failure. */
    fun open(source: RandomAccessSource, password: CharArray? = null): UnlockedMediaArray {
        var key: MainKey? = null
        try {
            checkInterrupted()
            val size = source.size
            require(size in (HEADER_BYTES + TAG_BYTES + 1).toLong()..MAX_ENCRYPTED_BYTES) { OPEN_FAILURE }
            val legacyHeader = ByteArray(HEADER_BYTES)
            readFully(source, 0, legacyHeader)
            val portable = legacyHeader.copyOfRange(0, 8).contentEquals(portableMagic)
            require(portable || legacyHeader.copyOfRange(0, 8).contentEquals(magic)) { OPEN_FAILURE }
            val header = if (portable) {
                require(size > PORTABLE_HEADER_BYTES + TAG_BYTES) { OPEN_FAILURE }
                ByteArray(PORTABLE_HEADER_BYTES).also {
                    legacyHeader.copyInto(it)
                    val remaining = ByteArray(PORTABLE_HEADER_BYTES - HEADER_BYTES)
                    readFully(source, HEADER_BYTES.toLong(), remaining)
                    remaining.copyInto(it, HEADER_BYTES)
                }
            } else legacyHeader
            val cipherLength = ByteBuffer.wrap(header, 40, 4).int
            val manifestLimit = if (portable) MAX_PORTABLE_MANIFEST_BYTES else MAX_MANIFEST_BYTES
            require(cipherLength in (TAG_BYTES + 1)..(manifestLimit + TAG_BYTES) && header.size + cipherLength.toLong() <= size) { OPEN_FAILURE }
            val passwordProtected = if (portable) validatePortableHeader(header) else {
                require(ByteBuffer.wrap(header, 36, 4).int == ITERATIONS) { OPEN_FAILURE }
                true
            }
            if (passwordProtected && password == null) throw PasswordRequiredException()
            if (passwordProtected) validatePassword(password!!)
            key = if (portable) unwrapPortableKey(header, if (passwordProtected) password else null) else deriveKey(password!!, header)
            val encrypted = ByteArray(cipherLength)
            readFully(source, header.size.toLong(), encrypted)
            val clear = try { manifestCipher(Cipher.DECRYPT_MODE, key, header).doFinal(encrypted) }
                finally { Wiper.wipe(encrypted) }
            val parsed = try {
                val decoder = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                parseManifest(JSONObject(decoder.decode(ByteBuffer.wrap(clear)).toString()), portable)
            } finally { Wiper.wipe(clear) }
            val dataStart = header.size + cipherLength.toLong()
            val expectedData = parsed.second.sumOf { it.entry.sizeBytes + it.chunkCount * TAG_BYTES }
            require(dataStart + expectedData == size && source.size == size) { OPEN_FAILURE }
            return UnlockedMediaArray(source, key, header, parsed.first, parsed.second, dataStart, size, portable, passwordProtected)
        } catch (failure: Throwable) {
            key?.wipe()
            try { source.close() } catch (closeFailure: Throwable) { failure.addSuppressed(closeFailure) }
            if (failure is Error || failure is PasswordRequiredException) throw failure
            if (Thread.currentThread().isInterrupted) throw IOException("Media operation cancelled.", failure)
            throw IOException(OPEN_FAILURE, failure)
        }
    }

    /** Format sniffing borrows source. The caller retains ownership even on failure. */
    fun isSupported(source: RandomAccessSource): Boolean = signature(source)?.let {
        it.contentEquals(magic) || it.contentEquals(portableMagic)
    } ?: false
    fun isPortable(source: RandomAccessSource): Boolean = signature(source)?.contentEquals(portableMagic) ?: false
    fun isSupported(file: File): Boolean = FileRandomAccessSource(file).use(::isSupported)
    fun isPortable(file: File): Boolean = FileRandomAccessSource(file).use(::isPortable)
    private fun signature(source: RandomAccessSource): ByteArray? = try {
        if (source.size < 8) null else ByteArray(8).also { readFully(source, 0, it) }
    } catch (_: Exception) { null }

    /** A non-secret identifier; the ecosystem key bytes are never returned. */
    val ecosystemKeyId: String get() = ecosystemKeyIdentifier().joinToString("") { "%02x".format(it.toInt() and 255) }

    private fun encodeManifest(catalog: MediaCatalog, indexes: List<IndexedMediaEntry>, portable: Boolean) = JSONObject().apply {
        put("format", if (portable) "dualscan-portable" else "dualscan-mp"); put("schemaVersion", if (portable) 2 else 1); put("id", catalog.id); put("title", catalog.title)
        put("chunkBytes", CHUNK_BYTES)
        if (portable) put("backupMetadata", catalog.backupMetadata ?: JSONObject.NULL)
        put("entries", JSONArray().apply { indexes.forEach { indexed ->
            val entry = indexed.entry
            val item = JSONObject().put("id", entry.id).put("displayName", entry.displayName).put("mimeType", entry.mimeType)
                .put("relativePath", entry.relativePath ?: JSONObject.NULL).put("sizeBytes", entry.sizeBytes).put("sha256", entry.sha256)
                .put("index", indexed.index).put("dataOffset", indexed.dataOffset).put("firstCounter", indexed.firstCounter).put("chunkCount", indexed.chunkCount)
            entry.trackNumber?.let { item.put("trackNumber", it) }
            entry.discNumber?.let { item.put("discNumber", it) }
            put(item)
        } })
    }

    private fun parseManifest(manifest: JSONObject, portable: Boolean): Pair<MediaCatalog, List<IndexedMediaEntry>> {
        require(manifest.string("format") == (if (portable) "dualscan-portable" else "dualscan-mp") && manifest.integer("schemaVersion") == (if (portable) 2L else 1L) && manifest.integer("chunkBytes") == CHUNK_BYTES.toLong()) { OPEN_FAILURE }
        val id = manifest.string("id")
        require(UUID.fromString(id).toString() == id) { OPEN_FAILURE }
        val title = manifest.string("title").also(::validateTitle)
        val array = manifest.getJSONArray("entries")
        val metadata = if (portable && !manifest.isNull("backupMetadata")) manifest.string("backupMetadata") else null
        validateMetadata(metadata)
        require(array.length() <= MAX_ENTRIES && (array.length() > 0 || portable && metadata != null)) { OPEN_FAILURE }
        val seen = HashSet<String>()
        var total = 0L
        var offset = 0L
        var counter = 1L
        val indexes = (0 until array.length()).map { index ->
            checkInterrupted()
            val item = array.getJSONObject(index)
            val name = item.string("displayName")
            require(name == normalizedName(name)) { OPEN_FAILURE }
            val path = if (item.isNull("relativePath")) null else item.string("relativePath").also { require(it == normalizedPath(it, name)) { OPEN_FAILURE } }
            require(seen.add(pathKey(path ?: name))) { OPEN_FAILURE }
            val mime = item.string("mimeType")
            validateMime(mime, portable)
            if (portable) validatePublicPath(path ?: name)
            val size = item.integer("sizeBytes")
            require(size in 0..(MAX_TOTAL_BYTES - total)) { OPEN_FAILURE }
            total += size
            val hash = item.string("sha256")
            require(hash.matches(shaPattern) && item.string("id") == entryId(index)) { OPEN_FAILURE }
            val chunks = chunksFor(size)
            require(item.integer("index") == index.toLong() && item.integer("dataOffset") == offset &&
                item.integer("firstCounter") == counter && item.integer("chunkCount") == chunks) { OPEN_FAILURE }
            val trackNumber = item.optionalTrackMetadata("trackNumber")
            val discNumber = item.optionalTrackMetadata("discNumber")
            IndexedMediaEntry(MediaEntry(entryId(index), name, mime, path, size, hash, trackNumber, discNumber), index, offset, counter, chunks).also {
                offset += size + chunks * TAG_BYTES
                counter += chunks
            }
        }
        return MediaCatalog(id, title, Collections.unmodifiableList(indexes.map { it.entry }), metadata) to indexes
    }

    private fun JSONObject.optionalTrackMetadata(name: String): Int? {
        if (!has(name) || isNull(name)) return null
        val value = integer(name)
        require(value in 1L..9999L) { OPEN_FAILURE }
        return value.toInt()
    }

    private fun validateMime(mime: String, portable: Boolean) {
        require(if (portable) mime.length <= 127 && portableMimePattern.matches(mime) && mime !in prohibitedMimes
            else mimePattern.matches(mime)) { "This file type is unsupported. Application packages and executable files cannot be included." }
    }
    private fun validatePublicPath(path: String) {
        val parts = path.split('/').map { it.lowercase(Locale.ROOT) }
        require(parts.last().substringAfterLast('.', "") !in runtimeExtensions) {
            "Application runtime files cannot be included."
        }
        require(parts.zipWithNext().none { (a, b) -> a == "android" && b in setOf("data", "obb") }) {
            "App private data and runtime folders cannot be included."
        }
    }
    private fun validateMetadata(metadata: String?) {
        if (metadata == null) return
        require(metadata.length <= MAX_BACKUP_METADATA_BYTES) { "The backup metadata is too large." }
        val bytes = metadata.toByteArray(Charsets.UTF_8)
        try {
            require(bytes.size <= MAX_BACKUP_METADATA_BYTES) { "The backup metadata is too large." }
            JSONObject(metadata)
        } finally { Wiper.wipe(bytes) }
    }

    private fun ecosystemKeyIdentifier(): ByteArray {
        val bytes = EcosystemBuildKey.bytes()
        return try { MessageDigest.getInstance("SHA-256").digest(bytes).copyOf(16) }
        finally { Wiper.wipe(bytes) }
    }

    private fun makePortableHeader(manifestCipherLength: Int, password: CharArray?): Pair<ByteArray, MainKey> {
        val salt = ByteArray(16)
        val nonce = ByteArray(12)
        val dataKey = ByteArray(32)
        SecureRandom().apply { nextBytes(salt); nextBytes(nonce); nextBytes(dataKey) }
        val prefix = ByteBuffer.allocate(PORTABLE_PREFIX_BYTES).put(portableMagic).put(salt).put(nonce)
            .putInt(if (password == null) 0 else ITERATIONS).putInt(manifestCipherLength)
            .put(if (password == null) GLOBAL_MODE.toByte() else PASSWORD_MODE.toByte())
            .put(byteArrayOf(0, 0, 0)).put(ecosystemKeyIdentifier()).array()
        val wrapping = portableWrappingKey(prefix, password)
        try {
            val wrapped = wrapCipher(Cipher.ENCRYPT_MODE, wrapping, prefix).doFinal(dataKey)
            return (prefix + wrapped) to MainKey(dataKey)
        } finally { wrapping.wipe(); Wiper.wipe(dataKey) }
    }

    private fun validatePortableHeader(header: ByteArray): Boolean {
        require(header.size == PORTABLE_HEADER_BYTES && header[44].toInt() in GLOBAL_MODE..PASSWORD_MODE &&
            header.copyOfRange(45, 48).all { it == 0.toByte() }) { OPEN_FAILURE }
        val passwordProtected = header[44].toInt() == PASSWORD_MODE
        require(ByteBuffer.wrap(header, 36, 4).int == if (passwordProtected) ITERATIONS else 0) { OPEN_FAILURE }
        require(MessageDigest.isEqual(header.copyOfRange(48, 64), ecosystemKeyIdentifier())) { OPEN_FAILURE }
        return passwordProtected
    }

    private fun unwrapPortableKey(header: ByteArray, password: CharArray?): MainKey {
        val prefix = header.copyOfRange(0, PORTABLE_PREFIX_BYTES)
        val wrapping = portableWrappingKey(prefix, password)
        val clear = try { wrapCipher(Cipher.DECRYPT_MODE, wrapping, prefix).doFinal(header.copyOfRange(64, 112)) }
            finally { wrapping.wipe() }
        return try { require(clear.size == 32) { OPEN_FAILURE }; MainKey(clear) }
        finally { Wiper.wipe(clear) }
    }

    /** HKDF-SHA256 derives a per-container wrapping key from global key + optional PBKDF2 secret. */
    private fun portableWrappingKey(prefix: ByteArray, password: CharArray?): MainKey {
        val global = EcosystemBuildKey.bytes()
        val salt = prefix.copyOfRange(8, 24)
        val extra = if (password == null) ByteArray(0) else {
            val specification = PBEKeySpec(password, salt, ITERATIONS, 256)
            try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded }
            finally { specification.clearPassword() }
        }
        val input = global + extra
        val extracted = try { hmac(salt, input) }
            finally { Wiper.wipe(global); Wiper.wipe(extra); Wiper.wipe(input) }
        val expanded = try { hmac(extracted, "Dualscan portable container v2 key wrapping".toByteArray(Charsets.US_ASCII) + byteArrayOf(1)) }
            finally { Wiper.wipe(extracted) }
        return try { MainKey(expanded) } finally { Wiper.wipe(expanded) }
    }
    private fun hmac(key: ByteArray, input: ByteArray): ByteArray = Mac.getInstance("HmacSHA256").run {
        init(SecretKeySpec(key, "HmacSHA256")); doFinal(input)
    }
    private fun wrapCipher(mode: Int, key: MainKey, prefix: ByteArray): Cipher =
        recordCipher(mode, key, prefix, Long.MAX_VALUE, prefix + byteArrayOf(2))

    private fun makeHeader(manifestCipherLength: Int): ByteArray {
        val salt = ByteArray(16); val nonce = ByteArray(12)
        SecureRandom().apply { nextBytes(salt); nextBytes(nonce) }
        return ByteBuffer.allocate(HEADER_BYTES).put(magic).put(salt).put(nonce).putInt(ITERATIONS).putInt(manifestCipherLength).array()
    }

    private fun deriveKey(password: CharArray, header: ByteArray): MainKey {
        val specification = PBEKeySpec(password, header.copyOfRange(8, 24), ITERATIONS, 256)
        val bytes = try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(specification).encoded }
            finally { specification.clearPassword() }
        return try { MainKey(bytes) } finally { Wiper.wipe(bytes) }
    }

    internal fun manifestCipher(mode: Int, key: MainKey, header: ByteArray) = recordCipher(mode, key, header, 0,
        header + byteArrayOf(0))

    internal fun dataCipher(mode: Int, key: MainKey, header: ByteArray, indexed: IndexedMediaEntry, chunk: Long, length: Int): Cipher {
        val aad = ByteBuffer.allocate(header.size + 1 + 4 + 8 + 4).put(header).put(1.toByte()).putInt(indexed.index).putLong(chunk).putInt(length).array()
        return recordCipher(mode, key, header, indexed.firstCounter + chunk, aad)
    }

    private fun recordCipher(mode: Int, key: MainKey, header: ByteArray, counter: Long, aad: ByteArray): Cipher {
        val nonce = header.copyOfRange(24, 36)
        for (index in 0..7) nonce[11 - index] = (nonce[11 - index].toInt() xor (counter ushr (8 * index)).toInt()).toByte()
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(mode, key.key ?: throw IOException("The media array is locked."), GCMParameterSpec(128, nonce)); updateAAD(aad)
        }
    }

    private fun normalizedName(name: String): String = Normalizer.normalize(name, Normalizer.Form.NFC).also {
        require(it.isNotBlank() && it.length <= 240 && it !in setOf(".", "..") && it.none { character -> character == '/' || character == '\\' || character.code < 32 || character.code == 127 }) { "A media filename is unsafe or unsupported." }
        require(it.substringAfterLast('.', "").lowercase(Locale.ROOT) !in prohibitedExtensions) { "Application and executable files are not media." }
    }
    private fun normalizedPath(path: String, name: String): String = Normalizer.normalize(path, Normalizer.Form.NFC).also {
        require(it.length <= 2048 && it.isNotBlank() && !it.startsWith('/') && !it.endsWith('/') && '\\' !in it) { "Use a safe relative media path." }
        val segments = it.split('/')
        require(segments.size <= 32 && segments.last() == name && segments.all { segment -> segment == normalizedName(segment) }) { "Use a safe relative media path ending in its filename." }
    }
    // Conservative fold also rejects SS/ß and sigma variants across filesystems.
    private fun pathKey(path: String) = Normalizer.normalize(path.uppercase(Locale.ROOT).lowercase(Locale.ROOT), Normalizer.Form.NFC)
    private fun validateTitle(title: String) { require(title.isNotBlank() && title.length <= 160 && title.none { it.code < 32 || it.code == 127 }) { "Enter a media-array title of 1–160 characters." } }
    private fun validatePassword(password: CharArray) { require(password.size in 8..256) { "Use a password of 8–256 characters. A long unique passphrase is recommended." } }
    private fun entryId(index: Int) = "media-${(index + 1).toString().padStart(6, '0')}"
    private fun chunksFor(size: Long) = (size + CHUNK_BYTES - 1) / CHUNK_BYTES
    private fun JSONObject.string(key: String) = (get(key) as? String) ?: throw IOException("Invalid media catalog string.")
    private fun JSONObject.integer(key: String): Long = when (val value = get(key)) { is Int -> value.toLong(); is Long -> value; else -> throw IOException("Invalid media catalog integer.") }
    private fun MessageDigest.hex() = digest().joinToString("") { "%02x".format(it.toInt() and 255) }
    internal fun checkInterrupted() { if (Thread.currentThread().isInterrupted) throw IOException("Media operation cancelled.") }

    private fun hashStream(input: InputStream, digest: MessageDigest, limit: Long): Long {
        val buffer = ByteArray(CHUNK_BYTES)
        var total = 0L
        try {
            while (true) {
                checkInterrupted()
                val count = input.read(buffer)
                if (count == -1) return total
                if (count == 0) throw IOException("The selected media provider stopped producing data.")
                require(count.toLong() <= limit - total) { "Selected media exceeds the 32 GiB array limit." }
                digest.update(buffer, 0, count); total += count
            }
        } finally { Wiper.wipe(buffer) }
    }
    private fun readExpected(input: InputStream, buffer: ByteArray, length: Int) {
        var offset = 0
        while (offset < length) {
            checkInterrupted()
            val count = input.read(buffer, offset, length - offset)
            if (count <= 0) throw IOException("A selected source changed or stopped during encryption.")
            offset += count
        }
    }
    internal fun readFully(source: RandomAccessSource, offset: Long, target: ByteArray) {
        var position = 0
        while (position < target.size) {
            checkInterrupted()
            val count = source.readAt(offset + position, target, position, target.size - position)
            if (count <= 0 || count > target.size - position) throw IOException("The encrypted media is truncated or unavailable.")
            position += count
        }
    }
}

internal data class IndexedMediaEntry(val entry: MediaEntry, val index: Int, val dataOffset: Long, val firstCounter: Long, val chunkCount: Long)

/** Owns one encrypted source and one wipeable plaintext chunk cache. */
class UnlockedMediaArray internal constructor(
    private val source: RandomAccessSource,
    private val key: MainKey,
    private val header: ByteArray,
    val catalog: MediaCatalog,
    indexes: List<IndexedMediaEntry>,
    private val dataStart: Long,
    val encryptedSize: Long,
    val isPortable: Boolean = false,
    val passwordProtected: Boolean = true
) : Closeable {
    private val entries = indexes.associateBy { it.entry.id }
    private var cachedEntry = ""
    private var cachedChunk = -1L
    private var cachedBytes = ByteArray(0)
    private var closed = false

    /** Returns -1 at EOF. Authenticates a complete chunk before copying any of it. */
    @Synchronized fun readAt(entryId: String, position: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
        ensureOpen()
        require(targetOffset >= 0 && count >= 0 && targetOffset <= target.size - count) { "Invalid media buffer bounds." }
        val indexed = entries[entryId] ?: throw IOException("This media entry is not in the unlocked array.")
        if (position < 0 || position > indexed.entry.sizeBytes) throw IOException("The requested media position is outside this entry.")
        if (count == 0) return 0
        if (position == indexed.entry.sizeBytes) return -1
        if (source.size != encryptedSize) { close(); throw IOException("The encrypted source changed. Unlock it again.") }
        var copied = 0
        val desired = minOf(count.toLong(), indexed.entry.sizeBytes - position).toInt()
        while (copied < desired) {
            MediaArray.checkInterrupted()
            val absolutePosition = position + copied
            val chunk = absolutePosition / MediaArray.CHUNK_BYTES
            if (cachedEntry != entryId || cachedChunk != chunk) loadChunk(indexed, chunk)
            val inChunk = (absolutePosition % MediaArray.CHUNK_BYTES).toInt()
            val length = minOf(desired - copied, cachedBytes.size - inChunk)
            cachedBytes.copyInto(target, targetOffset + copied, inChunk, inChunk + length)
            copied += length
        }
        return copied
    }

    /** The returned stream borrows this unlocked array; closing it does not close the array. */
    fun openEntry(entryId: String): InputStream {
        synchronized(this) { ensureOpen(); require(entries.containsKey(entryId)) { "Unknown collection entry." } }
        return object : InputStream() {
            private var position = 0L
            private var streamClosed = false
            override fun read(): Int {
                val one = ByteArray(1)
                return if (read(one, 0, 1) == -1) -1 else one[0].toInt() and 255
            }
            override fun read(target: ByteArray, offset: Int, count: Int): Int {
                if (streamClosed) throw IOException("This entry stream is closed.")
                val read = readAt(entryId, position, target, offset, count)
                if (read > 0) position += read
                return read
            }
            override fun close() { streamClosed = true }
        }
    }

    /** Authenticates every data chunk and compares each original file hash, without staging files. */
    @Synchronized fun verifyAll() {
        ensureOpen()
        val buffer = ByteArray(128 * 1024)
        try {
            catalog.entries.forEach { entry ->
                val digest = MessageDigest.getInstance("SHA-256")
                openEntry(entry.id).use { input ->
                    while (true) {
                        val count = input.read(buffer)
                        if (count == -1) break
                        digest.update(buffer, 0, count)
                    }
                }
                val actual = digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
                if (actual != entry.sha256) { close(); throw IOException("The file content does not match its authenticated hash.") }
            }
        } finally { Wiper.wipe(buffer) }
    }

    private fun loadChunk(indexed: IndexedMediaEntry, chunk: Long) {
        Wiper.wipe(cachedBytes)
        cachedBytes = ByteArray(0); cachedEntry = ""; cachedChunk = -1
        val length = minOf(MediaArray.CHUNK_BYTES.toLong(), indexed.entry.sizeBytes - chunk * MediaArray.CHUNK_BYTES).toInt()
        val encrypted = ByteArray(length + MediaArray.TAG_BYTES)
        try {
            val offset = dataStart + indexed.dataOffset + chunk * (MediaArray.CHUNK_BYTES.toLong() + MediaArray.TAG_BYTES)
            MediaArray.readFully(source, offset, encrypted)
            val clear = MediaArray.dataCipher(Cipher.DECRYPT_MODE, key, header, indexed, chunk, length).doFinal(encrypted)
            if (clear.size != length) { Wiper.wipe(clear); throw IOException("The encrypted media chunk has an invalid size.") }
            cachedBytes = clear; cachedEntry = indexed.entry.id; cachedChunk = chunk
        } catch (failure: Throwable) {
            close()
            if (failure is Error) throw failure
            throw IOException("The encrypted media could not be authenticated. It may have changed or become unavailable.", failure)
        } finally { Wiper.wipe(encrypted) }
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        Wiper.wipe(cachedBytes)
        cachedBytes = ByteArray(0); cachedEntry = ""; cachedChunk = -1
        key.wipe()
        source.close()
    }
    private fun ensureOpen() { if (closed) throw IOException("The media array is locked or closed.") }
}
