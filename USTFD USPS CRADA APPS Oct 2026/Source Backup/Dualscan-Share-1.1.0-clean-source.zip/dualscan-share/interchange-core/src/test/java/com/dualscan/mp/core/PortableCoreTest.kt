package com.dualscan.mp.core

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Random
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class PortableCoreTest {
    @get:Rule val temporary = TemporaryFolder()
    private val password get() = "Optional private passphrase 東京 2026".toCharArray()
    private val song = ByteArray(2 * MediaArray.CHUNK_BYTES + 113) { (it * 23 + (it shr 10)).toByte() }
    private val document = "Private public-folder document 東京".toByteArray()
    private val metadata = JSONObject().put("kind", "lite-media").put("sourceDevice", "OEM fixture").toString()

    @Test fun globalDefaultRoundTripsMediaAndDocumentsWithoutAPassword() {
        val file = create()
        assertTrue(MediaArray.isPortable(file))
        assertTrue(MediaArray.isSupported(file))
        assertEquals("DSMP0002", String(file.readBytes().copyOfRange(0, 8)))
        assertFalse(String(file.readBytes(), Charsets.ISO_8859_1).contains("Private public-folder"))
        MediaArray.open(file).use { array ->
            assertTrue(array.isPortable)
            assertFalse(array.passwordProtected)
            assertEquals(metadata, array.catalog.backupMetadata)
            assertEquals(listOf("Music/Album/02 Song.wav", "Documents/Notes.txt", "Pictures/empty.png"), array.catalog.entries.map { it.relativePath })
            assertEquals(2, array.catalog.entries.first().trackNumber)
            assertEquals(1, array.catalog.entries.first().discNumber)
            assertArrayEquals(song, array.openEntry(array.catalog.entries[0].id).use { it.readBytes() })
            assertArrayEquals(document, array.openEntry(array.catalog.entries[1].id).use { it.readBytes() })
            assertEquals(-1, array.openEntry(array.catalog.entries[2].id).use { it.read() })
            array.verifyAll()
        }
        assertEquals(listOf(file.name), temporary.root.listFiles()!!.map { it.name })
    }

    @Test fun optionalPasswordRequiresBothGlobalAndPasswordSecretsAndNeverDowngrades() {
        val file = create(password)
        val missing = MemorySource(file.readBytes())
        assertTrue(rejected { MediaArray.open(missing) } is PasswordRequiredException)
        assertTrue(missing.closed)
        val wrong = MemorySource(file.readBytes())
        assertFalse(rejected { MediaArray.open(wrong, "Incorrect-password".toCharArray()) } is PasswordRequiredException)
        assertTrue(wrong.closed)
        MediaArray.open(file, password).use { assertTrue(it.passwordProtected); it.verifyAll() }
        val downgrade = file.readBytes().also { it[44] = 0; ByteBuffer.wrap(it, 36, 4).putInt(0) }
        assertFalse(rejected { MediaArray.open(MemorySource(downgrade)) } is PasswordRequiredException)
    }

    @Test fun legacyPasswordOnlyArraysRemainReadableAndAskForPassword() {
        val file = fresh()
        MediaArray.create(file, "Legacy", listOf(MediaInput("old.wav", "audio/wav") { document.inputStream() }), password).close()
        assertFalse(MediaArray.isPortable(file))
        assertTrue(MediaArray.isSupported(file))
        assertTrue(rejected { MediaArray.open(file) } is PasswordRequiredException)
        MediaArray.open(file, password).use { array ->
            assertFalse(array.isPortable)
            assertTrue(array.passwordProtected)
            assertNull(array.catalog.backupMetadata)
            assertArrayEquals(document, array.openEntry(array.catalog.entries.single().id).use { it.readBytes() })
        }
    }

    @Test fun freshDataKeySaltAndNonceRandomizeEveryContainer() {
        val one = create().readBytes()
        val two = create().readBytes()
        assertFalse(one.contentEquals(two))
        listOf(8 to 24, 24 to 36, 64 to 112).forEach { (start, end) ->
            assertFalse(one.copyOfRange(start, end).contentEquals(two.copyOfRange(start, end)))
        }
        assertArrayEquals(one.copyOfRange(48, 64), two.copyOfRange(48, 64))
        assertEquals(32, MediaArray.ecosystemKeyId.length)
    }

    @Test fun malformedAndTamperedHeadersManifestsAndWrappingFailClosed() {
        val bytes = create().readBytes()
        listOf(0, 8, 24, 44, 45, 48, 64, 111, 112, 112 + manifestLength(bytes) - 1).forEach { index ->
            val changed = bytes.clone().also { it[index] = (it[index].toInt() xor 1).toByte() }
            val source = MemorySource(changed)
            rejected { MediaArray.open(source) }
            assertTrue("source must close after tampering at $index", source.closed)
        }
        listOf(-1, 0, 16, MediaArray.MAX_PORTABLE_MANIFEST_BYTES + 17, Int.MAX_VALUE).forEach { length ->
            val changed = bytes.clone().also { ByteBuffer.wrap(it, 40, 4).putInt(length) }
            val source = MemorySource(changed)
            rejected { MediaArray.open(source) }
            assertTrue(source.closed)
            assertEquals(112L, source.bytesRead)
        }
    }

    @Test fun everyDataChunkAuthenticatesBeforeExposingPlaintext() {
        val bytes = create().readBytes()
        val dataStart = 112 + manifestLength(bytes)
        listOf(0, 1, 2).forEach { chunk ->
            val changed = bytes.clone()
            val location = dataStart + chunk * (MediaArray.CHUNK_BYTES + 16)
            changed[location] = (changed[location].toInt() xor 1).toByte()
            val source = MemorySource(changed)
            val array = MediaArray.open(source)
            val output = ByteArray(16) { 0x55 }
            rejected { array.readAt(array.catalog.entries.first().id, chunk * MediaArray.CHUNK_BYTES.toLong(), output, 0, output.size) }
            assertTrue(output.all { it == 0x55.toByte() })
            assertTrue(source.closed)
        }
    }

    @Test fun seekableDecryptionUsesOnlyRequestedChunkAndWorksAcrossBoundaries() {
        val source = MemorySource(create().readBytes(), 17_003)
        MediaArray.open(source).use { array ->
            val entry = array.catalog.entries.first()
            val before = source.bytesRead
            val one = ByteArray(1)
            assertEquals(1, array.readAt(entry.id, entry.sizeBytes - 1, one, 0, 1))
            assertEquals(song.last(), one[0])
            assertEquals(113L + 16, source.bytesRead - before)
            val random = Random(20261016)
            repeat(100) {
                val start = random.nextInt(song.size)
                val output = ByteArray(1 + random.nextInt(81_017))
                val count = array.readAt(entry.id, start.toLong(), output, 0, output.size)
                assertArrayEquals(song.copyOfRange(start, start + count), output.copyOf(count))
            }
        }
        assertTrue(source.closed)
    }

    @Test fun incompleteContainersAndSourceMutationCloseTheOwnedSource() {
        val bytes = create().readBytes()
        listOf(bytes.copyOf(111), bytes.copyOf(bytes.size - 1), bytes + byteArrayOf(0)).forEach {
            val source = MemorySource(it)
            rejected { MediaArray.open(source) }
            assertTrue(source.closed)
        }
        val source = MemorySource(bytes)
        val array = MediaArray.open(source)
        source.reportedSize++
        rejected { array.verifyAll() }
        assertTrue(source.closed)
    }

    @Test fun formatDetectionBorrowsSourcesWithoutClosingOrReadingPayloads() {
        val source = MemorySource(create().readBytes())
        assertTrue(MediaArray.isPortable(source))
        assertTrue(MediaArray.isSupported(source))
        assertFalse(source.closed)
        assertEquals(16L, source.bytesRead)
        val short = MemorySource("DSMP".toByteArray())
        assertFalse(MediaArray.isSupported(short)); assertFalse(short.closed)
        val unknown = MemorySource("DSMP9999not-a-container".toByteArray())
        assertFalse(MediaArray.isSupported(unknown)); assertFalse(unknown.closed)
    }

    @Test fun executableTypesUnsafePathsAndMalformedMetadataNeverOpenSources() {
        var opens = 0
        fun input(name: String, mime: String, path: String? = null) = MediaInput(name, mime, path) { opens++; document.inputStream() }
        listOf(input("app.apk", "application/octet-stream"), input("app.apkm", "application/octet-stream"),
            input("main.obb", "application/zip"), input("a.txt", "application/vnd.android.package-archive"),
            input("a.txt", "text/plain", "Android/data/a.txt"), input("a.txt", "text/plain", "../a.txt"),
            input("a.txt", "bad"), input("a.txt", "text/plain", "/Documents/a.txt")).forEach {
            rejected { MediaArray.createPortable(fresh(), "Unsafe", listOf(it)) }
        }
        listOf("not json", "[1,2]", "x".repeat(MediaArray.MAX_BACKUP_METADATA_BYTES + 1)).forEach {
            rejected { MediaArray.createPortable(fresh(), "Metadata", listOf(input("a.txt", "text/plain")), metadata = it) }
        }
        assertEquals(0, opens)
    }

    @Test fun emptyInventoryIsAllowedOnlyWithAuthenticatedMetadata() {
        rejected { MediaArray.createPortable(fresh(), "Empty", emptyList()) }
        val file = fresh()
        MediaArray.createPortable(file, "Inventory", emptyList(), metadata = "{\"kind\":\"inventory\"}").use { array ->
            assertTrue(array.catalog.entries.isEmpty()); array.verifyAll()
            assertEquals("{\"kind\":\"inventory\"}", array.catalog.backupMetadata)
        }
    }

    @Test fun existingOutputsAndChangingInputsDoNotLeavePartialFiles() {
        val file = fresh().also { it.writeText("preserve") }
        rejected { MediaArray.createPortable(file, "Existing", inputs()) }
        assertEquals("preserve", file.readText())
        var opens = 0
        val changed = fresh()
        val input = MediaInput("a.txt", "text/plain") { if (opens++ == 0) document.inputStream() else byteArrayOf(3).inputStream() }
        rejected { MediaArray.createPortable(changed, "Changed", listOf(input)) }
        assertFalse(changed.exists())
    }

    @Test fun independentStandardJceDecoderReadsGlobalAndProtectedProductionOutput() {
        listOf<CharArray?>(null, password).forEach { secret ->
            val file = create(secret)
            val bytes = file.readBytes()
            val decoded = independentDecode(bytes, secret)
            try {
                assertEquals("dualscan-portable", decoded.first.getString("format"))
                assertEquals(2, decoded.first.getInt("schemaVersion"))
                assertEquals(metadata, decoded.first.getString("backupMetadata"))
                val entries = decoded.first.getJSONArray("entries")
                val offset = 112 + manifestLength(bytes)
                val entry = entries.getJSONObject(0)
                val clear = ByteArray(song.size)
                var copied = 0
                var chunk = 0L
                while (copied < song.size) {
                    val length = minOf(MediaArray.CHUNK_BYTES, song.size - copied)
                    val encryptedStart = offset + copied + chunk.toInt() * 16
                    val aad = ByteBuffer.allocate(112 + 17).put(bytes.copyOfRange(0, 112)).put(1.toByte())
                        .putInt(0).putLong(chunk).putInt(length).array()
                    val cipher = independentCipher(Cipher.DECRYPT_MODE, decoded.second, bytes, entry.getLong("firstCounter") + chunk, aad)
                    val plaintext = cipher.doFinal(bytes.copyOfRange(encryptedStart, encryptedStart + length + 16))
                    plaintext.copyInto(clear, copied); plaintext.fill(0)
                    copied += length; chunk++
                }
                assertArrayEquals(song, clear)
                clear.fill(0)
            } finally { decoded.second.fill(0) }
        }
    }

    @Test fun independentFixtureIsReadableWithoutUsingProductionWriter() {
        listOf<CharArray?>(null, password).forEach { secret ->
            val bytes = independentFixture(secret)
            MediaArray.open(MemorySource(bytes), secret).use { array ->
                assertEquals("Independent fixture", array.catalog.title)
                assertEquals("Documents/message.txt", array.catalog.entries.single().relativePath)
                assertArrayEquals(document, array.openEntry(array.catalog.entries.single().id).use { it.readBytes() })
                array.verifyAll()
            }
        }
    }

    @Test fun authenticatedButFalseFileHashFailsFullVerification() {
        val file = fresh()
        MediaArray.createPortable(file, "Empty hash", listOf(MediaInput("empty.txt", "text/plain") { byteArrayOf().inputStream() })).close()
        val original = file.readBytes()
        val (manifest, key) = independentDecode(original, null)
        try {
            manifest.getJSONArray("entries").getJSONObject(0).put("sha256", "0".repeat(64))
            val encoded = manifest.toString().toByteArray()
            val header = original.copyOfRange(0, 112)
            assertEquals(manifestLength(original), encoded.size + 16)
            val encrypted = independentCipher(Cipher.ENCRYPT_MODE, key, header, 0, header + byteArrayOf(0)).doFinal(encoded)
            val source = MemorySource(header + encrypted)
            val array = MediaArray.open(source)
            rejected { array.verifyAll() }
            assertTrue(source.closed)
        } finally { key.fill(0) }
    }

    private fun inputs() = listOf(
        MediaInput("02 Song.wav", "audio/wav", "Music/Album/02 Song.wav", { song.inputStream() }, 2, 1),
        MediaInput("Notes.txt", "text/plain", "Documents/Notes.txt") { document.inputStream() },
        MediaInput("empty.png", "image/png", "Pictures/empty.png") { byteArrayOf().inputStream() }
    )
    private fun create(secret: CharArray? = null) = fresh().also { MediaArray.createPortable(it, "Portable files", inputs(), secret, metadata).close() }
    private fun fresh() = File(temporary.root, "${UUID.randomUUID()}.dshare")
    private fun manifestLength(bytes: ByteArray) = ByteBuffer.wrap(bytes, 40, 4).int
    private fun rejected(block: () -> Unit): Exception {
        try { block() } catch (failure: Exception) { return failure }
        throw AssertionError("Invalid portable operation was accepted")
    }
    private class MemorySource(private val bytes: ByteArray, private val maxRead: Int = Int.MAX_VALUE) : RandomAccessSource {
        var closed = false
        var bytesRead = 0L
        var reportedSize = bytes.size.toLong()
        override val size get() = reportedSize
        override fun readAt(offset: Long, target: ByteArray, targetOffset: Int, count: Int): Int {
            if (closed) throw IOException("closed")
            if (offset >= bytes.size) return -1
            val length = minOf(count, maxRead, bytes.size - offset.toInt())
            bytes.copyInto(target, targetOffset, offset.toInt(), offset.toInt() + length)
            bytesRead += length
            return length
        }
        override fun close() { closed = true }
    }

    // Independent JCE framing and HKDF implementation intentionally avoid production crypto helpers.
    private fun independentWrappingKey(header: ByteArray, password: CharArray?): ByteArray {
        val global = EcosystemBuildKey.bytes()
        val salt = header.copyOfRange(8, 24)
        val extra = if (password == null) byteArrayOf() else {
            val spec = PBEKeySpec(password, salt, 600000, 256)
            try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
            finally { spec.clearPassword() }
        }
        fun hmac(key: ByteArray, input: ByteArray) = Mac.getInstance("HmacSHA256").run { init(SecretKeySpec(key, "HmacSHA256")); doFinal(input) }
        val input = global + extra
        val extracted = try { hmac(salt, input) } finally { global.fill(0); extra.fill(0); input.fill(0) }
        return try { hmac(extracted, "Dualscan portable container v2 key wrapping".toByteArray() + byteArrayOf(1)) }
        finally { extracted.fill(0) }
    }
    private fun independentCipher(mode: Int, key: ByteArray, header: ByteArray, counter: Long, aad: ByteArray) =
        Cipher.getInstance("AES/GCM/NoPadding").apply {
            val nonce = header.copyOfRange(24, 36)
            for (index in 0..7) nonce[11 - index] = (nonce[11 - index].toInt() xor (counter ushr (index * 8)).toInt()).toByte()
            init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce)); updateAAD(aad)
        }
    private fun independentDecode(bytes: ByteArray, password: CharArray?): Pair<JSONObject, ByteArray> {
        val prefix = bytes.copyOfRange(0, 64)
        val wrapping = independentWrappingKey(prefix, password)
        val key = try { independentCipher(Cipher.DECRYPT_MODE, wrapping, prefix, Long.MAX_VALUE, prefix + byteArrayOf(2))
            .doFinal(bytes.copyOfRange(64, 112)) } finally { wrapping.fill(0) }
        val header = bytes.copyOfRange(0, 112)
        val clear = independentCipher(Cipher.DECRYPT_MODE, key, header, 0, header + byteArrayOf(0))
            .doFinal(bytes.copyOfRange(112, 112 + manifestLength(bytes)))
        return try { JSONObject(String(clear, Charsets.UTF_8)) to key } finally { clear.fill(0) }
    }
    private fun independentFixture(password: CharArray?): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256").digest(document).joinToString("") { "%02x".format(it.toInt() and 255) }
        val item = JSONObject().put("id", "media-000001").put("displayName", "message.txt").put("mimeType", "text/plain")
            .put("relativePath", "Documents/message.txt").put("sizeBytes", document.size).put("sha256", digest)
            .put("index", 0).put("dataOffset", 0).put("firstCounter", 1).put("chunkCount", 1)
        val manifest = JSONObject().put("format", "dualscan-portable").put("schemaVersion", 2)
            .put("id", "e668e4b9-9101-4e6f-b7ce-e8f7416d79d2").put("title", "Independent fixture")
            .put("chunkBytes", MediaArray.CHUNK_BYTES).put("entries", JSONArray().put(item)).put("backupMetadata", JSONObject.NULL)
            .toString().toByteArray()
        val global = EcosystemBuildKey.bytes()
        val identifier = try { MessageDigest.getInstance("SHA-256").digest(global).copyOf(16) } finally { global.fill(0) }
        val prefix = ByteBuffer.allocate(64).put("DSMP0002".toByteArray()).put(ByteArray(16) { it.toByte() })
            .put(ByteArray(12) { (it + 20).toByte() }).putInt(if (password == null) 0 else 600000).putInt(manifest.size + 16)
            .put(if (password == null) 0.toByte() else 1.toByte()).put(byteArrayOf(0, 0, 0)).put(identifier).array()
        val wrapping = independentWrappingKey(prefix, password)
        val key = ByteArray(32) { (it + 55).toByte() }
        try {
            val wrapped = independentCipher(Cipher.ENCRYPT_MODE, wrapping, prefix, Long.MAX_VALUE, prefix + byteArrayOf(2)).doFinal(key)
            val header = prefix + wrapped
            val encryptedManifest = independentCipher(Cipher.ENCRYPT_MODE, key, header, 0, header + byteArrayOf(0)).doFinal(manifest)
            val aad = ByteBuffer.allocate(129).put(header).put(1.toByte()).putInt(0).putLong(0).putInt(document.size).array()
            return header + encryptedManifest + independentCipher(Cipher.ENCRYPT_MODE, key, header, 1, aad).doFinal(document)
        } finally { wrapping.fill(0); key.fill(0); manifest.fill(0) }
    }
}
