# Dualscan offline interchange core

`interchange-core` supplies the same `com.dualscan.mp.core` API to Share and Diamond Player. It keeps the legacy DSMP0001 reader and writer and adds the always-encrypted DSMP0002 portable format. The extension (`.dshare` or `.dmpa`) does not determine the cryptographic format. Legacy Share ZIP/DSHP0001 archives remain handled by Share's compatibility reader.

## Build key

Build both apps with the same **32 raw bytes** in an external key file. The default location is `~/.local/share/dualscan-research/keys/ecosystem-v1.key`; override with Gradle property `dualscanEcosystemKeyFile` or environment variable `DUALSCAN_ECOSYSTEM_KEY_FILE`. The Gradle task generates its package-private Java key source under the module's `build/generated/ecosystemKey`, outside checked-in source. Never include that generated source, the private key file, Gradle caches, or build intermediates in a source delivery.

Retain an access-controlled backup of this key separately from source archives. A different key creates a different ecosystem and cannot unlock earlier DSMP0002 files. `MediaArray.ecosystemKeyId` is a safe non-secret identifier (first 16 SHA-256 bytes rendered as hex) for matching build configurations.

The APK must contain sufficient key material to open default files offline. A determined person can extract that shared key from an APK or a running device. The global mode provides encrypted portable storage and app interoperability; it does not provide device-bound DRM, revocation, or protection from other holders of the shared key. The optional password adds an independent user secret. Neither mode makes a firmware image authentic or authorizes installing firmware.

## Public API

```kotlin
MediaArray.createPortable(output, title, inputs, password = null, metadata = null)
MediaArray.open(fileOrRandomAccessSource, password = null)
MediaArray.isPortable(fileOrRandomAccessSource)
MediaArray.isSupported(fileOrRandomAccessSource)
```

`createPortable` always encrypts. A null password selects global mode. A nonnull password must contain 8–256 characters and selects global-plus-password mode. An empty character array is an invalid password, not a request for global mode. The library borrows caller password arrays without modifying them.

`open` takes ownership of `RandomAccessSource`, closing it on every failure and when the returned array closes. It throws `PasswordRequiredException` only when a supported password-protected format needs a missing password. Wrong passwords, tampering, and unsupported files produce an ordinary `IOException` rather than another password-required exception. Detection helpers borrow sources and never close them. File overloads own their temporary file handles.

`UnlockedMediaArray.catalog` contains authenticated paths, MIME types, sizes, SHA-256 values, and optional track/disc numbers. `catalog.backupMetadata` carries optional authenticated JSON for Share-specific device, backup-kind, inventory, or OEM metadata; it is never used directly as an extraction path. `isPortable` and `passwordProtected` describe the opened format. `readAt` authenticates each complete chunk before returning bytes from that chunk; `openEntry` exposes the same reader as a stream without taking ownership of the array. `verifyAll` reads every chunk and checks every original SHA-256 without creating plaintext files. Opening alone authenticates metadata and validates all lengths/indexes; payload verification is lazy until read or `verifyAll`.

## DSMP0002 framing

All integer fields are unsigned-compatible nonnegative values serialized big endian, except counters stored in signed 64-bit Java/Kotlin values. Header fields:

| Offset | Bytes | Value |
| --- | ---: | --- |
| 0 | 8 | ASCII `DSMP0002` |
| 8 | 16 | Random salt |
| 24 | 12 | Random base nonce |
| 36 | 4 | PBKDF2 iterations: 0 global, 600000 password |
| 40 | 4 | Encrypted manifest length including GCM tag |
| 44 | 1 | Mode: 0 global, 1 global plus password |
| 45 | 3 | Reserved, must be zero |
| 48 | 16 | Ecosystem key identifier |
| 64 | 48 | Random 32-byte data encryption key wrapped with AES-256-GCM |

The 64-byte prefix is authenticated as wrapping AAD, followed by byte `2`. The wrapping nonce XORs `Long.MAX_VALUE` into the last eight bytes of the base nonce. The wrapping key is HKDF-SHA256: extract using the random salt and input `ecosystemKey || passwordKey`, with `passwordKey` empty in global mode or PBKDF2-HMAC-SHA256(password, salt, 600000, 256 bits) in password mode; expand with ASCII `Dualscan portable container v2 key wrapping` followed by byte `1`. A fresh random data key is generated for every container. Header mode and password parameters are authenticated; editing them cannot downgrade a password-protected file.

The encrypted manifest follows the 112-byte header. It uses the random data key, nonce counter 0, and AAD `header || byte(0)`. Its JSON format is `dualscan-portable`, schema 2, with the same indexed entry layout as DSMP0001 plus nullable `backupMetadata` JSON string. Data follows the manifest with consecutive global nonce counters starting at 1. Each entry is split into independently authenticated 1 MiB chunks, with a shorter final chunk as necessary. Empty files have no data chunks. Data AAD is `header || byte(1) || entryIndex:int32 || localChunkIndex:int64 || clearLength:int32`. Counter bytes are XORed into the last eight bytes of the base nonce. The authenticated manifest fixes every data offset, size, count, entry index, and first counter. Missing or trailing bytes are rejected.

The writer hashes reopenable inputs before encryption and compares the complete byte count and hash again while writing. If a provider changes or disconnects, the incomplete output is deleted. Reading and writing use bounded buffers, never a plaintext staging file. The existing Tella-derived `MainKey`/`Wiper` helpers retain their MIT notices. Wiping clears owned arrays on a best-effort basis; JVM/provider/decoder copies cannot be guaranteed erased.

## Bounds and content policy

Payloads total at most 32 GiB, at most 10000 entries, 240-character normalized names, 2048-character relative paths, and 32 path segments. NFC and conservative case folding reject ambiguous duplicate paths. Paths must be relative and end in the supplied filename, with no traversal, backslashes, control characters, or empty components. Portable containers accept media and public document MIME types with a bounded syntax, while rejecting application packages, executable extensions/MIME types, and `Android/data` or `Android/obb` paths. App-level source selection must additionally enforce public-folder/document-provider policy.

The legacy manifest limit stays 8 MiB. Portable manifests are limited to 16 MiB, including a maximum 8 MiB UTF-8 optional backup metadata object. Empty inventory-only portable containers require nonnull valid backup metadata; ordinary media collections must contain at least one entry. Track and disc numbers, when present, are integers 1–9999. Bounds, types, and all indexes are checked again after authentication before playback or extraction.

## Verification

`PortableCoreTest` covers global and password round trips, documents and media, unchanged legacy reads, independently implemented JCE readers and writers, fresh encryption randomness, password downgrade tampering, header/manifest/chunk corruption, short reads and random seeks, truncation/trailing data, source ownership and changes, rejected application/private paths, metadata limits, inventory-only archives, and cleanup. Existing legacy core tests remain in the Player app test suite.
