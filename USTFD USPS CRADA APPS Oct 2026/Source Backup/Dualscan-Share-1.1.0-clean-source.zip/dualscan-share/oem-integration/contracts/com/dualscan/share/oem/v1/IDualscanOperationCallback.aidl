package com.dualscan.share.oem.v1;

/** DESIGN EXAMPLE ONLY. Callbacks are untrusted input at the receiving UI. */
oneway interface IDualscanOperationCallback {
    // totalBytes == -1 means unknown; progress must not invent a percentage.
    void onProgress(String operationId, long completedBytes, long totalBytes, String phase);

    // Only one terminal callback is allowed. Neither callback proves USB durability.
    void onComplete(String operationId, String resultJson);
    void onFailure(String operationId, String reasonCode, String safeMessage);
}
