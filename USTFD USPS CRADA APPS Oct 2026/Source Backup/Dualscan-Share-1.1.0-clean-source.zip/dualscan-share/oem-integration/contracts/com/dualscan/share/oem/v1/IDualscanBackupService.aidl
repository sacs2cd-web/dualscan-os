package com.dualscan.share.oem.v1;

import android.os.ParcelFileDescriptor;
import com.dualscan.share.oem.v1.IDualscanOperationCallback;

/**
 * DESIGN EXAMPLE ONLY. Not included in the Lite APK, not a running service.
 * Implementations require OEM permission/signature/caller checks on every call.
 * JSON bounds, enums, cancellation and FD ownership are specified in README.txt.
 * No password, key, filesystem path or partition-install operation is accepted.
 */
interface IDualscanBackupService {
    // Small synchronous handshake. Echo requestNonce; report capabilities separately.
    String getCapabilitiesJson(String requestNonce);

    // Return a unique operation ID immediately. Long capture work is asynchronous.
    // destination is a non-seekable pipe WRITE end; the app owns the READ end and
    // encrypts every exported byte before its USB-only storage writer receives it.
    String startExport(String requestJson, in ParcelFileDescriptor destination,
                       IDualscanOperationCallback callback);

    // Idempotent; restricted to the authenticated operation owner/user.
    void cancel(String operationId);
}
