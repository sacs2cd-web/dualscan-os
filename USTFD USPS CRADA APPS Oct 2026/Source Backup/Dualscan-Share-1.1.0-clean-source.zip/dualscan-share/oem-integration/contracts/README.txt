Dualscan OEM Binder export contract v1 — proposal, not an implemented service

These AIDL files live outside app/src and are not compiled into the Lite APK.
They define one possible OEM export boundary for ODM implementation/review.
They do not expose hidden framework APIs, root operations, raw partition reads,
firmware installation, passwords, cryptographic keys or a network destination.
The separately reviewed updater and any restore/staging contract need their own
permissions, validation and release acceptance; export does not authorize them.

The ordinary Lite app needs no OEM service for user-selected shared folders/files
such as Documents, Download, Music, Pictures, DCIM and Movies. Its access is limited
to real system-picker grants; APKs, app inventory and app-private data are excluded.
Android 11+ tree-picker restrictions still apply to storage roots, Download root,
Android/data and Android/obb. Offer allowed subfolder/file selection; never imply
that a rejected root was captured. Generic SAF restore retains validated relative
paths, while direct MediaStore restore remains limited to Music/Pictures/Movies.
These portable capabilities must not be inferred from an OEM service response.

Identity and permission
- Bind only to the configured explicit service component. Before binding, verify
  the installed package certificate/approved rotation lineage and build policy.
- Protect the service using a custom android:protectionLevel="signature"
  permission, for example com.dualscan.share.permission.OEM_BACKUP. The OEM must
  align actual service/client signers so the declared grant is valid. Do not
  replace this with a normal permission just to make a preview APK bind.
- Authenticate Binder.getCallingUid(), allowed package signer and user on each
  entry point, including cancel. A caller-supplied package/user field is not proof
  of identity. Framework/transport and SELinux privileges remain separate grants.
- Refuse binding if the OEM build is unsupported. Unknown service, wrong signer,
  permission denial or Binder death leaves all OEM capabilities unavailable.

getCapabilitiesJson
- requestNonce is a fresh 32-byte random value encoded as lowercase hex. Accept
  exactly 64 ASCII hex characters and echo it. The nonce detects stale responses;
  Binder authentication and certificate pinning establish trust, not the nonce.
- Return UTF-8 JSON no larger than 64 KiB. schemaVersion=1 is the major version.
  Return explicit per-capability state, reasonCode, implementationVersion, scopes
  and eligibleUserIds. Allowed states: available, unavailable, needsUserUnlock,
  needsUserConsent. Missing/unknown states or keys deny that capability.
- Device/product/build fields must match an ODM-approved compatibility policy.
  Never derive availability solely from manufacturer/model or preinstallation.
- The unavailable example is intentionally all-denied and is not a success mock.
  No global support boolean or implication from updater to backup is permitted.
- Bound JSON depth/arrays/string lengths and reject duplicate keys. Do not put
  tokens, account names, app private contents or secrets in a capability response.

startExport
- requestJson is UTF-8 JSON <=16 KiB, strict schemaVersion=1. Fields should include
  capability, capabilityImplementationVersion, requested scopes, expected
  product/device/build, requestNonce, user-consent token and operation policy.
  Treat every field as untrusted, and reject unknown/conflicting combinations.
  Use an OS-owned single-use consent token bound to caller UID, actual Android
  user, requested scopes and short expiry; a boolean consent=true is insufficient.
- Recheck capability, current build, actual user unlock, consent, transport state,
  quotas and app backup policy before capture. Default-deny unsupported scopes.
  Do not accept requests for hidden accounts/keys, arbitrary paths, raw block
  devices, system partitions or a change to another Android user/profile.
- Perform only short validation synchronously and return a random operation ID.
  Work and callbacks run asynchronously; never block Binder threads for capture.
  The client must tolerate an early callback arriving before startExport returns.
- destination is the WRITE end of a ParcelFileDescriptor pipe. The app retains
  the READ end. Adopt an owned duplicate within the service, then close the
  incoming PFD after setup; each process closes its own descriptors. Reject any
  unexpected descriptor type. Support non-seekable sequential output only.
- Capture a documented, versioned export stream with declared categories and
  consistency/eligibility metadata. It must end with verified final totals/hash.
  Define and qualify that stream format before enabling the capability. A raw
  userdata dump is neither this stream nor a portable backup.
- The app reads the service stream privately, applies its password-derived
  authenticated archive encryption and writes the protected archive to a verified
  USB-C destination. The service never receives the password or derived key and
  never writes plaintext to USB. Pipe backpressure bounds buffering. Preserve
  user cancellation even when a producer is blocked by a slow/disconnected drive.
- onComplete is permitted only after full capture, final metadata and descriptor
  closure. The app separately completes archive authentication, USB write and
  read-back before displaying export success. A callback alone is not success.

Progress, cancellation and failure
- onProgress reports nonnegative completedBytes; totalBytes=-1 means unknown.
  Otherwise 0 <= completedBytes <= totalBytes. Define progress phases as bounded
  enum strings: VALIDATING, CAPTURING, FINALIZING. Unknown values are nonfatal
  display text only; they grant no state transition. Rate-limit callbacks.
- Exactly one terminal callback: onComplete or onFailure. resultJson <=16 KiB
  includes schemaVersion, actual scopes/user, stream version/bytes/SHA-256 and
  excluded-category reason codes. It contains no credentials or raw app contents.
- cancel is idempotent and restricted to the initiating UID/user. Close the pipe,
  signal the worker and cleanup staged capture. No timeout/late callback may turn
  a cancelled/failed operation into success. Never reuse operation IDs.
- Link callback death; cancel on client death. Client cancels on service death,
  revoked grant, user lock, USB disconnect or encryption/writer failure. Stop
  producers, close all descriptors and remove incomplete encrypted output when
  possible. Do not retry into another destination or widen capture permissions.
- Safe reason codes include NOT_AUTHORIZED, CAPABILITY_UNAVAILABLE,
  DEVICE_BUILD_MISMATCH, USER_LOCKED, CONSENT_REQUIRED, EXCLUDED_BY_APP_POLICY,
  BUSY, NO_SPACE, IO_FAILURE, CANCELLED and INTERNAL_FAILURE. Logs/callbacks must
  omit passwords, keys, content, account tokens and sensitive paths.

Acceptance is governed by docs/OEM-ODM-INTEGRATION.txt. The ODM must implement
and validate this contract on shipping firmware before an OEM capability is shown
as available; these examples do not confer Golden Master approval.
