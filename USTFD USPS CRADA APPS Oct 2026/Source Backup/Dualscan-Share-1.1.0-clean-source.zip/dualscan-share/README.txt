DUALSCAN SHARE 1.1.0 — DEVELOPMENT RELEASE CANDIDATE

1.1.0 creates encrypted DSMP0002 images that Diamond Player can open directly.
Leaving the optional password empty uses the shared Dualscan application key;
adding an 8–256 character password adds a password-derived key requirement.
The shared key provides application interoperability, not private user-only
protection or a DRM boundary: it is distributed in both APKs and can be extracted
by someone who inspects them. Use the optional password for private backups.
New images contain seekable authenticated chunks, with no plaintext ZIP staging.
Old DSHP0001 password-protected ZIPs and plain legacy ZIPs remain read-only inputs.
An old password-protected image still needs its original password.

1.0.1 fixes a foreground-service startup/stop race that could close the app after
quick source checks or image validation. Archive work now waits for Android's
foreground-service acknowledgement; cancellation/completion before service
creation is deferred until foreground promotion. Both editions receive the fix.

Independent Android shared-file and media backup/restore, with an OEM artifact edition.
Minimum Android 8.0 (API 26); target API 36. No Internet permission.

EDITIONS
- Lite: com.dualscan.share.lite, label Dualscan Share Lite.
  Selected accessible local files/folders, including documents and media; no apps or app inventory.
- OEM: com.dualscan.share, label Dualscan Share.
  Same file/media workflow plus packaging already-built OEM update artifacts.
  Does not capture protected partitions, sign firmware or install firmware.

BUILD (JDK 21, Android SDK 36)
  ./gradlew :app:testLiteDebugUnitTest :app:testOemDebugUnitTest
  ./gradlew :app:assembleLiteDebug :app:assembleOemDebug
  ./gradlew :app:assembleLiteDebugAndroidTest :app:lintLiteDebug :app:lintOemDebug
  ./gradlew :app:assembleLiteRelease :app:assembleOemRelease

Installable development APKs:
  app/build/outputs/apk/lite/debug/app-lite-debug.apk
  app/build/outputs/apk/oem/debug/app-oem-debug.apk
Unsigned OEM release candidates:
  app/build/outputs/apk/lite/release/app-lite-release-unsigned.apk
  app/build/outputs/apk/oem/release/app-oem-release-unsigned.apk
No production/OEM signing key is embedded or borrowed from another app. Debug builds
use Android's development certificate. ODM production signing and hardware
acceptance are still required; this is not Golden Master certification.

USB-ONLY WORKFLOW
1. Preview the app on a normal Android device; OEM privileges are not needed.
2. Choose local files or add an accessible local folder and subfolders.
   Documents, Music, Movies, Pictures, DCIM and other granted shared folders
   are supported; relative folder paths are preserved. Known cloud providers
   and photo-picker cloud routes are rejected before input is opened. APK,
   APKM/APKS/XAPK/AAB and app runtime files are excluded. Folder scans report
   skipped application packages; explicit package picks are rejected.
   Android 11+ blocks storage roots, the Download root and Android/data/obb in
   the folder picker. Individually accessible Downloads files and permitted
   subfolders can still be selected. Android's grants determine coverage.
3. Attach/mount a USB-C/OTG storage drive. Optionally set and confirm an 8–256
   character password; leave both fields empty for direct Diamond Player access.
   Create the .dshare backup image. Every newly created image is encrypted.
4. Save to USB-C / removable drive. Only Android's external-storage document
   provider and a mounted removable volume UUID are accepted, with an attached
   USB mass-storage interface. Other archive providers/primary storage fail.
5. Keep the drive attached until SHA-256 destination read-back verification
   finishes. If read-back is unavailable, the app explicitly reports that the
   copy is unverified. Incomplete/invalid app-created outputs are removed when
   the provider permits deletion. Use Android's eject control before removal.
6. On another device, insert the drive and Open image from USB-C. Enter a password
   only if the image requests one. The archive is fully authenticated and all
   payload hashes checked before preview or restoration. Legacy unencrypted
   archives are labeled. Diamond Player opens new .dshare files to play their
   audio/video/photos directly, ignoring ordinary document and OEM payloads.
7. On all supported Android versions, restore selected files to a local
   folder you choose. A new Dualscan-Restore folder preserves the archived
   relative paths. Every output is read back and SHA-256 verified; a failure
   attempts to remove the new output folder. Existing files are not overwritten.
   Android 10+ also offers a separate direct-media route: select only audio,
   pictures and videos, then decrypt to Music/DualscanShare, Pictures/DualscanShare
   or Movies/DualscanShare. MediaStore outputs stay pending until every output's
   size/SHA-256 read-back is verified. Mixed documents use the folder route.
8. Close image to clear its password and remove its private working copy.
   Working copies are also removed when replacing an image or restarting the
   app. USB source/destination files are never deleted by closing a preview.

BOUNDARIES
- No Internet, cloud backup, system backup/restore, general share sheet, app
  inventory, accounts, app-private data, passwords or protected partitions.
- Lite is a selected shared-file image, not a full OS or full phone state image.
- OEM wraps supplied image/update files as opaque artifacts with declared
  device/build metadata. Hashes do not establish firmware authenticity.
- Public Android APIs cannot reliably map each removable volume to USB vs SD
  while USB is attached, nor prove the physical connector is USB-C. The app
  reports mounted removable storage plus USB attachment; choose USB explicitly.
- Optional passwords cannot be recovered. New ciphertext uses bounded AES-256-GCM
  chunks and authenticated encrypted catalog metadata; Share fully authenticates
  and SHA-256 verifies all payloads before exposing a preview or restore output.
  New-image validation and playback require no plaintext ZIP staging. Legacy
  DSHP0001 inputs still use ephemeral app-private plaintext ZIP files, removed on
  completion and abandoned files purged at startup. An explicit user-requested
  restore writes decrypted files to the destination the user chooses.
  App data is excluded from cloud/device backup. Keep sufficient local free
  space for staging and do not rely on a single drive copy.
- Long operations use a dataSync foreground service and a bounded wake lock.
  Android/process death, device policies, drive removal and the platform's
  time limit can still interrupt a transfer. Interrupted work is not resumed.
- Maximum payload: 32 GiB and 10,000 entries per archive; private staging requires
  additional free space. Folder paths are limited to 32 segments and 1024
  characters; the manifest is capped at 8 MiB. FAT32 drives impose their own lower file-size limit.

ARTWORK
User-supplied original pixels are byte-for-byte preserved at:
  app/src/main/res/drawable-nodpi/dualscan_share_artwork.png
Launcher foreground uses a centered inset for adaptive circle/squircle masks.
No Samsung, postal-service or reference-APK branding/components are included.

See docs/OEM-ODM-INTEGRATION.txt for OEM/ODM handoff and platform boundaries.
See docs/OFFLINE-INTERCHANGE-HANDOFF.txt for same-key build provisioning,
separate private-key backup requirements, legacy compatibility and Tella credits.
See verification/ for build/test outputs and the root delivery report for
actual Android emulator tests vs unverified physical USB-C hardware testing.

1.1.0 INTERCHANGE VERIFICATION
PortableShareInterchangeTest covers default encrypted creation, Diamond codec
access, optional-password isolation, full verification before any restore
destination, metadata/relative folders and byte-exact mixed-media/document restore.
PortableShareInteropInstrumentedTest produces share-global.dshare,
share-password.dshare and share-fixture.json through the actual Share ArchiveEngine
in private files/exports. These public test fixtures contain synthetic 24-bit
192 kHz PCM WAV, a 2x2 PNG and a text document. Diamond's instrumented consumer
compares full decrypted PCM and artwork bytes/pixels. Runtime results and exact APK
hashes belong in the current delivery verification report; test source alone does
not establish that a run passed. Fixtures are test-only, never app startup data.

The interchange-core and tella-keys-core source modules are included with this
project. Interoperable rebuilds also require the same 32-byte ecosystem key file
used for both Share and Diamond. Supply its protected OEM handoff path through
-PdualscanEcosystemKeyFile=/absolute/path/to/key or DUALSCAN_ECOSYSTEM_KEY_FILE;
the default is ~/.local/share/dualscan-research/keys/ecosystem-v1.key. The source
archive does not include that raw key. Keep its backup with controlled release
materials: generating a replacement would make old default-key images unreadable
to that replacement app. The key is compiled into APKs for offline use and can be
extracted; it does not provide password-grade privacy. Tella license/provenance is retained in
third_party and the application legal assets. Legacy DSHP test vectors remain
to verify backwards-compatible restoration.
Compiled Tella-derived scope is MainKey/Wiper only under MIT (copyright 2025
Horizontal). The upstream unauthenticated AES-CTR helper is retained as an audit
reference and is never compiled or used for these images.

1.0.1 REGRESSION RECORDS
The delivery packager requires six actual Lite instrumentation tests on both
Android 14 (API 34) and Android 16 (API 36), with recorded APK hashes matching the
delivered Lite APK. These include immediate transfer completion before Android
creates the foreground service, and recoverable file/folder/create validation
failures observed beyond Android's service-start grace period. Folder-selection
UI evidence and independently verified Android-produced encrypted fixtures must
also identify this APK. The resulting report records the actual run and evidence
hashes. Emulator lifecycle checks do not qualify real USB hardware or OEM firmware.
Version 1.0.1 is packaged into dist-1.0.1; prior delivery folders are retained.
The separate verification ZIP preserves the reproduced 1.0.0 crash and current
1.0.1 regression/UI records with an evidence hash manifest. APKs, signing keys
and unrelated reference analysis are excluded from that evidence ZIP.
