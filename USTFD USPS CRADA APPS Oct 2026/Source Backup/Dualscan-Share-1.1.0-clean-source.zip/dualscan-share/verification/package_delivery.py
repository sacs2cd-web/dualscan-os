"""Package already-built Dualscan Share 1.1.0 candidates; never signs/rebuilds.

Requires final build/lint/JVM and actual API36 instrumentation evidence. Only
allowlisted source/config/docs/reproducer scripts enter the source ZIP. The
external content key, generated source, SDK paths, caches and signing keys do not.
"""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

VERSION = "1.1.0"
VERSION_CODE = 3
project = Path(__file__).resolve().parents[1]
dist = project / f"dist-{VERSION}"
dist.mkdir(exist_ok=True)
sdk = Path(os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or
           Path.home() / "Library/Android/sdk")
build_tools = sdk / "build-tools/36.0.0"
aapt, apksigner = build_tools / "aapt", build_tools / "apksigner"
key_file = Path(os.environ.get("DUALSCAN_ECOSYSTEM_KEY_FILE") or
                Path.home() / ".local/share/dualscan-research/keys/ecosystem-v1.key").expanduser()
key_bytes = key_file.read_bytes()
assert len(key_bytes) == 32, "Provision the same 32-byte ecosystem build key used by both apps"
key_id = hashlib.sha256(key_bytes).hexdigest()[:32]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*arguments, allow_failure=False):
    result = subprocess.run([str(arg) for arg in arguments], capture_output=True, text=True)
    if not allow_failure:
        result.check_returncode()
    return result


def tests(module, task, minimum):
    suites = []
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    for file in sorted((project / module / "build/test-results" / task).glob("TEST-*.xml")):
        root = ET.parse(file).getroot()
        counts = {name: int(root.attrib[name]) for name in totals}
        suites.append({"suite": root.attrib["name"], **counts})
        for name, count in counts.items():
            totals[name] += count
    assert totals["tests"] >= minimum, (module, task, totals)
    assert totals["failures"] == totals["errors"] == totals["skipped"] == 0, (module, task, totals)
    return {"module": module, "task": task, "totals": totals, "suites": suites}


units = {variant: tests("app", f"test{variant.title()}DebugUnitTest", 88)
         for variant in ("lite", "oem")}
units["interchange-core"] = tests("interchange-core", "testDebugUnitTest", 15)
units["tella-keys-core"] = tests("tella-keys-core", "test", 7)
build_log = project / "verification/build-interchange-1.1.0.txt"
statuses = re.findall(r"BUILD (SUCCESSFUL|FAILED)", build_log.read_text())
assert statuses and statuses[-1] == "SUCCESSFUL", "Final build record must end in BUILD SUCCESSFUL"

lint = {}
for variant in ("lite", "oem"):
    path = project / f"app/build/reports/lint-results-{variant}Debug.xml"
    issues = ET.parse(path).getroot().findall("issue")
    severities = collections.Counter(issue.attrib["severity"] for issue in issues)
    assert not (severities["Error"] or severities["Fatal"]), (variant, severities)
    lint[variant] = {"severityCounts": dict(severities),
                     "warningIds": dict(collections.Counter(issue.attrib["id"] for issue in issues))}

# Enumerate only explicit source roots. Never recursively package whole modules:
# interchange-core/build contains the generated embedded-key implementation.
fixed = [".gitignore", "README.txt", "build.gradle.kts", "settings.gradle.kts",
         "gradle.properties", "gradlew", "gradlew.bat", "app/build.gradle.kts",
         "app/proguard-rules.pro", "interchange-core/build.gradle.kts",
         "interchange-core/FORMAT.md", "tella-keys-core/build.gradle.kts"]
roots = ("app/src", "gradle", "docs", "oem-integration/contracts",
         "interchange-core/src", "tella-keys-core/src", "third_party/tella")
allowed = {Path(name) for name in fixed}
for root in roots:
    allowed.update(path.relative_to(project) for path in (project / root).rglob("*") if path.is_file())
allowed.update(path.relative_to(project) for path in (project / "verification").rglob("*")
               if path.is_file() and path.suffix in (".py", ".mjs", ".js", ".sh"))
for relative in allowed:
    assert not (project / relative).is_symlink(), relative
    assert not any(part in ("build", ".gradle", ".kotlin", ".git", "node_modules") for part in relative.parts), relative
    assert relative.name not in ("local.properties", "EcosystemBuildKey.kt", "EcosystemBuildKey.java", "ecosystem-v1.key"), relative
    assert relative.suffix.lower() not in (".apk", ".key", ".jks", ".keystore", ".pem", ".p12", ".pfx"), relative
source = {str(path): (project / path).read_bytes() for path in sorted(allowed)}
for name, data in source.items():
    assert key_bytes not in data, f"Raw ecosystem key must not enter source archive: {name}"
    assert not re.search(rb"(?m)^\s*internal\s+object\s+EcosystemBuildKey\b", data), f"Generated key source must not enter source archive: {name}"
# Generator references are allowed; generated object definitions under build/ are not.
compiled_tella = {str(path.relative_to(project / "tella-keys-core/src/main/java"))
                  for path in (project / "tella-keys-core/src/main/java").rglob("*") if path.is_file()}
assert compiled_tella == {"org/hzontal/tella/keys/key/MainKey.java", "org/hzontal/tella/keys/util/Wiper.java"}
tella_license = source["third_party/tella/LICENSE"]
assert tella_license.startswith(b"MIT License") and b"2025 Horizontal" in tella_license
assert source["app/src/main/assets/legal/TELLA-LICENSE"] == tella_license
assert source["app/src/main/assets/legal/TELLA-NOTICE.txt"] == source["third_party/tella/NOTICE.txt"]
assert "b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc" in source["third_party/tella/PROVENANCE.md"].decode()
assert {"interchange-core/src/main/java/com/dualscan/mp/core/MediaArray.kt",
        "interchange-core/src/main/java/com/dualscan/mp/core/MediaArrayModels.kt"} <= source.keys()
assert "include(\":interchange-core\"" in source["settings.gradle.kts"].decode()
assert "include(\":interchange-core\", \":tella-keys-core\")" in source["settings.gradle.kts"].decode()
production_paths = [project / name for name in source if
                    name.startswith(("app/src/main/", "interchange-core/src/main/", "tella-keys-core/src/main/")) or
                    name in ("app/build.gradle.kts", "interchange-core/build.gradle.kts", "tella-keys-core/build.gradle.kts",
                             "build.gradle.kts", "settings.gradle.kts", "gradle.properties", "gradle/libs.versions.toml")]
newest_production = max([path.stat().st_mtime_ns for path in production_paths] + [key_file.stat().st_mtime_ns])
generated_key_source = project / "interchange-core/build/generated/ecosystemKey/com/dualscan/mp/core/EcosystemBuildKey.java"
generated_array = re.search(r"new\s+byte\[\]\s*\{([-0-9,\s]+)\}", generated_key_source.read_text())
assert generated_array, "Generated build-key source is missing or unsupported"
assert bytes(int(value.strip()) & 255 for value in generated_array.group(1).split(",")) == key_bytes, "Generated build key differs from the provisioned key"

artifacts = []
for variant in ("lite", "oem"):
    for kind in ("debug", "release"):
        suffix = "-unsigned" if kind == "release" else ""
        original = project / f"app/build/outputs/apk/{variant}/{kind}/app-{variant}-{kind}{suffix}.apk"
        assert original.stat().st_mtime_ns >= newest_production, f"Rebuild stale {original}"
        destination = dist / f"Dualscan-Share-{variant.title()}-{VERSION}-{'development' if kind == 'debug' else 'release-unsigned'}.apk"
        shutil.copy2(original, destination)
        data = destination.read_bytes()
        badging = run(aapt, "dump", "badging", destination).stdout
        manifest = run(aapt, "dump", "xmltree", destination, "AndroidManifest.xml").stdout
        permissions = re.findall(r"^uses-permission: name='([^']+)'", badging, re.MULTILINE)
        assert "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging
        assert "android.permission.INTERNET" not in permissions
        assert re.search(r"android:allowBackup.*=\(type 0x12\)0x0", manifest)
        expected_id = "com.dualscan.share.lite" if variant == "lite" else "com.dualscan.share"
        assert f"package: name='{expected_id}' versionCode='{VERSION_CODE}' versionName='{VERSION}'" in badging
        with zipfile.ZipFile(destination) as apk:
            assert apk.read("assets/legal/TELLA-LICENSE") == tella_license
            assert apk.read("assets/legal/TELLA-NOTICE.txt") == source["third_party/tella/NOTICE.txt"]
            assert apk.read("assets/legal/DUALSCAN-INTERCHANGE-NOTICE.txt") == source["app/src/main/assets/legal/DUALSCAN-INTERCHANGE-NOTICE.txt"]
            for entry in apk.infolist():
                assert not entry.filename.endswith((".key", "EcosystemBuildKey.kt", "EcosystemBuildKey.java")), entry.filename
                if not entry.is_dir() and not entry.filename.endswith(".dex"):
                    assert key_bytes not in apk.read(entry), f"No raw ecosystem-key asset allowed: {entry.filename}"
        signature = run(apksigner, "verify", "--print-certs", destination, allow_failure=True)
        if kind == "debug":
            assert signature.returncode == 0
            certificate = re.search(r"certificate SHA-256 digest: ([0-9a-f]{64})", signature.stdout).group(1)
        else:
            assert signature.returncode != 0 and "Signer #" not in signature.stdout
            with zipfile.ZipFile(destination) as apk:
                assert not any(re.match(r"META-INF/.*\.(RSA|DSA|EC)$", name) for name in apk.namelist())
            certificate = None
        artifacts.append({"file": destination.name, "bytes": len(data), "sha256": sha(data),
                          "edition": variant, "applicationId": expected_id, "versionCode": VERSION_CODE, "versionName": VERSION,
                          "minSdk": 26, "targetSdk": 36, "permissions": permissions, "allowBackup": False,
                          "signature": "verified-development-signature" if kind == "debug" else "unsigned-requires-ODM-signing",
                          "signerCertificateSha256": certificate, "installableAsDelivered": kind == "debug"})

source_manifest = (json.dumps({"schemaVersion": 1, "files": [
    {"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in sorted(source.items())
]}, indent=2) + "\n").encode()
source_archive = dist / f"Dualscan-Share-{VERSION}-clean-source.zip"
with zipfile.ZipFile(source_archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted({**source, "SOURCE-MANIFEST.json": source_manifest}.items()):
        entry = zipfile.ZipInfo("dualscan-share/" + name, date_time=(2026, 10, 16, 12, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = (0o100755 if name in ("gradlew", "gradlew.bat") else 0o100644) << 16
        bundle.writestr(entry, data)
with zipfile.ZipFile(source_archive) as bundle:
    assert bundle.testzip() is None and len(bundle.namelist()) == len(source) + 1
    for name, data in source.items():
        assert sha(bundle.read("dualscan-share/" + name)) == sha(data), name
    assert sha(bundle.read("dualscan-share/SOURCE-MANIFEST.json")) == sha(source_manifest)
for name, data in source.items():
    assert (project / name).read_bytes() == data, f"Source changed during packaging: {name}"
artifacts.append({"file": source_archive.name, "bytes": source_archive.stat().st_size,
                  "sha256": sha(source_archive.read_bytes()), "sourceFiles": len(source),
                  "sourceManifestSha256": sha(source_manifest), "zipCrcAndPerFileSha256": "PASS",
                  "allowlist": [*roots, "explicit module/root build configuration", "README.txt", "interchange-core/FORMAT.md", "verification reproducer scripts only"],
                  "excludes": ["local.properties", "caches", "build outputs", "generated ecosystem key source", "raw ecosystem key", "private signing keys",
                               "reference APKs", "reference-analysis evidence", "verification runtime outputs"],
                  "externalBuildKeyRequired": True, "externalBuildKeyId": key_id})

current_lite_sha = next(item["sha256"] for item in artifacts if item["file"] == f"Dualscan-Share-Lite-{VERSION}-development.apk")
android_record = project / "verification/android-interchange-api36.txt"
tested_apk_file = project / "verification/android-tested-interchange-api36.json"
tested_apk = json.loads(tested_apk_file.read_text())
counts = re.findall(r"OK \((\d+) tests?\)", android_record.read_text())
assert counts and int(counts[-1]) >= 7 and "FAILURES!!!" not in android_record.read_text(), android_record
android_tests = int(counts[-1])
assert tested_apk.get("result") == "PASS" and tested_apk.get("tests") == android_tests, tested_apk_file
assert tested_apk.get("androidApi") == 36, tested_apk_file
assert tested_apk.get("testedApkSha256") == current_lite_sha, "Android evidence must match the delivered Lite APK"
assert tested_apk.get("recordSha256") == sha(android_record.read_bytes()), android_record
producer_record = project / tested_apk.get("producerRefreshRecord", "verification/android-portable-producer-api36.txt")
assert producer_record.resolve().is_relative_to((project / "verification").resolve())
assert re.search(r"OK \(1 test\)", producer_record.read_text()), producer_record
assert tested_apk.get("producerRefreshTests") == 1
assert tested_apk.get("producerRefreshRecordSha256") == sha(producer_record.read_bytes())
fixture_evidence = []
for item in tested_apk.get("fixtures", []):
    path = project / item["file"]
    assert path.resolve().is_relative_to((project / "verification/portable-fixtures").resolve())
    assert path.is_file() and sha(path.read_bytes()) == item["sha256"] and path.stat().st_size == item["bytes"], path
    fixture_evidence.append(str(path.relative_to(project / "verification")))
assert len(fixture_evidence) == 3, "Retain both actual encrypted producer fixtures and their public manifest"
android_run = {"api": 36, "result": "PASS", "tests": android_tests,
               "record": str(android_record.relative_to(project)), "recordSha256": sha(android_record.read_bytes()),
               "metadata": str(tested_apk_file.relative_to(project)), "metadataSha256": sha(tested_apk_file.read_bytes()),
               "testedApkSha256": current_lite_sha, "producerRefreshTests": 1,
               "producerRefreshRecord": str(producer_record.relative_to(project)), "producerRefreshRecordSha256": sha(producer_record.read_bytes())}
cross_file = project / "verification/cross-app-interchange.json"
cross = {"result": "PENDING", "scope": "No cross-app runtime claim until actual Share producer and Diamond consumer records are provided"}
if cross_file.exists():
    cross = json.loads(cross_file.read_text())
    assert cross.get("result") == "PASS", cross_file
    assert cross.get("producerApkSha256") == current_lite_sha, "Cross-app evidence must identify this Share producer APK"
    assert re.fullmatch(r"[0-9a-f]{64}", cross.get("consumerApkSha256", "")), "Cross-app evidence must identify the Diamond consumer APK"
    cross = {**cross, "record": str(cross_file.relative_to(project)), "recordSha256": sha(cross_file.read_bytes())}
node_file = project / "verification/portable-fixtures/node-verification.json"
node_verification = {"result": "PENDING"}
if node_file.exists():
    node_verification = json.loads(node_file.read_text())
    assert node_verification.get("result") == "PASS" and node_verification.get("format") == "DSMP0002", node_file
    assert node_verification.get("publicKeyId") == key_id, node_file
    expected = json.loads((project / "verification/portable-fixtures/share-fixture.json").read_text())
    for mode, filename in (("global", "share-global.dshare"), ("password", "share-password.dshare")):
        check = node_verification[mode]
        assert check["fileSha256"] == sha((node_file.parent / filename).read_bytes())
        assert [{"relativePath": item["relativePath"], "sha256": item["sha256"], "sizeBytes": item["bytes"]}
                for item in check["entries"]] == expected["entries"]
    node_verification = {**node_verification, "record": str(node_file.relative_to(project)), "recordSha256": sha(node_file.read_bytes())}

# New evidence only; prior releases keep their original reports and qualification.
evidence_names = [build_log.name, android_record.name, tested_apk_file.name, producer_record.name, *fixture_evidence]
if cross_file.exists():
    evidence_names.append(cross_file.name)
if node_file.exists():
    evidence_names.append(str(node_file.relative_to(project / "verification")))
for optional in ("android-to-host-interchange.json", "launcher-interchange-api36.json", "ui-interchange-api36.json"):
    if (project / "verification" / optional).is_file():
        evidence_names.append(optional)
ui_records = {}
for name in ("launcher-interchange-api36.json", "ui-interchange-api36.json"):
    path = project / "verification" / name
    if path.is_file():
        record = json.loads(path.read_text())
        assert record.get("result") == "PASS" and record.get("testedApkSha256") == current_lite_sha, path
        for item in record.get("evidence", []):
            artifact = project / "verification" / item["file"]
            assert artifact.resolve().is_relative_to((project / "verification").resolve())
            assert sha(artifact.read_bytes()) == item["sha256"], artifact
            evidence_names.append(item["file"])
        ui_records[name] = {**record, "recordSha256": sha(path.read_bytes())}
# Retain actual current UI evidence only when named by the release workflow.
for pattern in ("ui-*-interchange-api36.png", "ui-*-interchange-api36.xml", "launcher-*-interchange-api36.png", "launcher-*-interchange-api36.xml"):
    evidence_names.extend(path.name for path in sorted((project / "verification").glob(pattern)))
evidence_names = sorted(set(evidence_names))
evidence = {name: (project / "verification" / name).read_bytes() for name in evidence_names}
for name, data in evidence.items():
    assert key_bytes not in data, f"No raw ecosystem key allowed in evidence: {name}"
evidence_manifest = (json.dumps({"schemaVersion": 1, "files": [
    {"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in evidence.items()
]}, indent=2) + "\n").encode()
evidence_zip = dist / f"Dualscan-Share-{VERSION}-verification.zip"
with zipfile.ZipFile(evidence_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted({**evidence, "EVIDENCE-MANIFEST.json": evidence_manifest}.items()):
        entry = zipfile.ZipInfo("Verification/" + name, date_time=(2026, 10, 16, 12, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        bundle.writestr(entry, data)
with zipfile.ZipFile(evidence_zip) as bundle:
    assert bundle.testzip() is None and len(bundle.namelist()) == len(evidence) + 1
    for name, data in evidence.items():
        assert sha(bundle.read("Verification/" + name)) == sha(data), name
    assert sha(bundle.read("Verification/EVIDENCE-MANIFEST.json")) == sha(evidence_manifest)
for name, data in evidence.items():
    assert (project / "verification" / name).read_bytes() == data, f"Evidence changed during packaging: {name}"
artifacts.append({"file": evidence_zip.name, "bytes": evidence_zip.stat().st_size,
                  "sha256": sha(evidence_zip.read_bytes()), "evidenceFiles": len(evidence),
                  "evidenceManifestSha256": sha(evidence_manifest), "zipCrcAndPerFileSha256": "PASS",
                  "allowlist": evidence_names, "excludes": ["APKs", "private keys", "generated key source", "reference-app evidence", "unrelated logs/files"]})
report = {
    "schemaVersion": 2, "versionName": VERSION, "versionCode": VERSION_CODE,
    "preparedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "releaseStatus": "OEM/ODM integration candidate; NOT Golden Master approved or certified",
    "build": {"result": "PASS", "record": str(build_log.relative_to(project)), "sha256": sha(build_log.read_bytes())},
    "jvmTests": units, "lint": lint,
    "format": {"created": "DSMP0002", "encryptedByDefault": True, "passwordOptional": True, "ecosystemKeyId": key_id,
               "passwordMode": "shared ecosystem key plus PBKDF2-derived password secret wraps a random per-image data key",
               "readOnlyLegacyInputs": ["DSHP0001 password-wrapped ZIP", "plain Dualscan ZIP"],
               "newFormatPlaintextZipStaging": False, "fullPayloadVerificationBeforePreviewOrRestore": True,
               "boundary": "Shared application key is extractable from APKs; optional password is needed for private user protection"},
    "sourceBuild": {"sameExternalEcosystemKeyRequired": True, "rawKeyIncluded": False, "generatedKeySourceIncluded": False,
                    "handoff": "docs/OFFLINE-INTERCHANGE-HANDOFF.txt", "compatibleFutureBuildBackup": "Source ZIP plus separate private ecosystem-key file and controlled APK upgrade-signing identity"},
    "thirdParty": {"tellaLicense": "MIT", "copyright": "2025 Horizontal", "commit": "b1a2a8afc25fb2d920c2ba5e210a738f4d32dacc",
                   "compiledScope": sorted(compiled_tella), "legacyUnauthenticatedCtrCompiled": False, "packagedLicenseChecked": True},
    "androidRuntimeEvidence": {
        "result": f"PASS: {android_tests} actual Android instrumentation tests on API36 using the delivered Lite APK",
        "scope": ["legacy independent-host fixture unlock and exact restore", "wrong password opens no restore destination",
                  "legacy Android encrypted fixture generation", "production MediaStore exact audio restore into Music",
                  "immediate foreground-service completion remains alive", "rejected source/create requests remain recoverable",
                  "actual Share engine creates encrypted global/password fixtures for Diamond"],
        "runs": [android_run], "currentDeliveredLiteApkRuntimeQualified": True, "oemApkRuntimeQualified": False,
        "testedApkSha256": current_lite_sha, "crossAppInterchange": cross,
        "independentNodeVerifier": node_verification,
        "uiRuntimeEvidence": ui_records,
        "priorApi34Evidence": "Historical 1.0.1 reports retained in dist-1.0.1; this 1.1.0 report claims the current API36 run only"},
    "unverified": ["physical USB-C/OTG media and filesystem qualification", "actual OEM/ODM and privileged backup/OTA integration",
                   "Samsung-approved/Knox or Google system-backup integration", "full OS/userdata snapshot and firmware rollback chain",
                   "independent cryptographic/security audit and production release signoff"],
    "knownLimits": ["Public APIs do not reliably map removable volumes to USB versus SD or prove USB-C; explicitly choose the attached USB drive",
                    "No apps/private app data, accounts or protected partition capture in Lite", "OEM packages supplied artifacts; it neither signs nor installs firmware",
                    "Release APKs require controlled ODM signing; development APKs use a development certificate", "Legacy DSHP inputs still require their original password"],
    "artifacts": artifacts}
serialized = json.dumps(report, indent=2) + "\n"
(project / "verification/delivery-verification-1.1.0.json").write_text(serialized)
(dist / "DELIVERY-VERIFICATION.json").write_text(serialized)
(dist / "READ-ME-FIRST.txt").write_text(
    f"Dualscan Share {VERSION} — OEM/ODM integration candidate\n\n"
    "For standard Android 8+ install the Lite development APK. OEM adds supplied\n"
    "device-specific artifact packaging. Development APKs are installable and signed\n"
    "with a development certificate; release APKs require controlled ODM signing.\n\n"
    "New .dshare images are encrypted automatically and open in Diamond Player.\n"
    "Leave the optional password empty for direct access, or add/confirm an 8–256\n"
    "character password for extra privacy. Old password images retain their password.\n"
    "USB transfer only; no cloud. New format never stages a plaintext ZIP.\n\n"
    f"JVM tests passed: Lite {units['lite']['totals']['tests']}, OEM {units['oem']['totals']['tests']}, "
    f"interchange {units['interchange-core']['totals']['tests']}, Tella keys {units['tella-keys-core']['totals']['tests']}.\n"
    f"Build/lint passed. {android_tests} actual Android tests passed on API36.\n"
    f"Cross-app runtime evidence: {cross['result']}. See DELIVERY-VERIFICATION.json.\n"
    "Physical USB-C, OEM firmware integration and independent security review remain\n"
    "unverified. This is not an approved/certified Golden Master.\n\n"
    "Back up both source ZIPs AND the separate private 32-byte ecosystem-key file\n"
    "for compatible future builds. Raw key/generated key source are excluded here.\n"
    "The build key defaults to ~/.local/share/dualscan-research/keys/ecosystem-v1.key;\n"
    "see docs/OFFLINE-INTERCHANGE-HANDOFF.txt in source for build provisioning.\n"
    "The application key is embedded in APKs and extractable: default images are\n"
    "not private-user security or DRM. Use an optional password for private backups.\n"
    "Keep APK signing identities separately for future installation upgrades.\n\n"
    "Source ZIP contains SOURCE-MANIFEST.json; verification ZIP contains current\n"
    "runtime records and per-file hashes. SHA256SUMS.txt covers delivered files.\n")
(dist / "SHA256SUMS.txt").write_text("".join(f"{sha(file.read_bytes())}  {file.name}\n" for file in sorted(dist.iterdir())
    if file.is_file() and file.name != "SHA256SUMS.txt"))
print(json.dumps({"dist": str(dist), "jvmTests": {name: entry["totals"]["tests"] for name, entry in units.items()},
                  "androidTests": android_tests, "androidApis": [36], "crossAppInterchange": cross["result"], "artifacts": artifacts}, indent=2))
