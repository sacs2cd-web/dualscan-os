"""Independent test-only DSHP0001 fixture: Python ZIP/WAV + Node/OpenSSL crypto.
Uses a public fixed salt/nonce only to make this fixture reproducible.
Production ProtectedArchive always uses fresh SecureRandom values.
"""
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import wave
import zipfile

project = Path(__file__).resolve().parents[2]
destination = project / "app/src/androidTest/assets/crypto"
destination.mkdir(parents=True, exist_ok=True)
node = os.environ.get("DUALSCAN_NODE") or shutil.which("node")
if not node:
    raise RuntimeError("Install Node.js or set DUALSCAN_NODE to its executable to regenerate the public fixture.")
password = "Dualscan fixture passphrase 東京 2026"
rate = 48000
frames = bytearray()
for index in range(rate * 8):
    amplitude = round(500 * math.sin(2 * math.pi * 997 * index / rate))
    frames += struct.pack("<hh", amplitude, amplitude)
audio = io.BytesIO()
with wave.open(audio, "wb") as wav:
    wav.setnchannels(2)
    wav.setsampwidth(2)
    wav.setframerate(rate)
    wav.writeframes(frames)
audio_bytes = audio.getvalue()
manifest = {
    "format": "dualscan-share", "schemaVersion": 1,
    "bundleId": "d5524722-67eb-43ac-a793-2c3fc9123953",
    "title": "Independent cross-provider fixture", "description": "Public synthetic audio test; no personal content.",
    "kind": "PORTABLE_BACKUP", "createdAtEpochMs": 1792152000000,
    "encryption": "none", "coverage": "explicit-user-selected-content",
    "device": {"manufacturer": "Dualscan", "model": "Host test fixture", "device": "crypto_fixture",
               "androidRelease": "14", "sdkInt": 34, "fingerprint": "dualscan/test/fixture:14/test:user/release-keys", "securityPatch": "2026-10-01"},
    "apps": [], "oem": None,
    "entries": [{"id": "file-000001", "displayName": "Dualscan test tone.wav", "mimeType": "audio/wav",
                 "sizeBytes": len(audio_bytes), "sha256": hashlib.sha256(audio_bytes).hexdigest()}]
}
archive = io.BytesIO()
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED) as container:
    for path, payload in [("payload/file-000001", audio_bytes), ("manifest.json", json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).encode())]:
        info = zipfile.ZipInfo(path, date_time=(2026, 10, 16, 12, 0, 0))
        info.compress_type = zipfile.ZIP_STORED
        container.writestr(info, payload)
plain = archive.getvalue()
with tempfile.TemporaryDirectory(prefix="dualscan-crypto-fixture-") as temporary:
    source = Path(temporary) / "archive.zip"
    source.write_bytes(plain)
    script = r'''
import { readFileSync, writeFileSync } from 'node:fs';
import { createCipheriv, pbkdf2Sync } from 'node:crypto';
const configuration = JSON.parse(process.env.DUALSCAN_PUBLIC_FIXTURE);
const plaintext = readFileSync(configuration.input);
const salt = Buffer.from(Array.from({length:16}, (_,index) => index));
const baseNonce = Buffer.from(Array.from({length:12}, (_,index) => 32 + index));
const header = Buffer.alloc(40);
header.write('DSHP0001', 0, 'ascii'); salt.copy(header, 8); baseNonce.copy(header, 24); header.writeInt32BE(600000, 36);
const key = pbkdf2Sync(Buffer.from(configuration.password, 'utf8'), salt, 600000, 32, 'sha256');
const records = [header];
let counter = 0n;
function seal(clear, declaredLength, final) {
  const nonce = Buffer.from(baseNonce);
  const suffix = nonce.readBigUInt64BE(4) ^ counter;
  nonce.writeBigUInt64BE(suffix, 4);
  const aad = Buffer.alloc(53); header.copy(aad); aad.writeBigUInt64BE(counter, 40); aad.writeInt32BE(declaredLength, 48); aad[52] = final ? 1 : 0;
  const cipher = createCipheriv('aes-256-gcm', key, nonce, {authTagLength:16});
  cipher.setAAD(aad);
  const length = Buffer.alloc(4); length.writeInt32BE(declaredLength);
  records.push(length, cipher.update(clear), cipher.final(), cipher.getAuthTag());
}
for (let offset = 0; offset < plaintext.length; offset += 1048576) {
  const chunk = plaintext.subarray(offset, Math.min(offset + 1048576, plaintext.length));
  seal(chunk, chunk.length, false); counter++;
}
const footer = Buffer.alloc(16); footer.writeBigUInt64BE(BigInt(plaintext.length), 0); footer.writeBigUInt64BE(counter, 8);
seal(footer, 0, true);
writeFileSync(configuration.output, Buffer.concat(records)); key.fill(0);
'''
    environment = os.environ.copy()
    environment["DUALSCAN_PUBLIC_FIXTURE"] = json.dumps({"input": str(source), "output": str(destination / "host-encrypted.dshare"), "password": password})
    subprocess.run([str(node), "--input-type=module", "-"], input=script, text=True, env=environment, check=True)
fixture = (destination / "host-encrypted.dshare").read_bytes()
vector = {
    "purpose": "Public cross-provider test fixture; NEVER use its fixed salt/nonce or password for personal backups.",
    "format": "DSHP0001-records-1MiB", "generator": "Python standard-library WAV/ZIP + Node OpenSSL AES-256-GCM",
    "password": password, "iterations": 600000, "saltHex": bytes(range(16)).hex(), "baseNonceHex": bytes(range(32, 44)).hex(),
    "plainArchiveBytes": len(plain), "plainArchiveSha256": hashlib.sha256(plain).hexdigest(),
    "encryptedBytes": len(fixture), "encryptedSha256": hashlib.sha256(fixture).hexdigest(),
    "payloadName": "Dualscan test tone.wav", "payloadId": "file-000001", "payloadBytes": len(audio_bytes),
    "payloadSha256": hashlib.sha256(audio_bytes).hexdigest(), "dataRecords": (len(plain) + 1048575) // 1048576,
    "audio": {"encoding": "PCM signed 16-bit little-endian", "rate": rate, "channels": 2, "durationSeconds": 8}
}
(destination / "host-encrypted-vector.json").write_text(json.dumps(vector, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: vector[key] for key in ("encryptedBytes", "encryptedSha256", "plainArchiveSha256", "payloadSha256", "dataRecords")}, indent=2))
