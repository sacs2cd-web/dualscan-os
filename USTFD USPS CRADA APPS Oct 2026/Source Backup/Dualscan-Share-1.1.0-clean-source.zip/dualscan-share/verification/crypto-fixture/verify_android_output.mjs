// Public, small test fixture verifier; independent Node/OpenSSL implementation.
import { readFileSync, statSync } from 'node:fs';
import { createDecipheriv, createHash, pbkdf2Sync } from 'node:crypto';
import assert from 'node:assert/strict';
const [encryptedPath, vectorPath] = process.argv.slice(2);
if (!encryptedPath || !vectorPath) throw Error('Usage: node verify_android_output.mjs encrypted-test-file vector.json');
assert(statSync(encryptedPath).size < 8 * 1024 * 1024, 'This verifier accepts only the small public test fixture.');
const vector = JSON.parse(readFileSync(vectorPath, 'utf8'));
const encrypted = readFileSync(encryptedPath);
const header = encrypted.subarray(0, 40);
assert.equal(header.subarray(0, 8).toString('ascii'), 'DSHP0001');
assert.equal(header.readInt32BE(36), 600000);
const key = pbkdf2Sync(Buffer.from(vector.password, 'utf8'), header.subarray(8, 24), 600000, 32, 'sha256');
const hash = createHash('sha256');
let offset = 40, records = 0n, total = 0n, finished = false, short = false;
try {
  while (offset < encrypted.length) {
    const length = encrypted.readInt32BE(offset); offset += 4;
    assert(length >= 0 && length <= 1048576);
    if (length) assert(!short, 'Noncanonical data after final short record');
    const clearLength = length || 16;
    assert(offset + clearLength + 16 <= encrypted.length);
    const nonce = Buffer.from(header.subarray(24, 36));
    nonce.writeBigUInt64BE(nonce.readBigUInt64BE(4) ^ records, 4);
    const aad = Buffer.alloc(53); header.copy(aad); aad.writeBigUInt64BE(records, 40); aad.writeInt32BE(length, 48); aad[52] = length ? 0 : 1;
    const decipher = createDecipheriv('aes-256-gcm', key, nonce, {authTagLength: 16});
    decipher.setAAD(aad); decipher.setAuthTag(encrypted.subarray(offset + clearLength, offset + clearLength + 16));
    const clear = Buffer.concat([decipher.update(encrypted.subarray(offset, offset + clearLength)), decipher.final()]);
    offset += clearLength + 16;
    if (!length) {
      assert.equal(clear.readBigUInt64BE(0), total); assert.equal(clear.readBigUInt64BE(8), records);
      assert.equal(offset, encrypted.length); finished = true; clear.fill(0); break;
    }
    hash.update(clear); total += BigInt(clear.length); records++; short = length < 1048576; clear.fill(0);
  }
  assert(finished, 'Authenticated totals footer missing');
  const sha256 = hash.digest('hex');
  assert.equal(Number(total), vector.plainArchiveBytes); assert.equal(sha256, vector.plainArchiveSha256);
  console.log(JSON.stringify({result:'PASS', direction:'Android -> independent Node/OpenSSL', records:Number(records), plaintextBytes:Number(total), plaintextSha256:sha256}, null, 2));
} finally { key.fill(0); }
