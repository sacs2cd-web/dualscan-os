"""Explicit-serial Android UI helper for the owned Share QA emulator."""
import re
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ADB = str(Path.home() / "Library/Android/sdk/platform-tools/adb")
SERIAL = sys.argv[1]
assert SERIAL in {"emulator-5590", "emulator-5592"}

def adb(*args):
    return subprocess.check_output([ADB, "-s", SERIAL, *args])

def dump():
    adb("shell", "uiautomator", "dump", "/sdcard/share-qa.xml")
    return ET.fromstring(adb("exec-out", "cat", "/sdcard/share-qa.xml"))

mode = sys.argv[2]
if mode == "labels":
    for node in dump().iter("node"):
        if node.get("text") or node.get("content-desc"):
            print(node.get("text"), "|", node.get("content-desc"), node.get("bounds"), node.get("enabled"))
elif mode == "tap":
    label = sys.argv[3]
    node = next(n for n in dump().iter("node") if n.get("text") == label or n.get("content-desc") == label)
    x1,y1,x2,y2 = map(int,re.findall(r"\d+",node.get("bounds")))
    adb("shell", "input", "tap", str((x1+x2)//2), str((y1+y2)//2))
else:
    raise ValueError(mode)
