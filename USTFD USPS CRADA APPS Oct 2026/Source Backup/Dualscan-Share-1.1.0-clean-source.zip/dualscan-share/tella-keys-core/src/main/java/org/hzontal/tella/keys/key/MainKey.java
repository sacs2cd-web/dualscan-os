/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2025 Horizontal
 * Adapted for Dualscan MP: dependency-free, synchronized key ownership,
 * AES size validation, temporary key-copy wiping and AutoCloseable support.
 * Upstream source and full license: third_party/tella.
 */
package org.hzontal.tella.keys.key;

import org.hzontal.tella.keys.util.Wiper;

import java.security.NoSuchAlgorithmException;

import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

/**
 * Owns one in-memory AES key. Wiping clears this owner's bytes; JVM/provider
 * copies and plaintext already passed to a decoder cannot be guaranteed erased.
 */
public final class MainKey implements AutoCloseable {
    private static final String KEY_ALGORITHM = "AES";
    private byte[] keyBytes;

    public static MainKey generate() {
        byte[] secret = null;
        try {
            KeyGenerator generator = KeyGenerator.getInstance(KEY_ALGORITHM);
            generator.init(256);
            secret = generator.generateKey().getEncoded();
            return new MainKey(secret);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("AES key generation is unavailable", ex);
        } finally {
            Wiper.wipe(secret);
        }
    }

    public MainKey(SecretKeySpec encryptionKey) {
        if (encryptionKey == null || !KEY_ALGORITHM.equalsIgnoreCase(encryptionKey.getAlgorithm())) {
            throw new IllegalArgumentException("An AES key is required");
        }
        byte[] encoded = encryptionKey.getEncoded();
        try {
            validate(encoded);
            this.keyBytes = encoded.clone();
        } finally {
            Wiper.wipe(encoded);
        }
    }

    public MainKey(byte[] keyBytes) {
        validate(keyBytes);
        this.keyBytes = keyBytes.clone();
    }

    /** Returns an independent provider key, or null after wipe. */
    public synchronized SecretKeySpec getKey() {
        return keyBytes == null ? null : new SecretKeySpec(keyBytes, KEY_ALGORITHM);
    }

    public synchronized void setKey(SecretKeySpec key) {
        if (key == null) {
            wipe();
            return;
        }
        if (!KEY_ALGORITHM.equalsIgnoreCase(key.getAlgorithm())) {
            throw new IllegalArgumentException("An AES key is required");
        }
        byte[] encoded = key.getEncoded();
        try {
            validate(encoded);
            byte[] replacement = encoded.clone();
            wipe();
            keyBytes = replacement;
        } finally {
            Wiper.wipe(encoded);
        }
    }

    public synchronized void wipe() {
        Wiper.wipe(keyBytes);
        keyBytes = null;
    }

    @Override
    public void close() {
        wipe();
    }

    private static void validate(byte[] bytes) {
        if (bytes == null || (bytes.length != 16 && bytes.length != 24 && bytes.length != 32)) {
            throw new IllegalArgumentException("An AES key must contain 16, 24 or 32 bytes");
        }
    }
}
