/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2025 Horizontal
 * Adapted for Dualscan MP: removed Android annotation dependency; char[] overload.
 */
package org.hzontal.tella.keys.util;

import java.util.Arrays;

/** Best-effort clearing of caller-owned arrays; does not erase provider copies. */
public final class Wiper {
    private Wiper() {}

    public static void wipe(byte[] bytes) {
        if (bytes != null) Arrays.fill(bytes, (byte) 0);
    }

    public static void wipe(char[] chars) {
        if (chars != null) Arrays.fill(chars, '\0');
    }
}
