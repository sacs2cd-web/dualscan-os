package org.hzontal.tella.keys.key;

import org.hzontal.tella.keys.util.Wiper;
import org.junit.Test;

import java.util.Arrays;

import javax.crypto.spec.SecretKeySpec;

import static org.junit.Assert.*;

public class MainKeyTest {
    @Test public void constructorOwnsIndependentBytes() {
        byte[] bytes = new byte[32];
        Arrays.fill(bytes, (byte) 7);
        try (MainKey key = new MainKey(bytes)) {
            Arrays.fill(bytes, (byte) 0);
            assertEquals(7, key.getKey().getEncoded()[0]);
        }
    }

    @Test public void encodedViewsCannotMutateOwner() {
        try (MainKey key = new MainKey(new byte[32])) {
            byte[] view = key.getKey().getEncoded();
            view[0] = 90;
            assertEquals(0, key.getKey().getEncoded()[0]);
        }
    }

    @Test public void wipeAndCloseInvalidateOwner() {
        MainKey key = MainKey.generate();
        assertEquals(32, key.getKey().getEncoded().length);
        key.wipe();
        assertNull(key.getKey());
        key.close();
        assertNull(key.getKey());
    }

    @Test public void replacingKeyUsesIndependentBytesAndNullWipes() {
        try (MainKey key = MainKey.generate()) {
            byte[] replacement = new byte[32];
            Arrays.fill(replacement, (byte) 23);
            key.setKey(new SecretKeySpec(replacement, "AES"));
            replacement[0] = 0;
            assertEquals(23, key.getKey().getEncoded()[0]);
            key.setKey(null);
            assertNull(key.getKey());
        }
    }

    @Test public void invalidKeysAreRejected() {
        for (int size : new int[] {0, 1, 15, 17, 31, 33}) {
            try {
                new MainKey(new byte[size]);
                fail("Accepted invalid AES key size " + size);
            } catch (IllegalArgumentException expected) {}
        }
        try {
            new MainKey(new SecretKeySpec(new byte[32], "HmacSHA256"));
            fail("Accepted another algorithm");
        } catch (IllegalArgumentException expected) {}
    }

    @Test public void generationIsIndependentAndNotZero() {
        try (MainKey first = MainKey.generate(); MainKey second = MainKey.generate()) {
            byte[] a = first.getKey().getEncoded();
            byte[] b = second.getKey().getEncoded();
            assertFalse(Arrays.equals(a, b));
            assertFalse(Arrays.equals(a, new byte[32]));
        }
    }

    @Test public void callerOwnedSecretsAreCleared() {
        byte[] bytes = {1, 2, 3};
        char[] chars = {'a', 'b'};
        Wiper.wipe(bytes);
        Wiper.wipe(chars);
        assertArrayEquals(new byte[3], bytes);
        assertArrayEquals(new char[2], chars);
        Wiper.wipe((byte[]) null);
        Wiper.wipe((char[]) null);
    }
}
