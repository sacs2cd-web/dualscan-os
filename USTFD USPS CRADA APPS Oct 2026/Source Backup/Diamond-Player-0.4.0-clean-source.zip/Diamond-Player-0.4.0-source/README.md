# Diamond Player 0.4.0

Diamond Player requires **Android 14 / API 34 or later**. The APK manifest rejects installation on older Android releases; the activity and playback services also check the OS version before initializing playback.

Two source paths share the Diamond interface:

- **Native files:** choose one or more audio files with Android's document picker. The native foreground service owns the queue, decoder, AudioTrack, notification, media session, audio focus and wake lock. Play/pause, previous/next and seek remain available with the screen off.
- **TIDAL Web:** the existing licensed TIDAL WebView remains available. The browser owns its decode and output path. The source badge displays only explicit reported bit depth/sample rate; missing values stay unknown. It does not measure Android output and does not prove bit-perfect TIDAL playback.

The app pauses browser media before starting native playback. Returning to the browser waits for the native track, source and USB mixer preference to be released.

## Native PCM and output selection

The WAV reader copies original little-endian integer PCM bytes for 16-bit, packed 24-bit and 32-bit RIFF/WAVE, including supported WAVE_FORMAT_EXTENSIBLE layouts. It validates frame size, speaker layout, valid precision and chunk bounds. Unsupported encodings or ambiguous layouts fail explicitly.

Other supported files use Android's MediaExtractor and MediaCodec. Device decoder availability determines support (for example FLAC, ALAC, AAC). FLAC STREAMINFO supplies independent source precision, including the documented FLAC `csd-0` in MP4. The source format, reported decoder PCM, produced pipeline PCM and actual AudioTrack input appear separately.

For 24-bit FLAC the player explicitly requests float PCM. An Android decoder can otherwise produce 16-bit data which the framework pads to a nominal packed-24 format; checking the public format alone misses that loss. The float adapter packs a sample into signed 24-bit only when it is finite, in range and exactly on the 24-bit integer grid. It never rounds, scales the signal, dithers, or changes channel order. Every signed 24-bit value has an exact normalized float32 representation. A known underlying 16-bit decoder report prevents strict playback even if the public format is wider. An Android instrumented fixture compares the entire produced packed-24 stream with the original source PCM; nominal format equality is not accepted as that test's success condition.

The native path applies no app EQ, normalization, resampling, mixing or software volume. AudioTrack is constructed using the actual PCM encoding, sample rate and channel mask; no playback-rate change is used to change hardware rate. This alone does not establish what an OEM HAL, internal DAC or headphone output does.

Choose a connected output or leave Android routing automatic. An explicitly selected device must become AudioTrack's actual route before any source samples are written. Its removal or a route change stops playback, including in ordinary headphone mode, to avoid a silent fallback to a speaker. Device capability lists describe advertised support, not the active stream.

## Strict USB bit-perfect mode

Strict mode is enabled initially. Select a USB DAC in the output menu. For each track, playback requires all of:

1. Independently known source precision with unchanged integer PCM bit depth, sample rate and channel count.
2. A platform-advertised `AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT` configuration with exactly matching encoding, sample rate and channel mask.
3. An accepted and retained `setPreferredMixerAttributes` preference.
4. A matching AudioTrack PCM format and an actual routed device equal to the selected USB DAC.

No source PCM is written before those checks pass. Route/device/preference listeners and continued checks stop playback if the contract is invalidated. The UI says **Android USB BIT_PERFECT mixer active**, describing Android's mixer contract; it does not claim independently measured DAC byte identity. Preferences are cleared on stop, failure, source switch and service cleanup.

If a FLAC decoder returns 16-bit PCM for a 24-bit file, the exact float packing checks fail, or source precision/rate/channels differ, strict mode rejects it. Other unverified floating-point decoder paths also fail strict mode. Framework compressed 32-bit source preservation is conservatively unsupported: the source remains correctly reported as 32-bit, but strict playback rejects the decoder path. Exact integer WAV32 remains supported. Ordinary native mode labels final output unverified and displays any known source-preservation limitation. Unknown compressed source precision also fails strict mode.

For a headphone jack, internal DAC, Bluetooth output, or a USB path without that exact advertised mixer contract, turn strict mode off to use ordinary native PCM playback. Its final output remains explicitly unverified. Android 14 by itself does not guarantee hardware support.

The implementation uses public Android APIs. It contains no reference-player code, assets, binaries, proprietary USB driver or hidden OEM audio parameters.

## Build and signing

Android SDK 36 and a JDK 21 Gradle daemon are configured for this project. Java source compatibility is 17. The existing app identity is preserved: `com.dualscan.diamondplayer.yoncen6`, version code 25.

```bash
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease
```

Release signing reads the existing ignored `keystore.properties`. Use the existing keystore to update an installed signed release; `keystore.properties.example` documents the fields. Keep signing secrets outside version control.

Outputs:

```text
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release.apk
dist/Diamond-Player-0.4.0-native-pcm-debug.apk
dist/Diamond-Player-0.4.0-native-pcm-release-signed.apk
```

## Verification and practical limits

Unit tests cover byte-preserving WAV reads and seeks, extensible precision/layouts, malformed and truncated files, large RIFF bounds, explicit website metadata, FLAC source precision, exact float24 representation packing, full-file buffer limits, clear fMP4 validation and exact mixer format/precision eligibility. The Android decoder test uses an independently generated unprotected 24-bit / 96 kHz stereo FLAC fMP4 and its original WAV, with full PCM SHA-256 equality required. Build/lint and emulator checks establish software behavior, not physical DAC fidelity.

Hardware acceptance still requires the intended Android device and DAC/headphone route. Test 44.1/48/96/192 kHz files at supported integer precisions, verify the DAC's displayed rate, test track-format transitions, disconnect the selected output, interrupt audio focus, and confirm native service/notification playback with the screen off. For byte identity, record a suitable digital DAC output and compare aligned PCM against the source. A DAC rate display alone cannot prove bit identity.

## WebView buffer handoff

The TIDAL WebView includes an explicit opt-in **clear-stream buffer** experiment. Open the streaming player, arm before a new track, and start that track. A document-start probe at the exact `https://listen.tidal.com` origin tees only supported clear, pre-decode MediaSource append bytes; it does not capture/resample browser PCM, fetch hidden stream URLs, decrypt content or access a CDM. Transfer uses an acknowledged bounded message port with byte hashes. A second native parser independently requires one clear FLAC/fMP4 audio track, a complete continuous timeline and matching full media duration. Protected, encrypted, missing, discontinuous and unsupported structures fail closed.

Only a complete validated file enables **Play native buffer**. The browser is paused first, then that file uses the same native decoder and strict USB checks. This is full-track buffering followed by native replay, with delayed startup; it is not a live clock takeover or seamless handoff. Live TIDAL availability depends on the website actually exposing the supported clear format and is not established by the bundled fixtures or local-file tests. Browser playback remains available for unsupported/protected sources and is always labelled output-unverified.

The separate app-owned buffer test screens exercise the public TIDAL Web SDK `NativePlayerComponent.Player` protocol with an unprotected WAV, and the actual clear MSE probe/message-port/private-spool/native-validator path with an unprotected FLAC fMP4. They do not navigate or replace the signed-in TIDAL WebView. The progressive SDK adapter accepts a supported authorized clear URL; encryption keys and protected playback require a separate authorized backend and are rejected here.

The encoded cache is app-private and bounded; files retained by the playback queue stay available for replay, and orphaned buffer files are cleaned at the next bridge lifetime. Source metadata, pipeline bytes and output eligibility remain separate facts throughout.
