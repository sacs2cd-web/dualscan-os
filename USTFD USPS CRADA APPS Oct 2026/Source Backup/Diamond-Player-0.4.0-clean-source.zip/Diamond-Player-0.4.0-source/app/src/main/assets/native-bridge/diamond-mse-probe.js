/* Passive, opt-in, pre-decode MSE probe. No network requests, credentials or CDM access.
 * Deliberately accepts only a narrow clear, single-track, contiguous fMP4/FLAC subset.
 * Native must independently validate the completed private spool before playback.
 */
(function (factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else factory(window);
})(function installDiamondMseProbe(w) {
  'use strict';
  if (w.top && w.top !== w) return;
  if (w.__diamondMseProbe) return w.__diamondMseProbe;
  var MAX_BOX = 8 * 1024 * 1024, MAX_QUEUE = 8 * 1024 * 1024;
  var MAX_TOTAL = 256 * 1024 * 1024, CHUNK = 48 * 1024;
  var armed = false, active = null, blocked = false, serial = 0, sources = new Map();
  var mediaUrls = new Map(), observedElements = new Set();
  var forbidden = new Set(['enca','encv','sinf','schm','schi','tenc','pssh','senc','saiz','saio','sgpd','sbgp','uuid']);
  var layouts = {
    moov: ['mvhd','trak','mvex'], trak: ['tkhd','mdia'], mdia: ['mdhd','hdlr','minf'],
    minf: ['smhd','dinf','stbl'], dinf: ['dref'], stbl: ['stsd','stts','stsc','stsz','stco','co64'],
    mvex: ['trex','mehd'], moof: ['mfhd','traf'], traf: ['tfhd','tfdt','trun']
  };
  function fail(reason) { throw new Error(reason); }
  function u32(b,p) { if (p < 0 || p+4>b.length) fail('truncated-field'); return new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p); }
  function u16(b,p) { if (p < 0 || p+2>b.length) fail('truncated-field'); return (b[p]<<8)|b[p+1]; }
  function four(b,p) { if (p+4>b.length) fail('truncated-type'); return String.fromCharCode(b[p],b[p+1],b[p+2],b[p+3]); }
  function join(a,b) { var c=new Uint8Array(a.length+b.length); c.set(a); c.set(b,a.length); return c; }
  function boxes(b,start,end) {
    var out=[]; while(start<end) {
      if(end-start<8) fail('truncated-box');
      var n=u32(b,start), type=four(b,start+4);
      if(n<8 || n>MAX_BOX || start+n>end) fail('unsupported-box-size');
      if(forbidden.has(type)) fail('protected-or-unknown-protection-box');
      out.push({type:type,start:start,data:start+8,end:start+n,size:n}); start+=n;
    } return out;
  }
  function children(b,box) {
    var list=boxes(b,box.data,box.end), allowed=layouts[box.type];
    list.forEach(function(x){ if(!allowed || allowed.indexOf(x.type)<0) fail('unsupported-'+box.type+'-box'); });
    return list;
  }
  function one(list,type) { var a=list.filter(function(x){return x.type===type;}); if(a.length!==1) fail('expected-one-'+type); return a[0]; }
  function flags(b,x) { if(b[x.data]!==0) fail('unsupported-fullbox-version'); return u32(b,x.data)&0xffffff; }
  function noSamples(b,x) {
    if(flags(b,x)!==0 || u32(b,x.data+4)!==0 || x.size!==16) fail('nonempty-initial-sample-table');
  }
  function init(b) {
    var top=boxes(b,0,b.length); if(top.length!==1 || top[0].type!=='moov') fail('expected-moov');
    var m=children(b,top[0]), track=one(m,'trak'), tr=children(b,track), tk=one(tr,'tkhd');
    var tkVersion=b[tk.data], trackId=u32(b,tk.data+(tkVersion===0?12:tkVersion===1?20:fail('tkhd-version')));
    var md=children(b,one(tr,'mdia')), h=one(md,'hdlr'); if(four(b,h.data+8)!=='soun') fail('not-audio');
    var hd=one(md,'mdhd'), version=b[hd.data];
    var timescale=u32(b,hd.data+(version===0?12:version===1?20:fail('mdhd-version'))); if(!timescale) fail('invalid-timescale');
    var mi=children(b,one(md,'minf')), di=children(b,one(mi,'dinf')), dr=one(di,'dref');
    if(flags(b,dr)!==0 || u32(b,dr.data+4)!==1) fail('external-data-reference');
    var urls=boxes(b,dr.data+8,dr.end); if(urls.length!==1 || urls[0].type!=='url ' || flags(b,urls[0])!==1 || urls[0].size!==12) fail('external-data-reference');
    var st=children(b,one(mi,'stbl')), sd=one(st,'stsd');
    if(flags(b,sd)!==0 || u32(b,sd.data+4)!==1) fail('sample-description-switching');
    var entries=boxes(b,sd.data+8,sd.end), a=one(entries,'fLaC');
    if(a.size<36 || u16(b,a.data+6)!==1 || u16(b,a.data+8)!==0) fail('unsupported-audio-sample-entry');
    var sampleChildren=boxes(b,a.data+28,a.end), df=one(sampleChildren,'dfLa');
    if(sampleChildren.some(function(x){return x.type!=='dfLa' && x.type!=='btrt';}) || flags(b,df)!==0 || df.size<50) fail('unsupported-flac-configuration');
    var p=df.data+4, metadataType=b[p]&127, len=(b[p+1]<<16)|(b[p+2]<<8)|b[p+3];
    if(metadataType!==0 || len!==34 || p+4+len>df.end) fail('invalid-flac-streaminfo');
    p+=4;
    var rate=(b[p+10]<<12)|(b[p+11]<<4)|(b[p+12]>>4);
    var channels=((b[p+12]>>1)&7)+1, bits=(((b[p+12]&1)<<4)|(b[p+13]>>4))+1;
    if(rate!==timescale || !rate || channels<1 || channels>8 || bits<4 || bits>32) fail('inconsistent-flac-format');
    if(u16(b,a.data+16)!==channels || u16(b,a.data+18)!==bits) fail('inconsistent-flac-sample-entry');
    // Declared source precision is diagnostic; native verifies actual decoder output.
    var sampleCount=(b[p+13]&15)*4294967296+u32(b,p+14);
    st.filter(function(x){return ['stts','stsc','stco','co64'].indexOf(x.type)>=0;}).forEach(function(x){noSamples(b,x);});
    var sz=one(st,'stsz'); if(flags(b,sz)!==0 || u32(b,sz.data+8)!==0 || sz.size!==20) fail('nonempty-initial-sample-table');
    var ex=children(b,one(m,'mvex')), tx=one(ex,'trex');
    if(flags(b,tx)!==0 || tx.size!==32 || u32(b,tx.data+4)!==trackId || u32(b,tx.data+8)!==1) fail('invalid-trex');
    return {codec:'fLaC',sampleRateHz:rate,channels:channels,bitDepth:bits,timescale:timescale,trackId:trackId,
      declaredSampleCount:sampleCount,defaultDuration:u32(b,tx.data+12),defaultSize:u32(b,tx.data+16)};
  }
  function fragment(b,meta,expected,previousSequence) {
    var root=boxes(b,0,b.length), c=children(b,one(root,'moof')), mf=one(c,'mfhd');
    if(flags(b,mf)!==0 || mf.size!==16) fail('invalid-mfhd'); var seq=u32(b,mf.data+4);
    if(previousSequence!==null && seq!==previousSequence+1) fail('fragment-sequence-discontinuity');
    var t=children(b,one(c,'traf')), th=one(t,'tfhd'), f=flags(b,th);
    if((f&~0x020038)!==0 || u32(b,th.data+4)!==meta.trackId) fail('unsupported-tfhd');
    var p=th.data+8, duration=meta.defaultDuration, size=meta.defaultSize;
    if(f&8){duration=u32(b,p);p+=4;} if(f&16){size=u32(b,p);p+=4;} if(f&32)p+=4;
    if(p!==th.end) fail('invalid-tfhd-length');
    var td=one(t,'tfdt'), v=b[td.data], time;
    if(v===0 && td.size===16) time=u32(b,td.data+4);
    else if(v===1 && td.size===20) time=u32(b,td.data+4)*4294967296+u32(b,td.data+8);
    else fail('invalid-tfdt');
    if((u32(b,td.data)&0xffffff)!==0 || !Number.isSafeInteger(time) || time!==expected) fail('noncontiguous-decode-timeline');
    var run=one(t,'trun'), rf=u32(b,run.data)&0xffffff;
    if(b[run.data]!==0 || (rf&~0x000701)!==0 || !(rf&1)) fail('unsupported-trun');
    var count=u32(b,run.data+4); if(!count || count>100000) fail('invalid-sample-count');
    var offset=u32(b,run.data+8); if(offset!==b.length+8) fail('nonadjacent-media-data');
    p=run.data+12; var ticks=0, bytes=0;
    for(var i=0;i<count;i++) {
      var d=duration,s=size; if(rf&0x100){d=u32(b,p);p+=4;} if(rf&0x200){s=u32(b,p);p+=4;} if(rf&0x400)p+=4;
      if(!d || !s) fail('missing-sample-duration-or-size'); ticks+=d; bytes+=s;
    }
    if(p!==run.end || !Number.isSafeInteger(ticks) || bytes>MAX_BOX-8) fail('invalid-trun-length');
    return {end:time+ticks,bytes:bytes,sequence:seq,samples:count};
  }
  function post(message) { var t=w.DiamondMseBridge; if(!t || typeof t.postMessage!=='function') fail('native-transport-unavailable'); t.postMessage(JSON.stringify(message)); }
  function status(reason) { try { post({v:1,type:'status',reason:reason,armed:armed,workerCoverage:false}); } catch(_) {} }
  function abort(reason) {
    var a=active; active=null; armed=false;
    if(a) { a.dead=true; if(a.timer)w.clearTimeout(a.timer); a.queue=[]; a.pending=new Uint8Array(0);
      try{post({v:1,type:'abort',streamId:a.id,reason:reason});}catch(_){} }
    status(reason);
  }
  function base64(b) { var s=''; for(var i=0;i<b.length;i+=8192) s+=String.fromCharCode.apply(null,b.subarray(i,i+8192)); return w.btoa(s); }
  async function pump(a) {
    if(a.dead || a.sending || a.inflight) return;
    if(!a.queue.length) {
      if(a.ended) {
        a.dead=true; active=null; armed=false;
        try { post({v:1,type:'complete',streamId:a.id,byteCount:a.total,fragmentCount:a.fragments,
          totalDurationUs:Math.round(a.end*1000000/a.metadata.timescale),expectedDurationUs:a.expectedDurationUs,metadata:a.metadata,
          evidence:{clearSingleTrackFlac:true,contiguousFromZero:true,normalRate:true,fullAppendWindow:true,
            encryptedMediaObserved:false,workerCoverage:false,chunkHash:'SHA-256',nativeValidationRequired:true,
            expectedDurationSource:'attached-media-element-before-endOfStream'}}); }
        catch(_) { status('native-completion-transport-failed'); }
      } return;
    }
    a.sending=true;
    try {
      var part=a.queue.shift(); a.queued-=part.length;
      if(!w.crypto || !w.crypto.subtle) fail('sha256-unavailable');
      var digest=new Uint8Array(await w.crypto.subtle.digest('SHA-256',part));
      if(a.dead || active!==a) return;
      var hash=Array.from(digest).map(function(n){return n.toString(16).padStart(2,'0');}).join('');
      var sequence=a.nextSequence++;
      a.inflight={sequence:sequence,length:part.length};
      a.timer=w.setTimeout(function(){if(active===a)abort('native-ack-timeout');},15000);
      post({v:1,type:'chunk',streamId:a.id,sequence:sequence,offset:a.sent,data:base64(part),sha256:hash});
      a.sent+=part.length;
    } catch(_) { if(active===a)abort('native-transport-or-hash-failed'); }
    finally { a.sending=false; if(!a.inflight && !a.dead) pump(a); }
  }
  function enqueue(a,b) {
    if(a.total+b.length>MAX_TOTAL || a.queued+b.length>MAX_QUEUE) fail('capture-byte-limit');
    a.total+=b.length;
    for(var i=0;i<b.length;i+=CHUNK){var part=b.slice(i,Math.min(i+CHUNK,b.length));a.queue.push(part);a.queued+=part.length;}
    pump(a);
  }
  function accept(a,b,type) {
    if(type==='ftyp') {
      if(a.haveFtyp || a.metadata) fail('representation-or-track-switch');
      a.haveFtyp=true; a.initBytes=b; return;
    }
    if(type==='moov') {
      if(!a.haveFtyp || a.metadata) fail('unexpected-initialization');
      a.metadata=init(b);
      post({v:1,type:'start',streamId:a.id,mime:a.mime,metadata:a.metadata});
      enqueue(a,join(a.initBytes,b)); a.initBytes=null; return;
    }
    if(!a.metadata) fail('missing-complete-initialization');
    if(type==='moof') {
      if(a.fragment) fail('missing-mdat');
      a.fragment=fragment(b,a.metadata,a.end,a.lastFragmentSequence); enqueue(a,b); return;
    }
    if(type==='mdat') {
      if(!a.fragment || b.length-8!==a.fragment.bytes) fail('sample-data-size-mismatch');
      a.end=a.fragment.end; a.lastFragmentSequence=a.fragment.sequence; a.fragments++;
      a.samples+=a.fragment.samples; a.fragment=null; enqueue(a,b); return;
    }
    fail(forbidden.has(type)?'protected-or-unknown-protection-box':'unsupported-top-level-box');
  }
  function append(sb,input) {
    if(!armed || blocked) return;
    var source=sources.get(sb); if(!source || !/^audio\/mp4(?:\s*;|$)/i.test(source.mime)) return;
    if(active && active.sb!==sb) { abort('multiple-audio-source-buffers'); return; }
    if(sb.mode!=='segments' || sb.timestampOffset!==0 || sb.appendWindowStart!==0 || sb.appendWindowEnd!==Infinity) { abort('nondefault-mse-timeline'); return; }
    var b=input instanceof ArrayBuffer?new Uint8Array(input):ArrayBuffer.isView(input)?new Uint8Array(input.buffer,input.byteOffset,input.byteLength):null;
    if(!b || b.length>MAX_BOX*2) { abort('unsupported-append-buffer'); return; }
    if(!active) {
      source.prefix=join(source.prefix,b.subarray(0,Math.max(0,8-source.prefix.length)));
      if(source.prefix.length<8) { source.early=join(source.early,b); return; }
      if(four(source.prefix,4)!=='ftyp') {source.prefix=new Uint8Array(0);source.early=new Uint8Array(0);status('waiting-for-next-track-initialization');return;}
      active={id:'mse-'+(++serial),sb:sb,ms:source.ms,mime:source.mime,pending:new Uint8Array(0),queue:[],queued:0,total:0,sent:0,
        nextSequence:0,inflight:null,sending:false,metadata:null,initBytes:null,haveFtyp:false,fragment:null,
        end:0,lastFragmentSequence:null,fragments:0,samples:0,ended:false,dead:false,timer:null};
      b=join(source.early,b);source.prefix=new Uint8Array(0);source.early=new Uint8Array(0);
    }
    var a=active;
    try {
      if(a.ended) fail('append-after-end');
      if(a.pending.length+b.length>MAX_BOX*2) fail('incomplete-box-limit');
      a.pending=join(a.pending,b);
      while(a.pending.length>=8) {
        var n=u32(a.pending,0),type=four(a.pending,4);
        if(n<8 || n>MAX_BOX) fail('unsupported-box-size'); if(a.pending.length<n)break;
        var box=a.pending.slice(0,n);a.pending=a.pending.slice(n);accept(a,box,type);
      }
    }catch(error){abort(error.message);}
  }
  function wrap(prototype,name,before) {
    if(!prototype || typeof prototype[name]!=='function')return;
    var original=prototype[name]; prototype[name]=function(){ before(this,arguments);return original.apply(this,arguments); };
  }
  function attachedDuration(ms) {
    if(w.document && w.document.querySelectorAll)Array.from(w.document.querySelectorAll('audio,video')).forEach(function(el){observedElements.add(el);});
    var matches=[];
    observedElements.forEach(function(el){
      if(mediaUrls.get(el.currentSrc || el.src)===ms)matches.push(el);
    });
    if(matches.length!==1)fail('cannot-identify-attached-media-element');
    var el=matches[0],duration=el.duration;
    if(el.mediaKeys || el.playbackRate!==1 || !Number.isFinite(duration) || duration<=0)fail('unknown-expected-track-duration');
    return duration;
  }
  if(w.URL && typeof w.URL.createObjectURL==='function') {
    var originalUrl=w.URL.createObjectURL;
    w.URL.createObjectURL=function(object){var url=originalUrl.apply(this,arguments);if(w.MediaSource && object instanceof w.MediaSource)mediaUrls.set(url,object);return url;};
    // Revoking an object URL does not detach a media element already using it;
    // retain the association until sourceclose rather than losing duration evidence.
  }
  var mediaSource=w.MediaSource && w.MediaSource.prototype;
  if(mediaSource && w.SourceBuffer) {
    var originalAdd=mediaSource.addSourceBuffer;
    mediaSource.addSourceBuffer=function(mime) {
      var sb=originalAdd.apply(this,arguments);sources.set(sb,{ms:this,mime:String(mime),prefix:new Uint8Array(0),early:new Uint8Array(0)});
      if(sb.addEventListener)sb.addEventListener('error',function(){if(active && active.sb===sb)abort('browser-source-buffer-error');});
      if(this.addEventListener)this.addEventListener('sourceclose',function(){if(active && active.ms===this)abort('media-source-closed');var ms=this;mediaUrls.forEach(function(value,key){if(value===ms)mediaUrls.delete(key);});});
      return sb;
    };
    var originalAppend=w.SourceBuffer.prototype.appendBuffer;
    w.SourceBuffer.prototype.appendBuffer=function(data){
      // appendBuffer copies these encoded bytes. Only mirror calls accepted synchronously.
      var result=originalAppend.apply(this,arguments);
      try{append(this,data);}catch(_){if(active)abort('probe-observer-failed');}
      return result;
    };
    ['remove','abort','changeType'].forEach(function(name){wrap(w.SourceBuffer.prototype,name,function(sb){if(active && active.sb===sb)abort('source-buffer-'+name);});});
    wrap(mediaSource,'removeSourceBuffer',function(ms,args){if(active && active.sb===args[0])abort('source-buffer-removed');sources.delete(args[0]);});
    var originalEnd=mediaSource.endOfStream;
    mediaSource.endOfStream=function(){
      var ms=this,args=arguments,expected=null;
      if(active && active.ms===ms)try{expected=attachedDuration(ms);}catch(error){abort(error.message);}
      var result=originalEnd.apply(this,arguments);
      var a=active;if(!a || a.ms!==ms)return;
      if(args.length && args[0]!==undefined){abort('media-source-error');return;}
      if(!a.metadata || a.pending.length || a.fragment || !a.fragments){abort('incomplete-media-source');return;}
      if(a.metadata.declaredSampleCount && a.metadata.declaredSampleCount!==a.end){abort('declared-duration-mismatch');return;}
      if(!expected || Math.abs(expected*a.metadata.timescale-a.end)>1){abort('incomplete-expected-track-duration');return;}
      a.expectedDurationUs=Math.round(expected*1000000);
      a.ended=true;pump(a);return result;
    };
  }
  if(w.HTMLMediaElement) {
    ['play','pause','load'].forEach(function(name){wrap(w.HTMLMediaElement.prototype,name,function(el){observedElements.add(el);});});
    // EME is observed, never intercepted for keys or decrypted payloads.
    wrap(w.HTMLMediaElement.prototype,'setMediaKeys',function(_,args){if(args[0]){blocked=true;abort('eme-media-keys-observed');}});
  }
  if(w.document && w.document.addEventListener) {
    w.document.addEventListener('encrypted',function(){blocked=true;abort('encrypted-media-event');},true);
    w.document.addEventListener('seeking',function(){if(active)abort('seek-during-capture');},true);
    w.document.addEventListener('ratechange',function(event){if(active && event.target && event.target.playbackRate!==1)abort('nonunit-playback-rate');},true);
  }
  var api={
    arm:function(){if(active)abort('rearmed');if(blocked){status('protected-page-capture-disabled');return false;}armed=true;sources.forEach(function(s){s.prefix=new Uint8Array(0);s.early=new Uint8Array(0);});status('armed-awaiting-new-clear-flac-track');return true;},
    cancel:function(){abort('cancelled');},
    receiveNative:function(message){
      try{if(typeof message==='string')message=JSON.parse(message);}catch(_){abort('invalid-native-ack');return;}
      var a=active;if(!a || !message || message.streamId!==a.id)return;
      if(message.type==='abort'){abort('native-rejected-capture');return;}
      if(message.type!=='ack' || !a.inflight || message.sequence!==a.inflight.sequence){abort('invalid-native-ack');return;}
      w.clearTimeout(a.timer);a.timer=null;a.inflight=null;pump(a);
    },
    getState:function(){return {version:1,armed:armed,blockedByEme:blocked,capturing:!!active,workerCoverage:false,sourceCount:sources.size};}
  };
  w.__diamondMseProbe=api;
  if(w.addEventListener)w.addEventListener('message',function(event){
    // Native owns and transfers this channel to this exact top-level origin. Browser
    // windows have a non-null source. Content sent over the port remains untrusted.
    if(event.data!=='diamond-mse-port-v1' || !event.isTrusted || event.source!==null ||
       !event.ports || event.ports.length!==1 || w!==w.top || !w.location || w.location.origin!=='https://listen.tidal.com')return;
    if(w.DiamondMseBridge) {try{event.ports[0].close();}catch(_){}return;}
    var port=event.ports[0];
    w.DiamondMseBridge={postMessage:function(text){port.postMessage(text);}};
    port.onmessage=function(message){
      var m;try{m=typeof message.data==='string'?JSON.parse(message.data):message.data;}catch(_){abort('invalid-native-message');return;}
      if(m && m.type==='arm')api.arm();else if(m && m.type==='cancel')api.cancel();else api.receiveNative(m);
    };
    if(port.start)port.start();status('native-transport-attached');
  });
  status(mediaSource?'installed-main-world-only':'mse-unavailable');return api;
});
