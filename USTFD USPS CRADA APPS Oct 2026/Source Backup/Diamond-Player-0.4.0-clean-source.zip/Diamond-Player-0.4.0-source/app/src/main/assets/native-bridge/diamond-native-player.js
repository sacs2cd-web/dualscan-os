/* Public TIDAL SDK NativePlayerComponent adapter. Configure an owned SDK page for native.
 * Merely injecting this object into listen.tidal.com does not change its player selection.
 * No audio samples, authorization headers, or protected-stream keys are handled in JavaScript.
 */
(function () {
  'use strict';
  if (window.DiamondNativePlayer) return;
  let port = null;
  let pending = [];
  const listeners = new Map();
  function emit(name, target) {
    for (const listener of [...(listeners.get(name) || [])]) {
      try { listener({ target }); } catch (_) { /* A consumer must not break the bridge. */ }
    }
    window.dispatchEvent(new CustomEvent('diamond-native-event', { detail: { event: name, target } }));
  }
  function send(method, args) {
    const message = JSON.stringify({ method, args: args || [] });
    if (port) port.postMessage(message);
    else if (pending.length < 32) pending.push(message);
    else emit('mediaerror', { error: 'Native bridge is unavailable.', errorCode: 'unreadable_file' });
  }
  const player = {
    addEventListener(name, listener) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      listeners.get(name).add(listener);
    },
    removeEventListener(name, listener) { listeners.get(name)?.delete(listener); },
    on(name, listener) { this.addEventListener(name, listener); },
    load(url, streamFormat, encryptionKey) {
      if (encryptionKey) {
        emit('mediaerror', { error: 'Protected streams require an authorized protected backend.', errorCode: 'unreadable_file' });
        return;
      }
      send('load', [url, streamFormat]);
    },
    preload() { emit('mediaerror', { error: 'Gapless SDK preloading is not implemented.', errorCode: 'unreadable_file' }); },
    cancelPreload() { send('cancelPreload'); },
    recover(url, encryptionKey) { this.load(url, 'flac', encryptionKey); },
    play() { send('play'); },
    pause() { send('pause'); },
    stop() { send('stop'); },
    seek(seconds) { send('seek', [seconds]); },
    listDevices() { send('listDevices'); },
    releaseDevice() { send('releaseDevice'); },
    selectDevice(device, mode) { send('selectDevice', [device, mode]); },
    selectSystemDevice() { send('selectSystemDevice'); },
    setVolume(volume) { send('setVolume', [volume]); }
  };
  window.addEventListener('message', event => {
    if (event.data !== 'diamond-native-port-v1' || event.ports.length !== 1) return;
    if (port) port.close();
    port = event.ports[0];
    port.onmessage = message => {
      try {
        const result = JSON.parse(message.data);
        if (typeof result.event === 'string') emit(result.event, result.target);
      } catch (_) { /* Reject malformed responses without disclosing payloads. */ }
    };
    port.start?.();
    const queued = pending;
    pending = [];
    for (const message of queued) port.postMessage(message);
    window.dispatchEvent(new Event('diamond-native-connected'));
  });
  window.DiamondNativePlayer = player;
  window.NativePlayerComponent = { Player: () => player };
})();
