package com.dualscan.music.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.Build
import android.os.PowerManager

class PlaybackKeepAliveService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT < 34) { stopSelf(); return }
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT < 34) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        acquireWakeLock()
        return START_STICKY
    }

    override fun onDestroy() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:DiamondTidalPlayback")
            .apply {
                setReferenceCounted(false)
                acquire()
            }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Diamond Player Playback",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps Diamond Player WebView playback active while the screen is off."
            setSound(null, null)
        }

        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Diamond Player")
            .setContentText("WebKit audio playback active")
            .setContentIntent(pendingIntent)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
    }

    companion object {
        const val ACTION_START = "com.dualscan.music.player.action.START_KEEPALIVE"
        const val ACTION_STOP = "com.dualscan.music.player.action.STOP_KEEPALIVE"
        private const val CHANNEL_ID = "diamond_tidal_playback"
        private const val NOTIFICATION_ID = 60315326
    }
}
