package com.dualscan.music.player

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

/** Framework decoder adapter. It checks the decoder's output, including ignored PCM requests. */
class CodecPcmSource(context: Context, uri: Uri, displayName: String) : NativePcmSource {
    private val extractor = MediaExtractor()
    private var codec: MediaCodec? = null
    private var pendingIndex = -1
    private var pendingBuffer: ByteBuffer? = null
    private var inputEnded = false
    private var outputEnded = false
    private var firstFormat: PcmFormat? = null
    private var firstDecoderFormat: PcmFormat? = null
    private var packFloat24 = false
    private var sourceIsFlac24 = false
    var decoderDiagnostics: String = "Not initialized"
        private set
    private val bufferInfo = MediaCodec.BufferInfo()
    override var info: NativeTrackInfo
        private set
    override val format: PcmFormat get() = checkNotNull(firstFormat)
    override val decoderFormat: PcmFormat? get() = firstDecoderFormat

    init {
        try {
            extractor.setDataSource(context, uri, null)
            val index = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("This file has no supported audio track.")
            extractor.selectTrack(index)
            check(extractor.drmInitData == null) { "Encrypted media needs an authorized DRM playback integration; native clear-PCM decoding is unavailable." }
            val input = extractor.getTrackFormat(index)
            val mime = input.getString(MediaFormat.KEY_MIME) ?: error("Missing audio codec.")
            // Android documents FLAC csd-0 as fLaC + STREAMINFO, including FLAC in MP4.
            val flac = if (mime == MediaFormat.MIMETYPE_AUDIO_FLAC) {
                readFlacInfo(context, uri) ?: input.getByteBuffer("csd-0")?.duplicate()?.let { csd ->
                    if (csd.remaining() < 42) null else parseFlacStreamInfo(ByteArray(42).also(csd::get))
                }
            } else null
            val rawBits = if (mime == MediaFormat.MIMETYPE_AUDIO_RAW && input.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                encodingBits(input.getInteger(MediaFormat.KEY_PCM_ENCODING))
            } else null
            val sourceBits = flac?.bits ?: rawBits
            val sourceRate = flac?.rate ?: input.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val sourceChannels = flac?.channels ?: input.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val reportedDuration = if (input.containsKey(MediaFormat.KEY_DURATION)) input.getLong(MediaFormat.KEY_DURATION) else 0L
            val duration = if (reportedDuration > 0) reportedDuration else {
                // Empty-moov fMP4 may have no extractor duration. Trust only the independently
                // checked, complete clear FLAC timeline, never a WebView/page duration claim.
                if (mime == MediaFormat.MIMETYPE_AUDIO_FLAC && uri.scheme == "file" && uri.path != null) {
                    runCatching { validateClearFlacFmp4(File(checkNotNull(uri.path))).durationUs }.getOrDefault(0L)
                } else 0L
            }
            info = NativeTrackInfo(
                displayName = displayName,
                sourceDescription = "$mime · ${sourceBits?.let { "$it-bit" } ?: "precision unknown"} · ${sourceRate / 1000.0} kHz · $sourceChannels ch",
                sourceBitDepth = sourceBits,
                sourceSampleRateHz = sourceRate,
                sourceChannelCount = sourceChannels,
                durationUs = duration,
                precisionKnown = sourceBits != null,
                decoderPreservationFailure = if (sourceBits == 32) "Framework compressed 32-bit decoder preservation has not been verified; strict playback is unavailable for this path." else null
            )
            sourceIsFlac24 = mime == MediaFormat.MIMETYPE_AUDIO_FLAC && sourceBits == 24
            // A decoder may ignore this request. The actual output is checked below.
            input.setInteger(MediaFormat.KEY_PCM_ENCODING, when (sourceBits) {
                // AOSP FLAC decodes to 16-bit or float. Requesting packed24 can merely pad 16-bit output.
                24 -> AudioFormat.ENCODING_PCM_FLOAT
                32 -> AudioFormat.ENCODING_PCM_32BIT
                else -> AudioFormat.ENCODING_PCM_16BIT
            })
            codec = try {
                startDecoder(mime, input)
            } catch (failure: Exception) {
                if (sourceBits == 24 || sourceBits == 32) {
                    // Ordinary playback may use the actual 16-bit decoder output. Strict policy rejects this precision change.
                    input.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                    startDecoder(mime, input)
                } else throw failure
            }
            val deadline = android.os.SystemClock.elapsedRealtime() + 10_000
            while (pendingBuffer == null && !outputEnded) {
                check(android.os.SystemClock.elapsedRealtime() < deadline) { "The decoder did not produce audio within 10 seconds." }
                pump()
            }
            check(firstFormat != null) { "The decoder did not report a PCM output format." }
        } catch (failure: Throwable) {
            close()
            throw failure
        }
    }

    private fun startDecoder(mime: String, input: MediaFormat): MediaCodec {
        val decoder = MediaCodec.createDecoderByType(mime)
        try {
            decoder.configure(input, null, null, 0)
            decoder.start()
            return decoder
        } catch (failure: Exception) {
            runCatching { decoder.release() }
            throw failure
        }
    }

    override fun read(target: ByteBuffer): Int {
        val deadline = android.os.SystemClock.elapsedRealtime() + 10_000
        while (true) {
            check(android.os.SystemClock.elapsedRealtime() < deadline) { "The decoder stopped producing audio." }
            val pending = pendingBuffer
            if (pending != null && pending.hasRemaining()) {
                if (packFloat24) {
                    val count = packFloat32ToPcm24(pending, target, format.channelCount)
                    check(count > 0) { "PCM output buffer cannot hold a complete frame." }
                    if (!pending.hasRemaining()) releasePending()
                    return count
                }
                val count = minOf(target.remaining(), pending.remaining()) / format.bytesPerFrame * format.bytesPerFrame
                check(count > 0) { "PCM output buffer cannot hold a complete frame." }
                val end = pending.limit()
                pending.limit(pending.position() + count)
                target.put(pending)
                pending.limit(end)
                if (!pending.hasRemaining()) releasePending()
                return count
            }
            if (outputEnded) return -1
            pump()
        }
    }

    private fun pump() {
        if (Thread.currentThread().isInterrupted) throw InterruptedException("Decoder stopped")
        val decoder = checkNotNull(codec)
        if (!inputEnded) {
            val inputIndex = decoder.dequeueInputBuffer(0)
            if (inputIndex >= 0) {
                val input = checkNotNull(decoder.getInputBuffer(inputIndex))
                input.clear()
                val size = extractor.readSampleData(input, 0)
                if (size < 0) {
                    decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    inputEnded = true
                } else {
                    check(extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED == 0) { "Encrypted audio samples are not accepted by the clear-PCM source." }
                    decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime.coerceAtLeast(0), 0)
                    extractor.advance()
                }
            }
        }
        when (val index = decoder.dequeueOutputBuffer(bufferInfo, 10_000)) {
            MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                val output = decoder.outputFormat
                val channels = output.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val reportedMask = if (output.containsKey(MediaFormat.KEY_CHANNEL_MASK)) {
                    output.getInteger(MediaFormat.KEY_CHANNEL_MASK)
                } else 0
                val mask = reportedMask.takeIf { it != 0 } ?: when (channels) {
                    1 -> AudioFormat.CHANNEL_OUT_MONO
                    2 -> AudioFormat.CHANNEL_OUT_STEREO
                    else -> error("The decoder did not specify a multichannel speaker layout.")
                }
                val raw = PcmFormat(
                    output.getInteger(MediaFormat.KEY_SAMPLE_RATE), channels,
                    if (output.containsKey(MediaFormat.KEY_PCM_ENCODING)) output.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    else AudioFormat.ENCODING_PCM_16BIT,
                    mask
                )
                check(firstDecoderFormat == null || firstDecoderFormat == raw) { "The decoder changed PCM format during playback." }
                firstDecoderFormat = raw
                val internalEncoding = if (output.containsKey("android._codec-pcm-encoding")) output.getInteger("android._codec-pcm-encoding") else null
                // This key is diagnostic and can negatively reveal padding; it is never sole positive proof.
                if (sourceIsFlac24 && internalEncoding == AudioFormat.ENCODING_PCM_16BIT) {
                    info = info.copy(decoderPreservationFailure = "The underlying FLAC codec produced 16-bit PCM; an advertised wider output cannot restore source precision.")
                }
                packFloat24 = sourceIsFlac24 && raw.encoding == AudioFormat.ENCODING_PCM_FLOAT
                val produced = if (packFloat24) raw.copy(encoding = AudioFormat.ENCODING_PCM_24BIT_PACKED) else raw
                check(firstFormat == null || firstFormat == produced) { "The PCM representation changed during playback." }
                firstFormat = produced
                decoderDiagnostics = "decoder=${decoder.name}; output=$output; exactFloat24Packing=$packFloat24"
            }
            in 0..Int.MAX_VALUE -> {
                outputEnded = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                if (bufferInfo.size > 0 && bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                    check(firstFormat != null) { "PCM data arrived without an output format." }
                    check(bufferInfo.size % checkNotNull(firstDecoderFormat).bytesPerFrame == 0) { "The decoder produced a partial PCM frame." }
                    pendingIndex = index
                    pendingBuffer = checkNotNull(decoder.getOutputBuffer(index)).apply {
                        position(bufferInfo.offset)
                        limit(bufferInfo.offset + bufferInfo.size)
                    }
                } else decoder.releaseOutputBuffer(index, false)
            }
        }
    }

    override fun seekTo(positionUs: Long): Long {
        releasePending()
        extractor.seekTo(positionUs.coerceAtLeast(0), MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val actual = extractor.sampleTime.coerceAtLeast(0)
        checkNotNull(codec).flush()
        inputEnded = false
        outputEnded = false
        return actual
    }

    private fun releasePending() {
        if (pendingIndex >= 0) codec?.releaseOutputBuffer(pendingIndex, false)
        pendingIndex = -1
        pendingBuffer = null
    }

    override fun close() {
        runCatching { releasePending() }
        codec?.let { runCatching { it.stop() }; runCatching { it.release() } }
        codec = null
        runCatching { extractor.release() }
    }
}

private fun encodingBits(encoding: Int): Int? = when (encoding) {
    AudioFormat.ENCODING_PCM_8BIT -> 8
    AudioFormat.ENCODING_PCM_16BIT -> 16
    AudioFormat.ENCODING_PCM_24BIT_PACKED -> 24
    AudioFormat.ENCODING_PCM_32BIT -> 32
    else -> null
}

data class FlacStreamInfo(val rate: Int, val channels: Int, val bits: Int)

/** STREAMINFO is an independent source-precision check; compressed decoder output is not evidence. */
fun parseFlacStreamInfo(bytes: ByteArray): FlacStreamInfo? {
    if (bytes.size < 42 || String(bytes, 0, 4, Charsets.US_ASCII) != "fLaC") return null
    if (bytes[4].toInt() and 0x7f != 0) return null
    val length = ((bytes[5].toInt() and 255) shl 16) or ((bytes[6].toInt() and 255) shl 8) or (bytes[7].toInt() and 255)
    if (length != 34) return null
    var packed = 0L
    for (index in 18..25) packed = (packed shl 8) or (bytes[index].toLong() and 255L)
    val result = FlacStreamInfo((packed ushr 44).toInt(), ((packed ushr 41) and 7).toInt() + 1, ((packed ushr 36) and 31).toInt() + 1)
    return result.takeIf { it.rate > 0 && it.bits in 4..32 }
}

private fun readFlacInfo(context: Context, uri: Uri): FlacStreamInfo? = runCatching {
    context.contentResolver.openInputStream(uri)?.use { input ->
        val bytes = ByteArray(42)
        var count = 0
        while (count < bytes.size) {
            val read = input.read(bytes, count, bytes.size - count)
            if (read < 0) break
            count += read
        }
        if (count == bytes.size) parseFlacStreamInfo(bytes) else null
    }
}.getOrNull()
