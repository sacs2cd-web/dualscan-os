package com.dualscan.music.player

import android.content.Context
import android.media.MediaExtractor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebMessage
import android.webkit.WebMessagePort
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * The public TIDAL Web SDK NativePlayerComponent contract for an app-owned SDK document.
 * An ordinary listen.tidal.com page does not automatically opt into this backend.
 * No JavascriptInterface is exposed to remote frames; a message port is transferred only
 * to the exact trusted HTTPS document origin supplied by the host.
 */
class TidalNativePlayerBridge(
    private val context: Context,
    private val webView: WebView,
    private val trustedOrigin: String = FIXTURE_ORIGIN,
    private val report: (String) -> Unit = {}
) : AutoCloseable {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val generation = AtomicLong()
    private val buffer = AuthorizedStreamBuffer(context.applicationContext)
    private var port: WebMessagePort? = null
    private var prepared: Prepared? = null
    private var started = false
    private var wantPlay = false
    private var closed = false
    private var lastState = ""
    private var lastError: String? = null
    private val retained = mutableListOf<BufferedAuthorizedAudio>()
    private data class Prepared(val audio: BufferedAuthorizedAudio, val info: NativeTrackInfo, val format: PcmFormat) {
        val uri: String get() = Uri.fromFile(audio.file).toString()
    }

    init {
        val parsed = Uri.parse(trustedOrigin)
        require(parsed.scheme == "https" && parsed.host != null && parsed.path.orEmpty() in listOf("", "/") && parsed.query == null) {
            "The native bridge requires an exact app-owned HTTPS origin."
        }
        NativeBufferLifetime.acquire(context)
    }

    /** Embed before bootstrapping the SDK, then explicitly configure the SDK player as native. */
    fun bootstrapScript(): String = context.assets.open("native-bridge/diamond-native-player.js").bufferedReader().use { it.readText() }

    /** Call from onPageFinished only for the app-owned SDK/fixture document. */
    fun attach() {
        check(Looper.myLooper() == Looper.getMainLooper())
        if (closed || !isTrustedDocument()) return
        port?.close()
        webView.evaluateJavascript(bootstrapScript()) {
            if (closed || !isTrustedDocument()) return@evaluateJavascript
            val channel = webView.createWebMessageChannel()
            port = channel[0].apply {
                setWebMessageCallback(object : WebMessagePort.WebMessageCallback() {
                    override fun onMessage(port: WebMessagePort, message: WebMessage) {
                        if (!closed && isTrustedDocument()) receive(message.data.orEmpty())
                    }
                }, handler)
            }
            webView.postWebMessage(WebMessage("diamond-native-port-v1", arrayOf(channel[1])), Uri.parse(trustedOrigin))
            report("Native buffer bridge ready for clear authorized progressive audio. Live TIDAL handoff remains unverified.")
            handler.removeCallbacks(poll)
            handler.post(poll)
        }
    }

    /** A deterministic app-owned proof page; it contains no TIDAL login, credentials, or audio. */
    fun fixtureHtml(): String = context.assets.open("native-bridge/fixture.html").bufferedReader().use { it.readText() }
        .replace("/* DIAMOND_NATIVE_BOOTSTRAP */", bootstrapScript())

    private fun isTrustedDocument(): Boolean {
        val current = webView.url?.let(Uri::parse) ?: return false
        val expected = Uri.parse(trustedOrigin)
        return current.scheme == expected.scheme && current.host == expected.host && current.port == expected.port
    }

    private fun receive(message: String) {
        if (message.length > 32_768) { fail("Native bridge message is too large."); return }
        try {
            val request = JSONObject(message)
            val args = request.optJSONArray("args") ?: JSONArray()
            when (request.getString("method")) {
                "load", "recover" -> load(args)
                "play" -> { wantPlay = true; playPrepared() }
                "pause" -> {
                    wantPlay = false
                    if (ownsQueue()) NativePlaybackService.command(context, NativePlaybackService.ACTION_PAUSE)
                    event("mediastate", "paused")
                }
                "stop", "releaseDevice" -> {
                    generation.incrementAndGet()
                    wantPlay = false
                    if (ownsQueue()) NativePlaybackService.command(context, NativePlaybackService.ACTION_STOP)
                    started = false
                    event("mediastate", "stopped")
                }
                "seek" -> {
                    // The SDK's actual nativePlayer.ts calls seek(seconds), despite an older
                    // nativeInterface.ts parameter name saying milliseconds.
                    val seconds = args.optDouble(0, Double.NaN)
                    require(seconds.isFinite() && seconds >= 0) { "Invalid native seek position." }
                    if (ownsQueue()) NativePlaybackService.command(context, NativePlaybackService.ACTION_SEEK) {
                        it.putExtra(NativePlaybackService.EXTRA_POSITION, (seconds * 1_000_000).toLong())
                    }
                }
                "listDevices" -> devices()
                "selectDevice" -> selectDevice(args)
                "selectSystemDevice" -> {
                    NativePlaybackService.command(context, NativePlaybackService.ACTION_DEVICE) { it.putExtra(NativePlaybackService.EXTRA_DEVICE, -1) }
                }
                "setVolume" -> {
                    require(args.optDouble(0, 100.0) == 100.0) { "Native exact-sample playback requires unity software volume." }
                    event("devicevolume", 100)
                }
                "preload" -> fail("Gapless SDK preloading is not implemented by this progressive buffer adapter.")
                "cancelPreload" -> Unit
                else -> fail("Unsupported native player command.")
            }
        } catch (failure: Exception) {
            // Never forward parser/network exception text which may contain URLs or credentials.
            val safe = if (failure is IllegalArgumentException) failure.message else null
            fail(safe ?: "The native audio command could not be completed.")
        }
    }

    private fun load(args: JSONArray) {
        val address = args.optString(0)
        val streamFormat = args.optString(1, "none")
        val encryptionKey = args.optString(2).takeUnless { it.isBlank() || it == "null" }
        require(encryptionKey == null) { "Protected TIDAL streams require an authorized protected playback backend." }
        if (ownsQueue()) NativePlaybackService.command(context, NativePlaybackService.ACTION_STOP)
        prepared?.let { retained.add(it.audio) }
        prepared = null
        started = false
        wantPlay = false
        lastError = null
        event("diamondclearerror", true)
        val token = generation.incrementAndGet()
        event("mediastate", "idle")
        report("Buffering clear progressive bytes before native decoding…")
        worker.execute {
            var audio: BufferedAuthorizedAudio? = null
            try {
                val buffered = buffer.buffer(address, streamFormat, encryptionKey, { closed || generation.get() != token }) { count, total ->
                    handler.post {
                        if (generation.get() == token) event("diamondbuffer", JSONObject().put("bytes", count).put("total", total ?: JSONObject.NULL))
                    }
                }
                audio = buffered
                val uri = Uri.fromFile(buffered.file)
                val name = if (address == AuthorizedStreamBuffer.FIXTURE_URI) "24-bit native bridge fixture" else "Authorized SDK audio"
                val source = if (WavPcmSource.isWave(context, uri)) WavPcmSource(context, uri, name) else {
                    rejectEncryptedSamples(uri)
                    CodecPcmSource(context, uri, name)
                }
                val result = source.use { Prepared(buffered, it.info, it.format) }
                handler.post {
                    if (closed || generation.get() != token) { buffer.release(result.audio); return@post }
                    prepared = result
                    event("mediaduration", result.info.durationUs / 1_000_000.0)
                    event("mediaformat", JSONObject().put("sampleRate", result.format.sampleRateHz)
                        .put("bitDepth", result.info.sourceBitDepth ?: JSONObject.NULL)
                        .put("decodedContainerBits", result.format.containerBits).put("precisionKnown", result.info.precisionKnown))
                    event("diamondbuffer", JSONObject().put("bytes", result.audio.byteCount).put("complete", true)
                        .put("sha256", result.audio.sha256).put("fixture", address == AuthorizedStreamBuffer.FIXTURE_URI))
                    event("mediastate", "ready")
                    report("Buffered ${result.audio.byteCount} unchanged bytes. ${result.info.sourceDescription}. Output proof is evaluated by the native engine.")
                    playPrepared()
                }
            } catch (failure: Exception) {
                audio?.let(buffer::release)
                handler.post {
                    if (!closed && generation.get() == token) {
                        fail(if (failure is IllegalArgumentException || failure is IllegalStateException) failure.message ?: "Audio buffering failed." else "Unable to buffer or decode the clear authorized stream.")
                    }
                }
            }
        }
    }

    private fun rejectEncryptedSamples(uri: Uri) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (index in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(index)
                if (format.getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    require(!format.containsKey("crypto-key") && !format.containsKey("crypto-mode")) { "Protected audio requires an authorized protected playback backend." }
                    extractor.selectTrack(index)
                    require(extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED == 0) { "Protected audio requires an authorized protected playback backend." }
                    return
                }
            }
        } finally { extractor.release() }
    }

    private fun playPrepared() {
        val clip = prepared ?: return
        if (!wantPlay) return
        if (started && ownsQueue()) {
            NativePlaybackService.command(context, NativePlaybackService.ACTION_PLAY)
            return
        }
        val start = {
            if (!closed && wantPlay && prepared === clip) {
                started = true
                lastState = ""
                NativePlaybackService.command(context, NativePlaybackService.ACTION_LOAD) {
                    it.putStringArrayListExtra(NativePlaybackService.EXTRA_URIS, arrayListOf(clip.uri))
                    it.putStringArrayListExtra(NativePlaybackService.EXTRA_NAMES, arrayListOf(clip.info.displayName))
                }
            }
        }
        val pause = NativePlaybackStore.pauseWebAudio
        if (pause == null) start() else pause(start)
    }

    private fun ownsQueue(): Boolean = prepared?.uri?.let { uri -> NativePlaybackStore.state.queue.any { it.uri == uri } } == true

    private val poll = object : Runnable {
        override fun run() {
            if (closed) return
            if (started && ownsQueue()) {
                val state = NativePlaybackStore.state
                if (state.error == null && lastError != null) {
                    lastError = null
                    event("diamondclearerror", true)
                    report(state.status)
                }
                event("mediacurrenttime", state.positionUs / 1_000_000.0)
                val next = when {
                    state.error != null -> "stopped"
                    state.loading -> "idle"
                    state.status == "Queue finished" -> "completed"
                    state.playing && state.positionUs > 0 -> "active"
                    state.playing -> "idle"
                    else -> "paused"
                }
                if (next != lastState) {
                    lastState = next
                    event("mediastate", next)
                    if (state.error == null && next in setOf("active", "paused", "completed")) report(state.status)
                }
                if (state.error != null && state.error != lastError) { lastError = state.error; fail(state.error) }
            }
            // Old buffered tracks are released only after the engine no longer has resources
            // open and their URI is not retained in the service's replay queue.
            if (NativePlaybackStore.state.resourcesReleased) {
                val queued = NativePlaybackStore.state.queue.map { it.uri }.toSet()
                retained.removeAll { audio ->
                    if (Uri.fromFile(audio.file).toString() !in queued) { buffer.release(audio); true } else false
                }
            }
            handler.postDelayed(this, 200)
        }
    }

    private fun devices() {
        val result = JSONArray().put(JSONObject().put("id", "default").put("name", "Android default output (strict proof required)")
            .put("type", "default").put("controllableVolume", false))
        NativePlaybackStore.state.devices.forEach { device ->
            result.put(JSONObject().put("id", device.id.toString()).put("name", device.label)
                .put("type", "default").put("controllableVolume", false))
        }
        event("devices", result)
    }

    private fun selectDevice(args: JSONArray) {
        val device = args.optJSONObject(0)
        val id = device?.optString("id")?.takeUnless { it == "default" }?.toIntOrNull()
        // Exclusive mode is a request; only the engine's exact mixer/routing checks can grant it.
        val mode = args.optString(1, "shared")
        if (mode == "exclusive" && !NativePlaybackStore.state.strictUsb) {
            event("deviceexclusivemodenotallowed", JSONObject.NULL)
            return
        }
        NativePlaybackService.command(context, NativePlaybackService.ACTION_DEVICE) { it.putExtra(NativePlaybackService.EXTRA_DEVICE, id ?: -1) }
    }

    private fun fail(message: String) {
        report(message)
        event("mediaerror", JSONObject().put("error", message).put("errorCode", "unreadable_file"))
    }

    private fun event(name: String, target: Any) {
        port?.postMessage(WebMessage(JSONObject().put("event", name).put("target", target).toString()))
    }

    override fun close() {
        if (closed) return
        closed = true
        generation.incrementAndGet()
        handler.removeCallbacks(poll)
        port?.close()
        port = null
        worker.shutdownNow()
        // The native service can outlive this WebView. Its queued cache files are retained.
        val queued = NativePlaybackStore.state.queue.map { it.uri }.toSet()
        (retained + listOfNotNull(prepared?.audio)).filter { Uri.fromFile(it.file).toString() !in queued }.forEach(buffer::release)
        NativeBufferLifetime.release()
    }

    companion object { const val FIXTURE_ORIGIN = "https://diamond-native.local" }
}
