package com.dualscan.music.player

import android.content.Context
import android.net.Uri
import java.io.File

/** Reclaims abandoned private buffers when opening the first bridge in a process/session. */
internal object NativeBufferLifetime {
    private var owners = 0

    @Synchronized fun acquire(context: Context) {
        if (owners == 0) {
            // A service may survive its Activity. Never remove anything in its replay queue.
            val retained = NativePlaybackStore.state.queue.mapNotNull { item ->
                Uri.parse(item.uri).takeIf { it.scheme == "file" }?.path?.let { File(it).absolutePath }
            }.toSet()
            listOf("authorized-audio-buffer", "clear-mse-buffer").forEach { name ->
                File(context.noBackupFilesDir, name).listFiles().orEmpty().forEach { file ->
                    if (file.isFile && file.absolutePath !in retained) file.delete()
                }
            }
        }
        owners++
    }

    @Synchronized fun release() { if (owners > 0) owners-- }
}
