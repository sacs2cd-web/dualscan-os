package com.dualscan.music.player

import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.dualscan.music.player.ui.theme.DualscanAlbumPlayerTheme
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.webkit.ScriptHandler
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var webView: WebView? = null
    private var playbackKeepAliveStarted = false
    private var protectedNavigationActive = true
    private var currentTidalHomeUrl = DEFAULT_TIDAL_HOME_URL
    private var storageAccessPrompted = false
    private val trackState = mutableStateOf(TidalTrackState())
    private val pageState = mutableStateOf("Opening Diamond Player")
    private val canGoBackState = mutableStateOf(false)
    private val nativeModeState = mutableStateOf(false)
    private val mseBufferState = mutableStateOf(MseBufferState())
    private var mseBufferBridge: TidalMseBufferBridge? = null
    private var mseDocumentScript: ScriptHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < 34) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Android 14 or later required")
                .setMessage("Diamond Player requires Android 14 or later for its native audio output APIs.")
                .setCancelable(false)
                .setPositiveButton("Close") { _, _ -> finish() }
                .show()
            return
        }
        volumeControlStream = AudioManager.STREAM_MUSIC
        NativePlaybackStore.pauseWebAudio = { complete ->
            val browser = webView
            if (browser == null) complete() else browser.evaluateJavascript(WEB_PAUSE) {
                setPlaybackKeepAlive(false)
                complete()
            }
        }
        NativePlaybackStore.state = NativePlaybackStore.state.copy(devices = connectedOutputDevices(getSystemService(AudioManager::class.java)))

        setContent {
            DualscanAlbumPlayerTheme {
                TidalDiamondKiosk(
                    track = trackState.value,
                    canGoBack = canGoBackState.value,
                    onHome = { loadTidalHome() },
                    onCollectionAlbums = { loadTidalCollectionAlbums() },
                    onArtistShortcut = { loadTidalArtistShortcut() },
                    onRefresh = { webView?.reload() },
                    onBack = { webView?.goBack() },
                    onCommand = ::sendWebPlayerCommand
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onDestroy() {
        NativePlaybackStore.pauseWebAudio = null
        mseDocumentScript?.remove()
        mseDocumentScript = null
        mseBufferBridge?.close()
        mseBufferBridge = null
        stopService(Intent(this, PlaybackKeepAliveService::class.java))
        webView?.run {
            stopLoading()
            destroy()
        }
        webView = null
        super.onDestroy()
    }

    private fun loadTidalHome() {
        loadProtectedEntry(currentTidalHomeUrl)
    }

    private fun loadTidalCollectionAlbums() {
        loadProtectedEntry(TIDAL_COLLECTION_ALBUMS_URL)
    }

    private fun loadTidalArtistShortcut() {
        loadProtectedEntry(TIDAL_ARTIST_SHORTCUT_URL)
    }

    private fun loadProtectedEntry(url: String) {
        protectedNavigationActive = true
        webView?.loadUrl(url)
    }

    private fun shouldAllowProtectedNavigation(target: Uri, currentUrl: String?): Boolean {
        if (target.isBlockedSearchUrl()) {
            return false
        }

        if (target.isAllowedAuthenticationUrl()) {
            return true
        }

        if (target.isAllowedEntryUrl()) {
            protectedNavigationActive = true
            return true
        }

        if (!target.isTidalWebUrl()) {
            return false
        }

        if (!protectedNavigationActive) {
            return false
        }

        val current = currentUrl?.toUriOrNull() ?: return true
        return current.isAllowedEntryUrl() || current.isTidalWebUrl()
    }

    private fun rejectToDefaultHome(view: WebView) {
        protectedNavigationActive = true
        view.stopLoading()
        view.loadUrl(currentTidalHomeUrl)
    }

    private fun readConfiguredTidalHomeUrl(): String {
        return tidalConfigTexts()
            .mapNotNull { text -> extractFirstTidalUrl(text) }
            .firstOrNull()
            ?: DEFAULT_TIDAL_HOME_URL
    }

    private fun tidalConfigTexts(): Sequence<String> {
        return sequence {
            tidalConfigCandidates().forEach { file ->
                runCatching { file.takeIf { it.isFile }?.readText() }
                    .getOrNull()
                    ?.let { yield(it) }
            }
            readTidalConfigFromMediaStore()?.let { yield(it) }
        }
    }

    @Suppress("DEPRECATION")
    private fun tidalConfigCandidates(): List<File> {
        val publicMusic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        val externalMusic = File(Environment.getExternalStorageDirectory(), "Music/$TIDAL_CONFIG_FILE_NAME")
        val appMusic = getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        return listOfNotNull(
            File(publicMusic, TIDAL_CONFIG_FILE_NAME),
            externalMusic,
            File("/storage/emulated/0/Music/$TIDAL_CONFIG_FILE_NAME"),
            File("/sdcard/Music/$TIDAL_CONFIG_FILE_NAME"),
            File("/sdcard/music/$TIDAL_CONFIG_FILE_NAME"),
            appMusic?.let { File(it, TIDAL_CONFIG_FILE_NAME) }
        ).distinctBy { it.absolutePath }
    }

    private fun readTidalConfigFromMediaStore(): String? {
        val collection = MediaStore.Files.getContentUri(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.VOLUME_EXTERNAL_PRIMARY
            } else {
                "external"
            }
        )
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.RELATIVE_PATH
        )
        val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME}=? AND " +
            "${MediaStore.Files.FileColumns.RELATIVE_PATH} LIKE ?"
        val args = arrayOf(TIDAL_CONFIG_FILE_NAME, "Music/%")

        return runCatching {
            contentResolver.query(collection, projection, selection, args, null)?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                while (cursor.moveToNext()) {
                    val uri = ContentUris.withAppendedId(collection, cursor.getLong(idColumn))
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (!text.isNullOrBlank()) return@use text
                }
                null
            }
        }.getOrNull()
    }

    private fun extractFirstTidalUrl(text: String): String? {
        return TIDAL_URL_PATTERN.find(text)
            ?.value
            ?.trimEnd('.', ',', ';', ')', ']')
            ?.let { normalizeTidalUrl(it) }
    }

    private fun requestPublicMusicAccessIfNeeded() {
        if (currentTidalHomeUrl != DEFAULT_TIDAL_HOME_URL) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        if (Environment.isExternalStorageManager()) return
        if (storageAccessPrompted) return

        storageAccessPrompted = true
        pageState.value = "Allow files access to read Music/tidal.txt"
        Toast.makeText(
            this,
            "Allow files access so Diamond Player can read Music/tidal.txt.",
            Toast.LENGTH_LONG
        ).show()

        val appSettings = Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:$packageName")
        )
        runCatching { startActivity(appSettings) }
            .onFailure {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }
    }

    private fun normalizeTidalUrl(value: String): String? {
        val parsed = runCatching { Uri.parse(value) }.getOrNull() ?: return null
        val scheme = parsed.scheme?.lowercase() ?: return null
        val host = parsed.host?.lowercase() ?: return null
        if (scheme != "https" || (host != "tidal.com" && !host.endsWith(".tidal.com"))) {
            return null
        }
        return parsed.toString()
    }

    private fun String.toUriOrNull(): Uri? {
        return runCatching { Uri.parse(this) }.getOrNull()
    }

    private fun Uri.isTidalWebUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase() ?: return false
        if (normalizedScheme != "https") return false

        val normalizedHost = host?.lowercase() ?: return false
        return normalizedHost == "tidal.com" || normalizedHost.endsWith(".tidal.com")
    }

    private fun Uri.isAllowedAuthenticationUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase() ?: return false
        if (normalizedScheme != "https") return false

        val normalizedHost = host?.lowercase() ?: return false
        if (normalizedHost in AUTH_FLOW_HOSTS) return true

        if (normalizedHost == "tidal.com" || normalizedHost.endsWith(".tidal.com")) {
            val pathText = path.orEmpty().lowercase()
            return AUTH_FLOW_PATH_MARKERS.any { marker -> marker in pathText }
        }

        return false
    }

    private fun Uri.isAllowedEntryUrl(): Boolean {
        return isSameRoute(currentTidalHomeUrl) ||
            isSameRoute(TIDAL_COLLECTION_ALBUMS_URL) ||
            isSameRoute(TIDAL_ARTIST_SHORTCUT_URL)
    }

    private fun Uri.isBlockedSearchUrl(): Boolean {
        if (!isTidalWebUrl()) return false

        val pathSegments = pathSegments.map { it.lowercase() }
        if ("search" in pathSegments) return true

        val normalizedPath = path.orEmpty().lowercase()
        val normalizedQuery = query.orEmpty().lowercase()
        val normalizedFragment = fragment.orEmpty().lowercase()
        return normalizedPath.contains("/search") ||
            normalizedQuery.contains("search") ||
            normalizedFragment.contains("search")
    }

    private fun Uri.isSameRoute(url: String): Boolean {
        val expected = Uri.parse(url)
        return scheme?.lowercase() == expected.scheme?.lowercase() &&
            host?.lowercase() == expected.host?.lowercase() &&
            path?.trimEnd('/') == expected.path?.trimEnd('/') &&
            (query ?: "") == (expected.query ?: "")
    }

    private fun sendWebPlayerCommand(command: WebPlayerCommand) {
        webView?.evaluateJavascript(command.javascript(), null)
    }

    private fun updateTrackState(payload: String) {
        runCatching {
            val json = JSONObject(payload)
            val next = TidalTrackState(
                title = json.optString("title").cleanMetadata().ifBlank { "TIDAL Web Player" },
                artist = json.optString("artist").cleanMetadata().ifBlank { "Waiting for playback" },
                album = json.optString("album").cleanMetadata(),
                fidelity = ReportedSourceQuality.label(json.optString("fidelity")),
                isPlaying = json.optBoolean("isPlaying", false),
                pageUrl = json.optString("url").cleanMetadata()
            )
            trackState.value = next
            if (NativePlaybackStore.state.playing && next.isPlaying) {
                webView?.evaluateJavascript(WEB_PAUSE, null)
            }
            setPlaybackKeepAlive(next.isPlaying && !NativePlaybackStore.state.playing)
            pageState.value = if (next.isPlaying) "Playing through TIDAL Web Player" else "Ready in TIDAL Web Player"
        }.onFailure {
            pageState.value = "Connected to TIDAL Web Player"
        }
    }

    private fun setPlaybackKeepAlive(isPlaying: Boolean) {
        if (playbackKeepAliveStarted == isPlaying) return

        playbackKeepAliveStarted = isPlaying
        val intent = Intent(this, PlaybackKeepAliveService::class.java)
        if (isPlaying) {
            intent.action = PlaybackKeepAliveService.ACTION_START
            ContextCompat.startForegroundService(this, intent)
        } else {
            stopService(intent)
        }
    }

    private fun String.cleanMetadata(): String {
        return replace('\n', ' ')
            .replace('\t', ' ')
            .trim()
            .take(140)
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun TidalDiamondKiosk(
        track: TidalTrackState,
        canGoBack: Boolean,
        onHome: () -> Unit,
        onCollectionAlbums: () -> Unit,
        onArtistShortcut: () -> Unit,
        onRefresh: () -> Unit,
        onBack: () -> Unit,
        onCommand: (WebPlayerCommand) -> Unit
    ) {
        var panelExpanded by rememberSaveable { mutableStateOf(true) }
        var playerVisible by rememberSaveable { mutableStateOf(true) }
        val native = NativePlaybackStore.state
        var openingWeb by rememberSaveable { mutableStateOf(false) }
        var pendingWebUrl by rememberSaveable { mutableStateOf<String?>(null) }
        val openFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                nativeModeState.value = true
                uris.forEach { uri -> runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
                NativePlaybackService.command(this@MainActivity, NativePlaybackService.ACTION_LOAD) {
                    it.putStringArrayListExtra(NativePlaybackService.EXTRA_URIS, ArrayList(uris.map(Uri::toString)))
                }
            }
        }
        LaunchedEffect(native.playing) {
            if (native.playing) { nativeModeState.value = true; openingWeb = false; pendingWebUrl = null }
        }
        LaunchedEffect(openingWeb, native.resourcesReleased) {
            if (openingWeb && native.resourcesReleased) {
                pendingWebUrl?.let { webView?.loadUrl(it) }
                pendingWebUrl = null
                nativeModeState.value = false
                openingWeb = false
            }
        }
        var railOffsetX by rememberSaveable { mutableStateOf(0f) }
        var railOffsetY by rememberSaveable { mutableStateOf(0f) }
        val density = LocalDensity.current
        val topRailPadding = with(density) { WindowInsets.statusBars.getTop(this).toDp() } + 64.dp

        BackHandler(enabled = canGoBack) {
            onBack()
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            val railWidthEstimate = 244.dp
            val railHeightEstimate = 58.dp
            val maxRailOffsetX = with(density) {
                (maxWidth - railWidthEstimate - 20.dp).coerceAtLeast(0.dp).toPx()
            }
            val maxRailOffsetY = with(density) {
                (maxHeight - topRailPadding - railHeightEstimate - 20.dp).coerceAtLeast(0.dp).toPx()
            }

            TidalWebView(
                modifier = Modifier.fillMaxSize(),
                hidden = nativeModeState.value,
                onPageStatus = { pageState.value = it },
                onCanGoBackChanged = { canGoBackState.value = it }
            )

            if (nativeModeState.value) {
                NativePlayerScreen(
                    state = native,
                    mseState = mseBufferState.value,
                    onOpenFiles = { openFiles.launch(arrayOf("audio/*")) },
                    onBufferProof = { startActivity(Intent(this@MainActivity, NativeBufferProofActivity::class.java)) },
                    onOpenTidalPlayer = {
                        pendingWebUrl = "https://listen.tidal.com/"
                        openingWeb = true
                        if (!native.resourcesReleased) NativePlaybackService.command(this@MainActivity, NativePlaybackService.ACTION_STOP)
                    },
                    onArmTidalBuffer = { mseBufferBridge?.arm() },
                    onCancelTidalBuffer = { mseBufferBridge?.cancel() },
                    onPlayTidalBuffer = { nativeModeState.value = true; mseBufferBridge?.playBuffered() },
                    onCommand = { action, value ->
                        NativePlaybackService.command(this@MainActivity, action) { intent ->
                            when (action) {
                                NativePlaybackService.ACTION_PLAY -> value?.let { intent.putExtra(NativePlaybackService.EXTRA_INDEX, it.toInt()) }
                                NativePlaybackService.ACTION_DEVICE -> intent.putExtra(NativePlaybackService.EXTRA_DEVICE, value?.toInt() ?: -1)
                                NativePlaybackService.ACTION_STRICT -> intent.putExtra(NativePlaybackService.EXTRA_STRICT, value == 1L)
                                NativePlaybackService.ACTION_SEEK -> intent.putExtra(NativePlaybackService.EXTRA_POSITION, value ?: 0L)
                            }
                        }
                    },
                    modifier = Modifier.padding(top = topRailPadding)
                )
            }

            Row(modifier = Modifier.align(Alignment.TopCenter)
                .padding(top = with(density) { WindowInsets.statusBars.getTop(this).toDp() } + 8.dp)
                .background(Color.Black.copy(alpha = .95f), RoundedCornerShape(24.dp))) {
                TextButton(onClick = {
                    if (!native.resourcesReleased) {
                        openingWeb = true
                        NativePlaybackService.command(this@MainActivity, NativePlaybackService.ACTION_STOP)
                    } else nativeModeState.value = false
                }) { Text(if (openingWeb) "Releasing output…" else "TIDAL Web", color = if (!nativeModeState.value) DiamondMagenta else Color.White) }
                TextButton(onClick = {
                    openingWeb = false
                    NativePlaybackStore.pauseWebAudio?.invoke { nativeModeState.value = true }
                }) { Text("Native files", color = if (nativeModeState.value) DiamondMagenta else Color.White) }
            }

            if (!nativeModeState.value) DiamondTopRail(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 10.dp, top = topRailPadding)
                    .offset {
                        IntOffset(railOffsetX.roundToInt(), railOffsetY.roundToInt())
                    }
                    .pointerInput(maxRailOffsetX, maxRailOffsetY) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            railOffsetX = (railOffsetX + dragAmount.x).coerceIn(0f, maxRailOffsetX)
                            railOffsetY = (railOffsetY + dragAmount.y).coerceIn(0f, maxRailOffsetY)
                        }
                    },
                canGoBack = canGoBack,
                onHome = onHome,
                onCollectionAlbums = onCollectionAlbums,
                onArtistShortcut = onArtistShortcut,
                onRefresh = onRefresh,
                onBack = onBack,
                playerVisible = playerVisible,
                onTogglePlayerVisible = { playerVisible = !playerVisible }
            )

            AnimatedVisibility(
                visible = playerVisible && !nativeModeState.value,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                DiamondPlayerPanel(
                    modifier = Modifier.padding(12.dp),
                    track = track,
                    mseState = mseBufferState.value,
                    onArmTidalBuffer = { mseBufferBridge?.arm() },
                    onCancelTidalBuffer = { mseBufferBridge?.cancel() },
                    onPlayTidalBuffer = { nativeModeState.value = true; mseBufferBridge?.playBuffered() },
                    expanded = panelExpanded,
                    onToggleExpanded = { panelExpanded = !panelExpanded },
                    onCommand = onCommand
                )
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun TidalWebView(
        modifier: Modifier = Modifier,
        hidden: Boolean,
        onPageStatus: (String) -> Unit,
        onCanGoBackChanged: (Boolean) -> Unit
    ) {
        val context = LocalContext.current
        AndroidView(
            modifier = modifier,
            factory = {
                WebView(context).apply {
                    webView = this
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)

                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.setSupportMultipleWindows(false)
                    settings.userAgentString = BROWSER_USER_AGENT

                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    val nativeBuffer = TidalMseBufferBridge(context, this) { mseBufferState.value = it }
                    mseBufferBridge = nativeBuffer
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                        mseDocumentScript = WebViewCompat.addDocumentStartJavaScript(this, nativeBuffer.bootstrapScript(), setOf("https://listen.tidal.com"))
                    }

                    addJavascriptInterface(DiamondBridge(), "DiamondBridge")
                    webChromeClient = DiamondChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                            nativeBuffer.onNavigationStarted()
                        }
                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            if (!request.isForMainFrame) return false

                            val target = request.url
                            if (shouldAllowProtectedNavigation(target, view.url)) {
                                return false
                            }

                            onPageStatus("Blocked outside Diamond Player")
                            rejectToDefaultHome(view)
                            return true
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            onPageStatus("Connected to TIDAL Web Player")
                            onCanGoBackChanged(view.canGoBack())
                            view.injectDiamondBridge()
                            nativeBuffer.attach()
                        }

                        override fun onPageCommitVisible(view: WebView, url: String) {
                            onPageStatus("TIDAL Web Player visible")
                        }

                        override fun onReceivedError(
                            view: WebView,
                            request: WebResourceRequest,
                            error: WebResourceError
                        ) {
                            if (request.isForMainFrame) {
                                onPageStatus("TIDAL page load issue")
                            }
                        }

                        override fun onReceivedSslError(
                            view: WebView,
                            handler: SslErrorHandler,
                            error: SslError
                        ) {
                            handler.cancel()
                            onPageStatus("Secure TIDAL connection blocked")
                        }
                    }

                    loadUrl(currentTidalHomeUrl)
                }
            },
            update = {
                it.visibility = if (hidden) android.view.View.INVISIBLE else android.view.View.VISIBLE
                it.importantForAccessibility = if (hidden) android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                    else android.view.View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
                it.injectDiamondBridge()
            }
        )
    }

    private inner class DiamondChromeClient : WebChromeClient() {
        override fun onPermissionRequest(request: PermissionRequest) {
            val protectedMediaResources = request.resources
                .filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                .toTypedArray()

            if (protectedMediaResources.isNotEmpty()) {
                request.grant(protectedMediaResources)
            } else {
                request.deny()
            }
        }
    }

    private inner class DiamondBridge {
        @JavascriptInterface
        fun postMetadata(payload: String) {
            runOnUiThread { updateTrackState(payload) }
        }

        @JavascriptInterface
        fun rejectBlockedPage() {
            runOnUiThread {
                webView?.let { rejectToDefaultHome(it) }
            }
        }
    }

    private fun WebView.injectDiamondBridge() {
        evaluateJavascript(
            DIAMOND_METADATA_BRIDGE.replace(
                "__DIAMOND_HOME_URL__",
                currentTidalHomeUrl.toJavaScriptSingleQuotedString()
            ),
            null
        )
    }

    private fun String.toJavaScriptSingleQuotedString(): String {
        return replace("\\", "\\\\").replace("'", "\\'")
    }

    enum class WebPlayerCommand {
        PlayPause,
        Next,
        Previous;

        fun javascript(): String {
            return when (this) {
                PlayPause -> WEB_PLAY_PAUSE
                Next -> WEB_NEXT
                Previous -> WEB_PREVIOUS
            }
        }
    }

    data class TidalTrackState(
        val title: String = "TIDAL Web Player",
        val artist: String = "Sign in and press play",
        val album: String = "",
        val fidelity: String = "FORMAT UNKNOWN",
        val isPlaying: Boolean = false,
        val pageUrl: String = DEFAULT_TIDAL_HOME_URL
    )

    companion object {
        private const val DEFAULT_TIDAL_HOME_URL =
            "https://tidal.com/album/511615560"
        private const val TIDAL_CONFIG_FILE_NAME = "tidal.txt"
        private val TIDAL_URL_PATTERN =
            Regex("""https://(?:[A-Za-z0-9-]+\.)*tidal\.com/[^\s"'<>]+""", RegexOption.IGNORE_CASE)
        private const val TIDAL_COLLECTION_ALBUMS_URL = DEFAULT_TIDAL_HOME_URL
        private const val TIDAL_ARTIST_SHORTCUT_URL = DEFAULT_TIDAL_HOME_URL
        private const val BROWSER_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 15; Diamond Player) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
        private val AUTH_FLOW_HOSTS = setOf(
            "account.tidal.com",
            "accounts.tidal.com",
            "auth.tidal.com",
            "login.tidal.com",
            "id.tidal.com",
            "my.tidal.com",
            "accounts.google.com",
            "appleid.apple.com",
            "facebook.com",
            "www.facebook.com"
        )
        private val AUTH_FLOW_PATH_MARKERS = listOf(
            "/login",
            "/auth",
            "/oauth",
            "/authorize",
            "/account",
            "/signin",
            "/sign-in",
            "/callback"
        )

        private const val DIAMOND_METADATA_BRIDGE = """
(function(){
  if (window.__diamondBridgeInstalled) { return; }
  window.__diamondBridgeInstalled = true;

  var DIAMOND_HOME_URL = '__DIAMOND_HOME_URL__';

  function isBlockedSearchUrl(value) {
    try {
      var url = new URL(value || window.location.href, window.location.href);
      var path = (url.pathname || '').toLowerCase();
      var query = (url.search || '').toLowerCase();
      var hash = (url.hash || '').toLowerCase();
      return /(^|\/)search(\/|${'$'})/i.test(path) ||
        path.indexOf('/search') !== -1 ||
        query.indexOf('search') !== -1 ||
        hash.indexOf('search') !== -1;
    } catch (error) {
      return false;
    }
  }

  function rejectBlockedSearch() {
    if (window.DiamondBridge && window.DiamondBridge.rejectBlockedPage) {
      window.DiamondBridge.rejectBlockedPage();
    } else {
      window.location.replace(DIAMOND_HOME_URL);
    }
  }

  function guardCurrentRoute() {
    if (isBlockedSearchUrl(window.location.href)) {
      rejectBlockedSearch();
      return true;
    }
    return false;
  }

  document.addEventListener('click', function(event) {
    var node = event.target;
    while (node && node !== document) {
      if (node.href && isBlockedSearchUrl(node.href)) {
        event.preventDefault();
        event.stopPropagation();
        rejectBlockedSearch();
        return;
      }
      node = node.parentNode;
    }
  }, true);

  ['pushState', 'replaceState'].forEach(function(methodName) {
    var original = history[methodName];
    history[methodName] = function() {
      var result = original.apply(this, arguments);
      setTimeout(guardCurrentRoute, 0);
      return result;
    };
  });

  window.addEventListener('popstate', function() {
    setTimeout(guardCurrentRoute, 0);
  });
  setInterval(guardCurrentRoute, 750);
  guardCurrentRoute();

  function clean(value) {
    return (value || '').toString().replace(/\s+/g, ' ').trim();
  }

  function firstText(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var node = document.querySelector(selectors[i]);
      var value = node ? clean(node.textContent || node.getAttribute('aria-label') || node.getAttribute('title')) : '';
      if (value) { return value; }
    }
    return '';
  }

  function pageMedia() {
    var nodes = Array.prototype.slice.call(document.querySelectorAll('audio,video'));
    return nodes.find(function(node) { return node && !node.paused && !node.ended; }) || nodes[0] || null;
  }

  function fidelityFromPage() {
    var selectors = [
      '[data-test*="quality" i]',
      '[data-test*="fidelity" i]',
      '[aria-label*="quality" i]',
      '[aria-label*="bit" i]',
      '[aria-label*="khz" i]',
      '[class*="nowPlaying" i] [class*="quality" i]',
      '[class*="player" i] [class*="fidelity" i]'
    ];
    var values = [];
    selectors.forEach(function(selector) {
      Array.prototype.slice.call(document.querySelectorAll(selector), 0, 8).forEach(function(node) {
        var value = clean(node.textContent || node.getAttribute('aria-label') || node.getAttribute('title'));
        if (value) { values.push(value); }
      });
    });

    return clean(values.join(' ')).slice(0, 500);
  }

  function sendMetadata() {
    try {
      var meta = navigator.mediaSession && navigator.mediaSession.metadata ? navigator.mediaSession.metadata : null;
      var media = pageMedia();
      var payload = {
        title: clean((meta && meta.title) || firstText([
          '[data-test*="now-playing-title" i]',
          '[data-test*="track-title" i]',
          '[class*="nowPlaying" i] [class*="title" i]',
          '[class*="player" i] [class*="title" i]'
        ]) || document.title || 'TIDAL Web Player'),
        artist: clean((meta && meta.artist) || firstText([
          '[data-test*="now-playing-artist" i]',
          '[data-test*="artist" i]',
          '[class*="nowPlaying" i] [class*="artist" i]',
          '[class*="player" i] [class*="artist" i]'
        ])),
        album: clean((meta && meta.album) || firstText([
          '[data-test*="album" i]',
          '[class*="nowPlaying" i] [class*="album" i]'
        ])),
        fidelity: fidelityFromPage(),
        isPlaying: !!(media && !media.paused && !media.ended),
        url: location.href
      };
      window.DiamondBridge.postMetadata(JSON.stringify(payload));
    } catch (error) {}
  }

  try {
    var OriginalMediaMetadata = window.MediaMetadata;
    if (OriginalMediaMetadata && !window.__diamondMediaMetadataPatched) {
      window.__diamondMediaMetadataPatched = true;
      window.MediaMetadata = function(init) {
        var metadata = new OriginalMediaMetadata(init);
        setTimeout(sendMetadata, 0);
        return metadata;
      };
      window.MediaMetadata.prototype = OriginalMediaMetadata.prototype;
    }
  } catch (error) {}

  ['play','pause','ended','loadedmetadata','durationchange','timeupdate'].forEach(function(name) {
    document.addEventListener(name, sendMetadata, true);
  });

  setInterval(sendMetadata, 1200);
  setTimeout(sendMetadata, 300);
})();
"""

        private const val WEB_PLAY_PAUSE = """
(function(){
  var media = Array.prototype.slice.call(document.querySelectorAll('audio,video'))[0];
  if (media) {
    if (media.paused) { media.play(); } else { media.pause(); }
    return true;
  }
  var labels = ['play', 'pause'];
  var buttons = Array.prototype.slice.call(document.querySelectorAll('button,[role="button"]'));
  var button = buttons.find(function(item) {
    var label = ((item.getAttribute('aria-label') || item.title || item.textContent || '') + '').toLowerCase();
    return labels.some(function(value) { return label.indexOf(value) >= 0; });
  });
  if (button) { button.click(); return true; }
  return false;
})();
"""

        private const val WEB_PAUSE = """
(function(){
  Array.prototype.slice.call(document.querySelectorAll('audio,video')).forEach(function(media) { media.pause(); });
  return true;
})();
"""

        private const val WEB_NEXT = """
(function(){
  function visible(node) {
    if (!node || node.disabled || node.getAttribute('aria-disabled') === 'true') { return false; }
    var rect = node.getBoundingClientRect();
    var style = window.getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  }

  function descriptor(node) {
    if (!node) { return ''; }
    var data = [];
    ['aria-label','title','data-test','data-testid','class','id'].forEach(function(name) {
      var value = node.getAttribute && node.getAttribute(name);
      if (value) { data.push(value); }
    });
    data.push(node.textContent || '');
    Array.prototype.slice.call(node.querySelectorAll('[aria-label], title, svg, use')).forEach(function(child) {
      data.push(child.getAttribute('aria-label') || child.getAttribute('title') || child.textContent || '');
      data.push(child.getAttribute('href') || child.getAttribute('xlink:href') || '');
    });
    return data.join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function clickNode(node) {
    if (!node) { return false; }
    var button = node.closest ? (node.closest('button,[role="button"]') || node) : node;
    if (!visible(button)) { return false; }
    button.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
    button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    button.click();
    button.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  function isNext(desc) {
    return /(next|skip\s*forward|forward|following|track-next|skip-next)/i.test(desc) &&
      !/(previous|prev|back|rewind)/i.test(desc);
  }

  var directSelectors = [
    'button[aria-label*="next" i]',
    '[role="button"][aria-label*="next" i]',
    '[data-test*="next" i]',
    '[data-testid*="next" i]',
    '[class*="next" i]',
    '[id*="next" i]'
  ];
  for (var i = 0; i < directSelectors.length; i++) {
    var direct = Array.prototype.slice.call(document.querySelectorAll(directSelectors[i])).find(function(node) {
      return visible(node.closest ? (node.closest('button,[role="button"]') || node) : node);
    });
    if (direct && clickNode(direct)) { return true; }
  }

  var buttons = Array.prototype.slice.call(document.querySelectorAll('button,[role="button"]')).filter(visible);
  var labeled = buttons.find(function(item) { return isNext(descriptor(item)); });
  if (labeled && clickNode(labeled)) { return true; }

  var play = buttons.find(function(item) {
    var desc = descriptor(item);
    return /(play|pause)/i.test(desc) && !/(replay|playlist)/i.test(desc);
  });
  if (play) {
    var playRect = play.getBoundingClientRect();
    var playCenterY = playRect.top + playRect.height / 2;
    var playCenterX = playRect.left + playRect.width / 2;
    var rowButtons = buttons
      .filter(function(item) {
        var rect = item.getBoundingClientRect();
        var centerY = rect.top + rect.height / 2;
        var centerX = rect.left + rect.width / 2;
        return Math.abs(centerY - playCenterY) < 80 && centerX > playCenterX + 8;
      })
      .sort(function(a, b) {
        return a.getBoundingClientRect().left - b.getBoundingClientRect().left;
      });
    if (rowButtons.length && clickNode(rowButtons[0])) { return true; }
  }

  window.dispatchEvent(new KeyboardEvent('keydown', { key: 'MediaTrackNext', bubbles: true }));
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'MediaTrackNext', bubbles: true }));
  return false;
})();
"""

        private const val WEB_PREVIOUS = """
(function(){
  function visible(node) {
    if (!node || node.disabled || node.getAttribute('aria-disabled') === 'true') { return false; }
    var rect = node.getBoundingClientRect();
    var style = window.getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  }

  function descriptor(node) {
    if (!node) { return ''; }
    var data = [];
    ['aria-label','title','data-test','data-testid','class','id'].forEach(function(name) {
      var value = node.getAttribute && node.getAttribute(name);
      if (value) { data.push(value); }
    });
    data.push(node.textContent || '');
    Array.prototype.slice.call(node.querySelectorAll('[aria-label], title, svg, use')).forEach(function(child) {
      data.push(child.getAttribute('aria-label') || child.getAttribute('title') || child.textContent || '');
      data.push(child.getAttribute('href') || child.getAttribute('xlink:href') || '');
    });
    return data.join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function clickNode(node) {
    if (!node) { return false; }
    var button = node.closest ? (node.closest('button,[role="button"]') || node) : node;
    if (!visible(button)) { return false; }
    button.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
    button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    button.click();
    button.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  function isPrevious(desc) {
    return /(previous|prev|skip\s*back|back|rewind|track-previous|skip-previous)/i.test(desc) &&
      !/(next|forward)/i.test(desc);
  }

  var directSelectors = [
    'button[aria-label*="previous" i]',
    'button[aria-label*="prev" i]',
    '[role="button"][aria-label*="previous" i]',
    '[role="button"][aria-label*="prev" i]',
    '[data-test*="previous" i]',
    '[data-test*="prev" i]',
    '[data-testid*="previous" i]',
    '[data-testid*="prev" i]',
    '[class*="previous" i]',
    '[class*="prev" i]',
    '[id*="previous" i]',
    '[id*="prev" i]'
  ];
  for (var i = 0; i < directSelectors.length; i++) {
    var direct = Array.prototype.slice.call(document.querySelectorAll(directSelectors[i])).find(function(node) {
      return visible(node.closest ? (node.closest('button,[role="button"]') || node) : node);
    });
    if (direct && clickNode(direct)) { return true; }
  }

  var buttons = Array.prototype.slice.call(document.querySelectorAll('button,[role="button"]')).filter(visible);
  var labeled = buttons.find(function(item) { return isPrevious(descriptor(item)); });
  if (labeled && clickNode(labeled)) { return true; }

  var play = buttons.find(function(item) {
    var desc = descriptor(item);
    return /(play|pause)/i.test(desc) && !/(replay|playlist)/i.test(desc);
  });
  if (play) {
    var playRect = play.getBoundingClientRect();
    var playCenterY = playRect.top + playRect.height / 2;
    var playCenterX = playRect.left + playRect.width / 2;
    var rowButtons = buttons
      .filter(function(item) {
        var rect = item.getBoundingClientRect();
        var centerY = rect.top + rect.height / 2;
        var centerX = rect.left + rect.width / 2;
        return Math.abs(centerY - playCenterY) < 80 && centerX < playCenterX - 8;
      })
      .sort(function(a, b) {
        return b.getBoundingClientRect().left - a.getBoundingClientRect().left;
      });
    if (rowButtons.length && clickNode(rowButtons[0])) { return true; }
  }

  window.dispatchEvent(new KeyboardEvent('keydown', { key: 'MediaTrackPrevious', bubbles: true }));
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'MediaTrackPrevious', bubbles: true }));
  return false;
})();
"""
    }
}

@Composable
private fun DiamondTopRail(
    modifier: Modifier = Modifier,
    canGoBack: Boolean,
    onHome: () -> Unit,
    onCollectionAlbums: () -> Unit,
    onArtistShortcut: () -> Unit,
    onRefresh: () -> Unit,
    onBack: () -> Unit,
    playerVisible: Boolean,
    onTogglePlayerVisible: () -> Unit
) {
    Surface(
        modifier = modifier,
        color = DiamondBlack.copy(alpha = 0.72f),
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier.padding(start = 8.dp, top = 4.dp, end = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                modifier = Modifier.size(42.dp),
                onClick = onCollectionAlbums
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(DiamondMagenta.copy(alpha = 0.18f))
                        .border(1.dp, DiamondMagenta.copy(alpha = 0.82f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = "My Collection Albums",
                        tint = DiamondMagenta,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }

            Spacer(Modifier.width(4.dp))

            IconButton(
                modifier = Modifier.size(42.dp),
                onClick = onArtistShortcut
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFFFFB84D),
                                    Color(0xFFFF00FE),
                                    Color(0xFF6D45FF)
                                )
                            )
                        )
                        .border(1.dp, DiamondMagenta.copy(alpha = 0.8f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "VI",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                }
            }
            IconButton(onClick = onHome) {
                Icon(Icons.Filled.Home, contentDescription = "Home", tint = DiamondMagenta)
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = DiamondMagenta)
            }
            IconButton(onClick = onTogglePlayerVisible) {
                Icon(
                    imageVector = if (playerVisible) Icons.Filled.CloseFullscreen else Icons.Filled.OpenInFull,
                    contentDescription = if (playerVisible) "Hide player" else "Show player",
                    tint = DiamondMagenta
                )
            }
        }
    }
}

@Composable
private fun DiamondPlayerPanel(
    modifier: Modifier = Modifier,
    track: MainActivity.TidalTrackState,
    mseState: MseBufferState,
    onArmTidalBuffer: () -> Unit,
    onCancelTidalBuffer: () -> Unit,
    onPlayTidalBuffer: () -> Unit,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onCommand: (MainActivity.WebPlayerCommand) -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = DiamondBlack.copy(alpha = 0.92f),
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(
                            DiamondPanelTop.copy(alpha = 0.98f),
                            DiamondBlack.copy(alpha = 0.99f)
                        )
                    )
                )
                .border(1.dp, DiamondMagenta.copy(alpha = 0.38f), RoundedCornerShape(24.dp))
                .padding(start = 18.dp, top = 14.dp, end = 14.dp, bottom = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(if (expanded) 64.dp else 44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DiamondMagenta)
                )
                Spacer(Modifier.width(14.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = track.title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = if (expanded) 2 else 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(10.dp))
                        FidelityBadge("SOURCE: " + track.fidelity)
                    }
                    Text(
                        text = track.artist,
                        color = DiamondMagenta.copy(alpha = 0.86f),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    AnimatedVisibility(visible = expanded && track.album.isNotBlank()) {
                        Text(
                            text = track.album,
                            color = Color.White.copy(alpha = 0.44f),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(onClick = onToggleExpanded) {
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandMore else Icons.Filled.ExpandLess,
                        contentDescription = if (expanded) "Collapse" else "Expand",
                        tint = DiamondMagenta
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column {
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { onCommand(MainActivity.WebPlayerCommand.Previous) }) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = DiamondMagenta)
                        }
                        IconButton(
                            modifier = Modifier
                                .size(66.dp)
                                .clip(CircleShape)
                                .background(DiamondMagenta)
                                .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape),
                            onClick = { onCommand(MainActivity.WebPlayerCommand.PlayPause) }
                        ) {
                            Icon(
                                imageVector = if (track.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (track.isPlaying) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        IconButton(onClick = { onCommand(MainActivity.WebPlayerCommand.Next) }) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = DiamondMagenta)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "WEB AUDIO · ANDROID OUTPUT UNVERIFIED",
                        color = DiamondMagenta.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    TidalBufferControls(mseState, onArmTidalBuffer, onCancelTidalBuffer, onPlayTidalBuffer)
                }
            }
        }
    }
}

@Composable
private fun FidelityBadge(value: String) {
    Text(
        text = value.ifBlank { "BIT/KHZ" }.uppercase(),
        color = DiamondMagenta,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(DiamondMagenta.copy(alpha = 0.10f))
            .border(1.dp, DiamondMagenta.copy(alpha = 0.70f), RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

private val DiamondMagenta = Color(0xFFFF00FE)
private val DiamondBlack = Color(0xFF000000)
private val DiamondPanelTop = Color(0xFF070007)
