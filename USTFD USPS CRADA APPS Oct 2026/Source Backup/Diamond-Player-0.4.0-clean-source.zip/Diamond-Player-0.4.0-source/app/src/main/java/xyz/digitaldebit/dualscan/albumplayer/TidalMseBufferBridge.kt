package com.dualscan.music.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.WebMessage
import android.webkit.WebMessagePort
import android.webkit.WebView
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger

data class MseBufferState(
    val status: String = "Clear MSE handoff is unverified. Arm before starting a new track.",
    val capturing: Boolean = false,
    val byteCount: Long = 0,
    val ready: Boolean = false,
    val validated: ValidatedClearFmp4? = null,
    val sha256: String? = null,
    val error: String? = null
)

/**
 * Receives only bounded, acknowledged PRE-DECODE bytes from the separate MSE probe.
 * This performs complete-track buffering, not WebAudio recording or live clock takeover.
 * Protected/unknown/missing/discontinuous content fails closed. A completed capture must
 * pass a second native container/timeline validator before it can reach NativeAudioEngine.
 */
class TidalMseBufferBridge(
    private val context: Context,
    private val webView: WebView,
    private val trustedOrigin: String = "https://listen.tidal.com",
    private val publish: (MseBufferState) -> Unit = {}
) : AutoCloseable {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val epoch = AtomicLong()
    private val queuedMessages = AtomicInteger()
    private val directory = File(context.noBackupFilesDir, "clear-mse-buffer").apply { mkdirs() }
    private var port: WebMessagePort? = null
    @Volatile private var closed = false
    private var session: Session? = null // worker-thread confined
    private var prepared: File? = null // main-thread confined
    private val retained = mutableListOf<File>()
    @Volatile var state: MseBufferState = MseBufferState()
        private set
    private data class Session(val id: String, val file: File, val output: FileOutputStream,
        val digest: MessageDigest = MessageDigest.getInstance("SHA-256"), var sequence: Long = 0, var bytes: Long = 0)

    init {
        val expected = Uri.parse(trustedOrigin)
        require(expected.scheme == "https" && expected.host != null && expected.path.orEmpty() in listOf("", "/") && expected.query == null)
        NativeBufferLifetime.acquire(context)
    }

    /** Install this at document start when supported, and on the current page before arming. */
    fun bootstrapScript(): String = context.assets.open("native-bridge/diamond-mse-probe.js").bufferedReader().use { it.readText() }

    /** Call after main-document completion; the exact origin is checked again for every message. */
    fun attach() {
        if (closed || !trustedDocument()) return
        port?.close()
        webView.evaluateJavascript(bootstrapScript()) {
            if (closed || !trustedDocument()) return@evaluateJavascript
            val channel = webView.createWebMessageChannel()
            port = channel[0].apply {
                setWebMessageCallback(object : WebMessagePort.WebMessageCallback() {
                    override fun onMessage(port: WebMessagePort, message: WebMessage) {
                        if (!closed && trustedDocument()) accept(message.data.orEmpty())
                    }
                }, main)
            }
            webView.postWebMessage(WebMessage("diamond-mse-port-v1", arrayOf(channel[1])), Uri.parse(trustedOrigin))
            emit(state.copy(status = "Ready to buffer a new supported TIDAL track for native playback."))
        }
    }

    fun arm() {
        if (closed || !trustedDocument() || port == null) {
            emit(state.copy(error = "The trusted TIDAL page is not ready for the clear-stream probe.")); return
        }
        epoch.incrementAndGet()
        worker.execute { discardSession() }
        prepared?.let(retained::add)
        prepared = null
        emit(MseBufferState(status = "Waiting for a complete supported stream. Start a new track. Native playback becomes available after full-track buffering.", capturing = true))
        webView.evaluateJavascript("window.__diamondMseProbe && window.__diamondMseProbe.arm()", null)
    }

    fun cancel() {
        epoch.incrementAndGet()
        worker.execute { discardSession() }
        if (trustedDocument()) webView.evaluateJavascript("window.__diamondMseProbe && window.__diamondMseProbe.cancel()", null)
        emit(state.copy(status = "Clear-track buffering cancelled.", capturing = false))
    }

    /** Explicit user action; the browser is paused only after independent complete-file validation. */
    fun playBuffered() {
        val file = prepared
        if (!state.ready || file == null || !file.isFile) {
            emit(state.copy(error = "There is no complete validated clear track to play.")); return
        }
        val start = {
            if (!closed && prepared == file) {
                NativePlaybackService.command(context, NativePlaybackService.ACTION_LOAD) {
                    it.putStringArrayListExtra(NativePlaybackService.EXTRA_URIS, arrayListOf(Uri.fromFile(file).toString()))
                    it.putStringArrayListExtra(NativePlaybackService.EXTRA_NAMES, arrayListOf("Buffered clear TIDAL audio"))
                }
                emit(state.copy(status = "Buffered track handed to native playback. Check the native player for exact USB output verification."))
            }
        }
        val pause = NativePlaybackStore.pauseWebAudio
        if (pause != null) pause(start) else {
            // The callback itself is an acknowledgement from the trusted main document.
            webView.evaluateJavascript("(function(){document.querySelectorAll('audio,video').forEach(function(m){m.pause();});return true;})()") { start() }
        }
    }

    fun onNavigationStarted() {
        epoch.incrementAndGet()
        port?.close(); port = null
        worker.execute { discardSession() }
        emit(state.copy(status = "Page changed. Reconnect and arm before a new track.", capturing = false))
    }

    private fun trustedDocument(): Boolean {
        val actual = webView.url?.let(Uri::parse) ?: return false
        val expected = Uri.parse(trustedOrigin)
        return actual.scheme == expected.scheme && actual.host == expected.host && actual.port == expected.port
    }

    private fun accept(message: String) {
        if (message.length > 100_000) { reject("The MSE probe exceeded the bounded message size."); return }
        if (queuedMessages.incrementAndGet() > 4) {
            queuedMessages.decrementAndGet()
            reject("The MSE probe exceeded the bounded native queue.")
            return
        }
        val token = epoch.get()
        worker.execute {
            try {
                if (closed || epoch.get() != token) return@execute
                val request = JSONObject(message)
                require(request.optInt("v") == 1) { "Unknown clear-buffer protocol version." }
                when (request.getString("type")) {
                    "start" -> begin(request)
                    "chunk" -> chunk(request, token)
                    "complete" -> complete(request, token)
                    "abort" -> {
                        discardSession()
                        main.post { if (!closed && epoch.get() == token) emit(state.copy(status = "Encrypted or unsupported stream — use normal TIDAL playback.", capturing = false, ready = false)) }
                    }
                    "status" -> main.post {
                        if (!closed && epoch.get() == token) {
                            when (request.optString("reason")) {
                                "protected-page-capture-disabled", "mse-unavailable" -> emit(state.copy(
                                    status = "Encrypted or unsupported stream — use normal TIDAL playback.", capturing = false, ready = false))
                                "armed-awaiting-new-clear-flac-track", "waiting-for-next-track-initialization" -> emit(state.copy(
                                    status = "Waiting for a complete supported stream. Start a new track.", capturing = true))
                                "cancelled" -> emit(state.copy(status = "Track buffering cancelled.", capturing = false))
                                // Technical observer reasons belong in diagnostics, never in the primary flow.
                                else -> Unit
                            }
                        }
                    }
                    else -> error("Unknown clear-buffer protocol message.")
                }
            } catch (_: Exception) {
                discardSession()
                main.post { if (!closed && epoch.get() == token) reject("The encoded capture failed native validation. Browser playback remains available.") }
            } finally {
                queuedMessages.decrementAndGet()
            }
        }
    }

    private fun begin(request: JSONObject) {
        require(state.capturing) { "Arm capture before accepting bytes." }
        discardSession()
        val id = request.getString("streamId")
        require(id.length in 1..100 && id.all { it.isLetterOrDigit() || it in "-_" })
        val mime = request.getString("mime").lowercase()
        require(mime.startsWith("audio/mp4") && mime.contains("flac")) { "Only clear FLAC/fMP4 is supported by this capture adapter." }
        require(directory.listFiles().orEmpty().sumOf { it.length() } < 512L * 1024 * 1024) { "The private capture buffer is full." }
        val file = File(directory, "${UUID.randomUUID()}.part")
        session = Session(id, file, FileOutputStream(file))
    }

    private fun chunk(request: JSONObject, token: Long) {
        val current = checkNotNull(session)
        require(request.getString("streamId") == current.id && request.getLong("sequence") == current.sequence && request.getLong("offset") == current.bytes) {
            "MSE byte chunks are missing, duplicated or out of order."
        }
        val encoded = request.getString("data")
        require(encoded.length <= 65_536 && encoded.all { it.isLetterOrDigit() || it in "+/=" })
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        require(bytes.isNotEmpty() && bytes.size <= 48 * 1024 && current.bytes <= 256L * 1024 * 1024 - bytes.size) { "The capture exceeds its bounded storage limit." }
        val expectedDigest = request.getString("sha256")
        val actualDigest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        require(expectedDigest == actualDigest) { "An encoded MSE byte chunk changed during transfer." }
        current.output.write(bytes)
        current.digest.update(bytes)
        current.bytes += bytes.size
        val acknowledgedSequence = current.sequence++
        main.post {
            if (!closed && epoch.get() == token) {
                emit(state.copy(byteCount = current.bytes))
                reply(JSONObject().put("v", 1).put("type", "ack").put("streamId", current.id).put("sequence", acknowledgedSequence))
            }
        }
    }

    private fun complete(request: JSONObject, token: Long) {
        val current = checkNotNull(session)
        require(request.getString("streamId") == current.id && request.getLong("byteCount") == current.bytes)
        current.output.fd.sync()
        current.output.close()
        val validated = validateClearFlacFmp4(current.file)
        require(request.getInt("fragmentCount") == validated.fragmentCount)
        require(kotlin.math.abs(request.getLong("totalDurationUs") - validated.durationUs) <= 1_000_000L / validated.sampleRateHz + 1)
        val expectedDuration = request.getLong("expectedDurationUs")
        require(expectedDuration > 0 && kotlin.math.abs(expectedDuration - validated.durationUs) <= 1_000_000L / validated.sampleRateHz + 2) {
            "The encoded timeline does not cover the complete media duration."
        }
        val destination = File(directory, "${UUID.randomUUID()}.mp4")
        require(current.file.renameTo(destination))
        val digest = current.digest.digest().joinToString("") { "%02x".format(it) }
        session = null
        main.post {
            if (closed || epoch.get() != token) { destination.delete(); return@post }
            prepared = destination
            emit(MseBufferState(status = "Complete supported track ready for native playback. This buffers the whole track before native playback starts.",
                byteCount = validated.byteCount, ready = true, validated = validated, sha256 = digest))
            reply(JSONObject().put("v", 1).put("type", "complete").put("streamId", current.id))
            releaseUnused()
        }
    }

    private fun reject(message: String) {
        epoch.incrementAndGet()
        if (!closed) worker.execute { discardSession() }
        emit(state.copy(status = message, error = message, capturing = false, ready = false))
        reply(JSONObject().put("v", 1).put("type", "abort").put("reason", message))
    }

    private fun reply(value: JSONObject) { port?.postMessage(WebMessage(value.toString())) }
    private fun emit(next: MseBufferState) { state = next; publish(next) }
    private fun discardSession() {
        session?.let { current -> runCatching { current.output.close() }; current.file.delete() }
        session = null
    }
    private fun releaseUnused() {
        val queued = NativePlaybackStore.state.queue.map { it.uri }.toSet()
        retained.removeAll { file -> if (Uri.fromFile(file).toString() !in queued) { file.delete(); true } else false }
    }
    override fun close() {
        if (closed) return
        closed = true
        epoch.incrementAndGet()
        port?.close(); port = null
        worker.execute { discardSession() }
        worker.shutdown()
        prepared?.let(retained::add)
        releaseUnused()
        NativeBufferLifetime.release()
    }
}
