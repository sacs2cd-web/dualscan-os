package com.dualscan.music.player

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.util.UUID

/** A clear, SDK-authorized progressive file; URLs/tokens are deliberately absent from results. */
data class BufferedAuthorizedAudio(val file: File, val byteCount: Long, val sha256: String)

/**
 * Buffers compressed bytes unchanged before the framework decoder or exact-byte WAVE reader.
 * This first implementation waits for the complete file, keeping seeking and format inspection
 * deterministic. It never captures WebAudio PCM or attempts to decrypt protected streams.
 */
class AuthorizedStreamBuffer(private val context: Context, private val maximumBytes: Long = 512L * 1024 * 1024) {
    private val directory = File(context.noBackupFilesDir, "authorized-audio-buffer").apply { mkdirs() }

    fun buffer(
        address: String,
        streamFormat: String,
        encryptionKey: String?,
        cancelled: () -> Boolean = { false },
        progress: (Long, Long?) -> Unit = { _, _ -> }
    ): BufferedAuthorizedAudio {
        require(encryptionKey.isNullOrEmpty()) { "Protected streams require an authorized protected playback backend." }
        require(streamFormat in setOf("flac", "aac", "aac+", "mp3", "mp4a.40.2", "mp4a.40.5", "wav")) {
            "Only clear progressive audio is supported by this native bridge."
        }
        val temporary = File(directory, "${UUID.randomUUID()}.part")
        val destination = File(directory, "${UUID.randomUUID()}.audio")
        val existingBytes = directory.listFiles().orEmpty().sumOf { it.length() }
        val available = maximumBytes - existingBytes
        require(available > 0) { "The private audio buffer is full. Stop playback and clear the buffer." }
        try {
            val result = if (address == FIXTURE_URI) {
                context.assets.open(FIXTURE_ASSET).use { input ->
                    temporary.outputStream().use { output -> copyAuthorizedBytes(input, output, available, null, cancelled, progress) }
                }
            } else {
                val connection = openHttps(address)
                try {
                    val length = connection.contentLengthLong.takeIf { it >= 0 }
                    require(length == null || length <= available) { "The audio exceeds the remaining private buffer limit." }
                    val type = connection.contentType.orEmpty().lowercase()
                    require(!type.contains("dash") && !type.contains("mpegurl") && !type.contains("json") && !type.contains("html")) {
                        "A progressive audio file is required; adaptive manifests and web pages stay in the authorized SDK player."
                    }
                    connection.inputStream.use { input ->
                        temporary.outputStream().use { output -> copyAuthorizedBytes(input, output, available, length, cancelled, progress) }
                    }
                } finally { connection.disconnect() }
            }
            check(!cancelled()) { "Audio buffering was cancelled." }
            check(temporary.renameTo(destination)) { "Unable to finish the private audio buffer." }
            return BufferedAuthorizedAudio(destination, result.first, result.second)
        } catch (failure: Exception) {
            temporary.delete()
            destination.delete()
            // HTTP exceptions often contain the signed URL. Expose only messages we control.
            if (failure is IllegalArgumentException || failure is IllegalStateException) throw failure
            throw IOException("Unable to buffer this authorized audio stream.")
        }
    }

    /** Call only when the engine has released the file and it is no longer queued for replay. */
    fun release(audio: BufferedAuthorizedAudio) {
        if (audio.file.parentFile?.canonicalFile == directory.canonicalFile) audio.file.delete()
    }

    private fun openHttps(address: String): HttpURLConnection {
        var current = parseProgressiveHttps(address)
        repeat(6) {
            val connection = (current.toURL().openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("User-Agent", "DiamondNativeBuffer/1")
                // Deliberately no cookies, Authorization header, or WebView credential copying.
            }
            val code = try { connection.responseCode } catch (_: IOException) {
                connection.disconnect()
                throw IOException("The authorized audio server could not be reached.")
            }
            if (code in listOf(301, 302, 303, 307, 308)) {
                val location = connection.getHeaderField("Location")
                connection.disconnect()
                require(!location.isNullOrBlank()) { "The audio redirect is invalid." }
                current = parseProgressiveHttps(current.resolve(location).toString())
            } else {
                if (code !in 200..299) {
                    connection.disconnect()
                    throw IOException("The authorized audio server did not return a playable file (HTTP $code).")
                }
                return connection
            }
        }
        throw IOException("The authorized audio server redirected too many times.")
    }

    companion object {
        const val FIXTURE_URI = "diamond-fixture://pcm24"
        const val FIXTURE_ASSET = "native-bridge/pcm24-fixture.wav"
    }
}

internal fun parseProgressiveHttps(address: String): URI {
    val uri = try { URI(address) } catch (_: Exception) { throw IllegalArgumentException("Invalid authorized audio address.") }
    require(uri.scheme.equals("https", true) && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.fragment == null) {
        "Authorized audio must use an HTTPS address without embedded credentials."
    }
    val path = uri.path.orEmpty().lowercase()
    require(!path.endsWith(".mpd") && !path.endsWith(".m3u8")) { "Adaptive manifests require the authorized SDK player." }
    return uri
}

/** Pure byte-copy core also used by JVM regression tests. It never changes audio samples. */
internal fun copyAuthorizedBytes(
    input: InputStream,
    output: java.io.OutputStream,
    maximumBytes: Long,
    expectedBytes: Long?,
    cancelled: () -> Boolean,
    progress: (Long, Long?) -> Unit
): Pair<Long, String> {
    require(maximumBytes > 0 && (expectedBytes == null || expectedBytes <= maximumBytes)) { "The audio exceeds the private buffer limit." }
    val digest = MessageDigest.getInstance("SHA-256")
    val bytes = ByteArray(64 * 1024)
    var total = 0L
    while (true) {
        check(!cancelled()) { "Audio buffering was cancelled." }
        var count = input.read(bytes)
        if (count < 0) break
        if (count == 0) {
            val one = input.read()
            if (one < 0) break
            bytes[0] = one.toByte()
            count = 1
        }
        require(count <= maximumBytes - total) { "The audio exceeds the private buffer limit." }
        output.write(bytes, 0, count)
        digest.update(bytes, 0, count)
        total += count
        progress(total, expectedBytes)
    }
    check(total > 0) { "The authorized audio file is empty." }
    check(expectedBytes == null || total == expectedBytes) { "The authorized audio file was truncated." }
    return total to digest.digest().joinToString("") { "%02x".format(it) }
}
