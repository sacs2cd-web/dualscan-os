package com.dualscan.music.player

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Changes only the representation of verified 24-bit FLAC samples, never their values.
 * Every signed 24-bit integer divided by 2^23 is represented exactly by IEEE float32.
 * The inverse must therefore land exactly on that integer grid; rounding is forbidden.
 *
 * The source is native-endian float32 PCM and must contain complete interleaved frames.
 * The target receives little-endian packed signed 24-bit PCM, in the same channel order.
 * Buffer positions advance together only after all selected frames validate and are packed.
 */
internal fun packFloat32ToPcm24(source: ByteBuffer, target: ByteBuffer, channelCount: Int): Int {
    require(channelCount in 1..24) { "Invalid float PCM channel count." }
    val inputFrameBytes = channelCount * 4
    val outputFrameBytes = channelCount * 3
    require(source.remaining() % inputFrameBytes == 0) { "The decoder produced a partial float PCM frame." }
    val frames = minOf(source.remaining() / inputFrameBytes, target.remaining() / outputFrameBytes)
    if (frames == 0) return 0
    val input = source.duplicate().order(ByteOrder.nativeOrder())
    val output = target.duplicate()
    repeat(frames * channelCount) {
        val sample = input.float
        val scaled = sample.toDouble() * 8_388_608.0
        if (!sample.isFinite() || scaled < -8_388_608.0 || scaled > 8_388_607.0) {
            throw IOException("The FLAC decoder returned a sample outside the signed 24-bit range.")
        }
        val integer = scaled.toInt()
        if (scaled != integer.toDouble()) {
            throw IOException("The FLAC decoder returned a sample outside the exact 24-bit grid; rounding is forbidden.")
        }
        output.put(integer.toByte())
        output.put((integer shr 8).toByte())
        output.put((integer shr 16).toByte())
    }
    source.position(source.position() + frames * inputFrameBytes)
    target.position(target.position() + frames * outputFrameBytes)
    return frames * outputFrameBytes
}
