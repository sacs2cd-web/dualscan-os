package com.dualscan.music.player.ui.theme

import androidx.compose.ui.graphics.Color

val Pine900 = Color(0xFF050507)
val Pine800 = Color(0xFF070007)
val Pine700 = Color(0xFF150014)
val Fern400 = Color(0xFFFF00FE)
val Sand200 = Color(0xFFFFFFFF)
val Mist300 = Color(0xFFC8B8C8)
val Copper400 = Color(0xFFFF00FE)
val Slate400 = Color(0xFF3B123A)
