package com.dualscan.music.player

import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.media.AudioRouting
import android.os.Build

data class NativeOutputDevice(val id: Int, val label: String, val capabilitySummary: String)

fun outputDeviceLabel(device: AudioDeviceInfo): String {
    val kind = when (device.type) {
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Headphones"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_SPEAKER_SAFE -> "Speaker"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth"
        else -> "Audio"
    }
    return "$kind · ${device.productName}"
}

fun isUsbAudioDevice(type: Int): Boolean = type == AudioDeviceInfo.TYPE_USB_DEVICE ||
    type == AudioDeviceInfo.TYPE_USB_HEADSET || type == AudioDeviceInfo.TYPE_USB_ACCESSORY

fun mixerFormatMatches(format: PcmFormat, encoding: Int, rate: Int, channelMask: Int): Boolean =
    format.encoding == encoding && format.sampleRateHz == rate && format.channelMask == channelMask

fun actualRoutedDevices(routing: AudioRouting): List<AudioDeviceInfo> = if (Build.VERSION.SDK_INT >= 36) {
    routing.routedDevices
} else listOfNotNull(routing.routedDevice)

fun selectedOutputMatches(routedIds: List<Int>, selectedId: Int): Boolean =
    routedIds.isNotEmpty() && routedIds.all { it == selectedId }

fun findExactBitPerfectMixer(manager: AudioManager, device: AudioDeviceInfo, format: PcmFormat): AudioMixerAttributes? =
    manager.getSupportedMixerAttributes(device).firstOrNull {
        it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT &&
            mixerFormatMatches(format, it.format.encoding, it.format.sampleRate, it.format.channelMask)
    }

fun connectedOutputDevices(manager: AudioManager): List<NativeOutputDevice> =
    manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { device ->
        val rates = device.sampleRates.sorted().joinToString { "${it / 1000.0}" }.ifEmpty { "not enumerated" }
        val exactCount = runCatching { manager.getSupportedMixerAttributes(device).count {
            it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT
        } }.getOrDefault(0)
        NativeOutputDevice(device.id, outputDeviceLabel(device),
            "Advertised kHz: $rates; USB bit-perfect configurations: $exactCount. Capabilities are not the active stream.")
    }
