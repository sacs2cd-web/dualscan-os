package com.dualscan.music.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat

class NativePlaybackService : Service() {
    private var engine: NativeAudioEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var mediaSession: MediaSession? = null
    private var lastNotificationKey = ""
    private var destroyed = false
    private var nextWakeLockRenewalMs = 0L

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT < 34) { stopSelf(); return }
        val notifications = getSystemService(NotificationManager::class.java)
        notifications.createNotificationChannel(NotificationChannel(CHANNEL, "Diamond native playback", NotificationManager.IMPORTANCE_LOW).apply {
            setSound(null, null)
        })
        mediaSession = MediaSession(this, "DiamondNativeAudio").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { enqueuePlayback(NativeCommand.Play()) }
                override fun onPause() { engine?.send(NativeCommand.Pause) }
                override fun onStop() { engine?.send(NativeCommand.Stop); stopSelf() }
                override fun onSeekTo(pos: Long) { engine?.send(NativeCommand.Seek(pos * 1000)) }
                override fun onSkipToNext() { enqueuePlayback(NativeCommand.Next) }
                override fun onSkipToPrevious() { enqueuePlayback(NativeCommand.Previous) }
            })
            isActive = true
        }
        engine = NativeAudioEngine(applicationContext, NativePlaybackStore.state) { state ->
            NativePlaybackStore.state = state
            if (!destroyed) {
                updateSession(state)
                setWakeLock(state.playing || state.loading)
                val key = "${state.title}|${state.playing}|${state.status}|${state.error}"
                if (key != lastNotificationKey) {
                    lastNotificationKey = key
                    notifications.notify(NOTIFICATION, notification(state))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT < 34) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_STOP) {
            engine?.send(NativeCommand.Stop)
            stopSelf()
            return START_NOT_STICKY
        }
        // Enter foreground before asking for focus; Android 15+ restricts background focus requests.
        startForeground(NOTIFICATION, notification(NativePlaybackStore.state), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        when (intent?.action) {
            ACTION_LOAD -> {
                val names = intent.getStringArrayListExtra(EXTRA_NAMES).orEmpty()
                val queue = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty().mapIndexed { index, value ->
                    val uri = Uri.parse(value)
                    NativeQueueItem(value, names.getOrNull(index)?.takeIf { it.isNotBlank() }?.take(200) ?: displayName(uri))
                }
                enqueuePlayback(NativeCommand.Load(queue))
            }
            ACTION_PLAY -> enqueuePlayback(NativeCommand.Play(intent.getIntExtra(EXTRA_INDEX, -1).takeIf { it >= 0 }))
            ACTION_PAUSE -> engine?.send(NativeCommand.Pause)
            ACTION_NEXT -> enqueuePlayback(NativeCommand.Next)
            ACTION_PREVIOUS -> enqueuePlayback(NativeCommand.Previous)
            ACTION_SEEK -> engine?.send(NativeCommand.Seek(intent.getLongExtra(EXTRA_POSITION, 0)))
            ACTION_DEVICE -> engine?.send(NativeCommand.SelectDevice(intent.getIntExtra(EXTRA_DEVICE, -1).takeIf { it >= 0 }))
            ACTION_STRICT -> engine?.send(NativeCommand.Strict(intent.getBooleanExtra(EXTRA_STRICT, true)))
        }
        return START_NOT_STICKY
    }

    private fun enqueuePlayback(command: NativeCommand) {
        val activeEngine = engine ?: return
        val pause = NativePlaybackStore.pauseWebAudio
        if (pause != null) pause { if (!destroyed) activeEngine.send(command) }
        else activeEngine.send(command)
    }

    private fun displayName(uri: Uri): String = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment ?: "Audio file"

    @android.annotation.SuppressLint("Wakelock") // Released on pause/error and onDestroy; bounded while playing.
    private fun setWakeLock(playing: Boolean) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (playing && (wakeLock?.isHeld != true || now >= nextWakeLockRenewalMs)) {
            if (wakeLock == null) wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:NativePcm")
                .apply { setReferenceCounted(false) }
            wakeLock?.acquire(10 * 60 * 1000L)
            nextWakeLockRenewalMs = now + 5 * 60 * 1000L
        } else if (!playing) {
            wakeLock?.takeIf { it.isHeld }?.release()
            wakeLock = null
            nextWakeLockRenewalMs = 0
        }
    }

    private fun updateSession(state: NativePlaybackState) {
        mediaSession?.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, state.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "Diamond Native Audio")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, state.durationUs / 1000).build())
        mediaSession?.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP)
            .setState(when {
                state.error != null -> PlaybackState.STATE_ERROR
                state.loading -> PlaybackState.STATE_BUFFERING
                state.playing -> PlaybackState.STATE_PLAYING
                state.resourcesReleased -> PlaybackState.STATE_STOPPED
                else -> PlaybackState.STATE_PAUSED
            }, state.positionUs / 1000, if (state.playing) 1f else 0f)
            .setErrorMessage(state.error.orEmpty()).build())
    }

    private fun servicePendingIntent(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, NativePlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun notification(state: NativePlaybackState): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(state.title)
            .setContentText(state.error ?: state.status)
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(state.playing)
            .setShowWhen(false)
            .addAction(Notification.Action.Builder(null, "Previous", servicePendingIntent(ACTION_PREVIOUS, 1)).build())
            .addAction(Notification.Action.Builder(null, if (state.playing) "Pause" else "Play",
                servicePendingIntent(if (state.playing) ACTION_PAUSE else ACTION_PLAY, 2)).build())
            .addAction(Notification.Action.Builder(null, "Next", servicePendingIntent(ACTION_NEXT, 3)).build())
            .addAction(Notification.Action.Builder(null, "Stop", servicePendingIntent(ACTION_STOP, 4)).build())
            .setStyle(Notification.MediaStyle().setMediaSession(mediaSession?.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    override fun onDestroy() {
        destroyed = true
        engine?.close()
        engine = null
        setWakeLock(false)
        mediaSession?.isActive = false
        mediaSession?.release()
        mediaSession = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_LOAD = "com.dualscan.music.player.native.LOAD"
        const val ACTION_PLAY = "com.dualscan.music.player.native.PLAY"
        const val ACTION_PAUSE = "com.dualscan.music.player.native.PAUSE"
        const val ACTION_STOP = "com.dualscan.music.player.native.STOP"
        const val ACTION_NEXT = "com.dualscan.music.player.native.NEXT"
        const val ACTION_PREVIOUS = "com.dualscan.music.player.native.PREVIOUS"
        const val ACTION_SEEK = "com.dualscan.music.player.native.SEEK"
        const val ACTION_DEVICE = "com.dualscan.music.player.native.DEVICE"
        const val ACTION_STRICT = "com.dualscan.music.player.native.STRICT"
        const val EXTRA_URIS = "uris"
        const val EXTRA_NAMES = "names"
        const val EXTRA_INDEX = "index"
        const val EXTRA_POSITION = "positionUs"
        const val EXTRA_DEVICE = "deviceId"
        const val EXTRA_STRICT = "strict"
        private const val CHANNEL = "diamond_native_audio"
        private const val NOTIFICATION = 60315327

        fun command(context: Context, action: String, configure: (Intent) -> Unit = {}) {
            val intent = Intent(context, NativePlaybackService::class.java).setAction(action).also(configure)
            if (action == ACTION_STOP) context.startService(intent)
            else ContextCompat.startForegroundService(context, intent)
        }
    }
}
