package com.dualscan.music.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val NativeAccent = Color(0xffff2db7)

@Composable
fun NativePlayerScreen(
    state: NativePlaybackState,
    mseState: MseBufferState,
    onOpenFiles: () -> Unit,
    onBufferProof: () -> Unit,
    onOpenTidalPlayer: () -> Unit,
    onArmTidalBuffer: () -> Unit,
    onCancelTidalBuffer: () -> Unit,
    onPlayTidalBuffer: () -> Unit,
    onCommand: (String, Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    var outputsOpen by remember { mutableStateOf(false) }
    var seekFraction by remember { mutableStateOf<Float?>(null) }
    Column(modifier.fillMaxSize().background(Color(0xff09070b))
        .verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("DIAMOND", color = NativeAccent, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Native audio", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text("PCM goes directly from the file reader or Android decoder to AudioTrack, with no app EQ, normalization, resampling or software volume.",
            color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = onOpenFiles, modifier = Modifier.fillMaxWidth()) { Text("Open audio files") }
        NativeCard {
            Text("OUTPUT", color = NativeAccent, fontWeight = FontWeight.Bold)
            val selected = state.devices.firstOrNull { it.id == state.selectedDeviceId }
            OutlinedButton(onClick = { outputsOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected?.label ?: if (state.selectedDeviceId == null) "Automatic Android route" else "Selected device disconnected")
                DropdownMenu(expanded = outputsOpen, onDismissRequest = { outputsOpen = false }) {
                    DropdownMenuItem(text = { Text("Automatic Android route") }, onClick = {
                        outputsOpen = false; onCommand(NativePlaybackService.ACTION_DEVICE, -1)
                    })
                    state.devices.forEach { device ->
                        DropdownMenuItem(text = { Text(device.label) }, onClick = {
                            outputsOpen = false; onCommand(NativePlaybackService.ACTION_DEVICE, device.id.toLong())
                        })
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Strict USB bit-perfect", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Stops if the exact platform mixer contract or USB route cannot be maintained.", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = state.strictUsb, onCheckedChange = { onCommand(NativePlaybackService.ACTION_STRICT, if (it) 1 else 0) })
            }
            Text("Headphone jacks and internal DACs use native PCM with strict mode off. Their bit-perfect output is unverified.", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            if (state.strictUsb) Text("The bit-perfect mixer bypasses software volume. Control the level on the DAC or amplifier.", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            selected?.let { Text(it.capabilitySummary, color = Color.White.copy(alpha = .55f), style = MaterialTheme.typography.bodySmall) }
        }

        NativeCard {
            Text(state.title, color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(state.error ?: state.status, color = if (state.error == null) NativeAccent else Color(0xffffb5b5))
            Text("Source: ${state.source?.sourceDescription ?: "Not opened"}", color = Color.White.copy(alpha = .8f))
            state.source?.let { source ->
                Text("Source format: ${source.sourceBitDepth?.let { "$it-bit" } ?: "precision unknown"} · ${source.sourceSampleRateHz / 1000.0} kHz · ${source.sourceChannelCount} ch", color = Color.White.copy(alpha = .7f))
            }
            state.rawDecoderFormat?.let { raw -> Text("Decoder PCM: ${raw.label}", color = Color.White.copy(alpha = .7f)) }
            Text("Pipeline PCM: ${state.decodedPcmFormat?.label ?: "Not opened"}", color = Color.White.copy(alpha = .8f))
            if (state.rawDecoderFormat?.encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT &&
                state.decodedPcmFormat?.encoding == android.media.AudioFormat.ENCODING_PCM_24BIT_PACKED) {
                Text("Float decoder samples are packed to signed 24-bit only when each value is exactly representable. No rounding or gain is applied.", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            }
            if (!state.strictUsb && state.source != null && state.decodedPcmFormat != null) {
                strictPrecisionFailure(state.source, state.decodedPcmFormat)?.let { reason ->
                    Text("Source preservation unverified: $reason", color = Color(0xffffd29b), style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("AudioTrack input: ${state.pcmFormat?.label ?: "Not configured"}", color = Color.White.copy(alpha = .8f))
            Text("Actual route: ${state.actualRoute}", color = Color.White.copy(alpha = .8f))
            if (state.bitPerfectContractActive) Text("Android accepted the exact USB mixer preference and AudioTrack reports the selected route. DAC byte identity has not been independently measured.",
                color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            val fraction = seekFraction ?: if (state.durationUs > 0) (state.positionUs.toFloat() / state.durationUs).coerceIn(0f, 1f) else 0f
            Slider(value = fraction, onValueChange = { seekFraction = it }, onValueChangeFinished = {
                seekFraction?.let { onCommand(NativePlaybackService.ACTION_SEEK, (it * state.durationUs).toLong()) }
                seekFraction = null
            }, enabled = !state.resourcesReleased && state.durationUs > 0)
            Text("${audioTime(state.positionUs)} / ${audioTime(state.durationUs)}", color = Color.White.copy(alpha = .65f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { onCommand(NativePlaybackService.ACTION_PREVIOUS, null) }, enabled = state.queue.isNotEmpty()) { Text("Previous") }
                Button(onClick = { onCommand(if (state.playing) NativePlaybackService.ACTION_PAUSE else NativePlaybackService.ACTION_PLAY, null) },
                    enabled = state.queue.isNotEmpty() && !state.loading) { Text(if (state.playing) "Pause" else "Play") }
                TextButton(onClick = { onCommand(NativePlaybackService.ACTION_NEXT, null) }, enabled = state.queueIndex + 1 < state.queue.size) { Text("Next") }
            }
            OutlinedButton(onClick = { onCommand(NativePlaybackService.ACTION_STOP, null) }, enabled = !state.resourcesReleased,
                modifier = Modifier.fillMaxWidth()) { Text("Stop and release output") }
        }
        NativeCard {
            Text("TIDAL CLEAR-STREAM BUFFER", color = NativeAccent, fontWeight = FontWeight.Bold)
            Text("Open listen.tidal.com in TIDAL Web, arm before a new track, then start that track. Only a complete, independently validated clear FLAC stream can be handed off.", color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onOpenTidalPlayer, modifier = Modifier.fillMaxWidth()) { Text("Open TIDAL streaming player") }
            TidalBufferControls(mseState, onArmTidalBuffer, onCancelTidalBuffer, onPlayTidalBuffer)
            OutlinedButton(onClick = onBufferProof, modifier = Modifier.fillMaxWidth()) { Text("Test WebView → native buffer") }
        }
        if (state.queue.isNotEmpty()) {
            Text("QUEUE · ${state.queue.size} FILES", color = NativeAccent, fontWeight = FontWeight.Bold)
            state.queue.forEachIndexed { index, item ->
                TextButton(onClick = { onCommand(NativePlaybackService.ACTION_PLAY, index.toLong()) }, modifier = Modifier.fillMaxWidth()) {
                    Text("${if (index == state.queueIndex) "▶ " else ""}${index + 1}. ${item.name}", color = if (index == state.queueIndex) NativeAccent else Color.White)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun TidalBufferControls(state: MseBufferState, onArm: () -> Unit, onCancel: () -> Unit, onPlay: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(state.error ?: state.status, color = if (state.error == null) Color.White.copy(alpha = .7f) else Color(0xffffb5b5), style = MaterialTheme.typography.bodySmall)
        if (state.byteCount > 0) Text("Buffered: ${state.byteCount / 1024} KiB", color = NativeAccent, style = MaterialTheme.typography.bodySmall)
        state.validated?.let { format ->
            Text("Validated encoded source: ${format.bitDepth}-bit · ${format.sampleRateHz / 1000.0} kHz · ${format.channels} ch", color = NativeAccent, style = MaterialTheme.typography.bodySmall)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onArm, enabled = !state.capturing) { Text("Arm clear buffer") }
            if (state.capturing) TextButton(onClick = onCancel) { Text("Cancel") }
            TextButton(onClick = onPlay, enabled = state.ready) { Text("Play native buffer") }
        }
    }
}

@Composable
private fun NativeCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xff17121a)),
        modifier = Modifier.fillMaxWidth().border(1.dp, NativeAccent.copy(alpha = .3f), RoundedCornerShape(12.dp))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

private fun audioTime(us: Long): String {
    val seconds = us.coerceAtLeast(0) / 1_000_000
    return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
}
