package com.dualscan.music.player

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Isolated app-owned fixture document; the signed-in TIDAL WebView is never navigated. */
class NativeBufferProofActivity : Activity() {
    private var browser: WebView? = null
    private var bridge: TidalNativePlayerBridge? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT < 34) { finish(); return }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val report = TextView(this).apply { setPadding(20, 12, 20, 12); text = "App-owned buffer fixture; live TIDAL handoff remains unverified." }
        val strict = Switch(this).apply {
            text = "Require exact USB bit-perfect mixer"
            isChecked = NativePlaybackStore.state.strictUsb
            setPadding(20, 8, 20, 8)
            setOnCheckedChangeListener { _, enabled ->
                NativePlaybackService.command(this@NativeBufferProofActivity, NativePlaybackService.ACTION_STRICT) {
                    it.putExtra(NativePlaybackService.EXTRA_STRICT, enabled)
                }
            }
        }
        val close = Button(this).apply { text = "Return to player"; setOnClickListener { finish() } }
        val mse = Button(this).apply {
            text = "Test pre-decode MSE handoff"
            setOnClickListener { startActivity(Intent(this@NativeBufferProofActivity, MseBufferProofActivity::class.java)) }
        }
        val view = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            setBackgroundColor(0xff0c1118.toInt())
        }
        browser = view
        val adapter = TidalNativePlayerBridge(this, view) { message -> report.text = message }
        bridge = adapter
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) { adapter.attach() }
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean = true
        }
        layout.addView(close)
        layout.addView(mse)
        layout.addView(strict)
        layout.addView(report)
        layout.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
        val fixtureUrl = TidalNativePlayerBridge.FIXTURE_ORIGIN + "/"
        // A null history URL makes WebView.url report about:blank even though the
        // document has the HTTPS base origin, defeating the native origin guard.
        view.loadDataWithBaseURL(fixtureUrl, adapter.fixtureHtml(), "text/html", "utf-8", fixtureUrl)
    }

    override fun onDestroy() {
        bridge?.close()
        bridge = null
        browser?.destroy()
        browser = null
        super.onDestroy()
    }
}
