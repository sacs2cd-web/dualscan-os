package com.dualscan.music.player

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioFormat
import android.net.Uri
import java.io.Closeable
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * Reads integer RIFF/WAVE PCM without decoding, scaling, dithering, or changing its bytes.
 * Format definitions: Microsoft RIFF/WAVE, WAVEFORMATEX, and WAVEFORMATEXTENSIBLE.
 * https://learn.microsoft.com/en-us/windows/win32/api/mmeapi/ns-mmeapi-waveformatex
 * https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ksmedia/ns-ksmedia-waveformatextensible
 */
class WavPcmSource private constructor(
    private val reader: WavePcmReader,
    displayName: String
) : NativePcmSource {
    constructor(context: Context, uri: Uri, displayName: String) : this(
        WavePcmReader(openWaveAccess(context, uri)), displayName
    )

    override val format = PcmFormat(
        reader.header.sampleRateHz,
        reader.header.channelCount,
        when (reader.header.containerBits) {
            16 -> AudioFormat.ENCODING_PCM_16BIT
            24 -> AudioFormat.ENCODING_PCM_24BIT_PACKED
            32 -> AudioFormat.ENCODING_PCM_32BIT
            else -> error("Unexpected WAVE PCM container")
        },
        reader.header.androidChannelMask
    )

    override val info = NativeTrackInfo(
        displayName = displayName,
        sourceDescription = if (reader.header.validBits == reader.header.containerBits) {
            "WAVE integer PCM · original sample bytes"
        } else {
            "WAVE integer PCM · ${reader.header.validBits} valid bits in ${reader.header.containerBits}-bit containers"
        },
        sourceBitDepth = reader.header.validBits,
        sourceSampleRateHz = reader.header.sampleRateHz,
        sourceChannelCount = reader.header.channelCount,
        durationUs = reader.header.durationUs,
        precisionKnown = true
    )

    override fun read(target: ByteBuffer): Int = reader.read(target)
    override fun seekTo(positionUs: Long): Long = reader.seekTo(positionUs)
    override fun close() = reader.close()

    companion object {
        /** Sniff the container, including WAVE encodings this exact-byte reader may reject. */
        fun isWave(context: Context, uri: Uri): Boolean = try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val signature = ByteArray(12)
                var read = 0
                while (read < signature.size) {
                    val count = input.read(signature, read, signature.size - read)
                    if (count < 0) break
                    if (count == 0) {
                        val one = input.read()
                        if (one < 0) break
                        signature[read++] = one.toByte()
                    } else {
                        read += count
                    }
                }
                read == signature.size && signature.hasFourCc(0, "RIFF") &&
                    signature.hasFourCc(8, "WAVE")
            } ?: false
        } catch (_: IOException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}

/** Pure JVM header and reader: Android is only used by the public URI adapter above. */
internal data class WavePcmHeader(
    val sampleRateHz: Int,
    val channelCount: Int,
    val containerBits: Int,
    val validBits: Int,
    val androidChannelMask: Int,
    val bytesPerFrame: Int,
    val dataOffset: Long,
    val dataSize: Long
) {
    val totalFrames: Long get() = dataSize / bytesPerFrame
    val durationUs: Long get() = framesToUs(totalFrames)
    fun framesToUs(frames: Long): Long =
        frames / sampleRateHz * MICROS_PER_SECOND +
            frames % sampleRateHz * MICROS_PER_SECOND / sampleRateHz
}

/** All offsets are relative to the asset, never the enclosing descriptor/file. */
internal interface WaveByteAccess : Closeable {
    val length: Long?
    fun readAt(offset: Long, target: ByteBuffer): Int
}

internal class WavePcmReader(access: WaveByteAccess) : Closeable {
    private val access: WaveByteAccess = access
    val header: WavePcmHeader = try {
        parseWaveHeader(access)
    } catch (failure: Throwable) {
        try {
            access.close()
        } catch (closing: Throwable) {
            failure.addSuppressed(closing)
        }
        throw failure
    }
    private var framePosition = 0L
    private var closed = false

    @Synchronized
    fun read(target: ByteBuffer): Int {
        checkOpen()
        val framesRemaining = header.totalFrames - framePosition
        if (framesRemaining == 0L) return -1
        val frameCount = minOf(framesRemaining, (target.remaining() / header.bytesPerFrame).toLong())
        if (frameCount == 0L) return 0
        val bytes = (frameCount * header.bytesPerFrame).toInt()
        val output = target.duplicate().apply { limit(position() + bytes) }
        var offset = header.dataOffset + framePosition * header.bytesPerFrame
        while (output.hasRemaining()) {
            val count = access.readAt(offset, output)
            if (count < 0) throw EOFException("WAVE PCM data was truncated during playback")
            if (count == 0) throw IOException("WAVE input made no progress")
            offset += count
        }
        // Expose only complete frames, including when the backing input returns short reads.
        target.position(target.position() + bytes)
        framePosition += frameCount
        return bytes
    }

    @Synchronized
    fun seekTo(positionUs: Long): Long {
        checkOpen()
        framePosition = when {
            positionUs <= 0L -> 0L
            positionUs >= header.durationUs -> header.totalFrames
            else -> {
                val seconds = positionUs / MICROS_PER_SECOND
                val fractionalUs = positionUs % MICROS_PER_SECOND
                minOf(header.totalFrames, seconds * header.sampleRateHz +
                    fractionalUs * header.sampleRateHz / MICROS_PER_SECOND)
            }
        }
        return header.framesToUs(framePosition)
    }

    @Synchronized
    override fun close() {
        if (!closed) {
            closed = true
            access.close()
        }
    }

    private fun checkOpen() {
        check(!closed) { "WAVE source is closed" }
    }

    companion object {
        fun fromBytes(bytes: ByteArray): WavePcmReader = WavePcmReader(object : WaveByteAccess {
            override val length = bytes.size.toLong()
            override fun readAt(offset: Long, target: ByteBuffer): Int {
                require(offset >= 0L)
                if (offset >= bytes.size) return -1
                val count = minOf(target.remaining().toLong(), bytes.size - offset).toInt()
                target.put(bytes, offset.toInt(), count)
                return count
            }
            override fun close() = Unit
        })

        fun fromFile(file: File, offset: Long = 0L, length: Long = file.length() - offset): WavePcmReader {
            require(offset >= 0L && length >= 0L && offset <= file.length() && length <= file.length() - offset)
            return WavePcmReader(ChannelWaveAccess(FileInputStream(file), offset, length))
        }

        /** The supplier must return a new stream from byte zero, so seeking can reopen it. */
        fun fromStream(openStream: () -> InputStream): WavePcmReader =
            WavePcmReader(StreamWaveAccess(openStream))
    }
}

private fun parseWaveHeader(access: WaveByteAccess): WavePcmHeader {
    val signature = access.readExactly(0L, 12)
    if (!signature.hasFourCc(0, "RIFF") || !signature.hasFourCc(8, "WAVE")) {
        throw IOException("Expected a little-endian RIFF/WAVE file")
    }
    val riffSize = signature.u32(4)
    if (riffSize < 4L) throw IOException("Invalid WAVE RIFF size")
    val riffEnd = 8L + riffSize
    if (access.length?.let { riffEnd > it } == true) {
        throw EOFException("WAVE RIFF size exceeds the available file")
    }
    var format: ParsedWaveFormat? = null
    var dataOffset: Long? = null
    var dataSize = 0L
    var offset = 12L
    while (offset < riffEnd) {
        if (riffEnd - offset < 8L) throw IOException("Incomplete WAVE chunk header")
        val chunk = access.readExactly(offset, 8)
        val size = chunk.u32(4)
        val bodyOffset = offset + 8L
        val bodyEnd = bodyOffset + size
        val paddedEnd = bodyEnd + (size and 1L)
        if (paddedEnd > riffEnd) throw EOFException("WAVE chunk exceeds its RIFF bounds")
        when {
            chunk.hasFourCc(0, "fmt ") -> {
                if (format != null) throw IOException("Multiple WAVE format chunks are ambiguous")
                format = parseWaveFormat(access, bodyOffset, size)
            }
            chunk.hasFourCc(0, "data") -> {
                if (dataOffset != null) throw IOException("Multiple WAVE data chunks are unsupported")
                dataOffset = bodyOffset
                dataSize = size
            }
        }
        // Unknown chunks and PCM data are skipped without allocating their advertised size.
        // Probing the last byte also validates truncation for streams with no known length.
        if (paddedEnd > bodyOffset) access.readExactly(paddedEnd - 1L, 1)
        offset = paddedEnd
    }
    val parsed = format ?: throw IOException("WAVE file has no format chunk")
    val pcmOffset = dataOffset ?: throw IOException("WAVE file has no data chunk")
    if (dataSize % parsed.bytesPerFrame != 0L) {
        throw IOException("WAVE data ends inside a PCM frame")
    }
    return WavePcmHeader(parsed.rate, parsed.channels, parsed.bits, parsed.validBits,
        parsed.androidMask, parsed.bytesPerFrame, pcmOffset, dataSize)
}

private data class ParsedWaveFormat(
    val rate: Int,
    val channels: Int,
    val bits: Int,
    val validBits: Int,
    val androidMask: Int,
    val bytesPerFrame: Int
)

private fun parseWaveFormat(access: WaveByteAccess, offset: Long, size: Long): ParsedWaveFormat {
    if (size < 16L || size == 17L) throw IOException("Incomplete WAVE PCM format")
    val fmt = access.readExactly(offset, minOf(size, 40L).toInt())
    val tag = fmt.u16(0)
    val channels = fmt.u16(2)
    val rate = fmt.u32(4)
    val byteRate = fmt.u32(8)
    val blockAlign = fmt.u16(12)
    val bits = fmt.u16(14)
    if (channels !in 1..18) throw IOException("Unsupported WAVE channel count: $channels")
    if (rate == 0L || rate > Int.MAX_VALUE) throw IOException("Invalid WAVE sample rate: $rate")
    if (bits != 16 && bits != 24 && bits != 32) {
        throw IOException("Exact-byte WAVE playback supports 16-, 24-, and 32-bit integer PCM")
    }
    val bytesPerFrame = channels * (bits / 8)
    if (blockAlign != bytesPerFrame) throw IOException("WAVE block alignment does not match its PCM format")
    if (byteRate != rate * bytesPerFrame) throw IOException("WAVE byte rate does not match its PCM format")
    val extensionSize = if (size >= 18L) fmt.u16(16) else 0
    if (size >= 18L && 18L + extensionSize > size) {
        throw IOException("WAVE format extension exceeds its chunk")
    }
    var validBits = bits
    val androidMask = when (tag) {
        1 -> when (channels) {
            1 -> 0x4 // Android CHANNEL_OUT_MONO; legacy WAVE mono has no speaker mask.
            2 -> 0xc // Android CHANNEL_OUT_STEREO.
            else -> throw IOException("Multichannel WAVE needs an explicit extensible speaker layout")
        }
        0xfffe -> {
            if (size < 40L || extensionSize < 22) throw IOException("Incomplete extensible WAVE format")
            val pcmGuid = byteArrayOf(1, 0, 0, 0, 0, 0, 0x10, 0, 0x80.toByte(), 0, 0, 0xaa.toByte(), 0, 0x38, 0x9b.toByte(), 0x71)
            if (!(24 until 40).all { fmt[it] == pcmGuid[it - 24] }) {
                throw IOException("Only integer PCM WAVE subformats support exact-byte playback")
            }
            validBits = fmt.u16(18)
            if (validBits !in 1..bits) throw IOException("Invalid extensible WAVE sample precision")
            val waveMask = fmt.u32(20)
            if (waveMask == 0L || waveMask and 0x3ffffL.inv() != 0L ||
                java.lang.Long.bitCount(waveMask) != channels) {
                throw IOException("Unknown or inconsistent extensible WAVE speaker layout")
            }
            // The first 18 WAVE speaker positions and Android output positions have the
            // same interleaved order; Android reserves the two least-significant bits.
            (waveMask shl 2).toInt()
        }
        else -> throw IOException("Unsupported WAVE encoding $tag; integer PCM is required")
    }
    return ParsedWaveFormat(rate.toInt(), channels, bits, validBits, androidMask, bytesPerFrame)
}

private fun WaveByteAccess.readExactly(offset: Long, size: Int): ByteArray {
    if (offset < 0L || size < 0 || length?.let { offset > it || size.toLong() > it - offset } == true) {
        throw EOFException("Truncated WAVE chunk")
    }
    val bytes = ByteArray(size)
    val target = ByteBuffer.wrap(bytes)
    var current = offset
    while (target.hasRemaining()) {
        val count = readAt(current, target)
        if (count < 0) throw EOFException("Truncated WAVE chunk")
        if (count == 0) throw IOException("WAVE input made no progress")
        current += count
    }
    return bytes
}

private class ChannelWaveAccess(
    private val input: FileInputStream,
    private val baseOffset: Long,
    override val length: Long
) : WaveByteAccess {
    private val channel: FileChannel = input.channel
    override fun readAt(offset: Long, target: ByteBuffer): Int {
        require(offset >= 0L)
        if (offset >= length) return -1
        val window = target.duplicate()
        window.limit(window.position() + minOf(window.remaining().toLong(), length - offset).toInt())
        val count = channel.read(window, baseOffset + offset)
        if (count > 0) target.position(target.position() + count)
        return count
    }
    override fun close() = input.close()
}

/** Bounded memory fallback for providers exposing pipes instead of seekable descriptors. */
private class StreamWaveAccess(private val openStream: () -> InputStream) : WaveByteAccess {
    override val length: Long? = null
    private var input: InputStream? = null
    private var position = 0L
    private val scratch = ByteArray(16 * 1024)

    override fun readAt(offset: Long, target: ByteBuffer): Int {
        require(offset >= 0L)
        if (input == null || offset < position) {
            input?.close()
            input = openStream()
            position = 0L
        }
        val stream = checkNotNull(input)
        while (position < offset) {
            val skipped = stream.skip(offset - position)
            if (skipped > 0L) {
                position += skipped
            } else {
                val count = stream.read(scratch, 0, minOf(scratch.size.toLong(), offset - position).toInt())
                if (count < 0) return -1
                if (count == 0) {
                    if (stream.read() < 0) return -1
                    position++
                } else position += count
            }
        }
        if (!target.hasRemaining()) return 0
        val count = stream.read(scratch, 0, minOf(scratch.size, target.remaining()))
        if (count > 0) {
            target.put(scratch, 0, count)
            position += count
            return count
        }
        if (count == 0) {
            val one = stream.read()
            if (one < 0) return -1
            target.put(one.toByte())
            position++
            return 1
        }
        return -1
    }
    override fun close() {
        input?.close()
        input = null
    }
}

private fun openWaveAccess(context: Context, uri: Uri): WaveByteAccess {
    var asset: AssetFileDescriptor? = null
    var input: FileInputStream? = null
    try {
        asset = context.contentResolver.openAssetFileDescriptor(uri, "r")
            ?: throw FileNotFoundException("Unable to open WAVE URI")
        input = asset.createInputStream()
        val channel = input.channel
        val baseOffset = asset.startOffset
        val available = channel.size() - baseOffset
        if (available < 0L) throw IOException("WAVE asset starts beyond its descriptor")
        channel.position(baseOffset) // Pipes reject this and use the reopening stream fallback.
        val declared = asset.declaredLength
        val length = if (declared == AssetFileDescriptor.UNKNOWN_LENGTH) available else minOf(declared, available)
        return ChannelWaveAccess(input, baseOffset, length)
    } catch (_: IOException) {
        // openInputStream also supports providers that cannot supply an asset descriptor.
        try {
            if (input != null) input.close() else asset?.close()
        } catch (_: IOException) {
            // Preserve the subsequent stream-open error, if any.
        }
    }
    return StreamWaveAccess {
        context.contentResolver.openInputStream(uri) ?: throw FileNotFoundException("Unable to open WAVE URI")
    }
}

private fun ByteArray.hasFourCc(offset: Int, value: String): Boolean =
    value.indices.all { this[offset + it].toInt() and 0xff == value[it].code }
private fun ByteArray.u16(offset: Int): Int =
    (this[offset].toInt() and 0xff) or ((this[offset + 1].toInt() and 0xff) shl 8)
private fun ByteArray.u32(offset: Int): Long =
    u16(offset).toLong() or (u16(offset + 2).toLong() shl 16)
private const val MICROS_PER_SECOND = 1_000_000L
