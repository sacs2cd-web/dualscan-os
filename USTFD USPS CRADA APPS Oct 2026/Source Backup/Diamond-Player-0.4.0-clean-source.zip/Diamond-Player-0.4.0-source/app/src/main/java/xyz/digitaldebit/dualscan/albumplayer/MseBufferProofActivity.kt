package com.dualscan.music.player

import android.app.Activity
import android.os.Bundle
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.io.ByteArrayInputStream

/** Controlled unprotected proof of the SAME pre-decode MSE bridge used by the TIDAL page. */
class MseBufferProofActivity : Activity() {
    private var browser: WebView? = null
    private var bridge: TidalMseBufferBridge? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT < 34) { finish(); return }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val report = TextView(this).apply { setPadding(20, 10, 20, 10) }
        val play = Button(this).apply { text = "Play validated buffer natively"; isEnabled = false }
        val strict = Switch(this).apply {
            text = "Require exact USB bit-perfect mixer"
            isChecked = NativePlaybackStore.state.strictUsb
            setOnCheckedChangeListener { _, value ->
                NativePlaybackService.command(this@MseBufferProofActivity, NativePlaybackService.ACTION_STRICT) { it.putExtra(NativePlaybackService.EXTRA_STRICT, value) }
            }
        }
        val view = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            setBackgroundColor(0xff0c1118.toInt())
        }
        browser = view
        val adapter = TidalMseBufferBridge(this, view) { state ->
            report.text = buildString {
                append(state.status)
                append("\nReceived: ${state.byteCount} encoded bytes")
                state.validated?.let { append("\nVerified source: ${it.bitDepth}-bit / ${it.sampleRateHz} Hz / ${it.channels} ch / ${it.durationUs / 1_000_000.0} s") }
                state.sha256?.let { append("\nSHA-256: $it") }
                state.error?.let { append("\n$it") }
            }
            play.isEnabled = state.ready
        }
        bridge = adapter
        val run = Button(this).apply {
            text = "Run pre-decode WebView buffer proof"
            setOnClickListener {
                adapter.arm()
                view.evaluateJavascript("window.runFixture && window.runFixture()", null)
            }
        }
        play.setOnClickListener { adapter.playBuffered() }
        val close = Button(this).apply { text = "Return to buffer tests"; setOnClickListener { finish() } }
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) { adapter.attach() }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse =
                WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
        }
        layout.addView(close)
        layout.addView(strict)
        layout.addView(run)
        layout.addView(play)
        layout.addView(report)
        layout.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
        val fixture = assets.open("native-bridge/clear-flac-fixture.mp4").use { Base64.encodeToString(it.readBytes(), Base64.NO_WRAP) }
        val html = assets.open("native-bridge/mse-fixture.html").bufferedReader().use { it.readText() }
            .replace("/* DIAMOND_MSE_BOOTSTRAP */", adapter.bootstrapScript())
            .replace("DIAMOND_FIXTURE_BASE64", fixture)
        // Synthetic base supplies the same secure origin contract; CSP/interception block network.
        // The existing signed-in TIDAL document and its cookies are never read or navigated.
        val fixtureUrl = "https://listen.tidal.com/native-buffer-proof"
        view.loadDataWithBaseURL(fixtureUrl, html, "text/html", "utf-8", fixtureUrl)
    }

    override fun onDestroy() {
        bridge?.close(); bridge = null
        browser?.destroy(); browser = null
        super.onDestroy()
    }
}
