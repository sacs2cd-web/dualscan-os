package com.dualscan.music.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DualscanColorScheme = darkColorScheme(
    primary = Fern400,
    onPrimary = Pine900,
    secondary = Sand200,
    onSecondary = Pine900,
    tertiary = Copper400,
    background = Pine900,
    onBackground = Sand200,
    surface = Pine800,
    onSurface = Sand200,
    surfaceVariant = Pine700,
    onSurfaceVariant = Mist300,
    primaryContainer = ColorTokens.primaryContainer,
    onPrimaryContainer = Pine900,
    outline = Slate400
)

@Composable
fun DualscanAlbumPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DualscanColorScheme,
        typography = Typography,
        content = content
    )
}

private object ColorTokens {
    val primaryContainer = Fern400.copy(alpha = 0.28f)
}
