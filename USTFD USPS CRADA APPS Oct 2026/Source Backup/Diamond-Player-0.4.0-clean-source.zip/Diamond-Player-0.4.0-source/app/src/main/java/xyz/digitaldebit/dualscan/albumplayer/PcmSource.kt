package com.dualscan.music.player

import android.media.AudioFormat
import java.io.Closeable
import java.nio.ByteBuffer

/** The PCM format actually produced by a source, never a quality-tier inference. */
data class PcmFormat(
    val sampleRateHz: Int,
    val channelCount: Int,
    val encoding: Int,
    val channelMask: Int
) {
    init {
        require(sampleRateHz > 0) { "Invalid PCM sample rate." }
        require(channelCount in 1..24 && Integer.bitCount(channelMask) == channelCount) { "PCM channel count and speaker layout disagree." }
        require(encoding in setOf(AudioFormat.ENCODING_PCM_8BIT, AudioFormat.ENCODING_PCM_16BIT,
            AudioFormat.ENCODING_PCM_24BIT_PACKED, AudioFormat.ENCODING_PCM_32BIT, AudioFormat.ENCODING_PCM_FLOAT)) { "Unsupported PCM encoding." }
    }
    val containerBits: Int
        get() = when (encoding) {
            AudioFormat.ENCODING_PCM_8BIT -> 8
            AudioFormat.ENCODING_PCM_16BIT -> 16
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 24
            AudioFormat.ENCODING_PCM_32BIT, AudioFormat.ENCODING_PCM_FLOAT -> 32
            else -> error("Unsupported PCM encoding: $encoding")
        }
    val bytesPerFrame: Int get() = channelCount * containerBits / 8
    val isInteger: Boolean get() = encoding != AudioFormat.ENCODING_PCM_FLOAT
    val label: String
        get() = "${containerBits}-bit ${if (isInteger) "PCM" else "float PCM"} · ${sampleRateHz / 1000.0} kHz · $channelCount ch"

    fun toAudioFormat(): AudioFormat = AudioFormat.Builder()
        .setEncoding(encoding)
        .setSampleRate(sampleRateHz)
        .setChannelMask(channelMask)
        .build()
}

data class NativeTrackInfo(
    val displayName: String,
    val sourceDescription: String,
    val sourceBitDepth: Int?,
    val sourceSampleRateHz: Int,
    val sourceChannelCount: Int,
    val durationUs: Long,
    /** True only when source PCM precision was independently read, not guessed from a decoder. */
    val precisionKnown: Boolean,
    /** Independent from source metadata: a known decoder limitation prevents strict playback. */
    val decoderPreservationFailure: String? = null
)

interface NativePcmSource : Closeable {
    val info: NativeTrackInfo
    val format: PcmFormat
    val decoderFormat: PcmFormat? get() = null

    /** Write whole PCM frames at the target's current position. Return -1 at end of stream. */
    fun read(target: ByteBuffer): Int

    /** Seek and return the actual start position, in microseconds. */
    fun seekTo(positionUs: Long): Long
}

/** Strict playback uses integer PCM with independently known, unchanged precision. */
fun strictPrecisionFailure(info: NativeTrackInfo, format: PcmFormat): String? = when {
    info.decoderPreservationFailure != null -> info.decoderPreservationFailure
    !info.precisionKnown || info.sourceBitDepth == null -> "The source precision cannot be verified for this file."
    !format.isInteger -> "The decoder produced floating-point PCM; strict source preservation is unverified."
    info.sourceBitDepth != format.containerBits -> "Source ${info.sourceBitDepth}-bit and decoded ${format.containerBits}-bit PCM differ."
    info.sourceSampleRateHz != format.sampleRateHz -> "The decoder changed the source sample rate."
    info.sourceChannelCount != format.channelCount -> "The decoder changed the source channel count."
    else -> null
}
