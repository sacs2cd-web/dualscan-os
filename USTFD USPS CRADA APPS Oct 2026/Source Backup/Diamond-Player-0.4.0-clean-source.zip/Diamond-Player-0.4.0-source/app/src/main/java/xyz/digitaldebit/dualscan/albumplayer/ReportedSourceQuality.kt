package com.dualscan.music.player

/** Display-only website metadata. This never describes the Android output or proves fidelity. */
object ReportedSourceQuality {
    fun label(text: String): String {
        val bit = Regex("\\b(8|16|20|24|32|64)\\s*[- ]?BIT\\b", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)
        val khz = Regex("\\b([0-9]{1,3}(?:\\.[0-9]+)?)\\s*K\\s*HZ\\b", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)
        val hz = Regex("\\b([0-9]{4,6})\\s*HZ\\b", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)?.toIntOrNull()
        val rate = khz ?: hz?.let { (it / 1000.0).toString().removeSuffix(".0") }
        return if (bit != null || rate != null) {
            "${bit ?: "?"}-BIT / ${rate ?: "?"} KHZ"
        } else {
            "FORMAT UNKNOWN"
        }
    }
}
