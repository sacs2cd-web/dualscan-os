package com.dualscan.music.player

import android.media.AudioFormat
import android.net.Uri
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.security.MessageDigest

/** Own unprotected fixture; asserts actual decoding and strict precision policy on this device. */
@RunWith(AndroidJUnit4::class)
class NativeDecoderInstrumentedTest {
    @Test fun completeClearBufferHasValidatedDurationAndExact24BitPcm() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val directory = File(context.cacheDir, "buffer-decoder-verification").apply { mkdirs() }
        val mp4 = File(directory, "clear-buffer.mp4")
        val wav = File(directory, "original-buffer.wav")
        context.assets.open("native-bridge/clear-flac-fixture.mp4").use { input -> mp4.outputStream().use { output -> input.copyTo(output) } }
        context.assets.open("native-bridge/pcm24-fixture.wav").use { input -> wav.outputStream().use { output -> input.copyTo(output) } }
        try {
            val validated = validateClearFlacFmp4(mp4)
            assertEquals(3_000_000L, validated.durationUs)
            CodecPcmSource(context, Uri.fromFile(mp4), "Own complete clear buffer").use { decoded ->
                assertEquals(validated.durationUs, decoded.info.durationUs)
                assertEquals(48000, decoded.format.sampleRateHz)
                assertEquals(AudioFormat.ENCODING_PCM_FLOAT, decoded.decoderFormat?.encoding)
                assertEquals(AudioFormat.ENCODING_PCM_24BIT_PACKED, decoded.format.encoding)
                assertNull(strictPrecisionFailure(decoded.info, decoded.format))
                val result = digest(decoded, File(context.filesDir, "verification-decoded-24-48.pcm"))
                Log.i("DiamondDecoderVerification", "clearBuffer durationUs=${decoded.info.durationUs} raw=${decoded.decoderFormat?.label} produced=${decoded.format.label} bytes=${result.first} sha256=${result.second}")
                WavPcmSource(context, Uri.fromFile(wav), "Original buffer fixture").use { source ->
                    assertEquals(digest(source, File(context.filesDir, "verification-source-24-48.pcm")), result)
                }
            }
        } finally { mp4.delete(); wav.delete(); directory.delete() }
    }

    @Test fun clearFragmentedFlacKeepsSourcePrecisionIndependentOfDecoderOutput() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val directory = File(context.cacheDir, "decoder-verification").apply { mkdirs() }
        val mp4 = File(directory, "clear-flac-24-96.mp4")
        val wav = File(directory, "source-24-96.wav")
        instrumentation.context.assets.open("verification/clear-flac-24-96.mp4").use { input -> mp4.outputStream().use { output -> input.copyTo(output) } }
        instrumentation.context.assets.open("verification/source-24-96.wav").use { input -> wav.outputStream().use { output -> input.copyTo(output) } }
        try {
            CodecPcmSource(context, Uri.fromFile(mp4), "Own clear FLAC fixture").use { decoded ->
                assertEquals(24, decoded.info.sourceBitDepth)
                assertTrue(decoded.info.precisionKnown)
                assertEquals(96000, decoded.info.sourceSampleRateHz)
                assertEquals(2, decoded.info.sourceChannelCount)
                val decodedFile = File(context.filesDir, "verification-decoded-24-96.pcm")
                val result = digest(decoded, decodedFile)
                val strictFailure = strictPrecisionFailure(decoded.info, decoded.format)
                Log.i("DiamondDecoderVerification", "source=24bit/96000Hz/stereo raw=${decoded.decoderFormat?.label} produced=${decoded.format.label} decodedBytes=${result.first} sha256=${result.second} strictPrecision=${strictFailure ?: "nominal integer source precision"} dump=${decodedFile.name}; ${decoded.decoderDiagnostics}")
                File(context.filesDir, "verification-decoder-result.txt").writeText("raw=${decoded.decoderFormat?.label}\nproduced=${decoded.format.label}\nbytes=${result.first}\nsha256=${result.second}\nstrictPrecision=$strictFailure\n${decoded.decoderDiagnostics}\nhead=${decodedFile.inputStream().use { stream -> stream.readNBytes(96).joinToString(" ") { "%02x".format(it.toInt() and 255) } }}\n")
                assertEquals(AudioFormat.ENCODING_PCM_FLOAT, decoded.decoderFormat?.encoding)
                assertEquals(AudioFormat.ENCODING_PCM_24BIT_PACKED, decoded.format.encoding)
                assertEquals(96000, decoded.format.sampleRateHz)
                assertEquals(2, decoded.format.channelCount)
                assertNull(strictFailure)
                WavPcmSource(context, Uri.fromFile(wav), "Source fixture").use { original -> assertEquals(digest(original, File(context.filesDir, "verification-source-24-96.pcm")), result) }
            }
        } finally {
            mp4.delete(); wav.delete(); directory.delete()
        }
    }

    private fun digest(source: NativePcmSource, destination: File): Pair<Long, String> {
        val hash = MessageDigest.getInstance("SHA-256")
        val frame = source.format.bytesPerFrame
        val buffer = ByteBuffer.allocateDirect(65536 / frame * frame)
        var bytes = 0L
        destination.outputStream().use { output ->
            while (true) {
                buffer.clear()
                val read = source.read(buffer)
                if (read < 0) break
                assertEquals(0, read % frame)
                assertEquals(read, buffer.position())
                buffer.flip()
                val transferred = ByteArray(read)
                buffer.get(transferred)
                output.write(transferred)
                hash.update(transferred)
                bytes += read
            }
        }
        assertTrue("The decoder must produce samples", bytes > 0)
        return bytes to hash.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}
