const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const events = new Map();
const window = {
  addEventListener(name, listener) { if (!events.has(name)) events.set(name, []); events.get(name).push(listener); },
  dispatchEvent(event) { for (const listener of events.get(event.type) || []) listener(event); }
};
class Event { constructor(type) { this.type = type; } }
class CustomEvent extends Event { constructor(type, options) { super(type); this.detail = options.detail; } }
vm.runInNewContext(fs.readFileSync('app/src/main/assets/native-bridge/diamond-native-player.js', 'utf8'), { window, Event, CustomEvent });
const player = window.NativePlayerComponent.Player();
const errors = [];
player.on('mediaerror', e => errors.push(e.target));
player.load('https://authorized.example/signed?token=private', 'flac', 'protected-token');
assert.equal(errors.length, 1);
assert(!JSON.stringify(errors).includes('private'));
assert(!JSON.stringify(errors).includes('protected-token'));
const messages = [];
player.load('diamond-fixture://pcm24', 'wav');
const port = { postMessage(message) { messages.push(JSON.parse(message)); }, close() {}, start() {} };
window.dispatchEvent({ type: 'message', data: 'diamond-native-port-v1', ports: [port] });
assert.equal(messages.length, 1);
assert.equal(messages[0].method, 'load');
assert.equal(messages[0].args[0], 'diamond-fixture://pcm24');
let duration = 0;
const handler = e => duration = e.target;
player.addEventListener('mediaduration', handler);
port.onmessage({ data: JSON.stringify({ event: 'mediaduration', target: 3 }) });
assert.equal(duration, 3);
player.removeEventListener('mediaduration', handler);
port.onmessage({ data: JSON.stringify({ event: 'mediaduration', target: 6 }) });
assert.equal(duration, 3);
player.seek(1.25);
assert.equal(messages.at(-1).args[0], 1.25);
player.preload();
assert.equal(errors.length, 2);
console.log('Native SDK bridge contract: PASS (origin-bound port host, unchanged control units, protected-token rejection, event unsubscribe)');
