// Controlled transport/structural proof using the app-owned bundled audio fixture.
// Run from the repository: node app/src/test/js/diamond-mse-probe.test.cjs
// This does not measure a TIDAL session, Android decoder or DAC.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const install = require('../../main/assets/native-bridge/diamond-mse-probe.js');
const fixture = fs.readFileSync(require('node:path').join(__dirname, '../../main/assets/native-bridge/clear-flac-fixture.mp4'));
const clone = b => new Uint8Array(b).slice();
function environment(acknowledge = true) {
  const events = new Map(), messages = [], stored = [];
  class SourceBuffer {
    constructor() {this.mode='segments';this.timestampOffset=0;this.appendWindowStart=0;this.appendWindowEnd=Infinity;this.events=new Map();}
    appendBuffer() {if(this.reject)throw new Error('browser rejected');} remove() {} abort() {} changeType() {}
    addEventListener(name,fn){this.events.set(name,fn);}
  }
  class MediaSource {addSourceBuffer(){return new SourceBuffer();}removeSourceBuffer(){}endOfStream(){}addEventListener(){}}
  class HTMLMediaElement {setMediaKeys(){return Promise.resolve();}play(){}pause(){}load(){}}
  let urlSerial=0;
  const w={SourceBuffer,MediaSource,HTMLMediaElement,crypto:crypto.webcrypto,setTimeout,clearTimeout,URL:{createObjectURL:()=>`blob:test-${++urlSerial}`,revokeObjectURL(){}},
    btoa:s=>Buffer.from(s,'binary').toString('base64'), document:{addEventListener:(name,fn)=>events.set(name,fn)}};
  w.DiamondMseBridge={postMessage(raw){const m=JSON.parse(raw);messages.push(m);
    if(m.type==='chunk') {
      const b=Buffer.from(m.data,'base64');
      assert.equal(b.length<=48*1024,true);assert.equal(m.sequence,stored.length);
      assert.equal(m.offset,stored.reduce((n,x)=>n+x.length,0));
      assert.equal(m.sha256,crypto.createHash('sha256').update(b).digest('hex'));stored.push(b);
      if(acknowledge)queueMicrotask(()=>w.__diamondMseProbe.receiveNative({type:'ack',streamId:m.streamId,sequence:m.sequence}));
    }
  }};
  const api=install(w);api.arm();const ms=new w.MediaSource(),sb=ms.addSourceBuffer('audio/mp4; codecs="flac"');
  const element=new w.HTMLMediaElement();element.src=w.URL.createObjectURL(ms);element.duration=3;element.playbackRate=1;element.play();
  return {w,api,ms,sb,element,events,messages,stored};
}
async function drain(){for(let i=0;i<50;i++)await new Promise(resolve=>setTimeout(resolve,2));}
function fragmented(e,b) {for(let i=0;i<b.length;) {const n=Math.min(b.length-i,(i%139)+1);e.sb.appendBuffer(b.subarray(i,i+n));i+=n;}}
async function run() {
  let e=environment();fragmented(e,clone(fixture));e.ms.endOfStream();await drain();
  let complete=e.messages.find(m=>m.type==='complete');assert.ok(complete,JSON.stringify(e.messages));
  assert.equal(complete.metadata.bitDepth,24);assert.equal(complete.metadata.sampleRateHz,48000);assert.equal(complete.metadata.channels,2);
  assert.equal(complete.fragmentCount,3);assert.equal(complete.totalDurationUs,3000000);
  assert.equal(complete.expectedDurationUs,3000000);
  assert.deepEqual(Buffer.concat(e.stored),fixture);assert.equal(complete.byteCount,fixture.length);
  assert.equal(e.api.getState().capturing,false);
  let n=1;
  async function rejected(label,mutate,action) {
    const e=environment(),b=clone(fixture);mutate?.(b);if(action)action(e,b);else fragmented(e,b);
    await drain();assert.ok(e.messages.some(m=>m.type==='abort') || !e.api.getState().armed,label);assert.ok(!e.messages.some(m=>m.type==='complete'),label);e.api.cancel();n++;
  }
  await rejected('protected sample entry',b=>b.set(Buffer.from('enca'),Buffer.from(b).indexOf('fLaC')));
  await rejected('encrypted fragment auxiliary data',b=>b.set(Buffer.from('saiz'),Buffer.from(b).indexOf('trun')));
  await rejected('seek resets full-track proof',null,(e,b)=>{fragmented(e,b);e.events.get('seeking')({});e.ms.endOfStream();});
  await rejected('source buffer removal',null,(e,b)=>{fragmented(e,b);e.sb.remove(0,0.2);e.ms.endOfStream();});
  await rejected('nonunit playback',null,(e,b)=>{fragmented(e,b);e.events.get('ratechange')({target:{playbackRate:1.01}});e.ms.endOfStream();});
  await rejected('MSE offset',null,(e,b)=>{e.sb.timestampOffset=1;fragmented(e,b);});
  await rejected('EME keys disable capture',null,(e,b)=>{fragmented(e,b);new e.w.HTMLMediaElement().setMediaKeys({});e.ms.endOfStream();assert.equal(e.api.arm(),false);});
  await rejected('encrypted event disable capture',null,(e,b)=>{fragmented(e,b);e.events.get('encrypted')({});e.ms.endOfStream();});
  await rejected('truncated last box',null,(e,b)=>{fragmented(e,b.subarray(0,b.length-1));e.ms.endOfStream();});
  await rejected('representation switch',null,(e,b)=>{fragmented(e,b);fragmented(e,b);e.ms.endOfStream();});
  await rejected('noncontiguous decode timeline',b=>{const p=Buffer.from(b).indexOf('tfdt');b[p+15]=1;});
  await rejected('box length bounded',b=>{b[0]=127;});
  await rejected('partial source with EOS',null,(e,b)=>{e.element.duration=4;fragmented(e,b);e.ms.endOfStream();});
  await rejected('unknown duration with EOS',null,(e,b)=>{e.element.duration=NaN;fragmented(e,b);e.ms.endOfStream();});
  await rejected('unidentified media element',null,(e,b)=>{e.element.src='blob:other';fragmented(e,b);e.ms.endOfStream();});
  e=environment(false);fragmented(e,clone(fixture));await drain();
  const chunk=e.messages.find(m=>m.type==='chunk');assert.ok(chunk);e.api.receiveNative({type:'ack',streamId:chunk.streamId,sequence:999});
  assert.ok(e.messages.some(m=>m.type==='abort'));e.api.cancel();n++;
  e=environment();e.sb.reject=true;
  assert.throws(()=>e.sb.appendBuffer(fixture));assert.ok(!e.messages.some(m=>m.type==='start'));e.api.cancel();n++;
  const result={passed:n,fixtureBytes:fixture.length,fixtureSha256:crypto.createHash('sha256').update(fixture).digest('hex'),
    assertions:['arbitrary append boundaries','ordered bounded chunk SHA-256 equality','byte-identical complete spool',
      'FLAC precision metadata','3-second contiguous timeline','reject protected/EME/seek/removal/rate/offset/truncation/switch/invalid ACK'],
    limitations:['mock MSE transport; fixture audio generated locally','no authorized TIDAL session','no Android decoder or DAC measurement']};
  console.log(JSON.stringify(result,null,2));
}
run().catch(error=>{console.error(error);process.exitCode=1;});
