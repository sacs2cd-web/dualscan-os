package com.dualscan.music.player

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

class AuthorizedStreamBufferTest {
    @Test fun copiesExactBytesAndDigestAcrossShortReads() {
        val inputBytes = ByteArray(200_011) { (it * 31 + 7).toByte() }
        val input = object : ByteArrayInputStream(inputBytes) {
            override fun read(buffer: ByteArray, offset: Int, length: Int): Int = super.read(buffer, offset, minOf(17, length))
        }
        val output = ByteArrayOutputStream()
        val result = copyAuthorizedBytes(input, output, inputBytes.size.toLong(), inputBytes.size.toLong(), { false }, { _, _ -> })
        assertArrayEquals(inputBytes, output.toByteArray())
        assertEquals(inputBytes.size.toLong(), result.first)
        assertEquals(MessageDigest.getInstance("SHA-256").digest(inputBytes).joinToString("") { "%02x".format(it) }, result.second)
    }

    @Test fun rejectsOverflowTruncationAndCancellation() {
        fun rejected(max: Long, expected: Long?, cancel: Boolean): Boolean = runCatching {
            copyAuthorizedBytes(ByteArrayInputStream(ByteArray(9)), ByteArrayOutputStream(), max, expected, { cancel }, { _, _ -> })
        }.isFailure
        assertTrue(rejected(8, null, false))
        assertTrue(rejected(10, 10, false))
        assertTrue(rejected(10, null, true))
    }

    @Test fun rejectsInsecureAndAdaptiveAddressesWithoutLeakingThem() {
        listOf("http://example.test/private?secret=one", "https://user:private@example.test/a", "https://example.test/a.mpd", "https://example.test/a.m3u8").forEach {
            val failure = runCatching { parseProgressiveHttps(it) }.exceptionOrNull()
            assertNotNull(failure)
            assertFalse(failure?.message.orEmpty().contains("private"))
        }
        assertEquals("example.test", parseProgressiveHttps("https://example.test/audio?token=private").host)
    }
}
