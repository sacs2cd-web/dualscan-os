package com.dualscan.music.player

import android.media.AudioFormat
import org.junit.Assert.*
import org.junit.Test

class NativeFormatPolicyTest {
    @Test fun websiteQualityNamesNeverInventSampleFormats() {
        listOf("MAX", "HIGH", "LOSSLESS", "HI-RES", "", "Maximum Love").forEach {
            assertEquals("FORMAT UNKNOWN", ReportedSourceQuality.label(it))
        }
    }

    @Test fun missingWebsiteFieldsRemainUnknown() {
        assertEquals("24-BIT / ? KHZ", ReportedSourceQuality.label("24-bit"))
        assertEquals("?-BIT / 96 KHZ", ReportedSourceQuality.label("96 kHz"))
        assertEquals("16-BIT / 44.1 KHZ", ReportedSourceQuality.label("16-bit 44100 Hz"))
        assertEquals("24-BIT / 192 KHZ", ReportedSourceQuality.label("24 BIT / 192 kHz"))
    }

    @Test fun exactMixerEligibilityRequiresEncodingRateAndLayout() {
        val format = PcmFormat(96000, 2, AudioFormat.ENCODING_PCM_24BIT_PACKED, AudioFormat.CHANNEL_OUT_STEREO)
        assertTrue(mixerFormatMatches(format, format.encoding, 96000, format.channelMask))
        assertFalse(mixerFormatMatches(format, AudioFormat.ENCODING_PCM_16BIT, 96000, format.channelMask))
        assertFalse(mixerFormatMatches(format, format.encoding, 48000, format.channelMask))
        assertFalse(mixerFormatMatches(format, format.encoding, 96000, AudioFormat.CHANNEL_OUT_MONO))
    }

    @Test fun explicitOutputRejectsMissingDifferentAndDuplicatedSpeakerRoutes() {
        assertTrue(selectedOutputMatches(listOf(9), 9))
        assertFalse(selectedOutputMatches(emptyList(), 9))
        assertFalse(selectedOutputMatches(listOf(3), 9))
        assertFalse(selectedOutputMatches(listOf(9, 3), 9))
    }

    @Test fun strictPolicyRejectsDecoderTruncationUnknownPrecisionFloatAndFormatChanges() {
        val info = NativeTrackInfo("track", "FLAC", 24, 96000, 2, 1_000_000, true)
        val exact = PcmFormat(96000, 2, AudioFormat.ENCODING_PCM_24BIT_PACKED, AudioFormat.CHANNEL_OUT_STEREO)
        assertNull(strictPrecisionFailure(info, exact))
        assertNotNull(strictPrecisionFailure(info, exact.copy(encoding = AudioFormat.ENCODING_PCM_16BIT)))
        assertNotNull(strictPrecisionFailure(info.copy(precisionKnown = false), exact))
        assertNotNull(strictPrecisionFailure(info.copy(sourceBitDepth = null), exact))
        assertNotNull(strictPrecisionFailure(info, exact.copy(encoding = AudioFormat.ENCODING_PCM_FLOAT)))
        assertNotNull(strictPrecisionFailure(info, exact.copy(sampleRateHz = 48000)))
        assertNotNull(strictPrecisionFailure(info, exact.copy(channelCount = 1, channelMask = AudioFormat.CHANNEL_OUT_MONO)))
    }

    @Test fun flacPrecisionIsReadIndependentlyFromStreaminfo() {
        val bytes = ByteArray(42)
        "fLaC".toByteArray().copyInto(bytes)
        bytes[4] = 0x80.toByte(); bytes[7] = 34
        val packed = (192000L shl 44) or (1L shl 41) or (23L shl 36) or 192000L
        for (index in 0..7) bytes[18 + index] = (packed ushr (56 - index * 8)).toByte()
        assertEquals(FlacStreamInfo(192000, 2, 24), parseFlacStreamInfo(bytes))
        bytes[7] = 33
        assertNull(parseFlacStreamInfo(bytes))
        assertNull(parseFlacStreamInfo(ByteArray(10)))
        assertNull(parseFlacStreamInfo(ByteArray(42)))
    }

    @Test fun knownSourcePrecisionAndDecoderPreservationAreSeparateFacts() {
        val source = NativeTrackInfo("track", "FLAC", 32, 96000, 2, 1_000_000, true,
            "Framework compressed 32-bit preservation is unverified")
        val output = PcmFormat(96000, 2, AudioFormat.ENCODING_PCM_32BIT, AudioFormat.CHANNEL_OUT_STEREO)
        assertTrue(source.precisionKnown)
        assertEquals(32, source.sourceBitDepth)
        assertNotNull(strictPrecisionFailure(source, output))
        assertNull(strictPrecisionFailure(source.copy(sourceDescription = "WAVE", decoderPreservationFailure = null), output))
        val padded24 = source.copy(sourceBitDepth = 24, decoderPreservationFailure = "Underlying decoder produced only 16 bits")
        assertNotNull(strictPrecisionFailure(padded24, output.copy(encoding = AudioFormat.ENCODING_PCM_24BIT_PACKED)))
    }
}
