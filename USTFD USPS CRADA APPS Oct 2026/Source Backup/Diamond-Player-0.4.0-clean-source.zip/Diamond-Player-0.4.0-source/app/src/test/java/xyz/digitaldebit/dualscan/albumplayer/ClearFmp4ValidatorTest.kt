package com.dualscan.music.player

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ClearFmp4ValidatorTest {
    private fun fixture() = File("src/main/assets/native-bridge/clear-flac-fixture.mp4").takeIf { it.isFile }
        ?: File("app/src/main/assets/native-bridge/clear-flac-fixture.mp4")

    @Test fun independentlyReadsActualClearFlacContainerAndCompleteTimeline() {
        val result = validateClearFlacFmp4(fixture())
        assertEquals(48_000, result.sampleRateHz)
        assertEquals(2, result.channels)
        assertEquals(24, result.bitDepth)
        assertEquals(3_000_000L, result.durationUs)
        assertEquals(3, result.fragmentCount)
        assertEquals(fixture().length(), result.byteCount)
    }

    @Test fun rejectsEncryptedSampleEntryAndIncompleteData() {
        val original = fixture().readBytes()
        val protectedEntry = original.clone()
        val entry = find(protectedEntry, "fLaC")
        "enca".toByteArray().copyInto(protectedEntry, entry)
        assertRejected(protectedEntry)
        assertRejected(original.copyOf(original.size - 1))
    }

    @Test fun rejectsChangedTimelineMissingDataAndUnknownInitStructure() {
        val original = fixture().readBytes()
        val gap = original.clone()
        val first = find(gap, "tfdt")
        gap[first + 15] = 1 // tfdt version 1 decode time is an unsigned 64-bit integer.
        assertRejected(gap)
        val protectedMetadata = original.clone()
        "pssh".toByteArray().copyInto(protectedMetadata, find(protectedMetadata, "dfLa"))
        assertRejected(protectedMetadata)
        val wrongDataSize = original.clone()
        val mdat = find(wrongDataSize, "mdat")
        wrongDataSize[mdat - 1] = (wrongDataSize[mdat - 1].toInt() xor 1).toByte()
        assertRejected(wrongDataSize)
    }

    private fun assertRejected(bytes: ByteArray) {
        val file = File.createTempFile("mse-validator-test", ".mp4")
        try { file.writeBytes(bytes); assertTrue(runCatching { validateClearFlacFmp4(file) }.isFailure) }
        finally { file.delete() }
    }
    private fun find(bytes: ByteArray, text: String): Int {
        val needle = text.toByteArray()
        return bytes.indices.first { index -> index + needle.size <= bytes.size && needle.indices.all { bytes[index + it] == needle[it] } }
    }
}
