package com.dualscan.music.player

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Float24PcmPackingTest {
    @Test
    fun preservesEverySigned24BoundaryAndLeastSignificantBits() {
        val integers = intArrayOf(-8_388_608, -8_388_607, -65_537, -257, -256, -255, -1,
            0, 1, 255, 256, 257, 65_537, 8_388_606, 8_388_607)
        val source = floatBuffer(integers)
        val output = ByteBuffer.allocate(integers.size * 3)
        assertEquals(integers.size * 3, packFloat32ToPcm24(source, output, 1))
        assertArrayEquals(packed(integers), output.array())
        assertEquals(source.limit(), source.position())
        assertEquals(output.limit(), output.position())
    }

    @Test
    fun preservesManyIndependentSigned24SamplesExactly() {
        var seed = 0x31415926
        val integers = IntArray(30_000) {
            seed = seed * 1_664_525 + 1_013_904_223
            seed shr 8
        }
        val source = floatBuffer(integers)
        val output = ByteBuffer.allocate(integers.size * 3)
        assertEquals(output.capacity(), packFloat32ToPcm24(source, output, 2))
        assertArrayEquals(packed(integers), output.array())
    }

    @Test
    fun stereoChannelsStayInterleavedAndByteBufferOrdersAreIgnored() {
        val integers = intArrayOf(0x123456, -0x123456, 1, -1, -8_388_608, 8_388_607)
        val inputBytes = floatBuffer(integers)
        val source = ByteBuffer.allocate(inputBytes.remaining() + 11).order(ByteOrder.BIG_ENDIAN)
        source.position(5)
        source.put(inputBytes)
        source.limit(source.position())
        source.position(5)
        val output = ByteBuffer.allocate(25).order(ByteOrder.BIG_ENDIAN)
        output.put(byteArrayOf(0x41, 0x42, 0x43))
        output.limit(21)
        assertEquals(18, packFloat32ToPcm24(source, output, 2))
        assertEquals(29, source.position())
        assertEquals(21, output.position())
        assertEquals(29, source.limit())
        assertEquals(21, output.limit())
        assertEquals(ByteOrder.BIG_ENDIAN, source.order())
        assertEquals(ByteOrder.BIG_ENDIAN, output.order())
        assertArrayEquals(byteArrayOf(0x41, 0x42, 0x43) + packed(integers), output.array().copyOf(21))
    }

    @Test
    fun targetCapacitySelectsOnlyCompleteFramesAndCanResume() {
        val integers = intArrayOf(1, -1, 2, -2, 3, -3)
        val source = floatBuffer(integers)
        val output = ByteBuffer.allocate(11)
        assertEquals(6, packFloat32ToPcm24(source, output, 2))
        assertEquals(8, source.position())
        assertEquals(6, output.position())
        assertEquals(0, packFloat32ToPcm24(source, output, 2))
        assertEquals(8, source.position())
        assertEquals(6, output.position())
        assertArrayEquals(packed(integers.copyOfRange(0, 2)), output.array().copyOf(6))
        val rest = ByteBuffer.allocate(13)
        assertEquals(12, packFloat32ToPcm24(source, rest, 2))
        assertArrayEquals(packed(integers.copyOfRange(2, 6)), rest.array().copyOf(12))
        assertEquals(source.limit(), source.position())
        assertEquals(0, packFloat32ToPcm24(source, rest, 2))
    }

    @Test
    fun sourceAndTargetMayBeDirectSlicesWithIndependentPositions() {
        val integers = intArrayOf(0x010203, -0x010203, 1, -1)
        val source = ByteBuffer.allocateDirect(32).apply {
            position(4)
            put(floatBuffer(integers))
            limit(position())
            position(4)
        }.slice().order(ByteOrder.BIG_ENDIAN)
        val backing = ByteBuffer.allocateDirect(20).apply { position(3); limit(17) }
        val output = backing.slice().order(ByteOrder.BIG_ENDIAN)
        assertEquals(12, packFloat32ToPcm24(source, output, 2))
        output.flip()
        val bytes = ByteArray(output.remaining()).also(output::get)
        assertArrayEquals(packed(integers), bytes)
        assertEquals(3, backing.position())
    }

    @Test
    fun positiveAndNegativeZeroBothPackToIntegerZero() {
        val source = ByteBuffer.allocate(8).order(ByteOrder.nativeOrder())
            .putFloat(0.0f).putFloat(-0.0f).apply { flip() }
        val output = ByteBuffer.allocate(6)
        assertEquals(6, packFloat32ToPcm24(source, output, 2))
        assertArrayEquals(ByteArray(6), output.array())
    }

    @Test
    fun rejectsNonFiniteOutOfRangeAndOffGridSamplesWithoutAdvancingPositions() {
        val invalid = floatArrayOf(Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY,
            1.0f, -1.0000001f, 1.0000001f, 1.0f / 16_777_216.0f,
            -1.0f / 16_777_216.0f, Float.MIN_VALUE)
        invalid.forEach { bad ->
            val source = ByteBuffer.allocate(12).order(ByteOrder.nativeOrder())
                .putInt(0).putFloat(1.0f / 8_388_608.0f).putFloat(bad)
                .apply { position(4) }
            val output = ByteBuffer.allocate(9).apply { position(3) }
            assertThrows("invalid sample $bad", IOException::class.java) {
                packFloat32ToPcm24(source, output, 2)
            }
            assertEquals(4, source.position())
            assertEquals(3, output.position())
        }
    }

    @Test
    fun partialSourceFramesAreRejectedEvenIfTheTargetHasNoSpace() {
        for (size in listOf(1, 4, 7, 9)) {
            val source = ByteBuffer.allocate(size)
            val output = ByteBuffer.allocate(0)
            assertThrows(IllegalArgumentException::class.java) { packFloat32ToPcm24(source, output, 2) }
            assertEquals(0, source.position())
        }
        assertThrows(IllegalArgumentException::class.java) {
            packFloat32ToPcm24(ByteBuffer.allocate(0), ByteBuffer.allocate(0), 0)
        }
        assertThrows(IllegalArgumentException::class.java) {
            packFloat32ToPcm24(ByteBuffer.allocate(0), ByteBuffer.allocate(0), 25)
        }
    }

    private fun floatBuffer(integers: IntArray): ByteBuffer =
        ByteBuffer.allocate(integers.size * 4).order(ByteOrder.nativeOrder()).apply {
            integers.forEach { putFloat((it.toDouble() / 8_388_608.0).toFloat()) }
            flip()
        }

    private fun packed(integers: IntArray): ByteArray = ByteArray(integers.size * 3).apply {
        integers.forEachIndexed { index, sample ->
            this[index * 3] = sample.toByte()
            this[index * 3 + 1] = (sample shr 8).toByte()
            this[index * 3 + 2] = (sample shr 16).toByte()
        }
    }
}
