package com.dualscan.music.player

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WavPcmSourceTest {
    @Test
    fun integer16Packed24And32ArePreservedByteForByte() {
        for (bits in listOf(16, 24, 32)) {
            val frameSize = 2 * bits / 8
            // Includes zero, negative/high-bit samples, and every octet value across variants.
            val pcm = ByteArray(frameSize * 257) { ((it * 73 + it / 7) and 0xff).toByte() }
            WavePcmReader.fromBytes(wave(format(bits), pcm)).use { reader ->
                assertEquals(bits, reader.header.containerBits)
                assertEquals(bits, reader.header.validBits)
                assertEquals(48_000, reader.header.sampleRateHz)
                assertEquals(2, reader.header.channelCount)
                assertEquals(frameSize, reader.header.bytesPerFrame)
                val actual = ByteArrayOutputStream()
                while (true) {
                    val buffer = ByteBuffer.allocate(frameSize * 7 + 5).order(ByteOrder.BIG_ENDIAN)
                    buffer.put(0x55.toByte()).put(0x66.toByte()).put(0x77.toByte())
                    val start = buffer.position()
                    val read = reader.read(buffer)
                    if (read == -1) break
                    assertTrue(read > 0 && read % frameSize == 0)
                    assertEquals(start + read, buffer.position())
                    assertEquals(0x55.toByte(), buffer.get(0))
                    assertEquals(0x66.toByte(), buffer.get(1))
                    assertEquals(0x77.toByte(), buffer.get(2))
                    actual.write(buffer.array(), start, read)
                }
                assertArrayEquals("$bits-bit PCM changed", pcm, actual.toByteArray())
                assertEquals(-1, reader.read(ByteBuffer.allocate(frameSize)))
            }
        }
    }

    @Test
    fun arbitraryChunksOddPaddingAndDataBeforeFormatAreHandled() {
        val pcm = byteArrayOf(0x80.toByte(), 0x12, 0x34) // one packed 24-bit mono frame
        val bytes = riff(
            chunk("JUNK", byteArrayOf(7, 8, 9), pad = 0x7f),
            chunk("data", pcm, pad = 0x33),
            chunk("LIST", ByteArray(31) { it.toByte() }),
            chunk("fmt ", format(24, channels = 1)),
            chunk("abcd", byteArrayOf())
        )
        WavePcmReader.fromBytes(bytes).use {
            assertEquals(1L, it.header.totalFrames)
            assertArrayEquals(pcm, readAll(it))
        }
    }

    @Test
    fun extensiblePcmMapsLayoutWithoutReorderingChannels() {
        // Front L/R/C, LFE, back L/R, side L/R in standard interleaved order.
        val pcm = ByteArray(8 * 4 * 5) { (it * 17).toByte() }
        WavePcmReader.fromBytes(wave(format(32, channels = 8, mask = 0x63f), pcm)).use {
            assertEquals(0x18fc, it.header.androidChannelMask)
            assertEquals(8, it.header.channelCount)
            assertEquals(32, it.header.validBits)
            assertArrayEquals(pcm, readAll(it))
        }
    }

    @Test
    fun reducedExtensiblePrecisionIsReportedWithoutChangingContainers() {
        val pcm = byteArrayOf(0, 0x23, 0x45, 0x67, 0, 0x89.toByte(), 0xab.toByte(), 0xcd.toByte())
        WavePcmReader.fromBytes(wave(format(32, validBits = 24, mask = 3), pcm)).use {
            assertEquals(32, it.header.containerBits)
            assertEquals(24, it.header.validBits)
            assertArrayEquals(pcm, readAll(it))
        }
    }

    @Test
    fun seekingIsFrameAlignedClampedAndIndependentOfReadBufferOrder() {
        val pcm = ByteArray(100 * 6) { it.toByte() }
        WavePcmReader.fromBytes(wave(format(24, rate = 44_100), pcm)).use {
            assertEquals(2_267L, it.header.durationUs)
            assertEquals(1_496L, it.seekTo(1_501L)) // floor(1501 * 44100 / 1e6) = 66 frames
            val target = ByteBuffer.allocate(7).order(ByteOrder.BIG_ENDIAN)
            assertEquals(6, it.read(target))
            assertArrayEquals(pcm.copyOfRange(66 * 6, 67 * 6), target.array().copyOf(6))
            assertEquals(0L, it.seekTo(-1L))
            assertEquals(0L, it.seekTo(1L))
            assertEquals(2_267L, it.seekTo(Long.MAX_VALUE))
            assertEquals(-1, it.read(ByteBuffer.allocate(6)))
            assertEquals(2_267L, it.seekTo(it.header.durationUs))
            assertEquals(0L, it.seekTo(0L))
            assertArrayEquals(pcm, readAll(it))
        }
    }

    @Test
    fun tooSmallTargetDoesNotConsumeAnyPartOfAFrame() {
        val pcm = ByteArray(12) { (it + 1).toByte() }
        WavePcmReader.fromBytes(wave(format(24), pcm)).use {
            val small = ByteBuffer.allocate(5)
            assertEquals(0, it.read(small))
            assertEquals(0, small.position())
            assertArrayEquals(pcm, readAll(it))
        }
    }

    @Test
    fun fileAssetOffsetsAndDeclaredLengthsExcludeEnclosingBytes() {
        val pcm = ByteArray(48) { (it * 3).toByte() }
        val bytes = wave(format(16), pcm)
        val file = File.createTempFile("wave-asset-offset", ".bin")
        try {
            file.writeBytes(ByteArray(37) { 0x55.toByte() } + bytes + ByteArray(61) { 0x77.toByte() })
            WavePcmReader.fromFile(file, 37, bytes.size.toLong()).use {
                assertArrayEquals(pcm, readAll(it))
                assertEquals(0L, it.seekTo(0L))
                assertArrayEquals(pcm, readAll(it))
            }
            assertThrows(EOFException::class.java) {
                WavePcmReader.fromFile(file, 37, bytes.size.toLong() - 1)
            }
        } finally {
            assertTrue(file.delete())
        }
    }

    @Test
    fun nonSeekableShortReadingStreamsReopenForSeekWithoutLoadingWholeTrack() {
        val pcm = ByteArray(6 * 101) { (it * 37).toByte() }
        val bytes = riff(chunk("fmt ", format(24)), chunk("JUNK", ByteArray(5)), chunk("data", pcm))
        var opens = 0
        var closes = 0
        val reader = WavePcmReader.fromStream {
            opens++
            object : ByteArrayInputStream(bytes) {
                override fun skip(n: Long): Long = 0L
                override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, minOf(len, 3))
                override fun close() { closes++ }
            }
        }
        assertArrayEquals(pcm, readAll(reader))
        assertEquals(0L, reader.seekTo(0L))
        assertArrayEquals(pcm, readAll(reader))
        reader.close()
        reader.close()
        assertTrue(opens >= 3)
        assertEquals(opens, closes)
        assertThrows(IllegalStateException::class.java) { reader.seekTo(0L) }
        assertThrows(IllegalStateException::class.java) { reader.read(ByteBuffer.allocate(6)) }
    }

    @Test
    fun incompleteHeadersDataFramesAndChunkBoundsAreRejected() {
        val good = wave(format(16), ByteArray(16))
        for (length in 0 until good.size) {
            assertThrows("truncated length $length", IOException::class.java) {
                WavePcmReader.fromBytes(good.copyOf(length))
            }
        }
        val badMagic = good.copyOf().apply { this[0] = 'X'.code.toByte() }
        assertRejected(badMagic)
        assertRejected(riff(chunk("data", ByteArray(4))))
        assertRejected(riff(chunk("fmt ", format(16))))
        assertRejected(wave(format(24), ByteArray(5)))
        assertRejected(riff(chunk("fmt ", format(16)), chunk("fmt ", format(16)), chunk("data", ByteArray(4))))
        assertRejected(riff(chunk("fmt ", format(16)), chunk("data", ByteArray(4)), chunk("data", ByteArray(4))))
        assertRejected(good.copyOf().apply { putU32(40, 0xfffffff0L) })
        assertRejected(riff(chunk("fmt ", format(16)), byteArrayOf(1, 2, 3)))
        val missingPadding = riff(chunk("fmt ", format(24, channels = 1)), chunk("data", byteArrayOf(1, 2, 3))).dropLast(1).toByteArray()
        missingPadding.putU32(4, missingPadding.size.toLong() - 8)
        assertRejected(missingPadding)
    }

    @Test
    fun malformedAndUnsupportedFormatsAreRejectedClearly() {
        val invalidFormats = listOf(
            format(16).apply { putU16(2, 0) },
            format(16).apply { putU32(4, 0) },
            format(16).apply { putU32(4, 0xffffffffL) },
            format(16).apply { putU16(12, 2) },
            format(16).apply { putU32(8, 1) },
            format(16).apply { putU16(14, 8) },
            format(16).apply { putU16(0, 3) },
            format(24, channels = 3),
            format(24, mask = 0),
            format(24, mask = 1),
            format(24, mask = 0x80000001L),
            format(24, mask = 3, validBits = 25),
            format(24, mask = 3, validBits = 0),
            format(24, mask = 3).apply { this[24] = 3 },
            format(24, mask = 3).apply { putU16(16, 21) },
            format(24, mask = 3).apply { putU16(16, 65535) },
            format(24, mask = 3).copyOf(39),
            format(16).copyOf(15),
            format(16).copyOf(17)
        )
        invalidFormats.forEachIndexed { index, fmt ->
            val failure = assertThrows("invalid format $index", IOException::class.java) {
                WavePcmReader.fromBytes(wave(fmt, ByteArray(24)))
            }
            assertFalse(failure.message.isNullOrBlank())
        }
    }

    @Test
    fun enormousUnsignedSizesAreBoundedAndDoNotAllocateChunkBodies() {
        val bytes = riff(chunk("fmt ", format(16)), chunk("data", ByteArray(4)))
        bytes.putU32(4, 0xffffffffL)
        assertRejected(bytes)
        val bytes2 = riff(chunk("fmt ", format(16)), chunk("data", ByteArray(4)))
        bytes2.putU32(40, 0xffffffffL)
        assertRejected(bytes2)
        // An unknown-length stream still verifies payload existence instead of trusting skip().
        assertThrows(EOFException::class.java) {
            WavePcmReader.fromStream { ByteArrayInputStream(bytes2) }
        }
    }

    @Test
    fun unsignedFourGiBContainerCanBeParsedAndSeekedWithConstantMemory() {
        val dataSize = 0xffff_ffc0L
        val prefix = wave(format(32), byteArrayOf()).apply {
            putU32(4, dataSize + 36L)
            putU32(40, dataSize)
        }
        var largestRead = 0
        WavePcmReader(object : WaveByteAccess {
            override val length = dataSize + prefix.size
            override fun readAt(offset: Long, target: ByteBuffer): Int {
                if (offset >= length) return -1
                val count = minOf(target.remaining().toLong(), length - offset).toInt()
                largestRead = maxOf(largestRead, count)
                repeat(count) { index ->
                    val position = offset + index
                    target.put(if (position < prefix.size) prefix[position.toInt()] else (position and 0xff).toByte())
                }
                return count
            }
            override fun close() = Unit
        }).use {
            assertEquals(dataSize / 8, it.header.totalFrames)
            assertTrue(it.header.dataSize > Int.MAX_VALUE)
            val seekUs = it.header.durationUs - 100L
            val actualUs = it.seekTo(seekUs)
            val frame = seekUs / 1_000_000L * 48_000L + seekUs % 1_000_000L * 48_000L / 1_000_000L
            assertEquals(frame / 48_000L * 1_000_000L + frame % 48_000L * 1_000_000L / 48_000L, actualUs)
            val target = ByteBuffer.allocate(8)
            assertEquals(8, it.read(target))
            assertArrayEquals(ByteArray(8) { index -> ((44L + frame * 8L + index) and 0xff).toByte() }, target.array())
            assertTrue(largestRead <= 40)
        }
    }

    @Test
    fun parseFailureClosesInputAndLiveTruncationDoesNotExposePartialFrames() {
        var closed = false
        assertThrows(IOException::class.java) {
            WavePcmReader.fromStream {
                object : ByteArrayInputStream(ByteArray(4)) {
                    override fun close() { closed = true }
                }
            }
        }
        assertTrue(closed)
        val bytes = wave(format(24), ByteArray(12) { it.toByte() })
        var truncated = false
        WavePcmReader(object : WaveByteAccess {
            override val length = bytes.size.toLong()
            override fun readAt(offset: Long, target: ByteBuffer): Int {
                val end = if (truncated) bytes.size - 1 else bytes.size
                if (offset >= end) return -1
                val count = minOf(target.remaining().toLong(), end - offset).toInt()
                target.put(bytes, offset.toInt(), count)
                return count
            }
            override fun close() = Unit
        }).use {
            truncated = true
            val output = ByteBuffer.allocate(13).apply { position(1) }
            assertThrows(EOFException::class.java) { it.read(output) }
            assertEquals(1, output.position())
        }
    }

    @Test
    fun emptyPcmAndTrailingBytesOutsideRiffAreHandled() {
        WavePcmReader.fromBytes(wave(format(16), byteArrayOf()) + byteArrayOf(1, 2, 3)).use {
            assertEquals(0L, it.header.durationUs)
            assertEquals(0L, it.seekTo(Long.MAX_VALUE))
            assertEquals(-1, it.read(ByteBuffer.allocate(4)))
        }
    }

    private fun assertRejected(bytes: ByteArray) {
        assertThrows(IOException::class.java) { WavePcmReader.fromBytes(bytes) }
    }

    private fun readAll(reader: WavePcmReader): ByteArray {
        val bytes = ByteArrayOutputStream()
        val buffer = ByteBuffer.allocate(reader.header.bytesPerFrame * 11 + 1)
        while (true) {
            buffer.clear()
            val count = reader.read(buffer)
            if (count < 0) return bytes.toByteArray()
            assertTrue(count > 0)
            bytes.write(buffer.array(), 0, count)
        }
    }

    private fun format(
        bits: Int,
        channels: Int = 2,
        rate: Int = 48_000,
        mask: Long? = null,
        validBits: Int = bits
    ): ByteArray {
        val bytes = ByteArray(if (mask == null) 16 else 40)
        bytes.putU16(0, if (mask == null) 1 else 0xfffe)
        bytes.putU16(2, channels)
        bytes.putU32(4, rate.toLong())
        bytes.putU32(8, rate.toLong() * channels * bits / 8)
        bytes.putU16(12, channels * bits / 8)
        bytes.putU16(14, bits)
        if (mask != null) {
            bytes.putU16(16, 22)
            bytes.putU16(18, validBits)
            bytes.putU32(20, mask)
            val guid = byteArrayOf(1, 0, 0, 0, 0, 0, 0x10, 0, 0x80.toByte(), 0, 0, 0xaa.toByte(), 0, 0x38, 0x9b.toByte(), 0x71)
            guid.copyInto(bytes, 24)
        }
        return bytes
    }

    private fun wave(format: ByteArray, pcm: ByteArray): ByteArray =
        riff(chunk("fmt ", format), chunk("data", pcm))

    private fun riff(vararg chunks: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray(Charsets.US_ASCII))
        out.write(ByteArray(4).apply { putU32(0, 4L + chunks.sumOf { it.size.toLong() }) })
        out.write("WAVE".toByteArray(Charsets.US_ASCII))
        chunks.forEach(out::write)
        return out.toByteArray()
    }

    private fun chunk(id: String, body: ByteArray, pad: Int = 0): ByteArray =
        id.toByteArray(Charsets.US_ASCII) + ByteArray(4).apply { putU32(0, body.size.toLong()) } +
            body + if (body.size % 2 == 1) byteArrayOf(pad.toByte()) else byteArrayOf()

    private fun ByteArray.putU16(offset: Int, value: Int) {
        this[offset] = value.toByte()
        this[offset + 1] = (value ushr 8).toByte()
    }

    private fun ByteArray.putU32(offset: Int, value: Long) {
        repeat(4) { this[offset + it] = (value ushr (8 * it)).toByte() }
    }
}
